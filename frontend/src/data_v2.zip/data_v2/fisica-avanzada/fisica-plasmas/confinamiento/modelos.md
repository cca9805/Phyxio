# confinamiento · Modelos

> (pendiente)

## Idea clave
- (pendiente)

## Desarrollo
- (pendiente)

## Resumen
- (pendiente)
