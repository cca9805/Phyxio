# corriente-alterna

> Subbloque: Corriente Alterna.

## Qué aprenderás
- (pendiente)

## Qué encontrarás aquí
- Teoría, calculadora, gráficos, ejemplos y errores típicos (según corresponda)

## Conexiones
- (pendiente)
