# circuitos-de-corriente-continua

> Bloque: Circuitos de Corriente Continua. Teoría, fórmulas, ejemplos y aplicaciones.

## Qué aprenderás
- (pendiente)

## Qué encontrarás aquí
- Teoría, calculadora, gráficos, ejemplos y errores típicos (según corresponda)

## Conexiones
- (pendiente)
