# interruptores · Errores típicos

> (pendiente)

## Idea clave
- (pendiente)

## Desarrollo
- (pendiente)

## Resumen
- (pendiente)
