﻿# Aplicaciones

- Estabilidad de estructuras y vehiculos.
- Biomecanica del movimiento.
- Analisis de choques y sistemas multiparticle.