﻿# Ejemplos

- Dos masas en una barra: localizacion del centro de masas.
- Dos patinadores: velocidad del centro de masas antes y despues del impulso interno.