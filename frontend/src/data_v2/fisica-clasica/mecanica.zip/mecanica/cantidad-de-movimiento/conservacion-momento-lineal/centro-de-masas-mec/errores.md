﻿# Errores frecuentes

- Promediar posiciones sin ponderar por masa.
- Confundir centro geometrico con centro de masas en distribuciones no uniformes.