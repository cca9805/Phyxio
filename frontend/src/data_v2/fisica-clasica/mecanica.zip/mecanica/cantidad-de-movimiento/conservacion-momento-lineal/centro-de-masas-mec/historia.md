﻿# Contexto historico

El concepto de centro de masas permite reducir sistemas complejos a una descripcion global simple, fundamental en mecanica clasica.