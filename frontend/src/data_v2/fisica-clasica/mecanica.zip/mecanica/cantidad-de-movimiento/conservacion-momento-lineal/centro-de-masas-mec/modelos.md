﻿# Modelos y alcance

- Modelo discreto: suma de masas puntuales.
- Aproximacion continua: integrales de masa para cuerpos extendidos.
- En ausencia de fuerza externa neta, el centro de masas se mueve con velocidad constante.