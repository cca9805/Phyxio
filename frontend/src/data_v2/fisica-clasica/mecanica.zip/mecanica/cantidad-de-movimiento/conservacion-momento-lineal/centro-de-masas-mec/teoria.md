﻿# Centro de masas (mecanica)

## Idea central
El centro de masas es el punto que resume la distribucion espacial de masa de un sistema. Permite describir el movimiento global de varios cuerpos como si todo el sistema estuviera concentrado en un unico punto.

Para un sistema discreto:

$$
\vec r_{cm}=\frac{\sum_i m_i\vec r_i}{\sum_i m_i}
$$

Para velocidades:

$$
\vec V_{cm}=\frac{\sum_i m_i\vec v_i}{\sum_i m_i}
$$

## Por que es util
En muchos problemas de varios cuerpos, estudiar cada particula es costoso. El centro de masas permite:
- seguir la traslacion global del sistema,
- separar movimiento global de movimiento interno,
- conectar con momento total:

$$
\vec p_{tot}=M\vec V_{cm}
$$

## Como interpretar fisicamente
- Si una masa es mayor, "tira" del centro de masas hacia su posicion.
- Si las masas son iguales, el centro queda en el punto medio.
- Si no hay fuerza externa neta, el centro de masas se mueve con velocidad constante.

## Cuando aplicar las formulas
Usa formulas de centro de masas cuando:
- hay mas de un cuerpo,
- necesitas una descripcion global del sistema,
- quieres simplificar colisiones o separaciones.

## Metodo de resolucion
1. Define eje y origen.
2. Lista masas y posiciones (o velocidades).
3. Calcula suma ponderada por masa.
4. Divide por masa total.
5. Interpreta el resultado en el contexto fisico.

## Errores frecuentes
- Promediar posiciones sin ponderar por masa.
- Confundir centro geometrico con centro de masas.
- Mezclar unidades de posicion o velocidad.

## Conexion con conservacion del momento
Cuando $\vec F_{ext}\approx 0$, el momento total se conserva y por tanto $\vec V_{cm}$ permanece constante. Esta idea explica por que el centro de masas mantiene un movimiento simple incluso cuando internamente ocurren choques complejos.