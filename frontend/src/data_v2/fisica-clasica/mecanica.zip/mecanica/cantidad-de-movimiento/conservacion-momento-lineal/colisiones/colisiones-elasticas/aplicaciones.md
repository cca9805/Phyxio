﻿# Aplicaciones

- Seguridad vial y diseno de absorcion de impactos.
- Deportes de choque y materiales protectores.
- Analisis forense de accidentes.