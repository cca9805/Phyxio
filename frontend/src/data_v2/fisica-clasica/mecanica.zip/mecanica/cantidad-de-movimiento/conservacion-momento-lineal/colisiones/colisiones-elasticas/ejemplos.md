﻿# Ejemplos

- Choque frontal 1D entre dos carros con distintas masas.
- Determinacion de velocidades finales por conservacion de momento.