﻿# Errores frecuentes

- Aplicar conservacion de energia cinetica en colisiones no elasticas.
- Perder signos en velocidades 1D.
- Elegir mal el sistema y olvidar fuerzas externas relevantes.