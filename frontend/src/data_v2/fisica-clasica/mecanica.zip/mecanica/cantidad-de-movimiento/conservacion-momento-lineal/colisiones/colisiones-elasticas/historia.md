﻿# Contexto historico

El estudio de colisiones consolidó la distincion entre conservacion de momento lineal y conservacion de energia cinetica, clave para clasificar choques reales.