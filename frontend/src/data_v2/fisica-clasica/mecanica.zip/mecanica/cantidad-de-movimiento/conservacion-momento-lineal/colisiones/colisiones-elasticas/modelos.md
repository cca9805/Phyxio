﻿# Modelos y alcance

- Modelo 1D con dos cuerpos puntuales.
- Fuerzas externas despreciables durante el choque.
- Clasificacion por conservacion (o no) de energia cinetica.