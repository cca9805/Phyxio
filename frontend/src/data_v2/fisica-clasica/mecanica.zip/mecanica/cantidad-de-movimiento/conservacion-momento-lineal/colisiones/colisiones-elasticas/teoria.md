﻿# Colisiones elasticas

## Definicion
Una colision elastica es aquella en la que se conservan simultaneamente:
- el momento lineal total,
- la energia cinetica total.

En 1D para dos cuerpos:

$$
m_1v_{1i}+m_2v_{2i}=m_1v_{1f}+m_2v_{2f}
$$

$$
\frac{1}{2}m_1v_{1i}^2+\frac{1}{2}m_2v_{2i}^2=\frac{1}{2}m_1v_{1f}^2+\frac{1}{2}m_2v_{2f}^2
$$

## Por que se conservan ambas magnitudes
- Momento: por aislamiento (impulso externo despreciable).
- Energia cinetica: por deformacion esencialmente recuperable durante el choque.

## Cuando aplicar este modelo
Aplicalo cuando el problema indique choque elastico o coeficiente de restitucion cercano a 1.

Casos tipicos: bolas de billar idealizadas, choques entre particulas en modelos simplificados.

## Metodo de resolucion (1D)
1. Fija signo de velocidades.
2. Escribe conservacion de momento.
3. Escribe conservacion de energia cinetica.
4. Resuelve el sistema para $v_{1f}, v_{2f}$.
5. Verifica unidades y sentido fisico.

## Atajo conceptual
En choque elastico frontal 1D, tambien puede usarse la relacion de velocidad relativa:

$$
v_{1i}-v_{2i}=-(v_{1f}-v_{2f})
$$

## Error frecuente
Aplicar formulas elasticas a choques donde hay perdida evidente de energia (deformacion permanente, sonido intenso, calentamiento notable).