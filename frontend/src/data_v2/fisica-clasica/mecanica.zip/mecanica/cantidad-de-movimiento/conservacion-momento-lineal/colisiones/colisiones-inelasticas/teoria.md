﻿# Colisiones inelasticas

## Definicion
En una colision inelastica se conserva el momento lineal total, pero no se conserva la energia cinetica total.

$$
m_1v_{1i}+m_2v_{2i}=m_1v_{1f}+m_2v_{2f}
$$

$$
K_f<K_i
$$

## Que ocurre con la energia
La energia cinetica "perdida" en terminos mecanicos se transforma en otras formas:
- deformacion,
- calor,
- vibracion,
- sonido.

No desaparece energia total, pero si disminuye la parte cinetica de traslacion.

## Cuando aplicar este modelo
Usalo cuando el choque no sea completamente elastico y los cuerpos no necesariamente queden unidos.

## Metodo de resolucion
1. Define sistema y signos.
2. Aplica conservacion de momento para obtener velocidades finales.
3. Calcula $K_i$ y $K_f$ para cuantificar disipacion:

$$
\Delta K=K_f-K_i<0
$$

4. Interpreta la magnitud de perdida energetica.

## Papel del coeficiente de restitucion
En muchos problemas se usa $0<e<1$ para modelar colisiones inelasticas. Cuanto menor es $e$, mayor es la disipacion.

## Error frecuente
Asumir que "inelastica" implica que siempre quedan pegados. Eso solo ocurre en la colision totalmente inelastica.