﻿# Colisiones totalmente inelasticas

## Definicion
Es el caso limite de colision inelastica: tras el choque, los cuerpos quedan unidos y se mueven con una velocidad comun final.

$$
v_{1f}=v_{2f}=v_f
$$

La conservacion de momento da:

$$
m_1v_{1i}+m_2v_{2i}=(m_1+m_2)v_f
$$

y por tanto:

$$
v_f=\frac{m_1v_{1i}+m_2v_{2i}}{m_1+m_2}
$$

## Que se conserva y que no
- Se conserva el momento lineal total.
- No se conserva la energia cinetica total (hay maxima disipacion dentro de choques con adherencia).

## Cuando usar este modelo
Cuando el enunciado indique explicitamente que los cuerpos quedan unidos, pegados o avanzan juntos despues del impacto.

## Metodo de resolucion
1. Define direccion positiva.
2. Escribe conservacion de momento.
3. Impone velocidad final comun.
4. Despeja $v_f$.
5. Si se pide energia perdida, compara $K_i$ y $K_f$.

## Lectura fisica
La velocidad final comun queda entre las velocidades iniciales, ponderada por masa. El cuerpo mas masivo influye mas en el valor final.

## Error frecuente
Usar ecuaciones de choque elastico (o dos velocidades finales independientes) cuando los cuerpos se adhieren tras el impacto.