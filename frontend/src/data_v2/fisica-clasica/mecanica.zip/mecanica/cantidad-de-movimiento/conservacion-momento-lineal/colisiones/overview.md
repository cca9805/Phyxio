﻿# Colisiones

Las colisiones son interacciones breves donde suelen dominar fuerzas internas grandes en tiempos cortos. Por eso, el momento lineal total del sistema se conserva si el sistema es aproximadamente aislado.

## Que aprenderas
- Diferenciar colisiones elasticas, inelasticas y totalmente inelasticas.
- Aplicar conservacion del momento en todos los tipos de colision.
- Reconocer cuando la energia cinetica se conserva y cuando no.

## Que encontraras aqui
- Modelos 1D para dos cuerpos con formulas operativas.
- Graficos Coord y DCL para interpretar estados iniciales y finales.
- Ejemplos comparativos entre tipos de choque.

## Conexiones
- Usa directamente impulso y momento lineal.
- Se relaciona con transferencia y disipacion de energia.