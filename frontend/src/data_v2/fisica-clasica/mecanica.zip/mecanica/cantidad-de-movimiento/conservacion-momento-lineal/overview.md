﻿# Conservacion del momento lineal

Este bloque formaliza cuando y como se conserva la cantidad de movimiento total de un sistema, y aplica ese principio a centro de masas y colisiones.

## Que aprenderas
- Aplicar la conservacion del momento lineal en sistemas con fuerza externa neta despreciable.
- Distinguir magnitudes del sistema completo frente a magnitudes de cada cuerpo.
- Usar el centro de masas como herramienta para simplificar problemas de varios cuerpos.
- Resolver colisiones elasticas, inelasticas y totalmente inelasticas.

## Que encontraras aqui
- Teoria con interpretacion fisica y formulas en notacion LaTeX.
- Graficos de coordenadas, representacion vectorial (DCL) y SVG donde corresponda.
- Ejemplos tipo, errores frecuentes y aplicaciones reales.

## Conexiones
- Continúa fundamentos de momento lineal e impulso.
- Se conecta con dinamica de sistemas y con energia mecanica en colisiones.