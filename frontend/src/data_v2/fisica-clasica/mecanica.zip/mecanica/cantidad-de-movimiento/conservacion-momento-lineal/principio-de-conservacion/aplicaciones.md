﻿# Aplicaciones

- Analisis de impactos.
- Propulsion y retroceso.
- Dinamica de sistemas multiparticle.