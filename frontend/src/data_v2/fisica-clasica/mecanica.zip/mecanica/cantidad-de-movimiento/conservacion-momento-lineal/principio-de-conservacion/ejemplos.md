﻿# Ejemplos

- Choque entre dos carros en pista de baja friccion.
- Persona que salta desde una barca y el sistema barca-persona.