﻿# Errores frecuentes

- Aplicar conservacion a un solo cuerpo en lugar del sistema.
- Ignorar fuerzas externas apreciables.