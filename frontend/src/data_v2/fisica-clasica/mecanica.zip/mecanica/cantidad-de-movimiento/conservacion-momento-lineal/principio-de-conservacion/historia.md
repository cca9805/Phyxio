﻿# Contexto historico

La conservacion del momento lineal es un principio central de la mecanica clasica con amplia validacion experimental.