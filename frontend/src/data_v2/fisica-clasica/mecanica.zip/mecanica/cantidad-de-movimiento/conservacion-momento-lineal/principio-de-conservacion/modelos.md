﻿# Modelos y alcance

- Sistema aislado ideal: conservacion exacta.
- Sistema casi aislado: conservacion aproximada en intervalos breves.
- Recomendacion: elegir como sistema todos los cuerpos que interactuan entre si.