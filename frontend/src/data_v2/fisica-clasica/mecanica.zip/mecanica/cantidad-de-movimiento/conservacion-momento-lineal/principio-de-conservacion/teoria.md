﻿# Principio de conservacion del momento lineal

## Idea fisica central
La cantidad de movimiento total de un sistema no cambia si el sistema no recibe impulso externo neto significativo durante el intervalo analizado.

Matematicamente:

$$
\vec F_{ext}\approx 0 \;\;\Longrightarrow\;\; \vec p_{tot,i}=\vec p_{tot,f}
$$

o, en forma de suma de particulas:

$$
\sum \vec p_i=\sum \vec p_f
$$

## Por que se conserva
La segunda ley en forma general dice:

$$
\vec F_{ext}=\frac{d\vec p_{tot}}{dt}
$$

Si la resultante externa es cero (o despreciable), la derivada temporal de $\vec p_{tot}$ es cero, asi que $\vec p_{tot}$ es constante.

## Cuando se puede aplicar
Se aplica con buena aproximacion cuando:
- el intervalo temporal es corto (por ejemplo, durante un choque),
- las fuerzas internas son mucho mayores que las externas en ese intervalo,
- o las fuerzas externas se compensan en direccion y modulo.

Ejemplos clasicos:
- colisiones en pista casi sin rozamiento,
- patinadores que se empujan entre si,
- separacion de cuerpos en un sistema inicialmente en reposo.

## Cuando no debes aplicarlo de forma directa
No conviene aplicarlo como ecuacion cerrada si:
- hay fuerza externa neta relevante (rozamiento fuerte, empuje continuo externo),
- el intervalo es largo y la accion externa acumulada no es despreciable,
- no has definido correctamente la frontera del sistema.

En esos casos debes incluir impulso externo:

$$
\Delta \vec p_{tot}=\vec J_{ext}
$$

## Como aplicarlo paso a paso
1. Define el sistema (que cuerpos incluyes).
2. Elige eje(s) y signo(s).
3. Verifica si $\vec F_{ext}\approx 0$ durante el evento.
4. Escribe conservacion:
   $$\sum p_{x,i}=\sum p_{x,f}$$
   y, si procede, tambien en $y$.
5. Sustituye datos y despeja la(s) incognita(s).
6. Verifica coherencia fisica (signo y orden de magnitud).

## Relacion con energia cinetica
Conservar momento no implica conservar energia cinetica.
- En colisiones elasticas: se conservan ambas.
- En inelasticas: se conserva momento, pero parte de $K$ se transforma en deformacion/calor/sonido.

## Error tipico
Aplicar conservacion de momento a un solo cuerpo cuando la ecuacion corresponde al sistema completo.