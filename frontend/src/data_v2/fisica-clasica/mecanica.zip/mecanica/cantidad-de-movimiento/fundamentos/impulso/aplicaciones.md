﻿# Aplicaciones

- Airbags y zonas de deformacion en automocion.
- Protecciones deportivas.
- Martillos, golpes y herramientas de impacto.