﻿# Ejemplos resueltos

- Fuerza de 200 N durante 0.05 s: J = 10 N·s.
- Si un cuerpo pasa de p_i=6 a p_f=14 kg·m/s, entonces J=8 N·s.
- Duplicar el tiempo de contacto (a igual J) reduce fuerza media.