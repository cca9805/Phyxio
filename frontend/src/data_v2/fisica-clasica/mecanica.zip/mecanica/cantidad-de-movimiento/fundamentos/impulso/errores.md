﻿# Errores frecuentes

- Confundir impulso con fuerza instantanea.
- Olvidar direccion/signo en problemas 1D.
- No usar SI coherente (ms vs s).