﻿# Contexto historico

El concepto de impulso formaliza como las fuerzas aplicadas en tiempo modifican el estado de movimiento y es clave en el estudio de impactos.