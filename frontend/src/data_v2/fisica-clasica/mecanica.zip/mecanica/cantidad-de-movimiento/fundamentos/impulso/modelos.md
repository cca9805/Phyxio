﻿# Modelos y alcances

- Fuerza constante: modelo escolar mas comun.
- Fuerza variable: uso de integral o fuerza media.
- Choques: impulso grande en intervalo temporal muy corto.