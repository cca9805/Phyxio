﻿# Impulso

## Definicion fisica
El impulso mide el efecto acumulado de una fuerza durante un intervalo temporal:

$$
\vec J=\int_{t_i}^{t_f}\vec F(t)\,dt
$$

Si la fuerza es aproximadamente constante:

$$
\vec J=\vec F\,\Delta t
$$

Por eso, no solo importa cuan grande es la fuerza, sino tambien cuanto tiempo actua.

## Teorema impulso-momento
El impulso neto se traduce directamente en cambio de momento lineal:

$$
\vec J=\Delta\vec p=\vec p_f-\vec p_i
$$

Esta ecuacion conecta fuerza-tiempo con cambio de velocidad y es clave para analizar choques y frenadas.

## Lectura grafica
En una grafica fuerza-tiempo, el impulso es el area bajo la curva $F(t)$:

- Area positiva: aumenta momento en el sentido positivo.
- Area negativa: reduce momento o lo invierte.

Si hay varias fases de fuerza, el impulso total es la suma algebraica de todas las areas.

## Fuerza media y tiempo de contacto
Otra forma util:

$$
\vec J=\vec F_{med}\,\Delta t
$$

Con el mismo impulso, aumentar el tiempo de contacto reduce la fuerza media. Este principio explica por que airbags, cascos, colchonetas o redes de seguridad disminuyen el pico de fuerza sobre el cuerpo.

## Unidades
- Impulso: N*s
- Equivalente: kg*m/s

Compatibilidad directa con momento lineal.

## Estrategia de resolucion en problemas
1. Define direccion positiva.
2. Calcula impulso (integral o $F\Delta t$).
3. Aplica $\vec p_f=\vec p_i+\vec J$.
4. Si hace falta, recupera velocidad con $\vec v_f=\vec p_f/m$.

## Error conceptual frecuente
Confundir impulso con fuerza instantanea. El impulso no es "fuerza grande", sino efecto acumulado de fuerza en el tiempo.