﻿# Aplicaciones

- Analisis de choques y colisiones.
- Seguridad vial (impactos y frenado).
- Deportes de contacto y transferencia de momento.