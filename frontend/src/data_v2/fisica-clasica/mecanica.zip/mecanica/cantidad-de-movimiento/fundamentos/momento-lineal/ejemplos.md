﻿# Ejemplos resueltos

- Cuerpo de 3 kg con velocidad 5 m/s: $p=15$ kg·m/s.
- Dos cuerpos con igual p pueden tener masas y velocidades distintas.
- Si un cuerpo invierte su sentido de marcha, su momento cambia de signo.