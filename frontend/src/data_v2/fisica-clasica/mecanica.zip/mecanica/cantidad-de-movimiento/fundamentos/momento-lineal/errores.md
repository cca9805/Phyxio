﻿# Errores frecuentes

- Tratar p como escalar cuando el problema es unidimensional con signos.
- Olvidar unidades de kg·m/s.
- Confundir momento lineal con energia cinetica.