﻿# Contexto historico

El concepto de cantidad de movimiento surge con la mecanica clasica y se consolida con Newton al relacionarlo con fuerza e interaccion entre cuerpos.