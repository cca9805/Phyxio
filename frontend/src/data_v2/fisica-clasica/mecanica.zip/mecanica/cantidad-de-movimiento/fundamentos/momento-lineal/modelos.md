﻿# Modelos y alcances

## Modelo basico
- Particula puntual o cuerpo tratado como punto material.
- Masa constante durante el intervalo de analisis.

## Modelo intermedio
- Sistemas de varias particulas con momento total:
  $\vec p_{tot}=\sum_i m_i\vec v_i$.

## Limites
- En regimen relativista no aplica $\vec p=m\vec v$.
- En sistemas con masa variable hay que usar forma general de $d\vec p/dt$.