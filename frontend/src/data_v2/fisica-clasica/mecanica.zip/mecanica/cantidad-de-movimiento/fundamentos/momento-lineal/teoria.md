﻿# Momento lineal

## Idea central
La cantidad de movimiento lineal (momento lineal) describe cuan "dificil" es cambiar el estado de movimiento de un cuerpo. Se define por:

$$
\vec p = m\vec v
$$

Es una magnitud vectorial, por lo que no basta con el valor numerico: tambien importa direccion y sentido.

## Interpretacion fisica
- Si dos cuerpos tienen la misma velocidad, el masivo tiene mayor momento.
- Si dos cuerpos tienen la misma masa, el mas rapido tiene mayor momento.
- Si inviertes el sentido de la velocidad, inviertes el vector momento.

En terminos practicos, un cuerpo con gran momento requiere una interaccion mayor (en fuerza, tiempo o ambos) para frenarlo o desviarlo.

## Relacion con las leyes de Newton
La forma general de la segunda ley es:

$$
\vec F_{net}=\frac{d\vec p}{dt}
$$

Si la masa es constante:

$$
\frac{d\vec p}{dt}=\frac{d(m\vec v)}{dt}=m\frac{d\vec v}{dt}=m\vec a
$$

y recuperas la forma habitual $\vec F=m\vec a$.

Esta forma en momento lineal es especialmente util en choques, sistemas de varias particulas y procesos de corta duracion.

## Escalar vs vector (error habitual)
En 1D se suele trabajar con signos ($+$ y $-$), lo cual simplifica calculos. Pero conceptualmente sigue siendo una magnitud vectorial.

- Derecha/arriba: signo positivo.
- Izquierda/abajo: signo negativo.

Perder esta informacion de signo lleva a errores en colisiones y en conservacion de momento.

## Unidades y chequeo dimensional
- Masa: kg
- Velocidad: m/s
- Momento lineal: kg*m/s

Equivalencia util:

$$
1\;\mathrm{kg\,m/s}=1\;\mathrm{N\,s}
$$

## Cuando usar este concepto
- Analisis de impactos (deportes, seguridad vial, maquinaria).
- Sistemas de varios cuerpos que interactuan entre si.
- Cualquier problema donde interese "estado de movimiento" mas que solo velocidad.

## Idea didactica final
La velocidad te dice "como se mueve"; el momento lineal te dice "cuanto cuesta cambiar ese movimiento".