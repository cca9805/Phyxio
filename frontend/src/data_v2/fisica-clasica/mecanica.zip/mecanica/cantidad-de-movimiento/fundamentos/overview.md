﻿# Fundamentos

Este bloque introduce los conceptos base de cantidad de movimiento: momento lineal, impulso y analisis de sistemas aislados.

## Que aprenderas
- Definir y calcular el momento lineal con $\vec p=m\vec v$.
- Relacionar impulso y cambio de momento: $\vec J=\Delta\vec p$.
- Interpretar el papel del tiempo de interaccion en choques y frenados.
- Identificar cuando un sistema puede tratarse como aislado para aplicar conservacion del momento.

## Que encontraras aqui
- Teoria conceptual con interpretacion fisica de cada magnitud.
- Formulas en notacion LaTeX con despejes utiles.
- Graficos y calculadora para visualizar dependencias entre masa, velocidad, fuerza y tiempo.
- Ejemplos resueltos y errores tipicos de signos, unidades y eleccion del sistema.

## Conexiones
- Conecta con las leyes de Newton, sobre todo la segunda ley en forma de cantidad de movimiento.
- Prepara el estudio de conservacion del momento lineal y colisiones.
- Se extiende a momento angular y fenomenos rotacionales en bloques posteriores.