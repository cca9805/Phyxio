﻿# Aplicaciones

- Colisiones en fisica y en ingenieria de seguridad.
- Analisis de propulsion y retroceso.
- Estudio de sistemas de particulas y centro de masas.