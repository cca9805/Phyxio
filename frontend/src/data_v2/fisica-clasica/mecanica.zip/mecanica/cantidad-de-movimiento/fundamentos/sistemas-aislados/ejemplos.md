﻿# Ejemplos resueltos

- Dos patinadores se empujan: el momento total del sistema permanece constante.
- Choque 1D entre carros con pista casi sin rozamiento.
- Retroceso en sistemas de propulsion (accion-reaccion interna).