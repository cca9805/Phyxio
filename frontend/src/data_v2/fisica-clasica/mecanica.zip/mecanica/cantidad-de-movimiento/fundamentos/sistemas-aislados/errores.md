﻿# Errores frecuentes

- Incluir solo un cuerpo y aplicar conservacion al parcial.
- Ignorar fuerzas externas no despreciables.
- Tratar magnitudes vectoriales como escalares sin signo.