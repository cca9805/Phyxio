﻿# Contexto historico

La conservacion del momento lineal es uno de los principios mas robustos de la mecanica clasica y fundamenta el estudio de interacciones entre cuerpos.