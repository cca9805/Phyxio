﻿# Modelos y alcances

- Modelo basico: sistema cerrado con fuerzas externas despreciables.
- En practica, se analiza en intervalos cortos para minimizar efectos externos.
- Si hay rozamiento o fuerza externa relevante, la conservacion exacta no aplica.