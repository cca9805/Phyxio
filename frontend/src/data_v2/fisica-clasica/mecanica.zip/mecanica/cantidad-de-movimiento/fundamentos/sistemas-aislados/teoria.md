﻿# Sistemas aislados

## Concepto clave
Un sistema se considera aislado (en momento lineal) cuando la fuerza externa neta es nula o despreciable durante el intervalo analizado:

$$
\vec F_{ext}\approx 0
$$

En ese caso, el momento lineal total del sistema permanece constante:

$$
\vec p_{tot,i}=\vec p_{tot,f}
$$

## Que significa "total"
El momento total es la suma vectorial de los momentos de todos los cuerpos del sistema:

$$
\vec p_{tot}=\sum_k \vec p_k
$$

Las fuerzas internas (accion-reaccion entre cuerpos del sistema) pueden cambiar $\vec p_k$ de cada objeto, pero se compensan en la suma total.

## Forma operativa en 1D
Para dos cuerpos:

$$
m_1v_{1i}+m_2v_{2i}=m_1v_{1f}+m_2v_{2f}
$$

Esta ecuacion permite despejar velocidades finales en choques, acoplamientos o separaciones.

## Cuándo es razonable asumir aislamiento
- Choques muy breves sobre superficies de bajo rozamiento.
- Interacciones internas dominantes respecto a fuerzas externas.
- Intervalos cortos donde gravedad/rozamiento no cambian mucho el resultado.

Si las fuerzas externas no son despreciables, la conservacion exacta deja de ser valida y hay que incluir impulso externo.

## Interpretacion didactica
Aislar el sistema correcto es decisivo:
- Si eliges solo un cuerpo, no se conserva necesariamente su momento.
- Si eliges ambos cuerpos que interactuan, suele conservarse el momento total.

## Relacion con colisiones
Este principio es la base de:
- colisiones elasticas,
- colisiones inelasticas,
- colisiones totalmente inelasticas.

Lo que cambia entre ellas no es la conservacion del momento (que sigue valiendo en sistema aislado), sino el comportamiento de la energia cinetica.

## Error frecuente
Aplicar conservacion del momento sin revisar si realmente $\vec F_{ext}\approx 0$ durante el proceso.