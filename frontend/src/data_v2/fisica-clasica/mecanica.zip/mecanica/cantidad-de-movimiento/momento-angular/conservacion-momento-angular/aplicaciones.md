﻿# Aplicaciones

- Control de satelites mediante ruedas de reaccion.
- Maniobras de patinadores y clavadistas.
- Estabilidad de drones y robots con rotores.
- Conservacion aproximada en colisiones rotacionales cortas.
