﻿# Ejemplos resueltos

- **Patinador**: $I_i=4$, $\omega_i=2$, $I_f=2$.
  $\omega_f=(I_i\omega_i)/I_f=4\;\mathrm{rad/s}$.
- **Rueda libre**: sin torque externo apreciable, el valor de $L$ permanece constante.
- **Banco giratorio**: al acercar masas al eje aumenta $\omega$ sin aporte motor instantaneo.
