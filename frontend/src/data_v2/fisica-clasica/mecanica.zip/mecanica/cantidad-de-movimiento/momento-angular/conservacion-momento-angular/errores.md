﻿# Errores frecuentes

- Aplicar conservacion sin revisar torques externos.
- Cambiar eje de referencia entre estado inicial y final.
- Suponer que conservar $L$ implica conservar energia mecanica.
- Olvidar unidades de $L$ y de $I$ en conversiones.
