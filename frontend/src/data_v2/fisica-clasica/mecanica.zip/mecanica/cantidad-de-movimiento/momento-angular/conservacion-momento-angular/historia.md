﻿# Historia breve

- **Noether (1918)** vinculo simetrias rotacionales con conservacion de momento angular.
- **Siglo XX**: auge de aplicaciones en aeroespacial y control automatico.
- **Actualidad**: fundamento en dinamica orbital y sistemas giroscopicos.
