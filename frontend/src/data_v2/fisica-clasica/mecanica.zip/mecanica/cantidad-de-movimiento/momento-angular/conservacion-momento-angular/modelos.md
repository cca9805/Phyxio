﻿# Modelos de uso

- **Sistema aislado rotacional**: $\sum \tau_{ext}\approx0$ y se aplica $L_i=L_f$.
- **Cuerpo con cambio de postura**: $I_i\omega_i=I_f\omega_f$.
- **Choque rotacional corto**: el impulso angular externo puede despreciarse.
- **Modelo no conservativo**: si hay torque externo significativo, usar $\sum\tau=dL/dt$.
