﻿# Conservacion del momento angular

## Principio fisico
Si el torque externo neto sobre un sistema es cero, el momento angular total se conserva:

$$
\sum \vec \tau_{ext}=0 \quad \Rightarrow \quad \vec L_f=\vec L_i
$$

No significa que no haya fuerzas internas. Significa que las interacciones externas no aportan torque neto respecto del eje elegido.

## Version util para eje fijo
Cuando un cuerpo cambia su distribucion de masa (por ejemplo, recoge los brazos):

$$
I_i\omega_i = I_f\omega_f
$$

Si $I$ disminuye, $\omega$ aumenta. Este efecto se observa en patinaje artistico, clavados y giros acrobaticos.

## Condicion clave: eleccion del eje
La conservacion depende del eje de referencia. Debes elegir un eje para el cual el torque externo neto sea nulo o despreciable.

Ejemplos:
- Persona girando sobre plataforma con rozamiento pequeno: buen modelo conservativo.
- Objeto apoyado con rozamiento fuerte en eje: puede no conservarse por torque disipativo.

## Metodo de resolucion
1. Define el sistema (que cuerpos entran en el analisis).
2. Elige eje de referencia y signos.
3. Evalua si $\sum \tau_{ext}\approx 0$ durante el proceso.
4. Si se cumple, aplica $L_i=L_f$.
5. Relaciona con $L=I\omega$ o con $\vec r\times\vec p$ segun el problema.

## Diferencia con conservacion de energia
- En muchos procesos rotacionales se conserva $L$ aunque la energia mecanica no se conserve exactamente.
- Si hay disipacion interna, energia mecanica puede bajar, pero $L$ puede mantenerse si no hay torque externo.

## Errores frecuentes
- Aplicar conservacion de $L$ sin verificar torque externo.
- Mezclar ejes distintos entre estado inicial y final.
- Confundir ausencia de fuerza con ausencia de torque.

## Idea final
El momento angular es una restriccion dinamica muy potente: cuando el entorno no torca al sistema, el giro total no se puede crear ni destruir, solo redistribuir.
