﻿# Aplicaciones

- Estabilidad de ruedas y rotores en maquinaria.
- Diseño de volantes de inercia para almacenamiento de energia.
- Analisis de maniobras en deporte (patinaje, clavados, gimnasia).
- Control de actitud en satelites con ruedas de reaccion.
