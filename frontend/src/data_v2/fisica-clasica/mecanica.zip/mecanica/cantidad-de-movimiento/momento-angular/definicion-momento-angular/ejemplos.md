﻿# Ejemplos resueltos

- **Disco**: $I=0.20\;\mathrm{kg\,m^2}$ y $\omega=12\;\mathrm{rad/s}$.
  Entonces $L=I\omega=2.4\;\mathrm{kg\,m^2/s}$.
- **Particula**: $m=2\;\mathrm{kg}$, $v=3\;\mathrm{m/s}$, $r_\perp=0.5\;\mathrm{m}$.
  Magnitud: $L=r_\perp mv=3\;\mathrm{kg\,m^2/s}$.
- **Cambio de sentido de giro**: si $\omega$ cambia de signo, $L$ tambien cambia de signo.
