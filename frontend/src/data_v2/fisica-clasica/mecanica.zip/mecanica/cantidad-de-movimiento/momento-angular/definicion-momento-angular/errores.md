﻿# Errores frecuentes

- No especificar punto o eje de referencia antes de calcular $L$.
- Usar $L=I\omega$ en un problema que no es de solido rigido.
- Ignorar el signo/sentido del giro.
- Confundir brazo perpendicular con distancia radial sin proyectar.
