﻿# Historia breve

- **Euler (s. XVIII)** formalizo ecuaciones del movimiento rotacional.
- **Lagrange y Hamilton** consolidaron el enfoque variacional para sistemas rotacionales.
- **Ingenieria moderna** aplica momento angular en turbomaquinas, navegacion inercial y control espacial.
