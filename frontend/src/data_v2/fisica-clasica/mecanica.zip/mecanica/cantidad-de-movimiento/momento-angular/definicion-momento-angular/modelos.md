﻿# Modelos de uso

- **Particula puntual**: $\vec L = \vec r \times \vec p$ para trayectorias orbitales o impactos respecto a un origen.
- **Solido rigido en eje fijo**: $L = I\omega$ cuando el eje es conocido y la distribucion de masa no cambia durante el instante.
- **Sistema discreto de particulas**: $\vec L_{tot}=\sum_i \vec r_i\times m_i\vec v_i$.
- **Aproximacion 1D angular**: se trabaja con signos de giro, manteniendo criterio horario/antihorario.
