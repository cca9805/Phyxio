﻿# Definicion de momento angular

## Que es el momento angular
El momento angular es la magnitud que describe el estado de rotacion de un cuerpo respecto de un punto o eje de referencia.

Para una particula:

$$
\vec L = \vec r \times \vec p = \vec r \times m\vec v
$$

donde $\vec r$ es el vector posicion medido desde el punto elegido, y $\vec p$ es el momento lineal.

Para un solido rigido girando alrededor de un eje fijo:

$$
L = I\omega
$$

## Interpretacion fisica
- A mayor masa y mayor velocidad tangencial, mayor $L$.
- A mayor distancia al eje, mayor capacidad de generar momento angular.
- El sentido de $\vec L$ se determina con la regla de la mano derecha.

Por eso un disco de inercia grande cuesta mas frenarlo que uno ligero a igual $\omega$.

## Relacion con el torque
La ley dinamica rotacional general es:

$$
\sum \vec \tau_{ext} = \frac{d\vec L}{dt}
$$

Si el eje es fijo y $I$ constante:

$$
\sum \tau = I\alpha
$$

Esta relacion es el equivalente rotacional de $\sum \vec F = d\vec p/dt$.

## Cuando usar cada formula
- Usa $\vec L=\vec r\times\vec p$ para particulas, choques, o sistemas con geometria variable.
- Usa $L=I\omega$ para solidos rigidos alrededor de eje conocido.

Si cambias el punto de referencia, cambia $\vec r$ y por tanto cambia $\vec L$. El punto elegido debe declararse siempre.

## Procedimiento de resolucion
1. Elige punto o eje de referencia.
2. Define signo positivo de giro (horario/antihorario o vectorial).
3. Calcula $I$, $\omega$ o bien $\vec r$ y $\vec p$ segun el modelo.
4. Verifica unidades: $[L]=\mathrm{kg\,m^2/s}$.
5. Contrasta signo y sentido del resultado.

## Errores frecuentes
- Olvidar que el momento angular depende del punto de referencia.
- Mezclar formulas escalares y vectoriales sin coherencia de signos.
- Usar $L=I\omega$ en situaciones donde no hay solido rigido.

## Idea final
La velocidad angular dice que tan rapido gira. El momento angular dice cuanto cuesta cambiar ese giro.
