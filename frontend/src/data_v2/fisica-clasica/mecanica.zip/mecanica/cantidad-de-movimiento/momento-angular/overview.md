﻿# Momento angular

El bloque de momento angular extiende las ideas de cantidad de movimiento lineal al movimiento de rotacion. Aqui se estudia como describir el estado de giro de un sistema, bajo que condiciones ese estado se conserva y que ocurre cuando aparece un torque externo que cambia la direccion del eje.

## Que aprenderas
- Definir momento angular para particulas y para solidos rigidos.
- Relacionar torque externo con variacion de momento angular.
- Aplicar conservacion de momento angular en problemas reales.
- Entender fisicamente la precesion de giroscopios y peonzas.

## Que encontraras aqui
- Teoria extensa con criterios de uso de formulas.
- Calculadora y graficos de coordenadas para visualizar dependencias.
- Ejemplos numericos, modelos tipicos, errores frecuentes e historia.

## Conexiones
- Con dinamica rotacional: $\sum\tau = dL/dt$.
- Con energia rotacional: combinacion de $L=I\omega$ y $E_r=\tfrac12 I\omega^2$.
- Con aplicaciones de ingenieria: control de actitud, ruedas de reaccion, estabilidad giroscopica.
