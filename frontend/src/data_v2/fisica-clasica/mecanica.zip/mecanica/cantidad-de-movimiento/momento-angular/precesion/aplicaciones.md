﻿# Aplicaciones

- Brijulas giroscopicas y navegacion inercial.
- Estabilizacion de bicicletas, motos y rotores.
- Control de orientacion de satelites y estaciones espaciales.
- Diseno de juguetes y peonzas de alta estabilidad.
