﻿# Ejemplos resueltos

- **Giroscopio**: $m=1.5\;\mathrm{kg}$, $r=0.08\;\mathrm{m}$, $I=0.02\;\mathrm{kg\,m^2}$, $\omega=120\;\mathrm{rad/s}$.
  $\Omega_p\approx \frac{mgr}{I\omega}=0.49\;\mathrm{rad/s}$.
- Si duplicas $\omega$, la precesion se reduce aproximadamente a la mitad.
- Si aumenta el torque externo, $\Omega_p$ aumenta.
