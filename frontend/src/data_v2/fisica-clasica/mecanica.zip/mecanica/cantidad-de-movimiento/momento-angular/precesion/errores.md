﻿# Errores frecuentes

- Creer que la precesion exige aumento de modulo de $L$; muchas veces cambia sobre todo la direccion.
- Aplicar la formula simplificada fuera de regimen estable.
- Ignorar rozamiento en apoyo cuando se comparan datos reales.
- Confundir velocidad de spin ($\omega$) con velocidad de precesion ($\Omega_p$).
