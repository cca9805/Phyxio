﻿# Historia breve

- **Foucault (1852)** mostro la utilidad del giroscopio para evidenciar rotacion terrestre.
- **Kelvin y Tait** desarrollaron interpretaciones dinamicas de precesion y nutacion.
- **Ingenieria del siglo XX-XXI** incorporo precesion en aviacion, marina y espacio.
