﻿# Modelos de uso

- **Precesion estable**: giro propio rapido y torque casi constante.
- **Giroscopio gravitatorio**: $\Omega_p\approx mgr/(I\omega)$.
- **Modelo vectorial general**: $d\vec L/dt = \vec\tau$ para estudiar direccion de $\vec L$.
- **Regimen con nutacion**: cuando el giro no es suficientemente alto, hay oscilaciones adicionales.
