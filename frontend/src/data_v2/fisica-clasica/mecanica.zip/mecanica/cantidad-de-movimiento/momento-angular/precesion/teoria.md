﻿# Precesion

## Que es la precesion
La precesion es el cambio gradual de la direccion del eje de rotacion de un cuerpo cuando actua un torque externo que no es paralelo al momento angular.

La ecuacion base es:

$$
\sum \vec \tau = \frac{d\vec L}{dt}
$$

Si el torque es aproximadamente perpendicular a $\vec L$, el modulo de $L$ puede mantenerse casi constante mientras su direccion gira.

## Intuicion fisica
Un giroscopio no cae de inmediato como un objeto sin giro. El torque gravitatorio cambia la direccion de $\vec L$ y aparece el movimiento de precesion alrededor de la vertical.

## Frecuencia de precesion (modelo simple)
Para una peonza o giroscopio de simetria axial en regimen estable:

$$
\Omega_p \approx \frac{\tau}{L} = \frac{mgr}{I\omega}
$$

donde:
- $m$ es la masa,
- $g$ la gravedad,
- $r$ el brazo respecto al punto de apoyo,
- $I\omega$ el momento angular de giro propio.

## Cuando aplicar esta expresion
Esta aproximacion funciona cuando:
- el giro propio $\omega$ es alto,
- la inclinacion cambia lentamente,
- no hay grandes perdidas por rozamiento.

Si el giro es bajo o hay mucha disipacion, aparece nutacion y el modelo simple deja de ser preciso.

## Procedimiento de analisis
1. Dibuja $\vec L$ del rotor.
2. Dibuja torque externo $\vec \tau$.
3. Usa $d\vec L/dt=\vec\tau$ para inferir hacia donde se mueve el eje.
4. Si procede, calcula $\Omega_p$ con la formula aproximada.

## Errores frecuentes
- Creer que el torque siempre cambia la rapidez angular; muchas veces cambia sobre todo la direccion de $\vec L$.
- Ignorar el vectorial: en precesion, direccion es mas importante que modulo.
- Aplicar $\Omega_p=\tau/L$ fuera del regimen de precesion estable.

## Idea final
La precesion muestra que en rotacion no basta con saber cuanto gira un cuerpo: tambien importa hacia donde apunta su momento angular y como los torques externos reorientan ese vector.
