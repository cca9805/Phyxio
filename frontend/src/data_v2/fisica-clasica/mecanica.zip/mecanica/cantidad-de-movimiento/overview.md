## Qué aprenderás
- El concepto de cantidad de movimiento y su conservación.
- El papel del impulso en los cambios de movimiento.
- A analizar colisiones y sistemas de partículas.

## Qué encontrarás aquí
- Momento lineal e impulso.
- Colisiones elásticas e inelásticas.
- Sistemas aislados.
- Momento angular y su conservación.

## Conexiones
- Fundamental en choques, explosiones y sistemas astronómicos.
- Conecta con dinámica rotacional y gravitación.
