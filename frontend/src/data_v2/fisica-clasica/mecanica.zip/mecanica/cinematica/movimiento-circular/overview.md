## Qué aprenderás
- A describir movimientos en trayectorias circulares.
- A trabajar con magnitudes angulares.
- A relacionar movimiento lineal y angular.

## Qué encontrarás aquí
- Movimiento circular uniforme (MCU).
- Movimiento circular uniformemente acelerado (MCUA).
- Velocidad y aceleración centrípeta.

## Conexiones
- Conecta cinemática con dinámica rotacional.
- Aparece en ruedas, engranajes y sistemas orbitales.
