## Qué aprenderás
- A describir movimientos en el plano.
- A descomponer movimientos en componentes.
- A combinar movimientos independientes.

## Qué encontrarás aquí
- Movimiento horizontal y vertical combinados.
- Trayectorias parabólicas.
- Análisis vectorial del movimiento.

## Conexiones
- Aplicable a deportes, balística y lanzamientos.
- Refuerza el uso de vectores en física.
