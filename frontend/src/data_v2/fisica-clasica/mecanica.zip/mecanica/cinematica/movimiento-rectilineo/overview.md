## Qué aprenderás
- A describir movimientos en una sola dimensión.
- A diferenciar movimiento uniforme y acelerado.
- A interpretar ecuaciones y gráficas rectilíneas del movimiento.

## Qué encontrarás aquí
- Movimiento rectilíneo uniforme (MRU).
- Movimiento rectilíneo uniformemente acelerado (MRUA).
- Caída libre como caso particular de movimiento acelerado.
- Interpretación de gráficas posición–tiempo y velocidad–tiempo.

## Conexiones
- Base de la cinemática y punto de partida de muchos modelos físicos.
- Aparece en caídas, frenadas, lanzamientos verticales y desplazamientos cotidianos.
