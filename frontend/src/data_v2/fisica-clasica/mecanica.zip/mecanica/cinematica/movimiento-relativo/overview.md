## Qué aprenderás
- A describir el movimiento desde distintos observadores.
- A trabajar con velocidades relativas.
- A interpretar sistemas de referencia móviles.

## Qué encontrarás aquí
- Movimiento relativo en una y dos dimensiones.
- Cambio de sistema de referencia.
- Ejemplos clásicos de trenes y barcos.

## Conexiones
- Clave para entender encuentros y persecuciones.
- Base conceptual para sistemas no inerciales.
