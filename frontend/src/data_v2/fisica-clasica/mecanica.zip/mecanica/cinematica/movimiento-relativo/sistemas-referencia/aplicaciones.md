# Aplicaciones

- **Navegación**: velocidad del barco respecto al agua y respecto a tierra (corriente).
- **Cintas transportadoras**: objetos “en reposo” en la cinta pero moviéndose en el suelo.
- **Robótica móvil**: sensores en un marco (robot) y medidas en el marco del laboratorio.
- **Deportes**: velocidad de un jugador respecto al campo y respecto a un compañero en movimiento.
- **Astrofísica (nivel superior)**: elección de marcos para simplificar trayectorias (aunque ahí se usan modelos más avanzados).
