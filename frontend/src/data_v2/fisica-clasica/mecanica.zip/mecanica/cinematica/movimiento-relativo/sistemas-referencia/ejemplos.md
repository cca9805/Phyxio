# Ejemplos

## 1) Pasajero en un tren (velocidad)
Un tren se mueve a \(v_0 = 20 \,\text{m/s}\) respecto a la vía (S).  
Un pasajero camina hacia delante dentro del tren a \(v' = 1.5 \,\text{m/s}\) (S').

Velocidad vista desde la vía:
\[
v = v' + v_0 = 1.5 + 20 = 21.5 \,\text{m/s}
\]

Si camina hacia atrás a \(v'=-1.5\), entonces:
\[
v = 20 - 1.5 = 18.5 \,\text{m/s}
\]

---

## 2) Posición en dos marcos
En \(t=0\), el origen del tren está en \(x_0 = 100\,\text{m}\) respecto al origen de la carretera.  
El tren lleva \(v_0 = 20\,\text{m/s}\).  
Un objeto dentro del tren está a \(x' = 5\,\text{m}\) del origen del tren.

A los \(t=3\,\text{s}\), su posición vista desde la carretera:
\[
x = x' + x_0 + v_0 t = 5 + 100 + 20\cdot 3 = 165 \,\text{m}
\]
