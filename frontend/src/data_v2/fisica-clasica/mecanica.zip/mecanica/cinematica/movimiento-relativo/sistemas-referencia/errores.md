# Errores comunes

1) **Confundir “depende del SR” con “no es real”**
- Posición y velocidad dependen del observador, pero el fenómeno es real.

2) **Sumar magnitudes sin fijar signos**
- En 1D, \(v' < 0\) si va en sentido contrario al eje elegido.

3) **No definir el origen en t=0**
- El término \(x_0\) es clave: si lo olvidas, la transformación de posición falla.

4) **Creer que siempre hay que “sumar”**
- La composición \(v = v' + v_0\) ya incluye el signo: puede sumar o restar.

5) **Aplicar fórmulas 1D a casos 2D sin vectores**
- Si hay direcciones distintas, debes usar versión vectorial y componentes.
