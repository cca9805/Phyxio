# Historia y contexto

- La idea de que el movimiento depende del observador aparece de forma clara en la ciencia clásica con **Galileo Galilei**.
- La “relatividad galileana” establece que las leyes de la mecánica son las mismas en todos los **marcos inerciales**.
- Más tarde, cuando las velocidades se acercan a la de la luz, la transformación galileana deja de ser válida y aparece la **relatividad especial** (Lorentz), pero eso es otro tema.
