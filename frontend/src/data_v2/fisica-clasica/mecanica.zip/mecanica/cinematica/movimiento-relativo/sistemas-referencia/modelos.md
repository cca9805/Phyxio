# Modelo y validez

## Modelo usado (Galileo básico)
Este subtema asume:

- Movimiento relativo entre marcos **constante** (velocidad \(v_0\) constante).
- Ejes **paralelos y alineados** (no hay rotación del marco móvil).
- El tiempo se considera **igual** en ambos marcos (cinemática clásica).

## Cuándo es válido
- Trenes, coches, cintas transportadoras, barcos, pasillos mecánicos…
- Situaciones donde \(v \ll c\) (muy lejos de relatividad especial).

## Cuándo deja de ser suficiente
- Si el marco móvil acelera (autobús que frena/arranca): aparecen efectos de marco no inercial.
- Si hay rotación del marco (carrusel, plataforma giratoria).
- Si necesitas 2D/3D con direcciones (vectores completos).

## Cómo reconocer el SR “más cómodo”
- Elige el SR donde el movimiento sea más simple (MRU si es posible).
- Si un objeto está en reposo en un SR, muchas ecuaciones se simplifican.
