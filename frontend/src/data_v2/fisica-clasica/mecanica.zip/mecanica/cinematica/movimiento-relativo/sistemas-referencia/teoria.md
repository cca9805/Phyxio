﻿# Sistemas de referencia

## Idea clave
En cinemÃ¡tica, **medir** significa elegir:
- un **observador**
- un **origen**
- unos **ejes**
- un **reloj**

A ese conjunto lo llamamos **sistema de referencia**.

Dos observadores diferentes pueden asignar **valores distintos** (por ejemplo, posiciÃ³n o velocidad) al **mismo objeto**, y ambos estar en lo correcto, porque **miden desde marcos distintos**.

---

## Â¿QuÃ© define un sistema de referencia?
Un sistema de referencia (SR) queda definido por:

1. **Origen**: el punto que se toma como \(x=0\).
2. **Ejes**: la direcciÃ³n positiva y el sentido de medida.
3. **Reloj**: cÃ³mo se mide el tiempo \(t\).
4. **Convenciones**: signos, unidades, y quÃ© se considera â€œen reposoâ€.

Ejemplo simple (1D):
- SR S: â€œla carreteraâ€
- SR S': â€œel trenâ€
- Un pasajero camina dentro del tren

---

## S y Sâ€™: marco â€œfijoâ€ y marco mÃ³vil
Llamaremos:
- **S**: marco principal (a veces â€œfijoâ€ por comodidad)
- **S'**: marco que se mueve respecto a S con velocidad constante \(v_0\)

En el modelo galileano bÃ¡sico:
- S' se mueve respecto a S con **velocidad constante** \(v_0\)
- los ejes estÃ¡n **alineados** (no hay rotaciÃ³n entre marcos)
- el tiempo se toma igual \(t\) en ambos (cinemÃ¡tica clÃ¡sica)

---

## TransformaciÃ³n galileana (posiciÃ³n, 1D)
Si en el instante \(t=0\) el origen de S' estÃ¡ en \(x_0\) (medido en S), entonces:

$$
x = x' + x_0 + v_0 t
$$

InterpretaciÃ³n:
- \(x'\) es â€œlo que veâ€ el observador del tren (S')
- \(x_0 + v_0 t\) es â€œdÃ³nde estÃ¡â€ el origen del tren visto desde la carretera (S)

---

## ComposiciÃ³n de velocidades (1D)
Derivando la relaciÃ³n de posiciÃ³n respecto del tiempo (y manteniendo \(v_0\) constante):

$$
v = v' + v_0
$$

Esto significa:
- si el pasajero camina hacia delante dentro del tren (\(v'>0\))
- y el tren avanza (\(v_0>0\))
- entonces desde la carretera se suma.

Ojo: **si camina hacia atrÃ¡s**, \(v'\) serÃ¡ negativa.

---

## NotaciÃ³n Ãºtil (y tÃ­pica)
A veces se usa notaciÃ³n del tipo:
- \(x_{A/B}\): â€œposiciÃ³n de A respecto a Bâ€
- \(v_{A/B}\): â€œvelocidad de A respecto a Bâ€

Esta notaciÃ³n es conceptual: exige definir claramente **quiÃ©n mide** y **desde dÃ³nde**.

---

## QuÃ© es calculable y quÃ© no
### Calculable (en este Tema)
- TransformaciÃ³n galileana 1D de posiciÃ³n: \(x = x' + x_0 + v_0 t\)
- ComposiciÃ³n de velocidades 1D: \(v = v' + v_0\)

### No calculable (aquÃ­) pero sÃ­ importante
- Versiones vectoriales \(\vec r = \vec r\,' + \vec r_0 + \vec v_0 t\)
- Casos con rotaciÃ³n de ejes, aceleraciÃ³n del marco o fuerzas ficticias

Esos casos requieren componentes, direcciones y un modelo mÃ¡s completo (marcos no inerciales), y se tratarÃ¡n en temas posteriores.
