# Aplicaciones

- Seguridad vial: velocidades relativas en adelantamientos.
- Aeropuertos: pasillos móviles (cintas).
- Robótica: velocidades relativas entre robots y entorno.
- Física del deporte: velocidad relativa jugador-pelota.
