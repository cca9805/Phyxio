# Ejemplos

## 1) Cinta transportadora
Una cinta (B) se mueve respecto al suelo (C) con \(v_{B/C}=+2\).  
Una caja (A) se mueve respecto a la cinta con \(v_{A/B}=+0.5\).

\[
v_{A/C}=0.5+2=2.5
\]

## 2) Persona caminando “hacia atrás” en un tren
Tren: \(v_{B/C}=+10\). Persona: \(v_{A/B}=-2\).

\[
v_{A/C}=-2+10=8
\]
