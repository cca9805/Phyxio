# Errores comunes

1) **Olvidar el signo**
- “hacia atrás” debe entrar como velocidad negativa si el eje positivo es hacia delante.

2) **Confundir v_{A/B} con v_{B/A}**
- Cambiar observador cambia el signo: \(v_{A/B}=-v_{B/A}\).

3) **Sumar dos velocidades medidas en marcos distintos sin notación**
- Escribe siempre el “/B” para saber quién mide.

4) **Aplicar la fórmula 1D a casos 2D**
- En 2D se suman vectores por componentes.
