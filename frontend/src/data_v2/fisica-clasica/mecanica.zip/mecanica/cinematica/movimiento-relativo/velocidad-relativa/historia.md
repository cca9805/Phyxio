# Historia

- Galileo formaliza la idea de marcos inerciales y relatividad clásica.
- En mecánica newtoniana, la suma de velocidades es válida para v << c.
- La relatividad especial modifica estas reglas cerca de la velocidad de la luz (otro tema).
