﻿# Modelo y alcance

## Modelo
- Movimiento relativo entre referencias constante.
- Problemas 1D: ejes alineados.
- No se considera relatividad especial.

## Alcance
Este Tema es la base para:
- encuentros y persecuciones
- cinemÃ¡tica en rÃ­os/corrientes (si se modela 2D en otro Tema)
- composiciÃ³n de movimientos

## Fuera de alcance aquÃ­
- suma vectorial completa en 2D/3D
- marcos no inerciales (acelerados o en rotaciÃ³n)
