# Velocidad relativa

## Idea clave
La velocidad **depende del observador**. Para no confundirnos usamos notación relativa:

$$
v_{A/B} \equiv \text{“velocidad de A medida por B”}
$$

En 1D, el signo importa: depende del **sentido positivo** elegido.

---

## Composición de velocidades (regla de cadena)
Si tienes tres “referencias” A, B y C (por ejemplo: persona, tren, tierra), se cumple:

$$
v_{A/C} = v_{A/B} + v_{B/C}
$$

Interpretación:
- \(v_{A/B}\): lo que ve B
- \(v_{B/C}\): cómo se mueve B respecto a C
- La suma da lo que ve C

---

## Ejemplo mental (persona en tren)
- Persona A camina dentro del tren B a \(v_{A/B}=+1.5\,\text{m/s}\)
- Tren B avanza respecto al suelo C a \(v_{B/C}=+20\,\text{m/s}\)

Entonces:
$$
v_{A/C}=1.5+20=21.5\,\text{m/s}
$$

Si camina hacia atrás:
$$
v_{A/B}=-1.5 \Rightarrow v_{A/C}=20-1.5=18.5\,\text{m/s}
$$

---

## Antisimetría (cambiar el observador)
Por definición:
$$
v_{A/B} = -v_{B/A}
$$

Esto no “calcula” nada nuevo, solo cambia el punto de vista.

---

## Qué es calculable y qué no
- **Calculable:** la regla de cadena en 1D \(v_{A/C} = v_{A/B} + v_{B/C}\).
- **No calculable aquí:** casos 2D/3D (vectores) o marcos que rotan/aceleran: requieren componentes y modelos adicionales.
