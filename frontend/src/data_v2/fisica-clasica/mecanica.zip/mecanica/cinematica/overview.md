## Qué aprenderás
- A describir el movimiento sin analizar sus causas.
- A trabajar con posición, velocidad y aceleración.
- A interpretar gráficas y ecuaciones del movimiento.

## Qué encontrarás aquí
- Movimiento rectilíneo y curvilíneo.
- Movimiento circular y rotacional.
- Movimiento en una y dos dimensiones.
- Movimiento relativo, encuentros y persecuciones.

## Conexiones
- Es la base de toda la mecánica.
- Fundamental para entender dinámica, energía y aplicaciones reales como el transporte.
