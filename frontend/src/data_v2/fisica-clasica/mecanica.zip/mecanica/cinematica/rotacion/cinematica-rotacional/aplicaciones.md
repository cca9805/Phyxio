# Aplicaciones (cinemática rotacional)

## Mecánica e ingeniería
- Motores y turbinas: perfiles de ω(t) y α(t) para control de arranque/parada.
- Ventiladores: régimen estacionario (ω constante) y transitorios (α ≠ 0).
- Poleas y engranajes: preparación para relaciones de transmisión y rodadura.

## Robótica y control
- Planificación de movimiento: limitar α para evitar vibraciones y sobreesfuerzos.
- Trayectorias suaves: cambios por tramos de α (jerk control).

## Puente a otros bloques
- MCU/MCUA rotacional: casos típicos y ejercicios estándar.
- Dinámica rotacional: torque, momento de inercia, energía de rotación (cuando toque el “por qué”).
