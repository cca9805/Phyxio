# Ejemplos (cinemática rotacional)

## Ejemplo 1: giro uniforme (ω constante)
Un disco tiene θ0 = 0,5 rad y ω = 3 rad/s. Calcula θ a los 4 s.

Modelo: ω constante → θ = θ0 + ω·t

θ = 0,5 + 3·4 = 12,5 rad

---

## Ejemplo 2: giro con α constante
Un motor parte con ω0 = 2 rad/s y α = 1,5 rad/s². Calcula ω a los 6 s.

ω = ω0 + α·t = 2 + 1,5·6 = 11 rad/s

---

## Ejemplo 3: interpretar signos
Se toma como positivo el giro antihorario.
Una rueda tiene ω0 = -8 rad/s y α = +2 rad/s².

- ω aumenta con el tiempo (va hacia valores menos negativos).
- El sistema gira inicialmente horario, pero “se está frenando” en ese sentido.
- Si llega a ω = 0, cambiará el sentido si α sigue siendo positiva.
