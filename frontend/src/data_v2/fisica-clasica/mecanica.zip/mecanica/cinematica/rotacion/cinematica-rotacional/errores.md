# Errores comunes en cinemática rotacional

## 1) Usar grados donde el modelo espera radianes
- Internamente trabaja en radianes.
- Convierte: 180° = π rad.

## 2) Confundir posición angular θ con desplazamiento Δθ
- θ es “dónde estoy”.
- Δθ es “cuánto he cambiado”: θ - θ0.

## 3) Perder el signo (sentido de giro)
- Elige un sentido positivo y manténlo.
- ω y α pueden ser positivas o negativas; interpretarlas depende del convenio.

## 4) “Si α es negativa entonces frena”
No necesariamente:
- Si ω > 0 y α < 0, |ω| suele disminuir (frena).
- Si ω < 0 y α < 0, |ω| puede aumentar (acelera en sentido negativo).

## 5) Pensar que θ está entre 0 y 2π
θ no tiene por qué estar acotada. Depende de cómo parametrices el giro.
