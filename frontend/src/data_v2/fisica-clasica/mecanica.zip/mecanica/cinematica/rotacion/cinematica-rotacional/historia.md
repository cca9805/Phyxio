# Historia y contexto

La descripción del movimiento angular surge como extensión natural de la cinemática lineal.
El **radián** se adopta como unidad “natural” porque conecta directamente geometría y física
(longitud de arco s = r·θ), y simplifica las relaciones matemáticas.

La cinemática rotacional se volvió esencial con el desarrollo de:
- máquinas rotativas (revolución industrial),
- motores eléctricos,
- control moderno de sistemas (automoción, aeronáutica, robótica).
