# Modelos en cinemática rotacional

## Qué significa “modelo”
Un modelo es una descripción matemática del movimiento basada en supuestos claros.
En cinemática rotacional el objetivo es describir **θ(t), ω(t), α(t)** sin estudiar aún fuerzas ni torques.

---

## Modelo 1: ω constante (giro uniforme)
**Supuesto:** la velocidad angular no cambia con el tiempo.

Consecuencias:
- α = 0
- θ crece (o decrece) linealmente con t

Interpretación física:
- el sistema gira “a ritmo constante”.
- si ω < 0 gira en el sentido contrario al positivo elegido.

---

## Modelo 2: α constante (giro uniformemente acelerado)
**Supuesto:** la aceleración angular es constante.

Consecuencias:
- ω cambia linealmente con t
- θ cambia de forma cuadrática con t

Interpretación física:
- el sistema acelera o frena según signos de ω y α (ojo: no es “frena” solo por ser α negativa; depende del convenio).

---

## Dominio de validez
Estos modelos funcionan bien cuando:
- el eje de giro es fijo,
- el cuerpo puede considerarse rígido,
- y los efectos de deformaciones o variaciones complejas se pueden despreciar.

---

## Limitaciones habituales
- Eje no fijo (precesión, rotaciones acopladas).
- α no constante (arranques reales con control por tramos).
- Medición en grados sin conversión a radianes (errores sistemáticos).
