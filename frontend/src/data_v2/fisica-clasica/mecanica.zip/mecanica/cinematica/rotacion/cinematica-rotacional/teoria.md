# Cinemática rotacional

## Idea fundamental
La cinemática rotacional describe **cómo gira** un sistema alrededor de un eje,
utilizando magnitudes angulares, sin estudiar todavía las causas del movimiento.

Es el análogo angular de la cinemática rectilínea.

---

## Magnitudes angulares

### Posición angular (θ)
Describe la orientación del sistema respecto a un origen elegido.

- Unidad SI: radián (rad)
- Puede crecer o decrecer sin límite
- Su signo depende del convenio de giro

---

### Desplazamiento angular (Δθ)
Cambio de posición angular entre dos instantes:

$$
\Delta\theta = \theta - \theta_0
$$

---

### Velocidad angular (ω)
Define cómo cambia la posición angular con el tiempo:

$$
\omega = \frac{d\theta}{dt}
$$

Esta expresión es **definicional**: no permite cálculo directo
sin conocer la función θ(t).

---

### Aceleración angular (α)
Define cómo cambia la velocidad angular con el tiempo:

$$
\alpha = \frac{d\omega}{dt}
$$

También es una **definición diferencial**.

---

## Modelos cinemáticos

### Giro con velocidad angular constante
Si ω es constante:

$$
\alpha = 0
$$
$$
\theta(t) = \theta_0 + \omega t
$$

Este modelo describe rotaciones en régimen estacionario.

---

### Giro con aceleración angular constante
Si α es constante:

$$
\omega(t) = \omega_0 + \alpha t
$$

$$
\theta(t) = \theta_0 + \omega_0 t + \frac{1}{2}\alpha t^2
$$

Estas ecuaciones son el análogo rotacional del MRUA.

---

## Relación integral general
En el caso general:

$$
\theta(t) = \theta_0 + \int_0^t \omega(t')\,dt'
$$

Esta expresión es **no calculable automáticamente**:
requiere conocer ω(t) y realizar integración analítica o numérica.

---

## Convenio de signos
- El sentido positivo de giro se elige arbitrariamente.
- ω y α pueden ser positivas o negativas.
- El signo no indica “bien” o “mal”, solo **sentido**.

---

## Alcance del bloque
Aquí se describe el movimiento.
Las causas (torque, fuerzas, momento de inercia) pertenecen
a la **dinámica rotacional**.
