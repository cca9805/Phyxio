# Ejemplos (magnitudes angulares)

## 1) Desplazamiento angular
Un rotor pasa de \(\theta_0 = 1.2\ \text{rad}\) a \(\theta = 4.7\ \text{rad}\).

$$
\Delta\theta = 4.7 - 1.2 = 3.5\ \text{rad}
$$

---

## 2) Velocidad angular media
Una rueda gira \(\Delta\theta = 12\ \text{rad}\) en \(\Delta t = 3\ \text{s}\).

$$
\omega = \frac{12}{3} = 4\ \text{rad/s}
$$

---

## 3) Aceleración angular media
Un motor cambia su velocidad angular de \(10\ \text{rad/s}\) a \(2\ \text{rad/s}\) en \(4\ \text{s}\).

$$
\Delta\omega = 2 - 10 = -8\ \text{rad/s}
$$
$$
\alpha = \frac{-8}{4} = -2\ \text{rad/s}^2
$$
El signo negativo indica que \(\omega\) disminuye siguiendo el convenio elegido.
