# Errores comunes (magnitudes angulares)

## 1) Usar grados en lugar de radianes
- Las fórmulas de cinemática rotacional se usan naturalmente con radianes.
- Si tienes grados, conviértelos antes.

## 2) Confundir posición con desplazamiento
- \(\theta\) es una orientación (puede crecer indefinidamente).
- \(\Delta\theta\) es el cambio entre dos instantes: \(\theta - \theta_0\).

## 3) Perder el signo
- \(\omega\) indica el sentido de giro.
- \(\alpha\) indica cómo cambia \(\omega\). Puede ser positiva aunque el sistema “frene”, según el signo de \(\omega\).

## 4) Cambiar el convenio de signos a mitad del ejercicio
Elige sentido positivo y no lo cambies. Si lo cambias, cambian los signos de \(\omega\), \(\alpha\) y \(\Delta\theta\).
