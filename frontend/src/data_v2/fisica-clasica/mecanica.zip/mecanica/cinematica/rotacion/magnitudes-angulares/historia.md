# Historia y contexto

El uso del **radián** se consolidó por ser la unidad “natural” del ángulo: conecta directamente longitud de arco y radio.
Eso hace que muchas relaciones matemáticas y físicas en rotación queden limpias y universales.

La cinemática rotacional se desarrolló en paralelo a la lineal como parte de la mecánica clásica,
y hoy es herramienta estándar en física, ingeniería y control de sistemas.
