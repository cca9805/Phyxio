# Modelo y validez (magnitudes angulares)

## Suposiciones del modelo
- Rotación alrededor de un **eje fijo**.
- Se describe el movimiento sin analizar sus causas (sin fuerzas/torques).
- Se trabaja con ángulos en **radianes** (recomendado SI).

## Dominio de validez
Este enfoque es apropiado cuando:
- el objeto puede tratarse como cuerpo rígido,
- el eje de giro está bien definido,
- y basta con describir “cómo gira” (cinemática) sin entrar aún en “por qué gira” (dinámica).

## Limitaciones
- Si el eje cambia con el tiempo o hay deformaciones apreciables, el modelo requiere ampliaciones.
- Mezclar grados sin conversión puede llevar a errores sistemáticos.
