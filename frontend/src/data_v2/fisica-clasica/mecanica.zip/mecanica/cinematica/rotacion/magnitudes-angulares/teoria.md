# Magnitudes angulares

## Idea clave
Las magnitudes angulares describen el movimiento de rotación alrededor de un eje de forma análoga
a como las magnitudes lineales describen el movimiento rectilíneo.

Trabajaremos con:
- **posición angular**: \(\theta\)
- **desplazamiento angular**: \(\Delta\theta\)
- **velocidad angular**: \(\omega\)
- **aceleración angular**: \(\alpha\)

> Importante: usa **radianes**. La física “habla en rad”.

---

## Variables y unidades
- \(\theta, \theta_0, \Delta\theta\) en rad
- \(\omega, \omega_0\) en rad/s
- \(\alpha\) en rad/s²
- \(t, \Delta t\) en s

---

## Fórmulas fundamentales (todas, aunque no todas sean calculables)

### 1) Desplazamiento angular (calculable)
$$
\Delta\theta = \theta - \theta_0
$$

### 2) Velocidad angular media (calculable)
$$
\omega_{\text{med}} = \frac{\Delta\theta}{\Delta t}
$$

### 3) Definición de velocidad angular (NO calculable directa)
$$
\omega = \frac{d\theta}{dt}
$$
Esta ecuación es **definicional y diferencial**: para obtener números necesitas conocer \(\theta(t)\) o medir \(\theta\) en el tiempo.

### 4) Aceleración angular media (calculable)
$$
\alpha_{\text{med}} = \frac{\Delta\omega}{\Delta t}
$$

### 5) Definición de aceleración angular (NO calculable directa)
$$
\alpha = \frac{d\omega}{dt}
$$
También es una definición diferencial.

---

## Modelo típico cuando \(\alpha\) es constante (calculable)
Cuando la aceleración angular es constante:
$$
\omega(t) = \omega_0 + \alpha t
$$
$$
\theta(t) = \theta_0 + \omega_0 t + \tfrac{1}{2}\alpha t^2
$$

---

## Relación integral general (NO calculable automática)
En el caso general:
$$
\theta(t) = \theta_0 + \int_0^t \omega(t')\,dt'
$$
No es calculable automáticamente sin un modelo explícito para \(\omega(t)\) o sin integración numérica.

---

## Convenio de signos (para no fallar)
1. Elige un sentido positivo de giro.
2. Manténlo en todo el problema.
3. El signo de \(\omega\) indica sentido de giro; el de \(\alpha\) indica cómo cambia \(\omega\).
