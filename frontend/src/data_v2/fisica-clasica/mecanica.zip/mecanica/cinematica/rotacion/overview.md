## Qué aprenderás
- A describir movimientos de rotación.
- A trabajar con magnitudes angulares.
- A relacionar rotación y traslación.

## Qué encontrarás aquí
- Posición, velocidad y aceleración angular.
- Relación entre magnitudes lineales y angulares.
- Introducción a la rodadura sin deslizamiento.

## Conexiones
- Puente entre cinemática y dinámica rotacional.
- Presente en sistemas mecánicos reales.
