# Aplicaciones

- Diseño de ruedas, poleas y engranajes: convertir ω (motor) en v_t (cinta, correa, rueda).
- Seguridad y límites: a_n crece con ω², por eso velocidades altas disparan cargas y exigencias.
- MCU/MCUA: traducción directa entre lo angular y lo lineal.
- Ingeniería: dimensionado de rotores y discos (cinemática antes de dinámica).
