# Ejemplos

## 1) Arco recorrido
Un punto a r = 0,40 m gira θ = 5 rad.

s = rθ = 0,40·5 = 2,0 m

## 2) Velocidad tangencial
Una rueda gira con ω = 12 rad/s y r = 0,25 m.

v_t = ωr = 12·0,25 = 3,0 m/s

## 3) Aceleración normal (centrípeta)
En MCU con ω = 10 rad/s y r = 0,30 m:

a_n = ω² r = 100·0,30 = 30 m/s²

## 4) Aceleración tangencial
Si α = 4 rad/s² y r = 0,50 m:

a_t = αr = 4·0,50 = 2,0 m/s²
