# Errores comunes

1) Usar θ en grados en s = rθ.
- Debe estar en radianes.

2) Confundir v (módulo) con v_t.
- En movimiento circular la relación directa es con la componente tangencial.

3) Creer que en MCU “no hay aceleración”.
- En MCU: a_t = 0, pero a_n = ω²r ≠ 0.

4) Perder r.
- r no es “detalle”: escala linealmente v_t y a_t, y también a_n.

5) Aplicar fórmulas escalares cuando el eje no es fijo.
- En ese caso el modelo vectorial es el correcto.
