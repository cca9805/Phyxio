# Historia y contexto

El radián se adopta por ser la unidad natural que hace que s = rθ sea una identidad geométrica.
Eso conecta de forma directa el mundo angular con el lineal y simplifica toda la mecánica de rotación.

La separación en componentes tangencial y normal se consolidó con el estudio sistemático
del movimiento circular y es base de la física e ingeniería modernas.
