# Modelos (relación lineal–angular)

## Modelo escalar (eje fijo, r constante)
Es el modelo operativo típico:
- el eje es fijo,
- el punto está a distancia r constante,
- se trabaja con magnitudes escalares (módulos).

Bajo estas hipótesis:
- s = rθ
- v_t = ωr
- a_t = αr
- a_n = ω²r

## Modelo vectorial (completo)
Cuando importan direcciones y ejes:
- se usa v = ω×r
- a = α×r + ω×(ω×r)

Este modelo es más general, pero exige vectores.
