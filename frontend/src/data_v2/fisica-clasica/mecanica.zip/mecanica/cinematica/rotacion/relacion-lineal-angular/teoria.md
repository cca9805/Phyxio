# Relación lineal–angular

## Idea clave
Cuando un punto de un cuerpo gira a una distancia **r** de un eje,
su movimiento lineal “hereda” el movimiento angular del sistema.

La relación entre magnitudes lineales y angulares funciona bien cuando:
- hay un eje de giro claro,
- r es conocido,
- y los ángulos se miden en **radianes**.

---

## 1) Arco y ángulo
Si un punto recorre un arco de circunferencia **s** al girar un ángulo **θ**:

$$
s = r\,\theta
$$

Esto exige que θ esté en **rad**. Con grados no funciona directamente.

---

## 2) Velocidad: lineal vs angular
La velocidad lineal relevante en rotación es la **tangencial**:

$$
v_t = \omega\,r
$$

- ω se mide en rad/s
- v_t en m/s
- r en m

Si r aumenta, el punto “va más rápido” aunque ω sea la misma.

---

## 3) Aceleración: dos piezas (tangencial y normal)
En movimiento circular, la aceleración total suele descomponerse:

### Aceleración tangencial (cambia el módulo de la velocidad)
$$
a_t = \alpha\,r
$$

### Aceleración normal o centrípeta (cambia la dirección)
$$
a_n = \omega^2\,r
$$

En MCU: α = 0 ⇒ a_t = 0, pero a_n ≠ 0.

---

## 4) Fórmulas vectoriales (más generales)
Para un tratamiento completo (direcciones incluidas) se usan relaciones vectoriales:

$$
\vec v = \vec\omega \times \vec r
$$

$$
\vec a = \vec\alpha \times \vec r + \vec\omega \times(\vec\omega \times \vec r)
$$

Estas fórmulas son **descriptivas**: requieren vectores y producto vectorial,
por eso un motor algebraico escalar no las resuelve directamente.

---

## 5) Advertencia con r
Si el punto cambia su distancia al eje (r variable), o el eje no es fijo,
las expresiones escalares simples requieren cuidado y el modelo vectorial se vuelve imprescindible.

---

## 6) Conexiones
- MCU / MCUA: aquí está el “puente” entre lo angular y lo lineal.
- Dinámica rotacional: torque cambia ω, y por tanto cambia v_t.
- Rodadura: conecta ω con v del centro de masas (cuando toque).
