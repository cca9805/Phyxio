# Aplicaciones

- Ruedas de vehículos: relación directa entre giro del motor/transmisión y velocidad de avance.
- Rodillos y cintas transportadoras.
- Robótica móvil: odometría (estimación de distancia por θ y R).
- Ingeniería: análisis de contacto y desgaste cuando aparece deslizamiento.
