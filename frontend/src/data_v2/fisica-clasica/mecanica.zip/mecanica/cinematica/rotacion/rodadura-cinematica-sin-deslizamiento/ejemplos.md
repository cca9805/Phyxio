# Ejemplos

## 1) De ω a v_cm
R = 0,30 m, ω = 12 rad/s.

v_cm = ωR = 12·0,30 = 3,6 m/s

## 2) De avance a giro
R = 0,25 m, x = 5 m.

θ = x/R = 5 / 0,25 = 20 rad

## 3) Aceleración del centro desde α
R = 0,40 m, α = 2,5 rad/s².

a_cm = αR = 2,5·0,40 = 1,0 m/s²

## 4) Velocidad del punto superior
Si v_cm = 4 m/s, entonces v_arriba = 8 m/s (rodadura pura).
