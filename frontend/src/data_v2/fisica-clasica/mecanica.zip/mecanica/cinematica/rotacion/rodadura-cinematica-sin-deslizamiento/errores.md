# Errores comunes

1) Aplicar v_cm = ωR cuando hay deslizamiento.
- Si patina, introduce v_slip y trabaja con v_slip = v_cm − ωR.

2) Creer que el punto de contacto está “parado siempre”.
- Solo está instantáneamente en reposo respecto al suelo; al instante siguiente es otro punto.

3) Confundir “rueda gira” con “rueda avanza”.
- Sin la condición de rodadura pura, giro y avance se desacoplan.

4) Usar grados en x = Rθ.
- θ debe estar en radianes.

5) Olvidar que v_arriba = 2v_cm solo en rodadura pura.
