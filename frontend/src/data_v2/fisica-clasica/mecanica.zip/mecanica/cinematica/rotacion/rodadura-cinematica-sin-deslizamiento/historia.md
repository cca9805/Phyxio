# Historia y contexto

La rodadura pura es un ejemplo clásico de restricción cinemática: impone una condición geométrica
que conecta traslación y rotación. Es un caso base en física e ingeniería porque permite modelizar
ruedas y cilindros con ecuaciones simples, y entender cuándo esas ecuaciones fallan (deslizamiento).
