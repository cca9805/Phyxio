# Modelos (rodadura sin deslizamiento)

## Modelo 1: rodadura pura sobre recta
Supuestos:
- superficie rígida
- rueda rígida
- contacto puntual (ideal)
- no hay deslizamiento: v_contacto = 0

Consecuencias operativas:
- x = Rθ
- v_cm = ωR
- a_cm = αR
- v_arriba = 2v_cm

## Modelo 2: deslizamiento (slip)
Si hay patinaje:
- v_slip ≠ 0
- NO vale v_cm = ωR como condición

En dinámica esto se decide por fricción: estática (rodadura pura) vs cinética (deslizamiento).
