# Rodadura sin deslizamiento

## Idea clave
Un cuerpo (rueda, cilindro, esfera) puede moverse combinando:
- **traslación** del centro de masas (CM), con velocidad [[vcm]]
- **rotación** alrededor de su eje

La **rodadura sin deslizamiento** (rodadura pura) impone una condición cinemática:

> El punto de contacto con el suelo tiene **velocidad instantánea cero** respecto al suelo.

Eso no significa que el punto “esté pegado”: significa que, en ese instante, su velocidad es cero.

---

## Condición de rodadura pura
Para una rueda de radio R rodando sobre una línea recta:

$$
v_{\text{contacto}} = 0
$$

De esta condición se deduce una relación fundamental (en módulo):

$$
v_{cm} = \omega R
$$

Y si hay aceleración angular:

$$
a_{cm} = \alpha R
$$

Además, el avance y el giro se relacionan:

$$
x = R\theta
$$

---

## Velocidad de puntos de la rueda (explicación física)
Para un punto cualquiera del borde, la velocidad (vectorial) es:

$$
\vec v = \vec v_{cm} + \vec\omega \times \vec r
$$

En rodadura pura sobre suelo:
- El **punto inferior** (contacto) tiene \(v=0\).
- El **centro** tiene \(v=v_{cm}\).
- El **punto superior** tiene:

$$
v_{\text{arriba}} = v_{cm} + \omega R = 2v_{cm}
$$

Esto es una propiedad muy útil: en rodadura pura, la parte de arriba va al doble de la velocidad del centro.

---

## ¿Qué pasa si hay deslizamiento?
Si el punto de contacto NO tiene velocidad cero, hay **deslizamiento** (slip):

$$
v_{\text{contacto}} \neq 0
$$

Entonces:
- ya no vale \(v_{cm} = \omega R\) como condición
- puede haber “patinaje”: gira mucho y avanza poco (o al revés)

En dinámica, la fricción (estática o cinética) decide si se cumple la rodadura pura.

---

## Qué es calculable y qué no
- Las relaciones escalares \(v_{cm} = \omega R\), \(x = R\theta\), \(a_{cm} = \alpha R\)
  son **calculables**.
- Las expresiones vectoriales con productos cruzados son **descriptivas**
  (necesitan direcciones y componentes), por eso se marcan como no calculables.
