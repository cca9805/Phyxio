﻿# Maquinas simples

Las maquinas simples permiten transformar fuerzas y desplazamientos para facilitar tareas mecanicas.
En este bloque trabajaras sobre palancas, poleas y planos inclinados con enfoque de dinamica aplicada.

## Que aprenderas
- Relacion entre fuerza aplicada, brazo y momento.
- Ventaja mecanica ideal y sus limites en sistemas reales.
- Criterios para elegir una maquina simple segun el problema.
- Lectura de modelos y calculadoras con unidades coherentes.

## Que encontraras aqui
- Teoria conceptual y formulas operativas.
- Calculadora con despejes directos.
- Graficos Coord/Svg segun el Tema.
- Ejemplos, aplicaciones, errores tipicos e historia.

## Conexion con otros bloques
- Equilibrio de fuerzas y momentos.
- Torque y momento de inercia en dinamica rotacional.
- Rozamiento y eficiencia energetica.
