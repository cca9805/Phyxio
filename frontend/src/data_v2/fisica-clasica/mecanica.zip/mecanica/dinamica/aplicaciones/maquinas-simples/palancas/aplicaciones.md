﻿# Palancas - Aplicaciones

- Tijeras, alicates y cizallas.
- Carretilla y abrebotellas.
- Pinzas y antebrazo humano.
- Barras de uña y palancas de rescate.
- Herramientas de mantenimiento industrial.
