﻿# Palancas - Ejemplos

## Ejemplo 1
\(R=300\,\text{N}\), \(b_R=0.2\,\text{m}\), \(b_P=0.8\,\text{m}\):
\[
P = \frac{R b_R}{b_P} = \frac{300\cdot0.2}{0.8}=75\,\text{N}
\]

## Ejemplo 2
\(P=120\,\text{N}\), \(b_P=0.6\,\text{m}\), \(b_R=0.3\,\text{m}\):
\[
R = \frac{P b_P}{b_R} = \frac{120\cdot0.6}{0.3}=240\,\text{N}
\]

## Ejemplo 3
Si \(b_P/b_R=3\), entonces \(VM=3\): la carga ideal es triple que la fuerza aplicada.
