﻿# Palancas - Errores tipicos

- Confundir brazo con longitud total de la barra.
- Medir brazos sin referencia al fulcro.
- Mezclar unidades (cm con m) en la misma operacion.
- Olvidar que la formula ideal no incluye perdidas por friccion.
- Pensar que siempre se gana fuerza en cualquier tipo de palanca.
