﻿# Palancas - Historia

El estudio de palancas se remonta a la mecanica clasica antigua, con
formulaciones atribuidas a Arquimedes sobre equilibrio y momentos.

Con la ingenieria moderna, las palancas se convirtieron en base de diseno
para herramientas, maquinaria y biomecanica aplicada.
