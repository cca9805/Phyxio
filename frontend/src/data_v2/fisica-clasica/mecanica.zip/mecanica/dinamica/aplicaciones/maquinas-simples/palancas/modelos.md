﻿# Palancas - Modelos

- Modelo ideal de barra rigida con fulcro puntual.
- Modelo estatico en equilibrio de momentos.
- Modelo de ventaja mecanica ideal VM.
- Extensiones con eficiencia mecanica real.
