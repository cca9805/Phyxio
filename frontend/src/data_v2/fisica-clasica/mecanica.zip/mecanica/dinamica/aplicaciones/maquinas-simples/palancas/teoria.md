﻿# Palancas

## Idea clave
Una palanca funciona por equilibrio de momentos respecto al fulcro.
Si aumentas el brazo de potencia, reduces la fuerza necesaria para mover la carga.

## Formula principal
\[
P\,b_P = R\,b_R
\]

De aqui:
\[
P = \frac{R b_R}{b_P}
\]

## Ventaja mecanica ideal
\[
VM = \frac{R}{P} = \frac{b_P}{b_R}
\]

- Si \(VM>1\), la palanca multiplica fuerza.
- Si \(VM<1\), ganas velocidad/desplazamiento pero no fuerza.

## Tipos de palancas
- Primer genero: fulcro entre potencia y resistencia.
- Segundo genero: resistencia entre fulcro y potencia.
- Tercer genero: potencia entre fulcro y resistencia.
