﻿# Planos inclinados - Aplicaciones

- Rampas de carga y descarga.
- Carreteras y vias con pendiente.
- Cintas y toboganes industriales.
- Diseno de superficies para control de deslizamiento.
- Analisis de frenos y adherencia en vehiculos.
