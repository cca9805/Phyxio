﻿# Planos inclinados - Ejemplos

## Ejemplo 1 (sin rozamiento)
\(\theta=30^\circ\), \(g=9.8\,\text{m/s}^2\):
\[
a = g\sin\theta = 9.8\cdot0.5 = 4.9\,\text{m/s}^2
\]

## Ejemplo 2 (con rozamiento)
\(\theta=35^\circ\), \(\mu=0.2\):
\[
a = g(\sin35^\circ-0.2\cos35^\circ)\approx 4.0\,\text{m/s}^2
\]

## Ejemplo 3 (normal)
\(m=10\,\text{kg}\), \(\theta=40^\circ\):
\[
N = mg\cos\theta \approx 10\cdot9.8\cdot0.766 \approx 75.1\,\text{N}
\]
