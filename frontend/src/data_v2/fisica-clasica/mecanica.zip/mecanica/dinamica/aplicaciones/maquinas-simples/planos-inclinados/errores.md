﻿# Planos inclinados - Errores tipicos

- Intercambiar seno y coseno en la descomposicion del peso.
- Olvidar que la normal es menor que el peso salvo theta=0.
- Aplicar rozamiento en sentido incorrecto respecto al movimiento relativo.
- Usar grados en calculadora configurada en radianes.
- Confundir bloque "en equilibrio" con "sin rozamiento".
