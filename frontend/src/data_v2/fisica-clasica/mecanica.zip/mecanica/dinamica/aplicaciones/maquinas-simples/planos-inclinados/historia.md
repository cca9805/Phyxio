﻿# Planos inclinados - Historia

Los planos inclinados fueron una de las primeras maquinas simples estudiadas
sistematicamente en mecanica clasica para entender intercambio fuerza-desplazamiento.

Su analisis ayudo a consolidar la descomposicion vectorial de fuerzas y las leyes
newtonianas aplicadas a sistemas con contacto y friccion.
