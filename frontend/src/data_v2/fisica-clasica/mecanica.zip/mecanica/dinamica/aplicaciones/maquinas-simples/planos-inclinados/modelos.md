﻿# Planos inclinados - Modelos

- Modelo ideal sin rozamiento: a = g sin(theta).
- Modelo con rozamiento cinetico: a = g(sin(theta)-mu cos(theta)).
- Modelo de equilibrio limite con rozamiento estatico.
- Representaciones Coord, Dcl y Svg para conectar algebra y fisica.
