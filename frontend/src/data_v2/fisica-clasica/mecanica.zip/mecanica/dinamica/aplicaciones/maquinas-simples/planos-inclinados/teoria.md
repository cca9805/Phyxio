﻿# Planos inclinados

## Idea clave
En un plano inclinado, el peso se descompone en una componente que empuja al bloque
por el plano y otra que lo comprime contra la superficie.

## Componentes del peso
\[
W_{\parallel}=mg\sin\theta,\qquad W_{\perp}=mg\cos\theta
\]

## Sin rozamiento
\[
a = g\sin\theta
\]

## Con rozamiento
\[
N = mg\cos\theta,\quad f=\mu N
\]
\[
F_{net}=mg\sin\theta-\mu mg\cos\theta
\]
\[
a=g(\sin\theta-\mu\cos\theta)
\]

El signo de \(a\) indica el sentido neto del movimiento en el eje elegido.
