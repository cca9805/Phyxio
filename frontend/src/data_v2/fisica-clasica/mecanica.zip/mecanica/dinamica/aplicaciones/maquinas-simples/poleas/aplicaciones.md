﻿# Poleas - Aplicaciones

- Gruas y polipastos industriales.
- Talleres de elevacion y mantenimiento.
- Sistemas de rescate y montanismo.
- Mecanismos de escenario y carga escenica.
- Maniobras navales con aparejos.
