﻿# Poleas - Ejemplos

## Ejemplo 1 (ideal)
Carga \(R=600\,\text{N}\) con \(n=3\):
\[
P = \frac{600}{3}=200\,\text{N}
\]

## Ejemplo 2 (con eficiencia)
\(R=600\,\text{N}\), \(n=3\), \(\eta=0.8\):
\[
P = \frac{600}{3\cdot0.8}=250\,\text{N}
\]

## Ejemplo 3 (desplazamiento)
Si \(n=4\) y elevas la carga \(s_R=0.5\,\text{m}\):
\[
s_P = 4\cdot0.5 = 2\,\text{m}
\]
Debes tirar 2 m de cuerda.
