﻿# Poleas - Errores tipicos

- Contar mal los tramos que realmente sostienen la carga.
- Suponer eficiencia 100% en sistemas reales.
- Confundir tension con fuerza total aplicada.
- Olvidar relacion de desplazamientos (s_P = n s_R).
- Mezclar unidades al convertir masa a peso (N).
