﻿# Poleas - Historia

Las poleas se usan desde la antiguedad para elevar cargas en construccion y navegacion.
El analisis formal de su ventaja mecanica se consolido con la mecanica clasica,
integrando conceptos de fuerza, tension y trabajo.
