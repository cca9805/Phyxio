﻿# Poleas - Modelos

- Polea fija: cambia direccion de la fuerza.
- Polea movil: reduce fuerza necesaria.
- Polipasto compuesto: combina varias poleas y tramos de cuerda.
- Modelo ideal vs modelo con eficiencia global.
