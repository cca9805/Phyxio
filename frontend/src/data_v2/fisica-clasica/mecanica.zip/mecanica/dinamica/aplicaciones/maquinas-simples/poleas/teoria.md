﻿# Poleas

## Idea clave
Las poleas reducen la fuerza necesaria para levantar una carga al repartir la tension
entre varios tramos de cuerda que sostienen el sistema movil.

## Formula principal (ideal)
\[
P = \frac{R}{n}
\]

Donde \(n\) es el numero de tramos que soportan la carga.

## Con eficiencia
\[
P = \frac{R}{n\eta}
\]
con \(0<\eta\le 1\).

## Ventaja mecanica
\[
VM = \frac{R}{P} = n\eta
\]

## Intercambio fuerza-desplazamiento
Si ganas fuerza, recorres mas cuerda:
\[
s_P = n\,s_R
\]
