﻿# Errores frecuentes - Aplicaciones

- Preparacion de exámenes de fisica.
- Revision de soluciones en clase.
- Autoevaluacion en simuladores y calculadoras.
- Entrenamiento de rapidez sin perder rigor.
