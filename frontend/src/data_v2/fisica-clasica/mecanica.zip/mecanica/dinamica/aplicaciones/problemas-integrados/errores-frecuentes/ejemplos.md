﻿# Errores frecuentes - Ejemplos

## Ejemplo 1: seno/coseno invertidos
Problema de plano inclinado con \(\theta=35^\circ\).
Si intercambias \(\sin\theta\) y \(\cos\theta\), el error en \(a\) puede ser grande,
especialmente en angulos pequenos o medios.

## Ejemplo 2: olvidar rozamiento
En presencia de \(\mu>0\), usar modelo sin rozamiento sobreestima la aceleracion.

## Ejemplo 3: signo incorrecto
Tomar \(F_{loss}\) con signo positivo en el eje de avance puede convertir un frenado en aceleracion falsa.
