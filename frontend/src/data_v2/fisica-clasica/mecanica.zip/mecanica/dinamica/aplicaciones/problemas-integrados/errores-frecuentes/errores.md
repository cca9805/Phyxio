﻿# Errores frecuentes - Errores tipicos

- No especificar eje positivo.
- Mezclar magnitudes escalares y vectoriales sin criterio.
- Sustituir datos en unidades incorrectas.
- Arrastrar redondeos prematuros.
- No comparar resultado con intuicion fisica minima.
