﻿# Errores frecuentes - Historia

La didactica de la fisica incorporó de forma sistematica el analisis de errores
para mejorar razonamiento cientifico y no solo resultados numericos.

En evaluacion moderna, justificar el modelo correcto suele pesar tanto como el valor final.
