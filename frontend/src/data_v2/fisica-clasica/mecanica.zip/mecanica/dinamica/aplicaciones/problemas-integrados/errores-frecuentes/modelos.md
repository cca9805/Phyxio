﻿# Errores frecuentes - Modelos

- Modelo correcto de referencia.
- Modelo con error de descomposicion trigonometrica.
- Modelo sin rozamiento para comparar sesgo.
- Analisis de error absoluto y relativo.
