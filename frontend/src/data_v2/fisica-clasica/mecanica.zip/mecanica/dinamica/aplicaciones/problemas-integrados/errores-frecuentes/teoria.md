﻿# Errores frecuentes

## Idea clave
En dinamica, los errores que mas penalizan suelen ser de planteamiento:
- ejes mal definidos,
- signos inconsistentes,
- confundir seno/coseno,
- omitir fuerzas relevantes.

## Checklist rapido
1. Define ejes antes de escribir fuerzas.
2. Dibuja DCL.
3. Comprueba unidades en cada ecuacion.
4. Revisa si el signo fisico del resultado tiene sentido.
5. Estima orden de magnitud para detectar absurdos.

## Formula de referencia (plano con rozamiento)
\[
a=\frac{F-mg\sin\theta-\mu mg\cos\theta}{m}
\]
