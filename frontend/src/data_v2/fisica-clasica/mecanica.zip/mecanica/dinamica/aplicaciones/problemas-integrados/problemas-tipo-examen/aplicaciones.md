﻿# Problemas tipo examen - Aplicaciones

- Preparacion de pruebas de acceso y evaluaciones parciales.
- Entrenamiento en resolucion rapida con datos incompletos.
- Simulacion de escenarios mecanicos realistas bajo tiempo.
- Autoevaluacion de errores de planteamiento y de calculo.
