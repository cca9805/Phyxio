﻿# Problemas tipo examen - Ejemplos

## Ejemplo 1
Bloque en plano inclinado con fuerza aplicada paralela al plano.
Datos: \(m=5\,\text{kg}\), \(\theta=30^\circ\), \(\mu=0.2\), \(F=60\,\text{N}\).

Se calcula:
\[
F_{net}=F-mg\sin\theta-\mu mg\cos\theta
\]
\[
a=\frac{F_{net}}{m}
\]

## Ejemplo 2
Con \(a\) conocida, obtener desplazamiento en \(t=4\,\text{s}\):
\[
x=\frac{1}{2}at^2
\]

## Ejemplo 3
Analiza sensibilidad de \(a\) cuando aumenta \(\mu\):
- mayor \(\mu\) -> menor \(F_{net}\) -> menor \(a\).
