﻿# Problemas tipo examen - Errores tipicos

- Elegir mal el signo de la componente del peso.
- Omitir la normal al calcular rozamiento.
- Confundir masa (kg) con peso (N).
- Resolver cinemática sin comprobar que la aceleracion es constante.
- No justificar pasos intermedios y perder trazabilidad.
