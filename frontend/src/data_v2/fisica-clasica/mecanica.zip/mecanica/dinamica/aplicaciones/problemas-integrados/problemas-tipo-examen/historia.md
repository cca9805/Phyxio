﻿# Problemas tipo examen - Historia

La enseñanza de mecanica por problemas tipo examen surge para evaluar no solo memoria,
sino capacidad de modelizacion y argumentacion fisica bajo restricciones de tiempo.

Con herramientas digitales, estos problemas se complementan con visualizacion de
curvas y escenas para reforzar la comprension conceptual.
