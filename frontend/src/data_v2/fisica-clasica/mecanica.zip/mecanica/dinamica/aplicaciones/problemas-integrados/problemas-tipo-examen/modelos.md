﻿# Problemas tipo examen - Modelos

- Modelo base: bloque sobre plano inclinado con rozamiento.
- Modelo extendido: fuerza aplicada en angulo y normal modificada.
- Modelo cinemático: aceleracion constante tras obtener F_net.
- Modelo de sensibilidad: variacion de parametros \(\mu\), \(\theta\), \(F\).
