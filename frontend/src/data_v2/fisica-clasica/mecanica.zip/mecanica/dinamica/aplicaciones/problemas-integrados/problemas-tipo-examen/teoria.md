﻿# Problemas tipo examen

## Estrategia de resolucion
1. Dibuja el esquema y define ejes.
2. Haz el DCL y escribe fuerzas por ejes.
3. Aplica Newton para obtener \(a\).
4. Usa cinematica para \(v\) y \(x\) si procede.
5. Verifica unidades, signos y orden de magnitud.

## Modelo frecuente
\[
F_{net}=F-mg\sin\theta-\mu mg\cos\theta
\]
\[
a=\frac{F_{net}}{m}
\]
\[
v=at,\qquad x=\frac{1}{2}at^2
\]

## Consejo de examen
Mantén notacion limpia y no mezcles ecuaciones de distintos ejes sin explicitarlo.
