﻿# Sistemas reales - Aplicaciones

- Vehiculos con perdidas mecanicas y aerodinamicas.
- Motores electricos y transmisiones.
- Cintas transportadoras y sistemas industriales.
- Robotica movil en entorno no ideal.
- Analisis de rendimiento energetico en maquinaria.
