﻿# Sistemas reales - Ejemplos

## Ejemplo 1
\(m=20\,\text{kg}\), \(F_{ap}=120\,\text{N}\), \(F_{loss}=30\,\text{N}\):
\[
a=\frac{120-30}{20}=4.5\,\text{m/s}^2
\]

## Ejemplo 2
\(P_{in}=1000\,\text{W}\), \(\eta=0.78\):
\[
P_{out}=\eta P_{in}=780\,\text{W}
\]

## Ejemplo 3
\(m=50\,\text{kg}\), \(v=6\,\text{m/s}\):
\[
K=\frac{1}{2}mv^2=900\,\text{J}
\]
