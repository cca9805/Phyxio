﻿# Sistemas reales - Errores tipicos

- Usar formulas ideales sin incluir perdidas.
- Tomar eficiencia mayor que 1.
- Confundir fuerza neta con fuerza aplicada.
- Olvidar unidades coherentes de potencia y energia.
- Suponer aceleracion constante sin justificarlo.
