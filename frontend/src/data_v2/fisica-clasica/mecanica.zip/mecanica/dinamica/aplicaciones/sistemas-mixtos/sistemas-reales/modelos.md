﻿# Sistemas reales - Modelos

- Modelo ideal (sin perdidas) como referencia.
- Modelo con fuerza de perdidas equivalente.
- Modelo energetico con eficiencia global.
- Curvas de rendimiento en funcion de parametros operativos.
