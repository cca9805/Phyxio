﻿# Sistemas reales

## Idea clave
Los sistemas reales no son ideales: aparecen perdidas por rozamiento, resistencia del medio
y conversiones energeticas incompletas.

## Modelo de trabajo
\[
F_{net}=F_{ap}-F_{loss}
\]
\[
a=\frac{F_{ap}-F_{loss}}{m}
\]

## Eficiencia
\[
\eta=\frac{P_{out}}{P_{in}}
\]

Con \(\eta<1\), parte de la energia suministrada no se transforma en trabajo util.

## Consecuencia practica
A igualdad de fuerza aplicada, un sistema con mayores perdidas acelera menos
y alcanza peores prestaciones.
