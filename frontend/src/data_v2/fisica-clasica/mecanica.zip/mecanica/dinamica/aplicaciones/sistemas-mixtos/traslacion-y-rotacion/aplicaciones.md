﻿# Traslacion y rotacion - Aplicaciones

- Ruedas de vehiculos y bicicletas.
- Rodillos y cintas en industria.
- Esferas y cilindros en planos inclinados.
- Diseno de volantes de inercia.
- Robotica movil con ruedas.
