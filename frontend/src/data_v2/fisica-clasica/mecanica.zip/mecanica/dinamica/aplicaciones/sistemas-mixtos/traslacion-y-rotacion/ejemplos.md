﻿# Traslacion y rotacion - Ejemplos

## Ejemplo 1 (rodadura)
Si \(R=0.3\,\text{m}\) y \(\omega=10\,\text{rad/s}\):
\[
v=\omega R=3\,\text{m/s}
\]

## Ejemplo 2 (aceleraciones)
Con \(a=1.2\,\text{m/s}^2\) y \(R=0.4\,\text{m}\):
\[
\alpha=\frac{a}{R}=3\,\text{rad/s}^2
\]

## Ejemplo 3 (energia)
\(m=2\,\text{kg}\), \(v=4\,\text{m/s}\), \(I=0.1\,\text{kg·m}^2\), \(\omega=8\,\text{rad/s}\):
\[
K_t=16\,\text{J},\quad K_r=3.2\,\text{J},\quad K=19.2\,\text{J}
\]
