﻿# Traslacion y rotacion - Errores tipicos

- Aplicar v = omega R cuando hay deslizamiento.
- Confundir velocidad del centro de masas con velocidad de un punto del borde.
- Olvidar termino rotacional en la energia total.
- Mezclar eje de torque y eje de traslacion sin consistencia.
- Usar I de una geometria que no corresponde al cuerpo.
