﻿# Traslacion y rotacion - Historia

El estudio unificado de traslacion y rotacion se consolidó en la mecanica clasica
al introducir el momento de inercia y las ecuaciones de Newton-Euler.

Este enfoque permitio modelar de forma realista ruedas, engranajes y sistemas
tecnologicos donde se acoplan movimiento lineal y angular.
