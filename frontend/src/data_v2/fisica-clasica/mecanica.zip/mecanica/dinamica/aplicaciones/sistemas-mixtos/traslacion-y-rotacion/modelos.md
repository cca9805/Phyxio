﻿# Traslacion y rotacion - Modelos

- Rodadura ideal sin deslizamiento.
- Rodadura con perdidas por friccion.
- Cuerpo rigido con fuerza neta y torque neto simultaneos.
- Reparto energetico traslacional/rotacional.
