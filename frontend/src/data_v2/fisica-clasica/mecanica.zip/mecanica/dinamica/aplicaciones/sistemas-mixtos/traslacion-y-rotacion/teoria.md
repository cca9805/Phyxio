﻿# Traslacion y rotacion

## Idea clave
En sistemas mixtos, el cuerpo se desplaza y gira simultaneamente.
Esto acopla variables lineales y angulares.

## Rodadura sin deslizamiento
\[
v=\omega R
\]
\[
a=\alpha R
\]

## Dinamica
\[
F=ma,\qquad \tau=I\alpha
\]

## Energia
\[
K=\frac{1}{2}mv^2+\frac{1}{2}I\omega^2
\]

La energia total se reparte entre traslacion y rotacion.
