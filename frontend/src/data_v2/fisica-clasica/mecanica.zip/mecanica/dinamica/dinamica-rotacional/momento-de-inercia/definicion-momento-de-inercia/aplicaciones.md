# Definicion · Aplicaciones

- Volantes de inercia: masas grandes distribuidas lejos del eje para estabilizar giros.
- Puertas: mayor resistencia a girar cuando se empuja cerca de las bisagras.
- Patinadores: variar I acercando o alejando los brazos del eje.
- Diseño de ruedas, discos y engranajes.
