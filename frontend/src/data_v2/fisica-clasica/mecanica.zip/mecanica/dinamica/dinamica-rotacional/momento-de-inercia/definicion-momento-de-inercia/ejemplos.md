# Definicion · Ejemplos

### Ejemplo conceptual

Dos discos tienen la misma masa total.
En uno, la masa está concentrada cerca del centro.
En el otro, la masa está distribuida hacia el borde.

El segundo tiene mayor momento de inercia y cuesta más cambiar su velocidad angular,
aunque la masa sea la misma.
