# Definicion · Errores típicos

- Confundir masa con momento de inercia.
- Creer que el momento de inercia es único para un cuerpo (olvidar el eje).
- Pensar que depende solo del material y no de la geometría.
- Usar valores de I sin especificar el eje correspondiente.
