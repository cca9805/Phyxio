# Definicion · Historia

El concepto de momento de inercia surge en el estudio de la rotación de cuerpos rígidos
como extensión natural de la inercia lineal.

Su formalización permitió desarrollar la dinámica rotacional y es fundamental en
ingeniería, física aplicada y mecánica clásica.
