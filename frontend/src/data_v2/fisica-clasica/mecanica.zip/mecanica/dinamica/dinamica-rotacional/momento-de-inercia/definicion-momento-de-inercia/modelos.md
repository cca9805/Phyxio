﻿# Definicion Â· Modelos

Este Tema usa un modelo conceptual de cuerpo rÃ­gido con eje fijo.

El momento de inercia se interpreta como una suma de contribuciones de masa situadas
a distintas distancias del eje.

No se realiza aÃºn cÃ¡lculo detallado ni integraciÃ³n continua: el objetivo es
comprender el significado fÃ­sico de I y su dependencia del eje y de la distribuciÃ³n
de masa.
