## ¿Qué es el momento de inercia?

El **momento de inercia** mide la resistencia de un cuerpo a cambiar su estado de
rotación alrededor de un eje.

Es el análogo rotacional de la masa en traslación:
- la masa mide “lo difícil que es acelerar un cuerpo en línea recta”
- el momento de inercia mide “lo difícil que es acelerar un cuerpo al girar”

---

## Dependencia del eje y de la distribución de masa

El momento de inercia **no depende solo de cuánta masa hay**, sino de **cómo está
distribuida respecto al eje de giro**.

Dos cuerpos con la misma masa:
- pueden tener momentos de inercia muy distintos
- dependiendo de si la masa está cerca o lejos del eje

Cuanto más lejos esté la masa del eje:
- mayor es el momento de inercia
- más cuesta cambiar el estado de rotación

---

## Papel en la dinámica rotacional

En la ecuación fundamental:

Στ = I·α

el momento de inercia:
- conecta el torque aplicado con la aceleración angular
- determina cuán sensible es el sistema al torque

A mayor I, menor α para el mismo Στ.

---

## Idea clave

El momento de inercia **no es una propiedad absoluta del cuerpo**, sino una propiedad
del **cuerpo respecto a un eje concreto**.
