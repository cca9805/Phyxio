# Momentos Tipicos · Aplicaciones

- Ruedas y discos en máquinas.
- Volantes de inercia.
- Puertas y palancas.
- Componentes rotatorios en ingeniería.
