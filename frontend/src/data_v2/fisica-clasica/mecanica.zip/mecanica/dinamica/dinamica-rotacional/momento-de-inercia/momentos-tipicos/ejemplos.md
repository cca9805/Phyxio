# Momentos Tipicos · Ejemplos

### Ejemplo 1
Un disco macizo de masa m y radio R gira alrededor de su eje central.
Su momento de inercia es:
I = (1/2)·m·R²

### Ejemplo 2
Una barra homogénea de longitud L gira alrededor de su centro.
I = (1/12)·m·L²
