# Momentos Tipicos · Errores típicos

- Usar una fórmula con un eje distinto al indicado.
- Confundir radio con diámetro.
- Aplicar un momento típico a un cuerpo no homogéneo.
- Olvidar que el punto material es un caso límite.
