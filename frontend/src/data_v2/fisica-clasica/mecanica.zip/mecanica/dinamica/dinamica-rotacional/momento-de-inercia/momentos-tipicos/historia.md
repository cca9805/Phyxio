# Momentos Tipicos · Historia

El cálculo de momentos de inercia para cuerpos simples permitió el desarrollo
de la dinámica rotacional y la ingeniería clásica, al evitar integrar desde
cero en cada problema.
