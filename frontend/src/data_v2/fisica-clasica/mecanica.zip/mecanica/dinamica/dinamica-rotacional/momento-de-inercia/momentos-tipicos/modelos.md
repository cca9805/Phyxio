# Momentos Tipicos · Modelos

Se consideran cuerpos rígidos homogéneos con distribución continua de masa.

Los valores de momento de inercia se refieren siempre a ejes bien definidos,
normalmente ejes de simetría o ejes que pasan por el centro del cuerpo.

No se contempla:
- deformación
- masa no homogénea
- cambio de eje durante el movimiento
