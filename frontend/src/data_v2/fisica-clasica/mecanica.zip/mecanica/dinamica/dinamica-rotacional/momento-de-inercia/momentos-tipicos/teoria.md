## Momentos de inercia típicos

El **momento de inercia** es la magnitud que mide la resistencia de un cuerpo a
cambiar su estado de rotación alrededor de un eje determinado.

En su forma más general, se define como:

$$
I = \int r^2 \, \mathrm{d}m
$$

donde:
- \( r \) es la distancia de cada elemento de masa al eje de giro,
- \( \mathrm{d}m \) es un elemento diferencial de masa.

Esta expresión muestra que **la contribución de cada parte del cuerpo crece con el
cuadrado de la distancia al eje**, lo que explica por qué la distribución de masa
es tan importante.

Para cuerpos rígidos homogéneos y ejes habituales, esta integral puede resolverse
analíticamente, dando lugar a expresiones conocidas como **momentos de inercia
típicos**, que se usan directamente en problemas de dinámica rotacional.

---

## Punto material

Un **punto material** de masa \( m \) situado a una distancia \( R \) del eje de giro
tiene un momento de inercia:

$$
I = m R^2
$$

Toda la masa está concentrada a la misma distancia del eje, por lo que la resistencia
al giro depende únicamente de:
- la masa,
- la distancia al eje.

Este caso constituye la base conceptual de todos los demás y es especialmente útil:
- cuando el tamaño del cuerpo es despreciable frente a \( R \),
- como elemento básico para construir momentos de inercia más complejos.

---

## Aro fino (eje central)

Un **aro fino** de radio \( R \) y masa \( m \), que gira alrededor de un eje
perpendicular a su plano y que pasa por su centro, tiene:

$$
I = m R^2
$$

Toda la masa del aro se encuentra a la misma distancia del eje, por lo que el resultado
es idéntico al del punto material.

Este caso ilustra una idea clave:
> no importa la forma del cuerpo, sino **cómo está distribuida la masa respecto al eje**.

---

## Disco macizo (eje central)

Para un **disco homogéneo** de radio \( R \) y masa \( m \), girando alrededor de su eje
central perpendicular al plano del disco, el momento de inercia es:

$$
I = \frac{1}{2} m R^2
$$

A diferencia del aro, en el disco:
- parte de la masa está cerca del eje,
- parte está más alejada.

El factor \( \tfrac{1}{2} \) refleja que, en promedio, la masa del disco se encuentra
más cerca del eje que en el caso del aro.

Por ello, para la misma masa y radio:

$$
I_{\text{disco}} < I_{\text{aro}}
$$

---

## Barra homogénea (eje por el centro)

Una **barra homogénea** de longitud \( L \) y masa \( m \), que gira alrededor de un eje
perpendicular a la barra y que pasa por su centro, tiene como momento de inercia:

$$
I = \frac{1}{12} m L^2
$$

La masa está distribuida simétricamente respecto al eje, y los puntos más alejados del
eje son los extremos, situados a una distancia \( L/2 \).

Este resultado aparece con frecuencia en problemas de:
- palancas,
- vigas,
- mecanismos articulados.

---

## Barra homogénea (eje por un extremo)

Si la misma barra gira alrededor de un eje perpendicular que pasa por uno de sus
extremos, el momento de inercia es mayor:

$$
I = \frac{1}{3} m L^2
$$

En este caso, la masa está, en promedio, más alejada del eje de giro que cuando el eje
pasa por el centro.

Este resultado puede obtenerse:
- resolviendo directamente la integral,
- o aplicando el **teorema de los ejes paralelos** al caso anterior.

---

## Relación con la dinámica rotacional

Los momentos de inercia típicos se usan directamente en la ecuación fundamental de la
rotación:

$$
\sum \tau = I \, \alpha
$$

De esta relación se deduce que, para un mismo torque neto:
- cuanto mayor sea \( I \), menor será la aceleración angular \( \alpha \),
- cuerpos con gran momento de inercia son más difíciles de acelerar o frenar.

---

## Lectura física global

Los momentos de inercia típicos permiten extraer conclusiones inmediatas:

- Concentrar masa lejos del eje aumenta significativamente \( I \).
- Cambiar el eje de giro puede modificar \( I \) incluso sin cambiar el cuerpo.
- Conocer estos valores evita recalcular integrales en cada problema.
- Identificar correctamente **el eje** es tan importante como conocer la fórmula.

Por ello, estos resultados constituyen una base esencial para el estudio de la
dinámica rotacional y sus aplicaciones en física e ingeniería.
