## Qué aprenderás
- Qué es el momento de inercia y qué mide físicamente.
- Por qué no depende solo de la masa, sino también de su distribución.
- Cómo influye el eje de giro en el valor del momento de inercia.
- El papel del momento de inercia en la dinámica rotacional.
- A interpretar situaciones reales donde cambiar I modifica el movimiento.

## Qué encontrarás aquí
- Una introducción conceptual al momento de inercia.
- Representaciones visuales para entender su significado físico.
- Comparaciones entre distintos cuerpos y distribuciones de masa.
- Conexiones directas con la ecuación fundamental de la rotación.
- Ejemplos cualitativos que preparan el terreno para el cálculo.

## Ideas clave
- El momento de inercia es el **análogo rotacional de la masa**.
- Dos cuerpos con la misma masa pueden tener momentos de inercia distintos.
- Cuanto más lejos esté la masa del eje, mayor será el momento de inercia.
- El momento de inercia **siempre se define respecto a un eje concreto**.
- Un mismo cuerpo puede tener distintos valores de I según el eje elegido.

## Cómo usar este bloque
1. Comprende primero el significado físico del momento de inercia.
2. Apóyate en los gráficos SVG para visualizar la distribución de masa.
3. Relaciona I con la respuesta del sistema ante un mismo torque.
4. Usa este bloque como base antes de entrar en el cálculo formal.

## Conexiones
- Es un concepto esencial para aplicar la ecuación Στ = I·α.
- Prepara el estudio del cálculo del momento de inercia en sistemas discretos y continuos.
- Conecta con la conservación del momento angular y con el teorema de Steiner.
- Fundamental en el análisis de sistemas rotatorios reales en física e ingeniería.
