# Teorema de ejes paralelos  · Aplicaciones

- Puertas: eje de giro en la bisagra (no por el centro) → cambia I.
- Poleas y ruedas con eje desplazado respecto al centro geométrico.
- Mecánica de robots: barras y brazos con ejes de articulación.
- Ingeniería: estimaciones rápidas sin integrar desde cero.
