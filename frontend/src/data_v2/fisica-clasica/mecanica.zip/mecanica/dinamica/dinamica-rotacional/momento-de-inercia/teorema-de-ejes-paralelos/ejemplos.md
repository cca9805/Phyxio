# Teorema de ejes paralelos  · Ejemplos

### Ejemplo 1 (barra por un extremo)
Para una barra homogénea:
$$
I_{cm} = \frac{1}{12}mL^2,\quad d=\frac{L}{2}
$$
Entonces:
$$
I = I_{cm} + md^2 = \frac{1}{12}mL^2 + m\left(\frac{L}{2}\right)^2 = \frac{1}{3}mL^2
$$

### Ejemplo 2 (disco con eje desplazado)
Para un disco:
$$
I_{cm} = \frac{1}{2}mR^2
$$
Si el eje paralelo se desplaza una distancia d:
$$
I = \frac{1}{2}mR^2 + md^2
$$
