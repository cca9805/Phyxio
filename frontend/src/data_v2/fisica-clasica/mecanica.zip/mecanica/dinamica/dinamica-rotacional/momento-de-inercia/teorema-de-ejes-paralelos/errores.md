# Teorema de ejes paralelos  · Errores típicos

- Usar el teorema con ejes que no son paralelos.
- Tomar d como “distancia a un punto” en vez de distancia entre ejes.
- Confundir I_cm con un momento respecto a otro eje diferente (aunque pase por el centro).
- Olvidar que el incremento es m·d² (d al cuadrado).
- Unidades: m en kg, d en m, I en kg·m².
