# Teorema de ejes paralelos  · Historia

El teorema se asocia frecuentemente a Steiner por su uso sistemático en problemas
geométricos y mecánicos. En física e ingeniería es una herramienta estándar porque
permite “trasladar ejes” sin recalcular integrales de masa.
