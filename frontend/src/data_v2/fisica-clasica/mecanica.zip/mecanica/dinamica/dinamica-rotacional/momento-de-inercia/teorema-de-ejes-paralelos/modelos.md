# Teorema de ejes paralelos · Modelos

- Cuerpo rígido homogéneo (o al menos con masa total m bien definida).
- El eje por el centro de masas debe ser paralelo al eje desplazado.
- d se mide como distancia perpendicular entre ejes, no a lo largo del cuerpo.
- No aplica a ejes no paralelos o rotaciones alrededor de ejes que cambian con el tiempo.
