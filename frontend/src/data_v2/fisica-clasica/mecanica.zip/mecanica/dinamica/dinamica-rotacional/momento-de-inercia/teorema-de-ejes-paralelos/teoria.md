## Teorema de los ejes paralelos (Steiner)

El **teorema de los ejes paralelos** relaciona el momento de inercia de un cuerpo
respecto a un eje que pasa por su **centro de masas** con el momento de inercia
respecto a otro eje **paralelo** separado una distancia perpendicular \(d\).

La relación es:

$$
I = I_{cm} + m d^2
$$

donde:
- \(I\) es el momento de inercia respecto al eje desplazado,
- \(I_{cm}\) es el momento de inercia respecto al eje paralelo que pasa por el centro de masas,
- \(m\) es la masa total del cuerpo,
- \(d\) es la distancia perpendicular entre ejes.

---

## Interpretación física

La fórmula se entiende muy bien si piensas en la definición:

$$
I = \int r^2 \, \mathrm{d}m
$$

Al desplazar el eje, todas las distancias \(r\) cambian. El teorema afirma que ese
cambio global se resume exactamente en un término adicional:

$$
\Delta I = m d^2
$$

Es decir: “mover el eje” siempre aumenta \(I\) porque en promedio la masa queda más
lejos del eje, y el incremento crece con \(d^2\).

---

## Condiciones de aplicación (muy importante)

El teorema solo puede usarse si:
- los ejes son **paralelos**,
- \(d\) es la **distancia perpendicular** entre ejes,
- \(I_{cm}\) está calculado para el **mismo tipo de eje**, pero pasando por el centro de masas.

Si el eje no es paralelo, o \(d\) no es la distancia perpendicular real, el resultado es incorrecto.

---

## Ejemplos típicos de uso

### Barra homogénea (eje por un extremo)
Si conoces para una barra de longitud \(L\):

$$
I_{cm} = \frac{1}{12} m L^2
$$

y quieres el eje perpendicular pasando por un extremo, la distancia es:

$$
d = \frac{L}{2}
$$

Entonces:

$$
I = I_{cm} + m\left(\frac{L}{2}\right)^2
  = \frac{1}{12}mL^2 + \frac{1}{4}mL^2
  = \frac{1}{3}mL^2
$$

Este resultado coincide con el “momento típico” de barra por el extremo.

---

### Disco macizo (eje paralelo desplazado)
Si para un disco:

$$
I_{cm} = \frac{1}{2} m R^2
$$

y el eje es paralelo al central pero desplazado una distancia \(d\), entonces:

$$
I = \frac{1}{2}mR^2 + md^2
$$

---

## Conexión con la dinámica rotacional

En la ecuación:

$$
\sum \tau = I\alpha
$$

si aumentas \(I\) (por ejemplo desplazando el eje), para el mismo torque neto la aceleración angular disminuye:

$$
\alpha = \frac{\sum \tau}{I}
$$

Por eso, el eje importa tanto como la forma del cuerpo.
