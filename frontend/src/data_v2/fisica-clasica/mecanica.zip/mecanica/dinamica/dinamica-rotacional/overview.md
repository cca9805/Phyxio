## Qué aprenderás
- A describir el movimiento de rotación causado por fuerzas.
- A trabajar con torque y momento de inercia.
- A aplicar una formulación rotacional de las leyes de Newton.

## Qué encontrarás aquí
- Torque y momento de una fuerza.
- Momento de inercia y teorema de ejes paralelos.
- Segunda ley de la rotación.
- Rodadura sin deslizamiento y sistemas reales.

## Conexiones
- Complementa la cinemática rotacional.
- Fundamental en máquinas, ruedas y mecanismos.
