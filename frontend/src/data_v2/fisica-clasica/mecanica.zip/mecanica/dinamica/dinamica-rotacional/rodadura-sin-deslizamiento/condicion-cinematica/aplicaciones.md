# Aplicaciones

- **Ruedas de vehículos**: en condiciones normales (sin derrape) la relación
  $$v = \omega R$$
  permite pasar de velocidad lineal a velocidad de giro.

- **Cintas transportadoras y rodillos**: un rodillo que gira sin patinar impone
  la velocidad de la cinta mediante
  $$v = \omega R.$$

- **Robótica móvil**: para robots con ruedas, la odometría usa la relación entre
  rotación medida (encoders) y avance del robot.

- **Diseño de transmisiones**: en engranajes/ruedas de fricción, la condición de
  no deslizamiento en la línea de contacto impone relaciones cinemáticas análogas.

- **Laboratorio**: medida indirecta de \(R\) o de \(\omega\) a partir de \(v\),
  siempre que se verifique que no hay patinamiento.

