# Condicion cinematica · Ejemplos

Un disco de radio R rueda sin deslizar con velocidad angular ω.

La velocidad del centro es:
$$
v = \omega R
$$

Si R = 0.3 m y ω = 10 rad/s:
$$
v = 3 \text{ m/s}
$$

