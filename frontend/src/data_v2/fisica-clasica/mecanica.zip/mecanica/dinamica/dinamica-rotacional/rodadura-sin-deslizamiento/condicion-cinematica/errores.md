# Condicion cinematica · Errores típicos

- Pensar que el punto de contacto se mueve respecto al suelo.
- Confundir rodadura con deslizamiento.
- Usar v = ωR cuando hay patinamiento.
- Mezclar cinemática con fuerzas en este subtema.
