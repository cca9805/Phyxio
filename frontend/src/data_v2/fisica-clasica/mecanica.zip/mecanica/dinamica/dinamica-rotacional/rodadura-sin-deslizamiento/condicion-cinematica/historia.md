# Historia

La rodadura sin deslizamiento se consolidó como concepto clave en el desarrollo de
la mecánica clásica al formalizar la combinación de traslación y rotación en un solo
modelo cinemático.

La condición
$$
v = \omega R
$$
se interpreta también mediante el **centro instantáneo de rotación**: durante la
rodadura pura, el punto de contacto con el suelo actúa como un “pivote instantáneo”,
lo que explica por qué su velocidad respecto al suelo es cero en ese instante.

Esta idea fue fundamental para el análisis de ruedas, poleas, rodillos y máquinas
clásicas, y sigue siendo una base estándar en física e ingeniería.

