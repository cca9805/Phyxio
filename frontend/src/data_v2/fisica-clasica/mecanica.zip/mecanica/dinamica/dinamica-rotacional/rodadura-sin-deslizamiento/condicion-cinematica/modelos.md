# Condicion cinematica · Modelos

- Cuerpo rígido cilíndrico o disco.
- Superficie rígida y fija.
- Punto de contacto único.
- No se consideran fuerzas ni pérdidas.
