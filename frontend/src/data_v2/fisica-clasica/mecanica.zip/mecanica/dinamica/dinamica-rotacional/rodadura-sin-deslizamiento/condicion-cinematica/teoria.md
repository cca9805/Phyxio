## Condición cinemática de rodadura sin deslizamiento

Un cuerpo **rueda sin deslizar** cuando su movimiento puede describirse como
una combinación de traslación del centro de masas y rotación alrededor de un eje.

La condición cinemática fundamental de la rodadura pura es:

$$
v = \omega R
$$

donde:
- \( v \) es la velocidad del centro de masas,
- \( \omega \) es la velocidad angular,
- \( R \) es el radio del cuerpo.

---

## Interpretación física

Durante la rodadura sin deslizamiento:
- el centro de masas se traslada,
- el cuerpo gira alrededor de su eje,
- el punto de contacto con el suelo está instantáneamente en reposo.

Esto ocurre porque la velocidad de traslación del centro se cancela con la
velocidad tangencial debida a la rotación en el punto de contacto.

---

## Punto de contacto

La velocidad de un punto del cuerpo se obtiene como suma de:
- la velocidad del centro de masas,
- la velocidad debida a la rotación.

Para el punto de contacto:

$$
v_{\text{contacto}} = v - \omega R = 0
$$

De aquí se obtiene directamente la condición:

$$
v = \omega R
$$

---

## Consecuencias

- Si \( v > \omega R \), el cuerpo desliza hacia delante.
- Si \( v < \omega R \), el cuerpo desliza hacia atrás.
- Solo cuando se cumple exactamente \( v = \omega R \) hay rodadura pura.

Esta condición es independiente de las fuerzas: es puramente cinemática.
