# Ejemplos clasicos · Aplicaciones

- Odómetros y encoders: pasar de giro a distancia recorrida usando \(v=\omega R\).
- Control de tracción: detectar patinamiento comparando \(v\) real con \(\omega R\).
- Rodillos y cintas: ajustar velocidades en procesos industriales.
- Robótica móvil: estimar velocidad del robot a partir de la velocidad angular de las ruedas.
