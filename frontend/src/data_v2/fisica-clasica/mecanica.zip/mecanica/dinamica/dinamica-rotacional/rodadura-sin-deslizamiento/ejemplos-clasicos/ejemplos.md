# Ejemplos clasicos · Ejemplos

### Ejemplo 1 (calcular v)
Una rueda de radio \(R = 0.30\ \text{m}\) gira con \(\omega = 10\ \text{rad/s}\).
En rodadura pura:

$$
v = \omega R = 10 \cdot 0.30 = 3.0\ \text{m/s}
$$

---

### Ejemplo 2 (calcular ω)
Una rueda de radio \(R = 0.25\ \text{m}\) avanza con \(v = 2.5\ \text{m/s}\).

$$
\omega = \frac{v}{R} = \frac{2.5}{0.25} = 10\ \text{rad/s}
$$

---

### Ejemplo 3 (detectar deslizamiento)
Datos medidos: \(R=0.20\ \text{m}\), \(v=2.0\ \text{m/s}\), \(\omega=8\ \text{rad/s}\).

$$
\Delta = v - \omega R = 2.0 - 8 \cdot 0.20 = 2.0 - 1.6 = 0.4\ \text{m/s}
$$

Como \(\Delta \neq 0\), esos datos no corresponden a rodadura pura.
