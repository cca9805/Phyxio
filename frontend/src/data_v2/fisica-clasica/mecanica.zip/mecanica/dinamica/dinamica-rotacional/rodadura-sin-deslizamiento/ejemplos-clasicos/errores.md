# Ejemplos clasicos · Errores típicos

- Usar R en cm y no convertir a m.
- Confundir rpm con rad/s (si aparece ω en rpm, convertir antes).
- No respetar signos: ω negativa implica v negativa si R > 0.
- Aceptar datos que no cumplen v = ωR (eso implicaría deslizamiento).
