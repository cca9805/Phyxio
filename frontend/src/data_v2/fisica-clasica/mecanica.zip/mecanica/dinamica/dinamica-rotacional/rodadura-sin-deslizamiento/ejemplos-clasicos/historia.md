# Ejemplos clasicos · Historia

La relación \(v=\omega R\) se interpreta también mediante el centro instantáneo de rotación:
en rodadura pura, el punto de contacto actúa como pivote instantáneo, lo que hace que su
velocidad sea cero en ese instante.

Este marco conceptual fue crucial en el análisis clásico de ruedas, poleas, rodillos y
mecanismos, y sigue siendo una herramienta básica en física aplicada e ingeniería.
