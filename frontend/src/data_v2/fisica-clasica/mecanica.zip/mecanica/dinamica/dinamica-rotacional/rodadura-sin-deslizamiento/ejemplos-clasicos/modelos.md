# Ejemplos clasicos · Modelos

- Rodadura sin deslizamiento (condición v = ωR válida).
- Cuerpo rígido con radio R constante.
- Se trabaja a nivel cinemático (sin fuerzas ni energía salvo que se indique).
- Convenio de signos coherente entre v y ω.
