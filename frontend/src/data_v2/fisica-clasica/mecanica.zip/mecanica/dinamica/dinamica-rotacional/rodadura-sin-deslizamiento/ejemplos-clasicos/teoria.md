## Ejemplos clásicos (cinemática de rodadura)

En rodadura sin deslizamiento, el vínculo esencial entre traslación y rotación es:

$$
v = \omega R
$$

donde:
- \(v\) es la velocidad del centro de masas,
- \(\omega\) es la velocidad angular,
- \(R\) es el radio del cuerpo.

---

## Lectura gráfica

Si representamos \(v\) frente a \(\omega\), obtenemos una recta:

$$
v(\omega) = R\,\omega
$$

- La recta pasa por el origen.
- La pendiente es \(R\).
- Si \(R\) aumenta, la recta se “inclina” más (para el mismo \(\omega\), \(v\) es mayor).

---

## Consistencia (detectar deslizamiento)

Para un conjunto de valores \((v,\omega,R)\), podemos comprobar la condición:

$$
\Delta = v - \omega R
$$

- Si \(\Delta = 0\), los datos son compatibles con rodadura pura.
- Si \(\Delta \neq 0\), esos datos implican deslizamiento (patinamiento), o que el modelo no aplica.

---

## Unidades y signos

- \(R\) debe estar en metros (m).
- \(\omega\) en rad/s.
- \(v\) en m/s.

Si \(\omega\) es negativa, indica giro en sentido opuesto, y el signo de \(v\) debe ser coherente:

$$
v = \omega R
$$

(Con el mismo convenio de signos para ambos.)
