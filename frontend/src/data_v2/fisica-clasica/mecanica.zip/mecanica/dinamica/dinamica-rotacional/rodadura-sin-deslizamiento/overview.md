## Qué aprenderás
- Qué significa que un cuerpo ruede sin deslizar.
- Cómo se combinan traslación y rotación en la rodadura.
- Por qué el punto de contacto está instantáneamente en reposo.
- Qué condiciones deben cumplirse para que no haya deslizamiento.

## Qué encontrarás aquí
- Explicación conceptual de la rodadura pura.
- Representaciones visuales del movimiento de un cuerpo rodante.
- La condición cinemática que relaciona velocidad lineal y angular.
- Gráficos para analizar cómo se conectan v, ω y R.

## Ideas clave
- Rodar sin deslizar no es solo girar: es girar **y** trasladarse.
- En la rodadura pura, el punto de contacto con el suelo tiene velocidad nula.
- La condición v = ωR es consecuencia directa de la cinemática.
- Si esta condición no se cumple, aparece deslizamiento.

## Cómo usar este bloque
1. Comprende primero la geometría del movimiento con el SVG.
2. Identifica claramente centro, eje y punto de contacto.
3. Usa la condición cinemática para relacionar v y ω.
4. Aplica el modelo a ruedas, discos y cuerpos cilíndricos.

## Conexiones
- Conecta traslación y rotación en un mismo sistema.
- Es clave para estudiar energía en rodadura.
- Base para el análisis dinámico con fuerzas de rozamiento.
