# ejemplos-aplicados · Aplicaciones

- Frenos mecánicos y de disco.
- Motores reales con pérdidas.
- Volantes de inercia.
- Sistemas rotatorios en robótica y automoción.
