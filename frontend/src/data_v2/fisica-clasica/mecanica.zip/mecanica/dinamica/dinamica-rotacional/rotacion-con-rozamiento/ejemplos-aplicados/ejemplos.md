# ejemplos-aplicados · Ejemplos

### Ejemplo 1: disco que acelera

Un disco tiene I = 0,50 kg·m².
Se aplica un torque τ_ap = 3,0 N·m y hay un rozamiento τ_roz = 1,0 N·m.

Στ = 3,0 − 1,0 = 2,0 N·m  
α = Στ / I = 2,0 / 0,50 = 4,0 rad/s²

El disco acelera.

---

### Ejemplo 2: rueda que se frena

I = 1,2 kg·m²  
τ_ap = 0  
τ_roz = 0,6 N·m

Στ = −0,6 N·m  
α = −0,6 / 1,2 = −0,5 rad/s²

La velocidad angular disminuye linealmente.
