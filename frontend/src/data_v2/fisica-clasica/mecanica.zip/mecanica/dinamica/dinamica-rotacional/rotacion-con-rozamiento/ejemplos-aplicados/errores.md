# ejemplos-aplicados · Errores típicos

- Olvidar restar el torque de rozamiento.
- Cambiar la convención de signos a mitad del problema.
- Creer que rozamiento “rompe” la ecuación Στ = I·α.
- Confundir frenar con detenerse instantáneamente (α ≠ 0 implica cambio gradual).
