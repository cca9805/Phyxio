# ejemplos-aplicados · Historia

El estudio del rozamiento fue clave para pasar de la mecánica ideal a la mecánica real.
Los modelos de torque resistente permiten describir sistemas rotatorios con gran
precisión en ingeniería.
