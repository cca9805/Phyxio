﻿# ejemplos-aplicados Â· Modelos

Este Tema usa un modelo simplificado de dinÃ¡mica rotacional con rozamiento:

## 1) Cuerpo rÃ­gido y eje fijo
Se considera un cuerpo rÃ­gido que gira alrededor de un eje definido y fijo.
Todas las magnitudes (torques, momento de inercia, aceleraciÃ³n angular) se refieren a ese mismo eje.

## 2) Torques separados por â€œrolâ€
Se distinguen dos tipos:
- **Torque aplicado** (Ï„_ap): intenta impulsar la rotaciÃ³n en el sentido positivo elegido.
- **Torque resistente** (Ï„_roz): se opone al giro y reduce el torque neto.

El torque neto se modela como:
Î£Ï„ = Ï„_ap âˆ’ Ï„_roz

## 3) EcuaciÃ³n fundamental (modelo dinÃ¡mico)
La aceleraciÃ³n angular viene dada por:
Î± = Î£Ï„ / I = (Ï„_ap âˆ’ Ï„_roz) / I

Esto describe cÃ³mo responde el sistema de forma inmediata al balance de torques.

## 4) ConvenciÃ³n de signos
Se fija un sentido positivo de giro. En este Tema:
- Ï„_ap es positivo si favorece el giro en el sentido elegido.
- Ï„_roz se resta porque actÃºa en sentido opuesto al movimiento (modelo resistente).

Lo importante es mantener coherencia en todo el ejercicio.

## 5) Alcance y lÃ­mites del modelo
Este modelo es Ãºtil para ejemplos aplicados, pero no cubre:
- variaciÃ³n de I con el tiempo (masa que se desplaza)
- eje que cambia o se mueve
- rozamientos complejos dependientes de temperatura, presiÃ³n, etc.
- modelos avanzados donde Ï„_roz depende de Ï‰ u otras variables (eso se puede tratar en un Tema especÃ­fico)

En resumen: es un modelo operativo para consolidar Î£Ï„ = IÂ·Î± en situaciones reales con pÃ©rdidas.
