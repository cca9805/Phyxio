﻿## QuÃ© se hace en estos ejemplos

En los problemas reales de rotaciÃ³n:
- hay **un torque que impulsa**
- y **uno o varios torques que frenan**

El procedimiento es siempre el mismo:

1. Elegir un eje y un sentido positivo de giro.
2. Calcular cada torque con su signo.
3. Sumar torques: Î£Ï„ = Ï„_ap âˆ’ Ï„_roz.
4. Aplicar la ecuaciÃ³n fundamental: Î± = Î£Ï„ / I.
5. Interpretar el resultado fÃ­sico.

Este Tema se centra en **aplicar** ese esquema, no en introducir teorÃ­a nueva.
