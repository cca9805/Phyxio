## Qué aprenderás
- A distinguir entre modelos ideales de rotación y sistemas reales con pérdidas.
- A interpretar el rozamiento como un torque resistente que se opone al movimiento.
- A aplicar la ecuación fundamental de la dinámica rotacional cuando existe rozamiento.
- A predecir si un sistema rota acelerando, frenando o manteniéndose estable.
- A analizar ejemplos reales donde el rozamiento no puede despreciarse.

## Qué encontrarás aquí
- Introducción conceptual a la rotación con rozamiento.
- Modelos sencillos de torque resistente (rozamiento constante y proporcional).
- Aplicación de la ecuación Στ = I·α en presencia de pérdidas.
- Ejemplos aplicados con interpretación física y gráfica.
- Representaciones Coord para visualizar el efecto del rozamiento en la dinámica.

## Ideas clave
- El rozamiento no anula las leyes de la dinámica: **modifica el torque neto**.
- Siempre que hay rozamiento, es imprescindible fijar una **convención de signos**.
- El comportamiento del sistema depende del equilibrio entre torque aplicado y torque resistente.
- Muchos sistemas reales funcionan en un régimen donde el rozamiento domina la respuesta.

## Cómo usar este bloque
1. Comienza entendiendo el papel del rozamiento como torque resistente.
2. Aplica la ecuación fundamental con sumatorio de torques.
3. Trabaja los ejemplos aplicados para consolidar el método.
4. Usa los gráficos Coord para relacionar fórmulas con comportamiento físico.

## Conexiones
- Extiende la **ecuación fundamental de la dinámica rotacional** a sistemas reales.
- Prepara el terreno para estudiar frenado, amortiguamiento y control de movimiento.
- Conecta con temas posteriores de energía, pérdidas y rendimiento mecánico.
