# analogia-traslacional · Aplicaciones

- Diseño de herramientas (llaves, palancas) para obtener mayor τ y lograr mayor α.
- Motores eléctricos y mecánicos: relación entre par (τ), inercia (I) y aceleración angular (α).
- Robótica: control de articulaciones (par vs inercia).
- Puertas, volantes, ruedas: cómo cambia la respuesta al giro al variar I.
