# analogia-traslacional · Ejemplos

### Ejemplo 1 (rotación)
I = 0,50 kg·m² y τ = 2,0 N·m
α = τ/I = 2,0 / 0,50 = 4,0 rad/s²

### Ejemplo 2 (traslación análoga)
m = 5 kg y F = 20 N
a = F/m = 20/5 = 4 m/s²

Observa la analogía directa: mismo “4”, pero en unidades distintas.
