# analogia-traslacional · Errores típicos

- Usar τ, I y α de ejes distintos (deben ser del mismo eje).
- Confundir masa con momento de inercia: I depende del radio y distribución.
- Mezclar módulos con signos sin convención (horario/antihorario).
- Olvidar unidades: τ (N·m), I (kg·m²), α (rad/s²).
