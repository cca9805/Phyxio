# analogia-traslacional · Historia

La formalización moderna de la dinámica rotacional se consolidó con el desarrollo de la mecánica clásica y el álgebra vectorial.

La idea de analogía rotación-traslación es una herramienta pedagógica habitual para conectar intuiciones del movimiento lineal con el movimiento angular.
