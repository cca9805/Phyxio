# analogia-traslacional · Modelos

El modelo base supone un eje de giro fijo y un cuerpo rígido.

La ecuación τ = I·α es el análogo rotacional de F = m·a:
- F produce aceleración lineal.
- τ produce aceleración angular.

El momento de inercia I cumple un papel equivalente al de la masa, pero depende de la distribución de la masa respecto al eje.

