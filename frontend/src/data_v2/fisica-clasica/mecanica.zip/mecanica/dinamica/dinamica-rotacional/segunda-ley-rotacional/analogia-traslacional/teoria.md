## La idea: “Newton también gira”

En traslación, la 2ª ley dice:

F = m·a

En rotación, la forma equivalente es:

τ = I·α

Donde:
- τ es el torque (momento de fuerzas) respecto al eje
- I es el momento de inercia respecto al mismo eje
- α es la aceleración angular

---

## Analogía traslación ↔ rotación

| Traslación | Rotación |
|---|---|
| Fuerza F | Torque τ |
| Masa m | Momento de inercia I |
| Aceleración a | Aceleración angular α |
| Velocidad v | Velocidad angular ω |
| Posición x | Ángulo θ |

Esta analogía es potentísima: si entiendes “cuesta acelerar una masa”, entonces
entiendes “cuesta acelerar la rotación” cuando I es grande.

---

## Interpretación física

- m mide “cuánta resistencia ofrece un cuerpo a cambiar su velocidad lineal”.
- I mide “cuánta resistencia ofrece un cuerpo a cambiar su velocidad angular”.

A mayor I, para el mismo torque τ:
- la aceleración angular α es menor.

---

## Forma práctica (módulos)

Si trabajas con módulos (sin signo):

α = τ / I

Esto es el equivalente exacto a:

a = F / m

---

## Límites de la analogía

La analogía es directa, pero hay matices:
- I depende de cómo está distribuida la masa respecto al eje (no es “solo una cantidad”).
- En problemas reales puede haber varios torques y el eje puede variar.
- El signo/sentido (horario/antihorario) requiere convención.
