# ecuacion-fundamental · Aplicaciones

- Motores: par aplicado (Στ) y respuesta angular (α) dependen de la inercia (I).
- Ruedas, volantes y discos: un I grande suaviza cambios de velocidad angular.
- Robótica: control por par para lograr aceleraciones angulares deseadas.
- Dinámica de mecanismos: suma de torques de diferentes fuerzas.
