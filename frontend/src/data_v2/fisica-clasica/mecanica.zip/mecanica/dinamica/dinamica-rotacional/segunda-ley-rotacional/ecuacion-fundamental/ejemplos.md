# ecuacion-fundamental · Ejemplos

### Ejemplo 1
Στ = 3,0 N·m e I = 0,75 kg·m²
α = Στ / I = 3,0 / 0,75 = 4,0 rad/s²

### Ejemplo 2
I = 2,0 kg·m² y se desea α = 1,5 rad/s²
Στ = I·α = 2,0·1,5 = 3,0 N·m
