# ecuacion-fundamental · Errores típicos

- No usar el mismo eje para Στ e I.
- Olvidar el sumatorio (usar un solo torque cuando hay varios).
- Mezclar signos sin convención (horario/antihorario).
- Tomar I “como una masa”: I depende de la distribución respecto al eje.
- Usar módulos cuando el problema requiere signo (torques opuestos).
