# ecuacion-fundamental · Historia

La dinámica rotacional se desarrolló como extensión natural de la mecánica clásica.
La relación entre torque e inercia rotacional se formaliza con el uso de álgebra vectorial
y el análisis de cuerpos rígidos.

La ecuación Στ = I·α es una piedra angular en ingeniería y física aplicada.
