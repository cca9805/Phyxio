﻿# ecuacion-fundamental Â· Modelos

Este Tema usa el modelo de cuerpo rÃ­gido con eje fijo.

La ecuaciÃ³n Î£Ï„ = IÂ·Î± es el â€œmotorâ€ de la dinÃ¡mica rotacional:
- Î£Ï„ determina la aceleraciÃ³n angular.
- I actÃºa como el factor de inercia rotacional respecto a ese eje.

En presencia de varios torques, el resultado depende del torque neto (con signos coherentes).
