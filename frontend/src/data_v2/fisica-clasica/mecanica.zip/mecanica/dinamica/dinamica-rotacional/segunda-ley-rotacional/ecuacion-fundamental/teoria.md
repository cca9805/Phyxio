## La ecuación fundamental (rotación)

La dinámica rotacional tiene una relación central análoga a la 2ª ley de Newton:

Στ = I·α

Interpretación:
- **Στ** (suma de torques) es la causa: “cuánto empuje de giro neto hay”.
- **α** (aceleración angular) es la respuesta: “cuánto cambia ω”.
- **I** es el “peso rotacional”: cuanto mayor I, más cuesta acelerar el giro.

---

## ¿Por qué aparece el sumatorio?

En rotación, suelen actuar varias fuerzas.
Cada fuerza produce un torque (positivo o negativo según convención).
El efecto total viene dado por el **torque neto**:

Στ = τ₁ + τ₂ + τ₃ + ...

---

## Forma práctica (si trabajas con módulos)

Si el problema está planteado con módulos y un único sentido:

α = Στ / I

---

## Cuándo NO debes usarla sin cuidado

- Si el eje no es fijo o cambia (modelo más avanzado).
- Si I cambia con el tiempo (por ejemplo, masas que se desplazan).
- Si no estás usando el mismo eje para torque e inercia.
- Si mezclas signos sin convención clara.
