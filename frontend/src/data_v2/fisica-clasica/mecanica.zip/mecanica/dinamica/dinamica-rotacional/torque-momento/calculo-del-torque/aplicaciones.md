# calculo-del-torque · Aplicaciones

Aplicaciones típicas del cálculo del torque:

- llaves inglesas y herramientas (aplicar fuerza con mayor brazo)
- puertas y bisagras (empujar lejos del eje)
- palancas y máquinas simples
- equilibrio de vigas, balancines y estructuras
- biomecánica (articulaciones y músculos)
