# calculo-del-torque · Ejemplos

### Ejemplo 1: método del brazo
Una fuerza F = 20 N se aplica con brazo perpendicular d = 0,30 m.
τ = F·d = 20·0,30 = 6 N·m.

### Ejemplo 2: método del ángulo
r = 0,40 m, F = 25 N, θ = 90° (π/2 rad).
τ = r·F·sin(θ) = 0,40·25·1 = 10 N·m.

### Ejemplo 3: por componentes (2D)
r = (rx, ry) = (0,20 m, 0,10 m)
F = (Fx, Fy) = (5 N, 12 N)
τz = rx·Fy − ry·Fx = 0,20·12 − 0,10·5 = 2,4 − 0,5 = 1,9 N·m (antihorario si convención +).

