# calculo-del-torque · Errores típicos

Errores frecuentes al calcular torque:

- Usar como d la distancia al punto de aplicación, en lugar de la distancia perpendicular.
- Olvidar especificar el eje/punto respecto al cual se calcula el momento.
- Confundir módulo con signo: τ = F·d da el módulo, el sentido requiere convención.
- Usar grados en sin(θ) cuando la calculadora interpreta radianes.
- Mezclar componentes con módulos sin coherencia (por ejemplo, usar r y Fx, Fy a la vez).

