# calculo-del-torque · Historia

El estudio del momento de una fuerza surge de las máquinas simples y del equilibrio,
con un desarrollo muy temprano en la estática clásica.

La formalización moderna se consolidó con el álgebra vectorial y el producto vectorial,
que permiten tratar el torque como una magnitud vectorial relacionada con r × F.
