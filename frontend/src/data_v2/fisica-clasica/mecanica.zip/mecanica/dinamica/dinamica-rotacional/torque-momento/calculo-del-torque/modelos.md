# calculo-del-torque · Modelos

El cálculo del torque se apoya en dos modelos equivalentes:

- Modelo geométrico: τ = F·d, donde d es la distancia perpendicular.
- Modelo vectorial: τ = r × F, que introduce dirección y sentido del efecto rotacional.

El modelo por componentes (2D) es una implementación práctica del producto vectorial
cuando el problema ocurre en un plano.
