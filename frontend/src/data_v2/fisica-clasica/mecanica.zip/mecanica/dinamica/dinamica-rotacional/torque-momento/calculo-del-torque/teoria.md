## Idea central: qué se calcula y qué NO

El torque (momento) mide el **efecto de giro** de una fuerza respecto a un eje/punto.
No basta con “hacer mucha fuerza”: importa **dónde** y **cómo** aplicas la fuerza.

---

## Método 1: brazo de palanca (el más práctico)

El módulo del torque respecto a un eje es:

τ = F · d

d es el **brazo de palanca**: la distancia **perpendicular** desde el eje a la **línea de acción** de la fuerza.

Claves rápidas:
- Si la línea de acción pasa por el eje → d = 0 → τ = 0.
- Si aplicas la fuerza más lejos del eje → d aumenta → τ aumenta.
- Si la fuerza es perpendicular al brazo → torque máximo.

---

## Método 2: geometría con ángulo

Si r es la distancia desde el eje al punto de aplicación y θ es el ángulo entre r y F:

d = r · sin(θ)
τ = r · F · sin(θ)

Esto te dice algo importante:
- Si θ = 0° (fuerza alineada con r) → sin(θ)=0 → no hay giro.
- Si θ = 90° → sin(θ)=1 → torque máximo.

---

## Método 3: cálculo por componentes (2D)

En un plano (x,y), el torque alrededor del eje z es:

τz = rx · Fy − ry · Fx

Interpretación:
- τz > 0 suele representar giro antihorario (convención habitual).
- τz < 0 suele representar giro horario.

---

## Signo del torque (convención)

El signo depende de la convención elegida:
- En 2D, suele tomarse antihorario como positivo.
- En 3D, se usa la regla de la mano derecha para la dirección del vector τ = r × F.

Lo importante no es “memorizar el signo”, sino ser consistente con el sistema de referencia.
