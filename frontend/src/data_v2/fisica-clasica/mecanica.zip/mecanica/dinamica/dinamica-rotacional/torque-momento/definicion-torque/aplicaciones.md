# definicion · Aplicaciones

El concepto de torque se aplica en:

- palancas y máquinas simples
- mecanismos de rotación
- análisis de equilibrio
- ingeniería mecánica
- biomecánica

Su comprensión es clave para diseñar sistemas estables y eficientes.
