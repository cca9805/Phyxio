# definicion · Ejemplos

- Una puerta gira más fácilmente cuando se empuja lejos de las bisagras.
- La misma fuerza puede producir distinto efecto según el punto de aplicación.
- Aumentar el brazo de palanca incrementa el torque.
