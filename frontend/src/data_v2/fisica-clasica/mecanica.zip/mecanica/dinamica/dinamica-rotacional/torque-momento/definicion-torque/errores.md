# definicion · Errores típicos

Errores frecuentes al trabajar con el momento de una fuerza:

- Confundir fuerza con torque.
- Usar la distancia incorrecta en lugar del brazo perpendicular.
- Ignorar el punto o eje de referencia.
- Tratar el torque como una magnitud escalar sin dirección.
