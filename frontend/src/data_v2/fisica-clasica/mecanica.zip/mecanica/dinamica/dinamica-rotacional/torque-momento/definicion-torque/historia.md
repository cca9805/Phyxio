# definicion · Historia

El concepto de momento de una fuerza se desarrolló con el estudio de las máquinas
simples y el equilibrio en la mecánica clásica.

Fue formalizado matemáticamente con el desarrollo del álgebra vectorial y es una
pieza clave de la dinámica rotacional moderna.
