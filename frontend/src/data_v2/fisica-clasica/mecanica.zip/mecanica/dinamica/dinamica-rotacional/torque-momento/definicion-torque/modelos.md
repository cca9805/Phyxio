# definicion · Modelos

El momento de una fuerza es un modelo que permite cuantificar el efecto rotacional
de las fuerzas sobre los cuerpos rígidos.

Este modelo es esencial para describir el equilibrio y el movimiento rotacional
en sistemas físicos reales.
