# definicion · Teoría

## ¿Qué es el momento de una fuerza?

El **momento de una fuerza**, también llamado **torque**, es la magnitud física
que mide la capacidad de una fuerza para producir **rotación** alrededor de un
punto o de un eje.

Mientras que una fuerza puede provocar traslación, el torque cuantifica su
**efecto rotacional**.

---

## Interpretación física

Una misma fuerza puede producir distintos efectos de rotación dependiendo de:

- el punto de aplicación
- la dirección de la fuerza
- la distancia al eje de giro

Por esta razón, no basta con conocer el valor de la fuerza: es necesario saber
**cómo y dónde actúa**.

---

## Definición vectorial

El momento de una fuerza respecto a un punto se define como el **producto
vectorial** entre el vector posición y la fuerza aplicada.

El torque es una magnitud vectorial cuya dirección indica el eje de rotación y
cuyo sentido viene dado por la regla de la mano derecha.

---

## Eje de rotación

El análisis del torque siempre se realiza respecto a un punto o eje elegido.

Cambiar el eje de referencia puede modificar el valor del momento de una fuerza,
aunque la fuerza aplicada sea la misma.
