## Qué aprenderás
- A analizar el movimiento de sistemas que se desplazan sin rotar.
- A aplicar las leyes de Newton en una dimensión.
- A resolver sistemas simples y compuestos.

## Qué encontrarás aquí
- Planos inclinados con y sin rozamiento.
- Sistemas de uno y varios cuerpos.
- Bloques, cuerdas y poleas.
- Análisis completo de sistemas traslacionales.

## Conexiones
- Extiende la cinemática incorporando fuerzas reales.
- Muy frecuente en problemas tipo examen.
