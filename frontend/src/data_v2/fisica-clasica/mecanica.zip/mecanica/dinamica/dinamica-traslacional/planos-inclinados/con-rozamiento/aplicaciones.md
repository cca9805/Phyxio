# Con rozamiento · Aplicaciones

- Deslizamiento de objetos por rampas.
- Diseño de pendientes en carreteras.
- Transporte de materiales en planos inclinados.
- Análisis de estabilidad en taludes.
