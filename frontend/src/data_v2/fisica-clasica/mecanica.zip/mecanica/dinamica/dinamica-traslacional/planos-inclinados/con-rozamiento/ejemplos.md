# Con rozamiento · Ejemplos

### Ejemplo
Un bloque desciende por un plano inclinado de \(30^\circ\) con \(\mu=0.2\).

$$
a = g(\sin30^\circ - 0.2\cos30^\circ)
$$

$$
a = 9.8(0.5 - 0.173) \approx 3.2\ \text{m/s}^2
$$
