# Con rozamiento · Errores típicos

- Usar sinθ y cosθ intercambiados.
- Olvidar que el rozamiento se opone al movimiento.
- No comprobar si el bloque realmente se mueve.
- Mezclar rozamiento estático y cinético sin indicarlo.
