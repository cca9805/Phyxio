# Con rozamiento · Historia

El plano inclinado fue uno de los sistemas fundamentales estudiados desde Galileo,
quien lo utilizó para investigar el movimiento acelerado y reducir los efectos
de la gravedad en sus experimentos.
