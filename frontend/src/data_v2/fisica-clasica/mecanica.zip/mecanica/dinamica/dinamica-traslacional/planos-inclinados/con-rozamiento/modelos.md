# Con rozamiento · Modelos

- Bloque tratado como punto material.
- Rozamiento cinético constante.
- Movimiento rectilíneo sobre el plano.
- No se considera rozamiento estático en este modelo.
