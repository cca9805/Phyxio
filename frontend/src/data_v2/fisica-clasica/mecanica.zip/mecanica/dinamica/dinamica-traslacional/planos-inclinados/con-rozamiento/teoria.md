## Plano inclinado con rozamiento

Consideramos un bloque de masa \(m\) situado sobre un plano inclinado un ángulo
\(\theta\) respecto a la horizontal.

Sobre el bloque actúan:
- el peso \(mg\),
- la normal \(N\),
- la fuerza de rozamiento \(f\).

---

## Descomposición del peso

El peso se descompone en:
- componente paralela al plano:
  $$
  mg\sin\theta
  $$
- componente perpendicular:
  $$
  mg\cos\theta
  $$

De aquí se obtiene directamente:
$$
N = mg\cos\theta
$$

---

## Fuerza de rozamiento

El rozamiento cinético tiene módulo:
$$
f = \mu N = \mu mg\cos\theta
$$

Su dirección es siempre opuesta al movimiento relativo.

---

## Ecuación del movimiento

Tomando como positiva la dirección descendente por el plano, la segunda ley de Newton
queda:

$$
mg\sin\theta - \mu mg\cos\theta = ma
$$

De donde se obtiene la aceleración:

$$
a = g(\sin\theta - \mu\cos\theta)
$$

---

## Interpretación física

- Si \( \sin\theta > \mu\cos\theta \), el bloque acelera cuesta abajo.
- Si \( \sin\theta = \mu\cos\theta \), el bloque se mueve con velocidad constante.
- Si \( \sin\theta < \mu\cos\theta \), el rozamiento impide el movimiento.

Este resultado muestra cómo el ángulo y el rozamiento compiten entre sí.
