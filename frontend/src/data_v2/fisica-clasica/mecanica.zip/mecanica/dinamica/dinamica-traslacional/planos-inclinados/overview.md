## Qué aprenderás
- Qué es un plano inclinado y por qué simplifica el análisis de fuerzas.
- Cómo se descompone el peso en direcciones paralela y perpendicular al plano.
- Cuándo un cuerpo permanece en reposo y cuándo se mueve sobre el plano.
- El papel del rozamiento en el movimiento sobre superficies inclinadas.

## Qué encontrarás aquí
- Una introducción conceptual al plano inclinado como sistema dinámico.
- Interpretación física de las componentes del peso.
- Conexión directa con la segunda ley de Newton.
- Ejemplos típicos que sirven de base para problemas más complejos.

## Ideas clave
- El plano inclinado transforma un problema vertical en uno más manejable.
- El peso se descompone en dos componentes:
  - una paralela al plano, que tiende a mover el cuerpo,
  - una perpendicular, que determina la normal.
- El ángulo del plano controla la intensidad de la aceleración.
- El rozamiento puede impedir el movimiento o modificarlo significativamente.

## Cómo usar este bloque
1. Identifica el ángulo del plano y el sistema de referencia.
2. Descompón el peso en componentes paralela y perpendicular.
3. Aplica la segunda ley de Newton en la dirección del movimiento.
4. Introduce el rozamiento solo cuando el modelo lo requiera.

## Conexiones
- Extiende el modelo de bloque sobre superficie horizontal.
- Base para sistemas con poleas y masas conectadas.
- Conecta con energía, trabajo y potencia.
- Fundamental en mecánica aplicada e ingeniería.
