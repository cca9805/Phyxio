# Sin rozamiento · Aplicaciones

- Rampas ideales en problemas teóricos.
- Comparación con el caso con rozamiento para medir pérdidas.
- Modelos base para introducir energía y trabajo.
- Sistemas de laboratorio con baja fricción (carritos).

