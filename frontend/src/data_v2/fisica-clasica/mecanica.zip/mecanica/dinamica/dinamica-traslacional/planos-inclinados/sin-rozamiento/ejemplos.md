# Sin rozamiento · Ejemplos

### Ejemplo
Un bloque está sobre un plano inclinado de \(20^\circ\).

$$
a = g\sin20^\circ = 9.8 \cdot 0.342 \approx 3.35\ \text{m/s}^2
$$
