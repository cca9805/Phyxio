# Sin rozamiento · Errores típicos

- Confundir mg·cosθ con la fuerza que mueve el bloque (esa es mg·sinθ).
- Olvidar que N = mg·cosθ (sin rozamiento).
- Usar g en otras unidades.
- Aplicar fórmulas en grados cuando la calculadora usa radianes (si aplica).
