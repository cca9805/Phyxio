# Sin rozamiento · Historia

El plano inclinado fue una herramienta experimental clave en los estudios de Galileo
sobre el movimiento acelerado, permitiendo “reducir” el efecto de la gravedad y medir
con mayor precisión la aceleración en condiciones controladas.
