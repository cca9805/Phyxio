# Sin rozamiento · Modelos

- Sin rozamiento (modelo ideal).
- Bloque como punto material.
- Plano rígido y fijo.
- Movimiento unidimensional sobre el plano.
