## Plano inclinado sin rozamiento

Consideramos un bloque de masa \(m\) sobre un plano inclinado un ángulo \(\theta\).
No hay rozamiento, así que la única fuerza paralela al plano es la componente del peso.

---

## Descomposición del peso

El peso \(mg\) se descompone en:
- Paralela al plano:
  $$
  mg\sin\theta
  $$
- Perpendicular al plano:
  $$
  mg\cos\theta
  $$

Como no hay aceleración perpendicular al plano:

$$
N = mg\cos\theta
$$

---

## Ecuación de movimiento

Tomando positiva la dirección descendente por el plano:

$$
\sum F_{\parallel} = mg\sin\theta = ma
$$

Por lo tanto, la aceleración del bloque es:

$$
a = g\sin\theta
$$

---

## Interpretación física

- Si \(\theta = 0\), entonces \(a=0\): no hay componente del peso que lo haga deslizar.
- Si \(\theta\) aumenta, \(a\) aumenta.
- El valor máximo se alcanzaría en \(\theta = 90^\circ\):
  $$
  a = g
  $$

Este modelo es ideal y sirve como referencia para comparar con el caso con rozamiento.
