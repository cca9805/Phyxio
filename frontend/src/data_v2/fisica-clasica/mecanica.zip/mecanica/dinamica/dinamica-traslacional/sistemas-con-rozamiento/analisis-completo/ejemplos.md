# Analisis completo · Ejemplos

### Ejemplo 1 (horizontal, cinético)
Bloque en horizontal, fuerza \(F\) hacia la derecha.

$$
N = mg,\quad f_k = \mu_k mg
$$
$$
F - \mu_k mg = ma
$$

### Ejemplo 2 (verificación de estático)
Si el bloque está en reposo con una fuerza aplicada \(F\):

$$
f_s = F
$$

Se debe cumplir:
$$
F \le \mu_s N = \mu_s mg
$$

Si no se cumple, hay deslizamiento y el rozamiento pasa a ser cinético.
