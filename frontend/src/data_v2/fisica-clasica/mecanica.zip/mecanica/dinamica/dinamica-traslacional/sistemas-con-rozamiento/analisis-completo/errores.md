# Analisis completo · Errores típicos

- Elegir mal el sentido del rozamiento (debe oponerse al deslizamiento relativo).
- Usar f = μN sin decidir si es estático o cinético.
- Olvidar calcular N antes de usar μN.
- Hacer ΣF=ma con signos incoherentes.
- No verificar la hipótesis (estático vs cinético).
