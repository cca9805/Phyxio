# Analisis completo · Historia

El rozamiento fue durante siglos una “fuerza incómoda” porque no encajaba en modelos ideales.
Su formalización empírica como proporcional a la normal (leyes de Coulomb) permitió
incorporarlo a la mecánica clásica en problemas reales, aunque sigue siendo un modelo
aproximado útil en un rango enorme de situaciones.
