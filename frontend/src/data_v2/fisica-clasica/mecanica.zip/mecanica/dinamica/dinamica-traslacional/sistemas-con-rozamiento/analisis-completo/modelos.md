# Analisis completo · Modelos

- Superficies rígidas, μ constante.
- Cuerpos rígidos.
- Movimiento 1D en el eje elegido.
- Para cinético: hay deslizamiento.
- Para estático: se verifica f_s ≤ μ_s N.
