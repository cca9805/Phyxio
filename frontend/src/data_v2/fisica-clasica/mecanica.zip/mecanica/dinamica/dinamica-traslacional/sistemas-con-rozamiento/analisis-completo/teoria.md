## Análisis completo de sistemas con rozamiento

El rozamiento es una fuerza de contacto que aparece para oponerse al deslizamiento relativo.
En problemas típicos (bloques en horizontal o planos inclinados), el error más común es
tratarlo como “una fuerza fija” sin comprobar el caso físico.

---

## 1) Modelo de rozamiento

### Rozamiento cinético (hay deslizamiento)
$$
f_k = \mu_k N
$$

### Rozamiento estático (no hay deslizamiento)
$$
f_s \le \mu_s N
$$

El rozamiento estático se ajusta “lo necesario” para impedir el deslizamiento, pero nunca
supera el máximo \( \mu_s N \).

---

## 2) Método general (pasos)

1. Define ejes y sentido positivo.
2. Dibuja fuerzas (DCL).
3. Halla la normal \(N\) (muchas veces usando equilibrio perpendicular):
$$
\sum F_{\perp} = 0
$$
4. Decide el sentido de la tendencia a moverse (o del movimiento).
5. Asigna el rozamiento en sentido contrario a esa tendencia.
6. Escribe la ecuación principal:
$$
\sum F_{\parallel} = ma
$$
7. Verifica el caso:
- Si asumiste rozamiento estático, comprueba que \(f_s \le \mu_s N\).
- Si no se cumple, entonces hay deslizamiento y debes usar \(f_k\).

---

## 3) Ejemplo plantilla (bloque en horizontal con fuerza F)

Si aplicas una fuerza \(F\) hacia la derecha:
- \(N = mg\)
- cinético: \(f_k = \mu_k mg\)

Ecuación:
$$
F - \mu_k mg = ma
$$

---

## 4) Verificación rápida
Una comprobación útil es el “residuo”:
$$
\Delta = \sum F - ma
$$
Una solución correcta debe dar \(\Delta \approx 0\) (con el modelo elegido).
