## Qué aprenderás
- A analizar sistemas traslacionales reales donde el rozamiento es determinante.
- A decidir correctamente el sentido del rozamiento (siempre se opone al deslizamiento relativo).
- A plantear ecuaciones completas con signos y ejes coherentes.
- A distinguir entre rozamiento estático (inicio del movimiento) y cinético (movimiento).

## Qué encontrarás aquí
- Plantillas de análisis completo: ejes, DCL y ecuaciones.
- Casos típicos con fuerzas aplicadas, normales y rozamiento.
- Errores frecuentes (signos, N, confusión μs/μk).
- Gráficos para explorar cómo cambian fuerza neta y aceleración.

## Ideas clave
- El rozamiento no “vale lo que quiera”: está limitado por el modelo.
- En movimiento (cinético):
  $$
  f_k = \mu_k N
  $$
- La ecuación dinámica se construye siempre con:
  $$
  \sum F = ma
  $$
- Un diagrama claro (DCL) evita el 90% de errores.

## Cómo usar este bloque
1. Elige ejes y sentido positivo.
2. Dibuja fuerzas y decide el sentido del rozamiento.
3. Calcula N y el valor del rozamiento (según el caso).
4. Escribe ΣF = ma y resuelve.
5. Verifica si el resultado es coherente con el sentido asumido.
