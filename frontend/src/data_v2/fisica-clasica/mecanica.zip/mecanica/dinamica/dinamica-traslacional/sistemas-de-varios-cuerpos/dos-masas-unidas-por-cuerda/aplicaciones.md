## Dos masas unidas por una cuerda · Aplicaciones

- Elevación de cargas con contrapeso.
- Sistemas de entrenamiento (poleas y masas).
- Modelos de arranque de mecanismos con masas conectadas.
- Laboratorio: medida indirecta de g o tensiones.
