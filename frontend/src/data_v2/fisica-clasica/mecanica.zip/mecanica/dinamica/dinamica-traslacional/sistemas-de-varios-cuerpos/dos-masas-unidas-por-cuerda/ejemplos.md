## Dos masas unidas por una cuerda · Ejemplos

### Ejemplo
\(m_1 = 2\,kg\), \(m_2 = 5\,kg\), \(g=9.8\,m/s^2\).

$$
a = \frac{(5-2)9.8}{2+5} = \frac{29.4}{7} = 4.2\ m/s^2
$$

Tensión (por \(m_1\)):

$$
T = m_1(g+a)=2(9.8+4.2)=28\ N
$$
