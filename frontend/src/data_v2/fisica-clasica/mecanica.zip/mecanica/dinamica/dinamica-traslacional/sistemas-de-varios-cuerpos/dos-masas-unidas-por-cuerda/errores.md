## Dos masas unidas por una cuerda · Errores típicos

- Cambiar el sentido positivo entre ecuaciones sin control de signos.
- Usar T diferente en cada lado de una cuerda ideal.
- Olvidar que ambas masas comparten |a|.
- Suponer a = g (solo pasa en casos extremos, no en Atwood ideal).
