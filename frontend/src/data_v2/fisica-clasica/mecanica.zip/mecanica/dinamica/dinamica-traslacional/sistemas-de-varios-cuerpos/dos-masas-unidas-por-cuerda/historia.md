## Dos masas unidas por una cuerda · Historia

La máquina de Atwood se diseñó para estudiar el movimiento acelerado con una aceleración
controlable (menor que g), facilitando mediciones experimentales y validación de ΣF = ma.
