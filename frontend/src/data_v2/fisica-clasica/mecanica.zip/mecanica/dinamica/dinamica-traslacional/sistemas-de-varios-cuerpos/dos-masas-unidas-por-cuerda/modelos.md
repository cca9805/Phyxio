## Dos masas unidas por una cuerda · Modelos

- Cuerda ideal: sin masa, inextensible.
- Polea ideal: sin rozamiento ni inercia.
- Tensión uniforme en la cuerda.
- Movimiento 1D (una masa sube, la otra baja).
