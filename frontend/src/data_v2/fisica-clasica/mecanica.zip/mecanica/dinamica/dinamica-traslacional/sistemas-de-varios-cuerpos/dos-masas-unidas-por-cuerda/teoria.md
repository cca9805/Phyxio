## Dos masas unidas por una cuerda (modelo tipo Atwood)

Considera dos masas \(m_1\) y \(m_2\) conectadas por una cuerda ideal que pasa por una polea ideal.
Suponiendo que \(m_2 > m_1\), el sistema acelera: \(m_2\) baja y \(m_1\) sube.

Tomamos como positiva la aceleración \(a\) en el sentido del movimiento:
- para \(m_2\): hacia abajo positivo,
- para \(m_1\): hacia arriba positivo.

---

## Ecuaciones por cuerpos

Para \(m_2\) (baja):
$$
m_2 g - T = m_2 a
$$

Para \(m_1\) (sube):
$$
T - m_1 g = m_1 a
$$

Sumando ambas ecuaciones, desaparece la tensión:

$$
(m_2 - m_1)g = (m_1 + m_2)a
$$

Por tanto:

$$
a = \frac{(m_2 - m_1)g}{m_1 + m_2}
$$

---

## Tensión

Sustituyendo en cualquiera:

$$
T = m_1(g + a) = m_2(g - a)
$$

---

## Interpretación
- Si \(m_1 = m_2\), entonces \(a=0\): equilibrio.
- Cuanto mayor la diferencia \(m_2 - m_1\), mayor la aceleración.
- La tensión siempre queda entre \(m_1 g\) y \(m_2 g\) (para \(m_2>m_1\)).
