# sistemas-de-varios-cuerpos

## Qué aprenderás
- A analizar sistemas formados por dos o más cuerpos conectados (cuerdas, poleas, contactos).
- A decidir cuándo conviene estudiar cada cuerpo por separado y cuándo estudiar el sistema completo.
- A identificar fuerzas internas (tensión, fuerzas de contacto) y entender por qué se cancelan al considerar el sistema global.
- A construir ecuaciones coherentes usando la segunda ley de Newton.

## Qué encontrarás aquí
- Metodología paso a paso para resolver sistemas de varios cuerpos.
- Reglas prácticas sobre tensiones, poleas y restricciones geométricas.
- Casos típicos: dos bloques, bloque y masa colgante, máquinas de Atwood, contactos con rozamiento, etc.
- Ejemplos y errores frecuentes (signos, tensiones, aceleraciones incompatibles).

## Ideas clave
- En muchos problemas, todos los cuerpos comparten una misma aceleración (o aceleraciones relacionadas) por una restricción:
  - cuerda inextensible,
  - polea ideal,
  - contacto sin deslizamiento, etc.
- Si analizas el sistema completo, las fuerzas internas (como la tensión) pueden desaparecer de la ecuación:
  $$
  \sum F_{\text{externas}} = M a
  $$
  donde \(M\) es la masa total del sistema.
- Si analizas cada cuerpo por separado, necesitas escribir:
  $$
  \sum F_i = m_i a_i
  $$
  y usar la restricción para relacionar \(a_1, a_2, \dots\).

## Cómo usar este bloque
1. Decide el nivel de análisis:
   - **por cuerpos** (más detallado),
   - **por sistema** (más rápido y limpio si hay tensiones internas).
2. Dibuja el DCL de cada cuerpo (o del sistema).
3. Elige ejes y sentido positivo coherente para todos.
4. Escribe ΣF = ma en cada ecuación.
5. Aplica la restricción (misma cuerda, misma aceleración, etc.).
6. Resuelve y verifica coherencia: signos, unidades y sentido del movimiento.

## Errores típicos
- Cambiar el sentido del eje entre cuerpos sin un criterio.
- Suponer tensiones distintas en una cuerda ideal.
- Olvidar que fuerzas internas se cancelan al analizar el sistema completo.
- No imponer la restricción geométrica (aceleraciones incompatibles).

## Conexiones
- Extiende los sistemas simples (bloque, bloque colgante, plano inclinado).
- Base para poleas, Atwood y sistemas con rozamiento en varios cuerpos.
- Conecta con energía y trabajo en sistemas compuestos.
