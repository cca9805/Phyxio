# Poleas compuestas · Aplicaciones

- Polipastos para elevar cargas en obra y talleres.
- Sistemas de rescate y maniobras con cuerda.
- Izado manual donde interesa reducir el esfuerzo máximo.
- Mecanismos de elevación en maquinaria y almacenes.
