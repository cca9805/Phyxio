# Poleas compuestas · Ejemplos

### Ejemplo 1 (ideal)
Carga con \(W = 800\,N\) y \(n = 4\) tramos sosteniendo la carga.

$$
F = \frac{W}{n} = \frac{800}{4} = 200\,N
$$

Si quieres elevar la carga \(0.30\,m\):

$$
\Delta x_{pull} = n\Delta x_{load} = 4\cdot 0.30 = 1.20\,m
$$
