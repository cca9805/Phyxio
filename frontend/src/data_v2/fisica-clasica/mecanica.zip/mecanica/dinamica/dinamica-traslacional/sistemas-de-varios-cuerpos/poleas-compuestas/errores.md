# Poleas compuestas · Errores típicos

- Contar mal los tramos que sostienen la carga (n).
- Pensar que “menos fuerza” significa “menos trabajo”: en ideal el trabajo se conserva.
- Confundir T (tensión) con W (peso) sin tener en cuenta n.
- Aplicar ΣF=ma sin imponer la restricción geométrica.
- Olvidar que el recorrido al tirar crece proporcionalmente con n.
