# Poleas compuestas · Historia

Los polipastos se han usado durante siglos para mover cargas grandes con fuerza humana.
Físicamente son un ejemplo muy didáctico de cómo la geometría transforma fuerza y recorrido
sin violar la conservación de la energía.
