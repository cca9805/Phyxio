# Poleas compuestas · Modelos

- Poleas ideales: sin rozamiento y sin inercia.
- Cuerda ideal: sin masa e inextensible.
- Tensión uniforme en cada tramo continuo de cuerda.
- La ventaja mecánica ideal se determina contando los tramos que sostienen la carga (n).
- La geometría impone la relación fuerza-recorrido.
