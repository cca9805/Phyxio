## Poleas compuestas (polipasto ideal)

Un polipasto combina varias poleas para repartir el peso de una carga entre varios tramos de cuerda.
En el modelo ideal (poleas y cuerda ideales), el resultado esencial es geométrico.

---

## 1) Ventaja mecánica ideal

Si la carga está sostenida por \(n\) tramos de cuerda, cada tramo ejerce una tensión \(T\) hacia arriba.
La fuerza total hacia arriba sobre la carga es:

$$
nT
$$

En equilibrio:

$$
nT = W \Rightarrow T = \frac{W}{n}
$$

Si el operador tira del extremo libre y en ideal \(F = T\), entonces:

$$
F = \frac{W}{n}
$$

---

## 2) Restricción geométrica (recorridos)

Si la carga sube \(\Delta x_{load}\), cada tramo que la sostiene se acorta \(\Delta x_{load}\).
El acortamiento total es \(n\Delta x_{load}\), por tanto el extremo libre debe moverse:

$$
\Delta x_{pull} = n\,\Delta x_{load}
$$

---

## 3) Conservación del trabajo (ideal)

$$
F\,\Delta x_{pull} = W\,\Delta x_{load}
$$

Sustituyendo \(\Delta x_{pull} = n\Delta x_{load}\):

$$
F\,n\,\Delta x_{load} = W\,\Delta x_{load} \Rightarrow F = \frac{W}{n}
$$

---

## 4) Comentario dinámico
Si hay aceleración, se usa:

$$
\sum F = ma
$$

y se combina con la restricción geométrica.
En el modelo ideal, el factor \(n\) sigue gobernando la relación entre el movimiento del extremo libre y la carga.
