# Poleas simples · Aplicaciones

- Polipastos simples para elevar cargas.
- Elevación manual en talleres y construcción.
- Sistemas de rescate y maniobras con cuerda.
- Reducción de fuerza en mecanismos de izado.
