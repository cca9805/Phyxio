# Poleas simples · Ejemplos

### Ejemplo 1 (polea fija, equilibrio)
Carga con peso \(W = 200\,N\).

$$
F = W = 200\,N
$$

### Ejemplo 2 (polea móvil simple, equilibrio)
Carga con \(W = 200\,N\) sostenida por \(n=2\) tramos.

$$
F = \frac{W}{n} = \frac{200}{2} = 100\,N
$$

Si quieres subir la carga \(0.5\,m\):

$$
\Delta x_{pull} = n \Delta x_{load} = 2 \cdot 0.5 = 1\,m
$$
