# Poleas simples - Errores

- Suponer que una polea móvil “reduce trabajo”: reduce fuerza, pero aumenta recorrido.
- Usar tensiones distintas en un mismo tramo de cuerda ideal.
- Contar mal los tramos que sostienen la carga (la ventaja depende de n).
- Mezclar análisis geométrico con ΣF=ma sin imponer la restricción.
- Olvidar que una polea fija solo cambia dirección (en ideal F=W).
