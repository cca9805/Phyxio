# Poleas simples · Historia

Las poleas se utilizan desde la antigüedad para manipular cargas. Su interés físico en
mecánica clásica está en separar dos ideas: la dinámica (ΣF=ma) y la geometría de la cuerda
(restricción), que determina la ventaja mecánica ideal.
