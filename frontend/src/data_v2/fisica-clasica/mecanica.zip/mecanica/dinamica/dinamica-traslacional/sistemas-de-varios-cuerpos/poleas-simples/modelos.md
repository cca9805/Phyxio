# Poleas simples · Modelos

- Polea ideal: sin rozamiento y sin inercia (no “consume” energía).
- Cuerda ideal: sin masa e inextensible.
- Tensión constante en un mismo tramo continuo de cuerda.
- El número de tramos que sostienen la carga determina la ventaja mecánica ideal.
- La geometría impone relaciones de desplazamiento/velocidad/aceleración.

