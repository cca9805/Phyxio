## Poleas simples (modelo ideal)

Una polea es un dispositivo que guía una cuerda para transmitir fuerza y movimiento.
En el modelo ideal:
- la cuerda es inextensible y sin masa,
- la polea no tiene rozamiento ni inercia,
- la tensión es constante a lo largo de un mismo tramo continuo de cuerda.

---

## 1) Polea fija
Una polea fija **solo cambia la dirección** de la fuerza aplicada.  
En ideal:

$$
F = T
$$

y si la carga \(W\) está en equilibrio (sin aceleración):

$$
T = W
$$

Por tanto:

$$
F = W
$$

No hay ventaja mecánica en fuerza: la ventaja es de dirección.

---

## 2) Polea móvil
En una polea móvil, la carga está sostenida por **dos tramos** de cuerda (en la configuración más simple).
Si la tensión en la cuerda es \(T\), la fuerza total hacia arriba sobre la carga es:

$$
2T
$$

En equilibrio:

$$
2T = W \Rightarrow T = \frac{W}{2}
$$

Como el esfuerzo aplicado en el extremo libre suele ser \(F=T\), entonces:

$$
F = \frac{W}{2}
$$

Esto es una **ventaja mecánica ideal** de 2.

---

## 3) Restricción geométrica (fuerza vs recorrido)
Una regla esencial: si la carga está sostenida por \(n\) tramos de cuerda, idealmente:

$$
F = \frac{W}{n}
$$

pero a cambio, el extremo libre debe recorrer \(n\) veces más distancia:

$$
\Delta x_{\text{tirar}} = n\,\Delta x_{\text{carga}}
$$

Por eso, en ideal, el trabajo se conserva:

$$
F\,\Delta x_{\text{tirar}} = W\,\Delta x_{\text{carga}}
$$

---

## 4) Dinámica (si hay aceleración)
Si la carga (masa \(m\)) acelera, se usa:

$$
\sum F = ma
$$

y se combina con la restricción geométrica para relacionar aceleraciones entre extremos de la cuerda.
