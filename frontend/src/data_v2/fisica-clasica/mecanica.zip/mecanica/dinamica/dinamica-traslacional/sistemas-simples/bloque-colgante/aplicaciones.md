# Bloque colgante · Aplicaciones

- Ascensores: relación entre tensión (o fuerza de soporte) y aceleración.
- Grúas y elevación de cargas.
- Tensado de cables en sistemas verticales.
- Calibración de sensores de fuerza y dinamómetros.
