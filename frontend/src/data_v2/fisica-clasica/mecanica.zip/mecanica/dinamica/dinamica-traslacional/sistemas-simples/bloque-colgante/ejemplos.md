# Bloque colgante · Ejemplos

### Ejemplo 1 (equilibrio)
Un bloque de \(m=3\,\text{kg}\) cuelga en reposo.

$$
T = mg = 3 \cdot 9.8 = 29.4\ \text{N}
$$

### Ejemplo 2 (acelera hacia abajo)
\(m=2\,\text{kg}\), \(a=1.5\,\text{m/s}^2\) hacia abajo.

$$
T = m(g-a) = 2(9.8-1.5)=16.6\ \text{N}
$$

### Ejemplo 3 (acelera hacia arriba)
Si el bloque acelera hacia arriba con \(1.5\,\text{m/s}^2\), entonces con nuestro convenio \(a=-1.5\):

$$
T = m(g-a)=2(9.8-(-1.5))=22.6\ \text{N}
$$
