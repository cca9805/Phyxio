# Bloque colgante · Errores típicos

- Cambiar el sentido del eje y no cambiar los signos.
- Confundir “aceleración hacia arriba” con “a positiva” sin indicar convenio.
- Usar T = mg siempre (solo vale si a=0).
- Mezclar N (normal) en un sistema colgante (no hay normal).
