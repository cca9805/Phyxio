# Bloque colgante · Historia

Los sistemas colgantes fueron fundamentales en los primeros análisis de dinámica
newtoniana porque permiten aislar fuerzas con claridad: peso y tensión. También
se usan como modelo base para sistemas con poleas (máquina de Atwood).
