# Bloque colgante · Modelos

- Cuerda ideal (sin masa, inextensible).
- Movimiento vertical unidimensional.
- Se ignora resistencia del aire.
- g constante.
