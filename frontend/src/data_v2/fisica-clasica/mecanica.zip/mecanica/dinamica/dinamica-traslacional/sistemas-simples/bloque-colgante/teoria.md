## Bloque colgante (dinámica vertical)

Considera un bloque de masa \(m\) colgando de una cuerda. Sobre él actúan:
- el peso \( \vec{P} = m\vec{g} \) (hacia abajo),
- la tensión \( \vec{T} \) (hacia arriba).

Elegimos el eje vertical y, para fijar ideas, tomamos **hacia abajo como positivo**.

Entonces la suma de fuerzas es:

$$
\sum F = mg - T
$$

y la segunda ley de Newton:

$$
mg - T = ma
$$

De aquí se obtiene la relación entre tensión y aceleración:

$$
T = m(g - a)
$$

---

## Casos importantes

### Equilibrio
Si el bloque está en reposo o se mueve con velocidad constante, \(a=0\):

$$
T = mg
$$

### Aceleración hacia abajo
Si el bloque acelera hacia abajo, entonces \(a>0\) y:

$$
T = m(g-a) < mg
$$

La tensión es menor que el peso.

### Aceleración hacia arriba
Si el bloque acelera hacia arriba, con nuestro convenio \(a<0\), entonces:

$$
T = m(g-a) > mg
$$

La tensión es mayor que el peso.

---

## Interpretación física

La tensión “compite” con el peso:
- si \(T=mg\) no hay aceleración,
- si \(T<mg\) el bloque acelera hacia abajo,
- si \(T>mg\) el bloque acelera hacia arriba.

El signo de \(a\) depende del convenio del eje, pero la física es la misma.
