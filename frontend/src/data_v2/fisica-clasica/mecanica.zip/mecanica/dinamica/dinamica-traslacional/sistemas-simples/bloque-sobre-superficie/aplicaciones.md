# Bloque sobre superficie · Aplicaciones

- Movimiento de cajas sobre el suelo.
- Transporte de cargas.
- Ensayos de coeficiente de rozamiento.
- Modelos básicos en ingeniería mecánica.
