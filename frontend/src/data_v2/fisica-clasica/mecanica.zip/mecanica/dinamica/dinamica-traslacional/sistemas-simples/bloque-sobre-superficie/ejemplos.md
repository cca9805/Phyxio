# Bloque sobre superficie · Ejemplos

### Ejemplo 1 (sin rozamiento)
Un bloque de masa \(m = 2\,\text{kg}\) es empujado con \(F = 6\,\text{N}\).

$$
a = \frac{F}{m} = \frac{6}{2} = 3\ \text{m/s}^2
$$

---

### Ejemplo 2 (con rozamiento)
Datos: \(m = 4\,\text{kg}\), \(F = 20\,\text{N}\), \(\mu = 0.2\).

$$
f = \mu m g = 0.2 \cdot 4 \cdot 9.8 = 7.84\ \text{N}
$$

$$
a = \frac{20 - 7.84}{4} = 3.04\ \text{m/s}^2
$$
