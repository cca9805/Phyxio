# Bloque sobre superficie · Errores típicos

- Olvidar que N = mg en superficie horizontal.
- Usar rozamiento sin comprobar si el bloque se mueve.
- Confundir rozamiento estático con cinético.
- No respetar el signo de las fuerzas.
