# Bloque sobre superficie · Historia

El estudio de bloques sobre superficies fue central en el desarrollo de la
mecánica newtoniana, al permitir verificar experimentalmente la relación
entre fuerza, masa y aceleración en sistemas controlables y reproducibles.
