# Bloque sobre superficie · Modelos

- Bloque tratado como punto material.
- Movimiento horizontal unidimensional.
- Rozamiento constante (modelo cinético).
- Superficie rígida y fija.
