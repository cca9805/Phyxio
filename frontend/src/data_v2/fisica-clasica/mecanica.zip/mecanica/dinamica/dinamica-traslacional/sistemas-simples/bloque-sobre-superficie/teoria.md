## Bloque sobre una superficie horizontal

Consideramos un bloque de masa \(m\) apoyado sobre una superficie horizontal.
Sobre él pueden actuar:
- su peso \( \vec{P} = m\vec{g} \),
- la fuerza normal \( \vec{N} \),
- una fuerza aplicada horizontal \( \vec{F} \),
- una fuerza de rozamiento \( \vec{f} \).

---

## Equilibrio vertical

En la dirección vertical, el bloque no se acelera, por lo que:

$$
\sum F_y = 0 \Rightarrow N = mg
$$

---

## Dinámica horizontal

En la dirección horizontal, la segunda ley de Newton establece:

$$
\sum F_x = m a
$$

Si no hay rozamiento:

$$
a = \frac{F}{m}
$$

---

## Con rozamiento

La fuerza de rozamiento cinético tiene módulo:

$$
f = \mu N = \mu m g
$$

La ecuación de movimiento queda:

$$
F - f = m a
$$

y por tanto:

$$
a = \frac{F - \mu m g}{m}
$$

---

## Interpretación física

- Si \(F > \mu m g\), el bloque acelera.
- Si \(F = \mu m g\), el bloque se mueve con velocidad constante.
- Si \(F < \mu m g\), el bloque se frena o no llega a moverse.

Este sistema es uno de los modelos fundamentales de la dinámica traslacional.
