## Qué aprenderás
- A identificar las fuerzas que actúan sobre sistemas traslacionales simples.
- A aplicar la segunda ley de Newton en una dimensión.
- A distinguir entre equilibrio, movimiento uniforme y movimiento acelerado.
- A analizar el efecto del rozamiento en el movimiento.

## Qué encontrarás aquí
- Modelos básicos de dinámica traslacional.
- Diagramas conceptuales de fuerzas (DCL implícitos).
- Ejemplos típicos resueltos paso a paso.
- Gráficos de coordenadas para interpretar aceleraciones, velocidades y fuerzas.

## Ideas clave
- La dinámica traslacional se rige por la relación:
  $$
  \sum F = m a
  $$
- El movimiento depende de la **fuerza neta**, no de fuerzas individuales.
- El rozamiento puede oponerse al movimiento o impedirlo completamente.
- Sistemas simples sirven como base para modelos más complejos.

## Cómo usar este bloque
1. Identifica el sistema y las fuerzas que actúan sobre él.
2. Escribe la suma de fuerzas en la dirección del movimiento.
3. Aplica la segunda ley de Newton.
4. Usa los gráficos para interpretar resultados y comparar casos.

## Conexiones
- Base para planos inclinados, poleas y sistemas compuestos.
- Conecta con energía y trabajo.
- Fundamental para comprender el rozamiento en sistemas reales.
