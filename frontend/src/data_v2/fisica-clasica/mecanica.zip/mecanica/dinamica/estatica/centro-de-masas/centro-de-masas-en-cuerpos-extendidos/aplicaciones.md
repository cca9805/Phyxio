# Aplicaciones

- Ingeniería estructural.
- Estabilidad de cuerpos.
- Análisis del movimiento rígido.
