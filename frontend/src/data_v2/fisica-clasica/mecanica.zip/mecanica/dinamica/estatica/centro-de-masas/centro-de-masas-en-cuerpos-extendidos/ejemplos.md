# Ejemplos

- Barra uniforme.
- Barra con densidad variable.
- Disco uniforme.
