# Errores comunes

1) Usar fórmulas discretas en cuerpos continuos.
2) Olvidar dividir por la masa total.
3) Ignorar simetrías evidentes.
4) Confundir centro de masas con centro geométrico.
