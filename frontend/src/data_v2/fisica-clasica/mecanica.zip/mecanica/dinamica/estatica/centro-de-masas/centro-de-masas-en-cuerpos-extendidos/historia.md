# Historia

- Desarrollo del cálculo integral ligado a la mecánica.
- Uso sistemático en física clásica.
