# Modelos y validez

- Cuerpos rígidos continuos.
- Densidad conocida o uniforme.
- Sin efectos relativistas.
