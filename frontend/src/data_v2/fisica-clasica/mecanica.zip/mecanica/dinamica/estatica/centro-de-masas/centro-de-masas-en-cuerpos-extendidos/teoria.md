# Centro de masas en cuerpos extendidos

## Idea clave
Cuando un cuerpo tiene masa distribuida de forma continua, el centro de masas
se obtiene **integrando** la posición de cada elemento diferencial de masa.

---

## Definición continua
La expresión general es:

$$
\vec r_{cm} = \frac{1}{M}\int \vec r\, dm
$$

donde \(dm\) representa un elemento infinitesimal de masa.

---

## Densidad
Para cuerpos continuos, la masa se expresa como:

$$
dm = \rho\, dV
$$

Si la densidad es constante, puede sacarse fuera de la integral.

---

## Importancia de la simetría
En cuerpos con simetría:
- el centro de masas coincide con el centro geométrico
- muchas integrales se evitan razonando geométricamente

Ejemplos:
- barra uniforme → centro
- disco uniforme → centro
- placa rectangular uniforme → centro geométrico

---

## Caso unidimensional continuo
Para una barra alineada con el eje x:

$$
x_{cm} = \frac{1}{M}\int x\, dm
$$

Si la densidad es uniforme:

$$
x_{cm} = \frac{1}{L}\int_0^L x\, dx = \frac{L}{2}
$$

---

## Cuerpos no uniformes
Si la densidad depende de la posición, por ejemplo \(\rho(x)\),
el centro de masas **ya no coincide** con el centro geométrico.

---

## Qué es calculable y qué no
- Las expresiones integrales son **descriptivas**.
- El cálculo concreto depende del cuerpo y su densidad.
- En la práctica se usan simetrías siempre que sea posible.
