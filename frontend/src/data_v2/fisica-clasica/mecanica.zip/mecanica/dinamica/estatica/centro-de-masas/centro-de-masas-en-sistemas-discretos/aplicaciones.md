# Aplicaciones

- Movimiento global de sistemas de partículas.
- Biomecánica (centro de masas del cuerpo).
- Astronomía (baricentro de sistemas planetarios).
- Ingeniería (modelos simplificados de estructuras).
