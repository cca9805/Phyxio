# Ejemplos

## 1) Dos masas en 1D
m1 = 2 kg en x1 = 0 m  
m2 = 6 kg en x2 = 4 m

$$
x_{cm} = \frac{2\cdot 0 + 6\cdot 4}{2+6} = 3\ \mathrm{m}
$$

## 2) Tres masas en 2D
Aplicar:
$$
x_{cm}= \frac{\sum m_i x_i}{\sum m_i},\quad
y_{cm}= \frac{\sum m_i y_i}{\sum m_i}
$$
