# Errores comunes

1) Olvidar dividir por la masa total.
2) Usar posiciones sin signo (eje mal definido).
3) Mezclar unidades (cm con m).
4) Confundir el centro de masas con el punto medio cuando las masas no son iguales.
5) En 2D, calcular x_cm bien pero y_cm mal por usar el denominador equivocado.
