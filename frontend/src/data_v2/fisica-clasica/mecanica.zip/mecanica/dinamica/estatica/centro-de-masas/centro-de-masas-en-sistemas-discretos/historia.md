# Historia

- El concepto se consolida con la mecánica clásica.
- Es una herramienta central para reducir sistemas complejos a comportamiento global.
