# Modelos y validez

- Masas puntuales o cuerpos cuyo tamaño es despreciable frente a distancias.
- Sistema clásico (no relativista).
- Coordenadas en un sistema de referencia dado.
