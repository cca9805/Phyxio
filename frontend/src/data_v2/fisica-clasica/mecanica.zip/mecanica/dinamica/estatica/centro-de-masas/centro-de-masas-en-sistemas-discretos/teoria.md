# Centro de masas en sistemas discretos

## Idea clave
Un sistema de masas puntuales puede sustituirse, para muchas descripciones globales,
por un punto situado en el **centro de masas**, que es un **promedio ponderado por la masa**.

---

## Definición discreta (vectorial)
Para N partículas:

$$
\vec r_{cm} = \frac{1}{M}\sum_i m_i\,\vec r_i
$$

donde la masa total es:

$$
M = \sum_i m_i
$$

---

## Caso 1D (sobre un eje)
Si todas las partículas están sobre el eje x:

$$
x_{cm} = \frac{\sum_i m_i x_i}{\sum_i m_i}
$$

### Dos masas
$$
x_{cm} = \frac{m_1 x_1 + m_2 x_2}{m_1+m_2}
$$

Interpretación:
- si \(m_1 = m_2\), el centro de masas queda justo en el punto medio
- si una masa es mayor, el centro de masas se desplaza hacia ella

---

## Caso 2D/3D (por componentes)
Se aplica la misma idea componente a componente.

En 2D:

$$
x_{cm}= \frac{\sum_i m_i x_i}{\sum_i m_i},\quad
y_{cm}= \frac{\sum_i m_i y_i}{\sum_i m_i}
$$

En 3D se añade:

$$
z_{cm}= \frac{\sum_i m_i z_i}{\sum_i m_i}
$$

---

## Qué es calculable y qué no
Calculable:
- casos con número de masas fijado (2 o 3, etc.)
- cálculo por componentes en 2D/3D con datos numéricos

Descriptivo:
- la definición general si no se fija N o no se enumeran partículas
