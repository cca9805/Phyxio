# Aplicaciones

- Análisis del movimiento de sistemas complejos.
- Biomecánica y estabilidad.
- Ingeniería estructural.
