# Ejemplos

- Dos masas distintas en una barra.
- Sistema de partículas alineadas.
- Comparación con el centro geométrico.
