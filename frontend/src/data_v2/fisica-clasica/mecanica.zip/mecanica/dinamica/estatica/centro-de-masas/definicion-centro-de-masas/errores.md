# Errores comunes

1) Confundir centro de masas con centro geométrico.
2) Usar masa total incorrecta.
3) Olvidar que puede estar fuera del cuerpo.
4) Aplicar fórmulas 1D en sistemas 2D o 3D sin justificar.
