# Historia

- Concepto desarrollado en la mecánica clásica.
- Fundamental en el estudio de sistemas de partículas.
