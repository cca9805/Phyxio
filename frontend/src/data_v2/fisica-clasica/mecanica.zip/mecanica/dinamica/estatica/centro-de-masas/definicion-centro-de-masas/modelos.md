# Modelos y validez

- Partículas puntuales o cuerpos rígidos.
- Sin efectos relativistas.
- Sistema clásico.
