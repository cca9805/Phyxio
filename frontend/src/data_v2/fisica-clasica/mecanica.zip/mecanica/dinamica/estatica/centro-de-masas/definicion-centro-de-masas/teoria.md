# Centro de masas – definición

## Idea clave
El **centro de masas** es el punto que representa **cómo está distribuida la masa**
de un sistema.

El movimiento del sistema completo puede describirse como si **toda la masa**
estuviera concentrada en ese punto.

---

## Definición general
Para un sistema de partículas, el vector posición del centro de masas es:

$$
\vec r_{cm} = \frac{1}{m}\sum_i m_i\,\vec r_i
$$

donde:
- \(m_i\) es la masa de cada partícula,
- \(\vec r_i\) su vector posición,
- \(m\) la masa total del sistema.

---

## Interpretación física
- El centro de masas **no tiene por qué coincidir con un punto material**.
- Puede estar fuera del cuerpo (por ejemplo, en un aro).
- Resume el comportamiento global del sistema.

---

## Centro de masas y movimiento
Una propiedad fundamental es que:

> El centro de masas se mueve como si toda la masa estuviera concentrada en él
> y todas las fuerzas externas actuaran sobre ese punto.

Esto conecta directamente con la **segunda ley de Newton**.

---

## Caso unidimensional
En una dimensión:

$$
x_{cm} = \frac{\sum_i m_i x_i}{m}
$$

Para dos masas:

$$
x_{cm} = \frac{m_1 x_1 + m_2 x_2}{m_1 + m_2}
$$

---

## Centro de masas vs centro geométrico
- **Centro geométrico**: depende solo de la forma.
- **Centro de masas**: depende de la distribución de masa.
- Coinciden solo si la densidad es uniforme.

---

## Qué es calculable y qué no
- Calculable: \(x_{cm}\) en 1D con masas discretas.
- Descriptivo: definición vectorial general.
