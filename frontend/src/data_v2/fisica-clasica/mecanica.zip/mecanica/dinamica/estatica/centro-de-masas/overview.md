# Centro de masas

## ¿Qué es el centro de masas?
El **centro de masas** es un punto matemático que representa la **distribución global de la masa** de un sistema.
Aunque no coincida con ningún punto material real, permite describir el movimiento del sistema completo
como si toda su masa estuviera concentrada en ese punto.

Es una herramienta fundamental en mecánica porque **simplifica sistemas complejos** formados por muchas
partículas o cuerpos extensos.

---

## Idea física clave
Para el movimiento global de un sistema:

> El sistema se comporta como si **toda la masa estuviera concentrada en el centro de masas**  
> y **todas las fuerzas externas actuaran sobre él**.

Esta idea conecta directamente el centro de masas con las **leyes de Newton** y explica por qué
muchos problemas pueden resolverse estudiando solo ese punto.

---

## Qué aprenderás en este bloque
En este tema aprenderás a:

- Comprender el significado físico del centro de masas.
- Calcular su posición en **sistemas discretos** (masas puntuales).
- Calcularlo en **cuerpos extendidos** mediante modelos continuos.
- Usar simetrías para simplificar cálculos.
- Relacionar el centro de masas con el movimiento global de un sistema.

---

## Cómo se organiza el contenido
El bloque se divide en tres partes bien diferenciadas:

### 1️⃣ Definición
Se introduce el concepto de centro de masas y su interpretación física,
sin entrar todavía en cálculos detallados.

### 2️⃣ Centro de masas en sistemas discretos
Se estudian sistemas formados por un número finito de masas puntuales.
Aquí aparecen las **sumas ponderadas** y el cálculo por componentes en 1D, 2D y 3D.

### 3️⃣ Centro de masas en cuerpos extendidos
Se generaliza el concepto a cuerpos con masa distribuida de forma continua,
introduciendo la **densidad** y las **integrales**, así como el uso de simetrías.

---

## Por qué es importante
El centro de masas aparece en numerosos contextos:

- Movimiento de sistemas de partículas.
- Biomecánica y movimiento humano.
- Ingeniería y diseño de estructuras.
- Astronomía (baricentro de sistemas planetarios).
- Análisis del movimiento de cuerpos rígidos.

Dominar este concepto es esencial para avanzar en **dinámica**, **rotación** y **estabilidad**.

---

## Qué no se trata aquí
En este bloque **no se estudia**:
- la estabilidad o el vuelco de cuerpos (eso se verá más adelante),
- el centro de gravedad en campos no uniformes,
- efectos relativistas.

El enfoque es estrictamente **clásico y cinemático/dinámico**.

---

## Cómo usar este bloque en Phyxio
- Empieza por la **Definición** para entender el concepto.
- Continúa con **Sistemas discretos** para aprender a calcularlo paso a paso.
- Avanza a **Cuerpos extendidos** para generalizar y conectar con problemas reales.

Cada subtema incluye teoría clara, calculadoras interactivas y gráficos dinámicos
para reforzar la comprensión.
