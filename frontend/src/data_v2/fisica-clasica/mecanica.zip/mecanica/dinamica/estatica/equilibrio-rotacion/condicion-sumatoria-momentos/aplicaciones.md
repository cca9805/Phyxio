# Aplicaciones

- Diseño de palancas.
- Ingeniería estructural.
- Análisis de vigas en equilibrio.
- Mecánica de máquinas simples.
