# Ejemplos típicos

- Barra apoyada en un punto con una fuerza aplicada.
- Palanca en equilibrio.
- Cuerpo colgado de una cuerda.
