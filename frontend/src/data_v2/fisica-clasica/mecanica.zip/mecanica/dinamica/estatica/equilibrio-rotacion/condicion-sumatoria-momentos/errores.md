# Errores comunes

1) Confundir brazo con distancia al punto.
2) Olvidar el seno del ángulo.
3) No fijar un criterio de signos.
4) Calcular momentos respecto a ejes mal elegidos.
5) Olvidar comprobar también el equilibrio traslacional.
