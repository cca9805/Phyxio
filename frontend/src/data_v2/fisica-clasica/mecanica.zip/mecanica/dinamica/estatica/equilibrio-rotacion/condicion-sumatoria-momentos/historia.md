# Contexto histórico

## Orígenes del concepto de momento
La idea de **momento de una fuerza** surge de la observación práctica de
herramientas simples como **palancas**, **balanzas** y **barras apoyadas**,
utilizadas desde la Antigüedad.

Mucho antes de una formulación matemática formal, ya se comprendía que:
- una fuerza aplicada más lejos del punto de apoyo produce un mayor efecto,
- no solo importa la intensidad de la fuerza, sino **dónde** se aplica.

---

## Arquímedes y la ley de la palanca
El primer tratamiento riguroso del equilibrio rotacional se debe a **Arquímedes**
(siglo III a.C.), quien formuló la **ley de la palanca**:

> Dos fuerzas están en equilibrio si sus efectos de giro se compensan.

Aunque Arquímedes no utilizó vectores ni trigonometría, su análisis geométrico
anticipa claramente el concepto moderno de momento.

La famosa frase atribuida a él:
> “Dadme un punto de apoyo y moveré el mundo”
resume de forma intuitiva el significado del momento de una fuerza.

---

## Desarrollo en la mecánica clásica
Con la aparición de la **mecánica newtoniana** (siglo XVII),
el estudio del equilibrio se sistematiza:

- Newton establece las leyes del movimiento.
- El equilibrio traslacional se describe con la suma de fuerzas nula.
- El equilibrio rotacional se introduce mediante la **suma de momentos nula**.

A partir de aquí, el momento de una fuerza se define de forma cuantitativa y
general, aplicable a cualquier sistema mecánico.

---

## Formalización matemática
Durante los siglos XVIII y XIX, con el desarrollo de la mecánica analítica,
el momento se expresa mediante:
- productos vectoriales,
- descomposición en componentes,
- criterios de signo según el sentido de giro.

Esto permite extender el concepto a:
- sistemas complejos,
- cuerpos rígidos,
- estructuras y máquinas reales.

---

## Importancia histórica y técnica
El estudio del equilibrio rotacional fue clave para:
- el desarrollo de la ingeniería estructural,
- el diseño de máquinas simples y compuestas,
- la comprensión del funcionamiento de balanzas y dinamómetros,
- la transición desde la mecánica empírica a la mecánica científica.

Hoy en día, la condición de suma de momentos nula es una herramienta básica
en ingeniería, arquitectura y física aplicada.

---

## Enfoque moderno
En la física actual, el momento de una fuerza se integra dentro de un marco
más amplio que incluye:
- dinámica rotacional,
- momento angular,
- conservación del momento angular.

Sin embargo, en el régimen clásico y para sistemas rígidos,
la **condición de equilibrio rotacional** sigue siendo una de las leyes
fundamentales del análisis mecánico.
