# Modelos y validez

- Cuerpos rígidos.
- Fuerzas coplanares.
- Sistema clásico no relativista.
