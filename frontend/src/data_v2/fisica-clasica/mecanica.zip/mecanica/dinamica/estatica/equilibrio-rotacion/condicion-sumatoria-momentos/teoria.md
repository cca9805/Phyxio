# Condición de equilibrio rotacional o condición sumatoria de momentos

## Idea clave
Un cuerpo rígido está en **equilibrio rotacional** cuando **no cambia su estado de rotación**.
Esto ocurre cuando la **suma de los momentos de todas las fuerzas** respecto a un punto o eje
es nula.

---

## Momento de una fuerza
El **momento** (o torque) de una fuerza mide su capacidad para producir rotación.

$$
\tau = r F \sin\theta
$$

donde:
- \(r\) es el brazo de la fuerza,
- \(F\) la intensidad de la fuerza,
- \(\theta\) el ángulo entre ambos.

---

## Condición de equilibrio rotacional
Para que un cuerpo esté en equilibrio rotacional debe cumplirse:

$$
\sum_i \tau_i = 0
$$

Esto significa que los momentos que tienden a hacer girar el cuerpo
en un sentido se compensan con los que lo hacen en el sentido contrario.

---

## Elección del eje
El punto respecto al cual se calculan los momentos puede elegirse libremente.
Elegir un eje adecuado permite:
- simplificar cálculos,
- anular momentos de fuerzas desconocidas,
- reducir el número de incógnitas.

---

## Equilibrio completo
Un cuerpo está en **equilibrio estático** cuando cumple simultáneamente:
- equilibrio traslacional,
- equilibrio rotacional.

Ambas condiciones son necesarias.

---

## Qué es calculable y qué no
- El momento de una fuerza es **calculable**.
- La condición de suma de momentos es **descriptiva** y se aplica
  tras analizar todas las fuerzas del sistema.
