# Aplicaciones

- Palancas.
- Balanzas.
- Diseño de herramientas.
- Ingeniería mecánica básica.
