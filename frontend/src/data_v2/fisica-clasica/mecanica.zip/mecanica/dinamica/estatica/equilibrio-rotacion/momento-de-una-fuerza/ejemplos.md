# Ejemplos típicos

- Puerta empujada cerca o lejos de la bisagra.
- Llave inglesa girando una tuerca.
- Palanca con fuerza aplicada perpendicularmente.
