# Errores comunes

1) Confundir brazo con distancia directa.
2) Olvidar el seno del ángulo.
3) No fijar el signo del momento.
4) Mezclar unidades.
5) Aplicar mal el punto de referencia.
