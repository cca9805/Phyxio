# Contexto histórico

El concepto de momento surge del estudio de palancas y máquinas simples
desde la Antigüedad.

Arquímedes fue el primero en formular de forma rigurosa la ley de la palanca,
anticipando el concepto moderno de momento de una fuerza.

Con el desarrollo de la mecánica clásica, el momento se formaliza
como una magnitud fundamental en el estudio del equilibrio y la rotación.
