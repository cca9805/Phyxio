# Momento de una fuerza

## Idea clave
El **momento de una fuerza** mide la capacidad de una fuerza para producir
**rotación** alrededor de un punto o eje.

Una misma fuerza puede producir efectos muy distintos dependiendo
de dónde y cómo se aplique.

---

## Definición
El momento de una fuerza respecto a un punto se define como:

$$
\tau = r F \sin\theta
$$

donde:
- \(r\) es el brazo de la fuerza,
- \(F\) es la intensidad de la fuerza,
- \(\theta\) es el ángulo entre ambos.

---

## Interpretación física
- Cuanto mayor es la fuerza, mayor es el momento.
- Cuanto mayor es la distancia al eje, mayor es el momento.
- Si la fuerza pasa por el eje (\(r=0\)), el momento es nulo.
- Si la fuerza es paralela al brazo (\(\theta=0\)), el momento es nulo.

---

## Brazo de la fuerza
El **brazo** es la distancia perpendicular desde el eje de giro
a la línea de acción de la fuerza.

No debe confundirse con la distancia directa al punto de aplicación.

---

## Caso particular: fuerza perpendicular
Si la fuerza es perpendicular al brazo:

$$
\tau = F x
$$

Este caso aparece con frecuencia en problemas sencillos y palancas.

---

## Signo del momento
Es necesario fijar un criterio de signos:
- giros antihorarios: positivos
- giros horarios: negativos

Lo importante es ser **coherente** en todo el problema.

---

## Qué es calculable y qué no
- El momento de una fuerza es **calculable**.
- El equilibrio rotacional se estudia combinando varios momentos.
