# Equilibrio y rotación

## ¿Qué estudia este bloque?
El bloque de **equilibrio y rotación** analiza cómo se comportan los cuerpos cuando:
- no cambian su estado de movimiento (equilibrio),
- o cuando giran alrededor de un eje (rotación).

Aquí se extienden las leyes de Newton para describir **movimientos angulares** y
situaciones en las que las fuerzas producen **giros**, no solo traslaciones.

---

## Idea física clave
Un cuerpo puede:
- **trasladarse**,  
- **rotar**,  
- o hacer ambas cosas a la vez.

Para describir completamente su comportamiento es necesario introducir nuevas magnitudes
(rotación) y nuevas condiciones (equilibrio).

> Un cuerpo está en equilibrio solo si **no acelera linealmente ni angularmente**.

---

## Qué aprenderás en este bloque
En este tema aprenderás a:

- Entender cuándo un cuerpo está en **equilibrio estático o dinámico**.
- Analizar la **rotación** de cuerpos rígidos alrededor de un eje.
- Interpretar el papel del **momento de una fuerza**.
- Relacionar fuerzas, momentos y condiciones de equilibrio.
- Aplicar estos conceptos a situaciones reales y técnicas.

---

## Cómo se organiza el contenido
El bloque se divide en varios subtemas conectados entre sí:

### 1️⃣ Condiciones de equilibrio
Se estudia cuándo un cuerpo permanece en reposo o en movimiento uniforme:
- equilibrio traslacional,
- equilibrio rotacional,
- interpretación física de ambas condiciones.

### 2️⃣ Momento de una fuerza
Se introduce el concepto de **momento** o **torque**, que mide la capacidad de una fuerza
para producir rotación alrededor de un eje.

### 3️⃣ Rotación de cuerpos rígidos
Se describen las magnitudes angulares (posición, velocidad y aceleración angular)
y su relación con las magnitudes lineales.

### 4️⃣ Aplicaciones y ejemplos
Se aplican los conceptos a:
- palancas,
- poleas,
- cuerpos apoyados,
- estructuras en equilibrio,
- sistemas que giran.

---

## Por qué es importante
El equilibrio y la rotación son esenciales para comprender:

- el funcionamiento de máquinas simples,
- la estabilidad de estructuras,
- el diseño mecánico e ingeniería,
- el comportamiento de cuerpos en rotación (ruedas, engranajes, ejes),
- muchos fenómenos cotidianos y tecnológicos.

Este bloque conecta directamente la **dinámica traslacional** con la **dinámica rotacional**.

---

## Qué no se trata aquí
En este bloque no se estudia todavía:
- vibraciones ni oscilaciones,
- dinámica de fluidos,
- efectos relativistas,
- modelos no clásicos.

El enfoque es **clásico**, con cuerpos rígidos y fuerzas bien definidas.

---

## Cómo usar este bloque en Phyxio
- Comienza por los conceptos
