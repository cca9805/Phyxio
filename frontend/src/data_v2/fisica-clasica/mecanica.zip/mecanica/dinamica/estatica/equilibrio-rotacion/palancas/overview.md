# Palancas

## ¿Qué es una palanca?
Una **palanca** es una máquina simple formada por una **barra rígida** que puede girar alrededor de un
**punto de apoyo** (fulcro). Aplicando una fuerza en un punto, puedes producir un efecto sobre una carga
en otro punto.

Su potencia no está en “crear” fuerza, sino en **redistribuirla**: permite intercambiar **fuerza**
por **distancia recorrida** (o por velocidad), manteniendo la lógica física del sistema.

---

## Idea física clave
En equilibrio estático (sin girar ni acelerarse):

> Una palanca está en equilibrio cuando la **suma de los momentos** respecto al apoyo es cero.

Es decir, el “efecto de giro” de la potencia compensa el “efecto de giro” de la resistencia.
Esto conecta directamente con:
- el **momento de una fuerza**,
- el **equilibrio de cuerpos rígidos**,
- y el **centro de masas**, porque el peso de un cuerpo actúa como si estuviera aplicado en su CM.

---

## Qué aprenderás en este bloque
En este tema aprenderás a:

- Identificar **apoyo**, **potencia** y **resistencia** en cualquier situación real.
- Clasificar palancas en **1er, 2º y 3er género** usando un criterio geométrico claro.
- Entender y calcular la **ventaja mecánica** e interpretarla físicamente.
- Relacionar el equilibrio de una palanca con el **centro de masas** (peso aplicado en el CM).
- Evitar errores típicos: brazos mal medidos, signos de momentos, interpretaciones energéticas incorrectas.

---

## Cómo se organiza el contenido
El bloque se divide en dos partes bien diferenciadas:

### 1️⃣ Tipos de palancas
Se clasifica la palanca según la posición relativa de:
- apoyo,
- potencia,
- resistencia.

Aprenderás a decidir el género **sin depender del dibujo**, solo del orden de los elementos.

### 2️⃣ Ventaja mecánica
Se estudia el “beneficio” de la palanca desde dos enfoques complementarios:
- definición como cociente entre resistencia y potencia,
- relación geométrica con los **brazos de palanca**.

También se conecta con el intercambio fuerza-recorrido (trabajo/energía en ideal).

---

## Por qué es importante
Las palancas aparecen en numerosos contextos:

- Herramientas y máquinas simples (tijeras, alicates, carretillas, abrebotellas).
- Biomecánica: músculos y huesos funcionan como palancas (a menudo de 3er género).
- Ingeniería y estructuras: transmisión de fuerzas y análisis de mecanismos.
- Física del equilibrio: es uno de los ejemplos más claros para dominar el concepto de **momento**.

Dominar palancas prepara el terreno para **estática avanzada**, **rotación**, **torque**, **máquinas simples**
y análisis de **cuerpos rígidos**.

---

## Qué no se trata aquí
En este bloque **no se estudia**:
- estabilidad y vuelco de cuerpos (se verá en un bloque específico),
- fuerzas no coplanares o mecanismos complejos con múltiples apoyos,
- análisis con deformaciones importantes (elasticidad/estructuras),
- centro de gravedad en campos no uniformes.

El enfoque es de **mecánica clásica** y palancas idealizadas para comprensión y cálculo.

---

## Cómo usar este bloque en Phyxio
- Empieza por **Tipos de palancas** para fijar el criterio de clasificación y reconocer casos reales.
- Continúa con **Ventaja mecánica** para cuantificar el comportamiento y conectar con cálculos.
- Usa las calculadoras y gráficos V2 para comprobar de forma interactiva cómo cambian momentos y VM
  al modificar posiciones, fuerzas y brazos.

Cada subtema incluye teoría clara, calculadoras interactivas y gráficos dinámicos
para reforzar la comprensión.
