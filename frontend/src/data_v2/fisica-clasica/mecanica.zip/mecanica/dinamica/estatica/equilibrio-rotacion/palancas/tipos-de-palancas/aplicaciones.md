# Aplicaciones

- Herramientas manuales (tijeras, alicates, abrebotellas, carretillas).
- Biomecánica (modelos simples de articulaciones y músculos).
- Ingeniería y diseño de mecanismos (transmisión de fuerzas y recorridos).
