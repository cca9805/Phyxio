### Ejemplo 1 (clasificación)
Un balancín con apoyo central: el apoyo está entre las dos fuerzas.  
→ **1er género**.

### Ejemplo 2 (clasificación)
Carretilla: apoyo en la rueda, carga en la cuba, esfuerzo en las manos.  
Orden: **A - R - P**  
→ **2º género**.

### Ejemplo 3 (clasificación)
Antebrazo con bíceps: apoyo en el codo, fuerza del bíceps entre codo y mano, peso en la mano.  
Orden: **A - P - R**  
→ **3er género**.
