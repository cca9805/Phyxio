# Errores comunes

- Clasificar por “forma” en vez de por el orden **A-P-R** sobre la barra.
- Usar como brazo la distancia “a ojo” en vez de la **distancia perpendicular** a la línea de acción.
- Olvidar que la resistencia puede ser el **peso aplicado en el centro de masas**.
- Poner signos de momentos sin criterio: define un sentido positivo (antihorario) y sé consistente.
