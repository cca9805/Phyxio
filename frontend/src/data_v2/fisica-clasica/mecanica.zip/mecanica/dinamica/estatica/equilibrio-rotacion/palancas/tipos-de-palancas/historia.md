# Contexto histórico

La ley de la palanca se asocia históricamente a Arquímedes, quien formalizó
la relación entre fuerzas y brazos para el equilibrio. La clasificación por
géneros se consolidó posteriormente en la estática clásica al estudiar
máquinas simples y mecanismos.
