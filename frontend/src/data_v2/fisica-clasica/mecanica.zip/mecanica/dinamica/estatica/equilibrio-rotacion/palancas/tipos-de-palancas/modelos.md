# Modelo físico

- Barra rígida (sin deformación).
- Apoyo ideal (sin rozamiento).
- Fuerzas coplanares.
- Se toma el momento respecto al apoyo.
- En problemas escolares: fuerzas normalmente perpendiculares a la barra (brazo = distancia).
- Si hay peso de la barra, se modela actuando en su centro de masas.
