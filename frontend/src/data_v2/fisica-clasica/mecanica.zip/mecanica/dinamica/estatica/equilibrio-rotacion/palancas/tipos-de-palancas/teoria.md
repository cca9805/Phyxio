# Tipos de palancas

## Idea clave
Una palanca es una **barra rígida** que puede girar alrededor de un **punto de apoyo**.  
Según dónde estén **apoyo**, **potencia** (fuerza aplicada) y **resistencia** (carga), hablamos de **palancas de 1er, 2º o 3er género**.

La clasificación **no depende** de si está horizontal o vertical, ni de su forma “bonita”. Depende solo del **orden** de esos tres elementos sobre la barra.

---

## Elementos de una palanca
- **Apoyo (A)**: punto o eje alrededor del cual gira.
- **Potencia (P)**: fuerza que aplicas (tu esfuerzo).
- **Resistencia (R)**: fuerza que “se opone” (normalmente el peso de la carga o una fuerza equivalente).

En muchos problemas, la resistencia es el **peso** de un objeto, que actúa en su **centro de masas**.

---

## Cómo clasificar una palanca
Imagina la barra como una recta y marca el orden:

### 1) Palanca de primer género (1er género)
**El apoyo está entre potencia y resistencia:**
$$
P \;-\; A \;-\; R \quad \text{o} \quad R \;-\; A \;-\; P
$$

**Ejemplos típicos:**
- Tijeras (cada hoja es una palanca)
- Balancín
- Alicates

**Lectura física:**
- Puede dar **ventaja en fuerza** o no, depende de los brazos.
- Suele permitir **cambiar el sentido** del movimiento (empujas hacia abajo y algo sube).

---

### 2) Palanca de segundo género (2º género)
**La resistencia está entre apoyo y potencia:**
$$
A \;-\; R \;-\; P
$$

**Ejemplos típicos:**
- Carretilla
- Cascanueces
- Abrebotellas

**Lectura física:**
- Suele dar **ventaja mecánica mayor que 1** (necesitas menos fuerza que la carga).
- Se paga con **más recorrido** de la potencia.

---

### 3) Palanca de tercer género (3er género)
**La potencia está entre apoyo y resistencia:**
$$
A \;-\; P \;-\; R
$$

**Ejemplos típicos:**
- Antebrazo humano con el bíceps (modelo simple)
- Pinzas (tipo “tweezers”)
- Caña de pescar (idealización)

**Lectura física:**
- Suele dar **ventaja mecánica menor que 1** (necesitas más fuerza que la carga).
- A cambio, se gana **velocidad/recorrido** en el extremo donde está la carga.

---

## Conexión con el equilibrio (por qué esta clasificación importa)
En estática, una palanca en reposo cumple:
$$
\sum M_A = 0
$$
Es decir: los **momentos** a un lado se equilibran con los del otro.

Esto explica por qué:
- En 2º género suele ser fácil “levantar mucho” con poco esfuerzo.
- En 3er género el cuerpo humano “prefiere” velocidad y control de movimiento aunque requiera mucha fuerza muscular.


---

## Brazos de potencia y de resistencia (lo que realmente manda)

### ¿Qué es el brazo de una fuerza?
El **brazo de palanca** de una fuerza es la **distancia perpendicular** desde el **punto de apoyo** hasta la
**línea de acción** de esa fuerza.

- No es “la distancia hasta donde toco la barra” sin más.
- Es la distancia **perpendicular** a la dirección de la fuerza.
- Si la fuerza no es perpendicular a la barra, el brazo **no coincide** con la distancia medida sobre la barra.

En símbolos:
- **dP**: brazo de la **potencia** (fuerza aplicada).
- **dR**: brazo de la **resistencia** (carga).

---

### Brazo de potencia (dP)
Es la distancia perpendicular desde el apoyo a la línea de acción de la **potencia P** (tu fuerza).

**¿Qué influye?**
- Cuanto mayor sea **dP**, mayor será el **momento** que puedes generar con la misma fuerza P.
- Aumentar dP suele “hacerte la vida más fácil”: con el mismo esfuerzo produces más giro.

---

### Brazo de resistencia (dR)
Es la distancia perpendicular desde el apoyo a la línea de acción de la **resistencia R** (la carga).

**¿Qué influye?**
- Cuanto mayor sea **dR**, mayor será el momento que produce la carga y **más difícil** será equilibrar o levantarla.
- Reducir dR suele “ayudar”: la carga tiene menos capacidad de hacer girar la palanca.

---

### Por qué son tan importantes: el momento
El efecto de giro de una fuerza se mide con el **momento**:

$$
M = F \cdot d
$$

Así que:
- Momento de la potencia: \(\;M_P = P \cdot dP\)
- Momento de la resistencia: \(\;M_R = R \cdot dR\)

---

### Condición de equilibrio (la ecuación que usa la calculadora)
Una palanca en equilibrio (sin girar) cumple:

$$
P \cdot dP = R \cdot dR
$$

Interpretación directa:
- Si quieres vencer una resistencia grande \(R\),
  necesitas o bien una potencia grande \(P\),
  o bien un **dP grande**,
  o bien un **dR pequeño**.

---

### Caso típico: fuerzas perpendiculares a la barra
En muchos ejercicios escolares la potencia y la resistencia son verticales y la barra se idealiza horizontal.
En ese caso, el brazo coincide con la distancia medida sobre la barra:

- \(dP\) = distancia sobre la barra desde el apoyo al punto donde aplicas P
- \(dR\) = distancia sobre la barra desde el apoyo al punto donde actúa R

Pero si la fuerza está inclinada o el apoyo no es un punto “limpio”, hay que volver a la definición:
**distancia perpendicular a la línea de acción**.

---

### Conexión con el centro de masas (muy frecuente en palancas)
Si la resistencia es el peso de un objeto colocado sobre la palanca, entonces:

- La fuerza resistencia es \(\;R = mg\)
- Y actúa en el **centro de masas** del objeto

Esto significa que **dR** se mide desde el apoyo hasta el **CM**, no hasta el borde del objeto.

---

## Mini-check (para no fallar nunca)
1. Marca **A, P, R**.
2. Mira quién está **en medio**.
3. Si el del medio es:
   - **A** → 1er género
   - **R** → 2º género
   - **P** → 3er género
