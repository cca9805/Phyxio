### Ejemplo 1 (VM por brazos)
Una palanca tiene d_P = 0,80 m y d_R = 0,20 m.

$$
VM = \frac{d_P}{d_R} = \frac{0.80}{0.20} = 4
$$

Interpretación: idealmente, la resistencia puede ser 4 veces la potencia.

---

### Ejemplo 2 (fuerza necesaria)
Si la carga equivale a R = 300 N y VM = 3:

$$
P = \frac{R}{VM} = \frac{300}{3} = 100 \text{ N}
$$

---

### Ejemplo 3 (intercambio fuerza-recorrido)
Si R = 200 N y P = 50 N, entonces VM = 4.

En máquina ideal:
$$
P\,s_P = R\,s_R \Rightarrow 50\,s_P = 200\,s_R \Rightarrow s_P = 4\,s_R
$$

La mano recorre 4 veces la distancia que recorre la carga.
