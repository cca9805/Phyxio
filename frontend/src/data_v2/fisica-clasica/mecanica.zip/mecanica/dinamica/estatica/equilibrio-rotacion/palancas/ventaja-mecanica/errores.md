### Errores comunes

- Creer que si VM>1 entonces “se hace menos trabajo”. En ideal, el trabajo se conserva: se cambia fuerza por recorrido.
- Confundir VM con rendimiento: VM puede ser grande y aun así tener pérdidas importantes (η<1).
- Olvidar que el brazo correcto es el **perpendicular** a la línea de acción.
- Usar el peso mal aplicado: si la carga es un cuerpo, su peso actúa en el **centro de masas**.
