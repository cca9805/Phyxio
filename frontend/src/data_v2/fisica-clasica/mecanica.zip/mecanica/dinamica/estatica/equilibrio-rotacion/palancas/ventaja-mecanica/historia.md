La idea de comparar fuerzas y distancias en máquinas simples surge de la estática clásica
y se consolida con el desarrollo del concepto de trabajo y energía en los siglos XVIII-XIX.
La palanca es el ejemplo canónico para introducir que “ganar fuerza” implica “perder recorrido”
en sistemas ideales.
