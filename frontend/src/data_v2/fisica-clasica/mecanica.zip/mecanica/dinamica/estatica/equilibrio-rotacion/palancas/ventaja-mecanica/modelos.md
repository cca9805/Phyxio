# Modelo físico

## Palanca ideal
- Barra rígida.
- Apoyo sin rozamiento.
- Sin pérdidas (trabajo de entrada = trabajo de salida).
- Fuerzas coplanares.

## Palanca real (extensión)
- Rozamiento en el apoyo.
- Flexión/deformación ligera.
- Rendimiento menor que 1.
