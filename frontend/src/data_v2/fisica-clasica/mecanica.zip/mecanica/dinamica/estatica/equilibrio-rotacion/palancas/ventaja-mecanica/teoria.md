# Ventaja mecánica (palancas)

## Idea clave
La **ventaja mecánica** mide “cuánta carga puedes vencer” con una fuerza dada:

$$
VM = \frac{R}{P}
$$

- Si \(VM > 1\), necesitas **menos** fuerza que la carga (ganas fuerza).
- Si \(VM < 1\), necesitas **más** fuerza que la carga (pierdes fuerza), pero ganas **recorrido/velocidad**.

Una palanca no fabrica energía. Solo cambia el reparto entre **fuerza** y **desplazamiento**.

---

## Ventaja mecánica y equilibrio de momentos
En una palanca ideal en equilibrio:

$$
P\,d_P = R\,d_R
$$

Dividiendo entre \(P\,d_R\):

$$
\frac{R}{P} = \frac{d_P}{d_R}
$$

Por tanto:

$$
VM = \frac{R}{P} = \frac{d_P}{d_R}
$$

Interpretación geométrica:
- Si el **brazo de potencia** es mayor que el de resistencia, \(VM>1\).
- Si el **brazo de potencia** es menor, \(VM<1\).

---

## Lectura energética (por qué no es “magia”)
En una máquina ideal (sin pérdidas), el **trabajo** de entrada iguala al de salida:

$$
W_{in} = W_{out}
$$

Si aplicas potencia \(P\) y tu punto de aplicación recorre \(s_P\),
mientras la carga (resistencia) recorre \(s_R\):

$$
P\,s_P = R\,s_R
$$

Si ganas fuerza (\(R>P\)), necesariamente:
$$
s_P > s_R
$$
o sea, tienes que mover tu mano **más distancia**.

---

## Ventaja mecánica real y rendimiento
En la realidad hay rozamientos y deformaciones. Se introduce el **rendimiento**:

$$
\eta = \frac{W_{out}}{W_{in}}
$$
con \(0 < \eta < 1\).

Entonces, aunque la geometría sugiera una VM ideal, la fuerza real necesaria puede ser mayor.

---

## Conexión con centro de masas
En muchos problemas, la resistencia es un **peso** aplicado en el centro de masas del objeto:
- Carga uniforme: peso en el centro geométrico.
- Carga no uniforme: peso en el centro de masas real.

Eso cambia el brazo \(d_R\) y, por tanto, la ventaja mecánica.
