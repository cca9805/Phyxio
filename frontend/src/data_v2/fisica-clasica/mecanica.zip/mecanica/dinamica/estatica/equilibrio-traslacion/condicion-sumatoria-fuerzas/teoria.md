# Condición de sumatoria de fuerzas (equilibrio traslacional)

## Idea clave
Un cuerpo está en **equilibrio traslacional** cuando su aceleración es cero:

\[
\vec{a}=0
\]

Por la segunda ley de Newton:

\[
\sum \vec{F} = m\vec{a} = \vec{0}
\]

**Condición de equilibrio:**

\[
\sum \vec{F} = \vec{0}
\]

---

## Paso a componentes
En 2D, la condición vectorial equivale a dos ecuaciones escalares:

\[
\sum F_x = 0
\qquad
\sum F_y = 0
\]

Esto es lo que realmente resuelves en problemas.

---

## Interpretación geométrica
Si dibujas las fuerzas “punta con cola” (polígono de fuerzas):

- Si el polígono **cierra**, la resultante es cero → equilibrio.
- Si **no cierra**, la resultante no es cero → hay aceleración.

---

## Procedimiento típico
1. Dibuja el **DCL** (solo fuerzas reales).
2. Elige ejes (x, y) con sentido y signos claros.
3. Proyecta cada fuerza en x e y.
4. Plantea:

\[
\sum F_x=0,\quad \sum F_y=0
\]

5. Resuelve las incógnitas.

---

## Fuerza equilibrante (concepto útil)
Si tienes fuerzas \(\vec{F}_1\) y \(\vec{F}_2\), la fuerza que **equilibra** es:

\[
\vec{F}_3 = -(\vec{F}_1 + \vec{F}_2)
\]

No es “mágica”: es simplemente la que hace que el polígono cierre.
