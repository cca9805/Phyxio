# Aplicaciones

- Diseño de estructuras simples: soportes, estanterías, tensores.
- Seguridad: cálculo de fuerzas mínimas de rozamiento para evitar deslizamiento.
- Ingeniería: análisis preliminar antes de introducir momentos (equilibrio rotacional).
- Física cotidiana: empujar muebles, tensar cuerdas, sujetar cargas.
