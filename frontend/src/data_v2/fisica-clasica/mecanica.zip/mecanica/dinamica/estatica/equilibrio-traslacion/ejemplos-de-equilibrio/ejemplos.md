# Ejemplos resueltos (guía)

## 1) Bloque en mesa sin rozamiento
**Datos:** masa m.  
**Fuerzas:** N (arriba), P=mg (abajo).  
**Equilibrio en y:** \(N - mg = 0 \Rightarrow N = mg\).

---

## 2) Bloque con fuerza horizontal y rozamiento estático
**Datos:** fuerza aplicada F, coeficiente μs.  
**Fuerzas:** N, P, F, fs.  
**Equilibrio en x:** \(F - f_s = 0 \Rightarrow f_s = F\).  
**Condición de posibilidad:** \(F \le \mu_s N\).

---

## 3) Bloque tirado con cuerda inclinada
**Datos:** fuerza T con ángulo θ.  
Descomponer \(T_x=T\cos\theta\), \(T_y=T\sin\theta\).  
En y: \(N + T_y - mg = 0\).  
En x: \(T_x - f_s = 0\) (si hay rozamiento).

---

> Estos ejemplos se complementan con los gráficos: DCL interactivo + escena SVG.
