# Errores comunes

- **Meter fuerzas internas** en el DCL (solo fuerzas externas).
- Dibujar el rozamiento “porque sí”: el rozamiento aparece **si hay contacto** y **si se necesita** para el equilibrio.
- Confundir **peso** con **masa**.
- Elegir ejes “caprichosos” y luego sufrir en las proyecciones.
- Signos: tomar \(+y\) hacia arriba y luego poner \(P=+mg\).

## Test rápido
Si te sale una normal negativa, casi siempre es:
- DCL mal, o
- signos/proyecciones mal.
