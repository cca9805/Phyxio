# Historia y contexto

La estática como disciplina se formaliza con el desarrollo de la mecánica clásica
(siglos XVII–XVIII). El equilibrio traslacional aparece como consecuencia directa
de la segunda ley de Newton: si la aceleración es cero, la fuerza neta debe ser cero.

En educación, el salto importante es aprender que “equilibrio” no significa
“no hay fuerzas”, sino **“se compensan”**.
