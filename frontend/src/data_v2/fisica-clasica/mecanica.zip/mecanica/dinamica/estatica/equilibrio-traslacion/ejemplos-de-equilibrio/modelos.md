# Modelos usados

## 1) Partícula (traslación pura)
- El cuerpo se modela como un punto.
- Solo importa \(\sum \vec{F}=0\).
- No se considera rotación ni momentos.

## 2) Sólido rígido sin rotación (equilibrio traslacional)
- El cuerpo puede ser extendido, pero se asume que no rota.
- Se usa igualmente \(\sum \vec{F}=0\).
- (El equilibrio rotacional se trata en el bloque correspondiente: \(\sum \tau = 0\).)

## 3) Contacto ideal con superficie
- Normal perpendicular.
- Rozamiento según modelo (estático/cinético) si se indica.
