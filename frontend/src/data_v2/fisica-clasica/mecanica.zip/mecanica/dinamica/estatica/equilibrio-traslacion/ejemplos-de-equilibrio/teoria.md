# Ejemplos de equilibrio (traslación)

## Idea clave
Un sistema está en **equilibrio traslacional** cuando su aceleración es **cero**.  
Eso se traduce en:

\[
\sum \vec{F} = \vec{0}
\quad\Rightarrow\quad
\sum F_x = 0,\ \sum F_y = 0 \ (\text{y } \sum F_z = 0 \text{ si aplica})
\]

El “truco” no es la fórmula, es el **DCL** (Diagrama de Cuerpo Libre): si el DCL está bien, el problema suele caer solo.

---

## Procedimiento estándar (plantilla)
1. **Aísla** el cuerpo que te interesa (uno solo).
2. Dibuja el **DCL**: todas las fuerzas **externas** sobre el cuerpo.
3. Elige ejes (muchas veces conviene alinear un eje con la fuerza aplicada o con el plano).
4. Proyecta:
   - \(\sum F_x = 0\)
   - \(\sum F_y = 0\)
5. Resuelve y revisa **sentidos** y **unidades**.

---

## Fuerzas típicas (mínimo indispensable)
- **Peso**: \(\vec{P}=m\vec{g}\) (vertical hacia abajo).
- **Normal**: \(\vec{N}\) (perpendicular a la superficie).
- **Tensión**: \(\vec{T}\) (a lo largo de la cuerda).
- **Rozamiento**:
  - Estático: \(|f_s| \le \mu_s N\)
  - Cinético: \(f_k = \mu_k N\)

---

## Notas de signos (para no sangrar)
- Si tomas \(+y\) hacia arriba, entonces \(P_y=-mg\).
- Si el empuje es horizontal, entonces suele ir en \(x\).
- El rozamiento **se opone** a la *tendencia* de movimiento (no al movimiento real si está en reposo).

---

## Mini-checklist de equilibrio
- ¿He metido fuerzas internas? (no deben aparecer)
- ¿He contado dos veces la misma fuerza? (clásico con la normal y “reacción”)
- ¿He elegido ejes que simplifiquen? (sí = felicidad)
- ¿Mis proyecciones tienen sentido físico? (si N sale negativa, algo está mal)
