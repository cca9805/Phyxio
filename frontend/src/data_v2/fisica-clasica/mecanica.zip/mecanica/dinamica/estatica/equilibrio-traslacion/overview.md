# Equilibrio de traslación

## ¿Qué es el equilibrio de traslación?
Un cuerpo está en **equilibrio de traslación** cuando **no acelera linealmente**.
Esto significa que su velocidad es constante, pudiendo ser:
- nula (reposo),
- o distinta de cero (movimiento rectilíneo uniforme).

El equilibrio de traslación es una consecuencia directa de la **segunda ley de Newton**.

---

## Idea física clave
La condición fundamental del equilibrio de traslación es:

> La **resultante de todas las fuerzas externas** que actúan sobre el cuerpo es **cero**.

Cuando esto ocurre, el cuerpo no cambia su estado de movimiento lineal.

---

## Qué aprenderás en este bloque
En este tema aprenderás a:

- Reconocer situaciones de equilibrio traslacional.
- Aplicar correctamente la **condición de fuerza neta nula**.
- Identificar y representar fuerzas mediante **diagramas de cuerpo libre**.
- Analizar cuerpos sometidos a varias fuerzas simultáneas.
- Resolver problemas en una y dos dimensiones.

---

## Cómo se organiza el contenido
El bloque de equilibrio de traslación se desarrolla de forma progresiva:

### 1️⃣ Condición de equilibrio
Se introduce la condición matemática del equilibrio traslacional y su relación
con las leyes de Newton.

### 2️⃣ Diagramas de cuerpo libre
Se aprende a aislar el cuerpo y representar **todas las fuerzas externas**
que actúan sobre él, paso esencial para cualquier análisis.

### 3️⃣ Descomposición de fuerzas
Se estudia cómo proyectar fuerzas en ejes adecuados para poder aplicar
las ecuaciones de equilibrio.

### 4️⃣ Aplicaciones típicas
Se analizan situaciones frecuentes:
- cuerpos apoyados,
- objetos colgados,
- planos inclinados,
- sistemas con cuerdas y poleas,
- fuerzas de rozamiento.

---

## Por qué es importante
El equilibrio de traslación es fundamental para:

- comprender el reposo y el movimiento uniforme,
- analizar estructuras y sistemas mecánicos,
- resolver problemas reales de ingeniería y física aplicada,
- servir de base al estudio del **equilibrio de rotación**.

Es uno de los pilares de la **estática** y de la **dinámica clásica**.

---

## Qué no se trata aquí
En este bloque no se estudia:
- el equilibrio rotacional (momentos),
- la rotación de cuerpos,
- vibraciones u oscilaciones,
- efectos no clásicos.

El análisis se limita al **movimiento lineal** y a la suma de fuerzas.

---

## Cómo usar este bloque en Phyxio
- Comienza identificando todas las fuerzas mediante diagramas claros.
- Aplica la condición de equilibrio en cada eje.
- Usa las calculadoras y gráficos interactivos para comprobar resultados
  y explorar cómo cambian las fuerzas al modificar parámetros.

Este bloque prepara directamente el camino hacia el estudio del
**equilibrio de rotación** y de sistemas más complejos.
