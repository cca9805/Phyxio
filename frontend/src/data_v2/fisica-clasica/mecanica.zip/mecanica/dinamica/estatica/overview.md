## Qué aprenderás
- A analizar sistemas en equilibrio.
- A distinguir equilibrio traslacional y rotacional.
- A calcular centros de masas y momentos.

## Qué encontrarás aquí
- Condiciones de equilibrio de fuerzas.
- Condiciones de equilibrio de momentos.
- Centro de masas en cuerpos y sistemas.
- Aplicaciones a palancas y estructuras.

## Conexiones
- Caso particular de la dinámica.
- Base del análisis de estructuras y máquinas simples.
