﻿# Concepto de fuerza centripeta

## Idea clave
Cuando un objeto describe una trayectoria curvada, su velocidad cambia de direccion.
Ese cambio exige una aceleracion dirigida hacia el centro de la curvatura.

A esa aceleracion se la llama aceleracion centripeta.

---

## Antes: inercial vs no inercial
Para evitar confusiones, primero distingue el marco de referencia:

- Marco inercial: esta en reposo o en MRU (sin aceleracion global del marco).
- Marco no inercial: el marco acelera o rota.

Regla practica:

- En marco inercial, describe el movimiento solo con fuerzas reales.
- En marco no inercial, puedes introducir fuerzas ficticias (como la centrifuga) para escribir Newton en ese marco.

---

## La centripeta no es una fuerza nueva
La llamada fuerza centripeta no es un agente adicional.

> Es el nombre de la componente radial de la fuerza resultante.

La segunda ley de Newton, proyectada en la direccion radial, se escribe:

\[
\sum F_{rad} = m a_c
\]

---

## Regla mental util
No preguntes "cual es la fuerza centripeta" como si fuera una fuerza aparte.
Pregunta: "que fuerza real, o combinacion de fuerzas reales, esta apuntando al centro".

Ejemplos:

- Tension en una cuerda (piedra girando).
- Gravedad en una orbita (planeta o satelite).
- Rozamiento lateral en una curva (coche o bici).

---

## Aceleracion centripeta
Para un movimiento circular de radio \(r\) y velocidad \(v\):

\[
a_c = \frac{v^2}{r}
\]

---

## Que fuerzas pueden aportar la centripeta
Depende del problema:

- Tension -> piedra atada a una cuerda.
- Rozamiento + normal -> coche en una curva.
- Gravitatoria -> orbitas.
- Combinaciones en sistemas mas complejos.

---

## Nota importante
En marco inercial: usas fuerzas reales y su resultante radial (centripeta).
En marco no inercial: puedes introducir centrifuga como fuerza ficticia para describir desde ese marco.
