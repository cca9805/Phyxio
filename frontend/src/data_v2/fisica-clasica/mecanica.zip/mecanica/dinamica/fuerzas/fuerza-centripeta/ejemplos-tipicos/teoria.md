# Ejemplos típicos de fuerza centrípeta

## Idea clave
En todos los ejemplos, la condición radial es:

\[
\sum F_{rad} = m\frac{v^2}{r}
\]

La “centrípeta” **no es una fuerza nueva**: es la **componente radial de la resultante** de fuerzas reales.

---

## 1) Piedra con cuerda (horizontal o aproximación en plano)
**¿Quién aporta la centrípeta?** La **tensión**.

- DCL: tensión hacia el centro (y peso/normal si hay plano).
- Eje radial hacia el centro.

\[
T \approx m\frac{v^2}{r}
\]

---

## 2) Coche en curva plana (sin peralte)
**¿Quién aporta la centrípeta?** El **rozamiento estático** (si no derrapa).

- DCL: peso y normal verticales (se compensan), rozamiento horizontal hacia el centro.

\[
f_s = m\frac{v^2}{r}
\]

Si el rozamiento máximo no llega, el coche derrapa.

---

## 3) Loop vertical (punto más bajo y más alto)
**¿Quién aporta la centrípeta?** La **resultante radial** de tensión y peso (según el punto).

### En el punto más bajo
Hacia el centro es “hacia arriba”:

\[
T - mg = m\frac{v^2}{r}
\]

### En el punto más alto
Hacia el centro es “hacia abajo”:

\[
T + mg = m\frac{v^2}{r}
\]

Aquí es donde los signos importan mucho.

---

## 4) Órbita circular (muy típico)
**¿Quién aporta la centrípeta?** La **gravitatoria**.

\[
F_g = m\frac{v^2}{r}
\]

(En un curso más avanzado, se conecta con \(F_g=GMm/r^2\).)

---

## Recordatorio sobre la centrífuga
En sistema **inercial** no se introduce centrífuga.
La centrífuga se estudia en **marcos no inerciales**.
