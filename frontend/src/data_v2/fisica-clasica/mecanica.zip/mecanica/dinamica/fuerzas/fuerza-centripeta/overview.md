## Qué aprenderás
- Qué es la fuerza centrípeta y cuál es su función.
- Por qué es necesaria en el movimiento circular.
- A diferenciar entre fuerza centrípeta y otros tipos de fuerzas.

## Qué encontrarás aquí
- Concepto de fuerza centrípeta.
- Relación entre fuerza, velocidad y radio.
- Ejemplos típicos de movimiento circular.

## Conexiones
- Relacionada con cinemática circular.
- Conecta con dinámica rotacional y fuerzas reales.
- Fundamental para entender órbitas y sistemas giratorios.
