# Ley de Hooke

## Idea clave
Un muelle ideal, dentro del **régimen elástico lineal**, ejerce una fuerza que tiende a **recuperar** la posición natural.

La deformación se mide con una elongación (o compresión) \(x\), definida respecto a \(x=0\).

---

## Ley de Hooke (modelo)
En 1D, en módulo:

$$
F = k|x|
$$

En forma restauradora (con signo, si fijas un eje):

$$
F_x = -k x
$$

Interpretación del signo:
- si \(x>0\) (estirado hacia +x), la fuerza va hacia -x
- si \(x<0\) (comprimido), la fuerza va hacia +x

---

## Constante elástica k
La constante \(k\) mide la rigidez:
- mayor \(k\) → más fuerza para la misma deformación
- unidades:

$$
[k] = \mathrm{N/m}
$$

---

## Equilibrio peso–muelle (vertical)
Si un cuerpo de masa \(m\) cuelga de un muelle vertical y queda en reposo:

$$
k x = m g
$$

De donde:

$$
x = \frac{m g}{k}
$$

---

## Energía potencial elástica
El muelle almacena energía al deformarse:

$$
U_{el} = \frac{1}{2}k x^2
$$

(Este resultado se conecta formalmente con trabajo y energía.)

---

## Validez del modelo (cuándo NO usar Hooke)
Hooke es una aproximación:
- válida para deformaciones pequeñas
- materiales elásticos lineales

En deformaciones grandes o materiales no lineales, \(F\) puede no ser proporcional a \(x\).

---

## Qué es calculable y qué no
Calculable:
$$
F = k|x|,\quad kx=mg,\quad U_{el}=\frac12 kx^2
$$

No calculable (sin fijar convención):
- forma vectorial general si no defines eje/dirección y signo de \(x\)
