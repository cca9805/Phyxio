## Qué aprenderás
- Cómo se comportan los sistemas elásticos.
- Qué relación existe entre fuerza y deformación.
- A modelar muelles y sistemas elásticos reales.

## Qué encontrarás aquí
- Ley de Hooke.
- Constante elástica.
- Sistemas con uno o varios muelles.
- Límites de validez del modelo elástico.

## Conexiones
- Aparece en oscilaciones y energía potencial elástica.
- Conecta dinámica con movimientos periódicos.
