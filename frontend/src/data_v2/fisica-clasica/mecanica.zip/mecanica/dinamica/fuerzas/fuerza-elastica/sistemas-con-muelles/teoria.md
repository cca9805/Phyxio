# Sistemas con muelles

## Idea clave
Cuando varios muelles actúan juntos, muchas veces podemos reemplazarlos por **un muelle equivalente** con constante:

$$
k_{eq}
$$

y después usar:

$$
F = k_{eq}x
$$

---

## 1) Muelles en paralelo
Dos muelles están en **paralelo** cuando ambos se deforman **lo mismo** (misma elongación):

$$
x_1 = x_2 = x
$$

La fuerza total se reparte:

$$
F = F_1 + F_2
$$

y, como:

$$
F_1 = k_1 x,\quad F_2 = k_2 x
$$

entonces:

$$
F = (k_1+k_2)x
$$

Por tanto, la constante equivalente es:

$$
k_{eq} = k_1 + k_2
$$

**Resultado físico**: en paralelo el sistema es **más rígido**.

---

## 2) Muelles en serie
Dos muelles están en **serie** cuando la elongación total es la suma:

$$
x = x_1 + x_2
$$

En serie la fuerza transmitida es la misma en ambos (misma tensión interna):

$$
F_1 = F_2 = F
$$

Con Hooke en cada uno:

$$
F = k_1 x_1,\quad F = k_2 x_2
$$

Entonces:

$$
x_1 = \frac{F}{k_1},\quad x_2 = \frac{F}{k_2}
$$

Sumando:

$$
x = \frac{F}{k_1} + \frac{F}{k_2} = F\left(\frac{1}{k_1}+\frac{1}{k_2}\right)
$$

y comparando con:

$$
F = k_{eq}x
$$

sale:

$$
\frac{1}{k_{eq}} = \frac{1}{k_1} + \frac{1}{k_2}
$$

equivalentemente:

$$
k_{eq} = \frac{k_1 k_2}{k_1 + k_2}
$$

**Resultado físico**: en serie el sistema es **menos rígido** (cede más).

---

## 3) Reparto: quién se deforma más (serie)
En serie, como:

$$
x_1 = \frac{F}{k_1},\quad x_2 = \frac{F}{k_2}
$$

el muelle con menor \(k\) se deforma más.

---

## 4) Reparto: quién soporta más fuerza (paralelo)
En paralelo:

$$
F_1 = k_1 x,\quad F_2 = k_2 x
$$

el muelle con mayor \(k\) soporta más fuerza.

---

## 5) Equilibrio vertical con muelle equivalente
Si cuelga una masa \(m\) y el sistema queda en reposo:

$$
k_{eq}x = mg
$$

por tanto:

$$
x = \frac{mg}{k_{eq}}
$$

---

## Qué es calculable y qué no
Calculable:
$$
k_{eq}\ \text{en serie/paralelo},\quad F = k_{eq}x,\quad x=\frac{mg}{k_{eq}}
$$

No calculable (sin datos extra):
- repartos completos si no se fija \(F\) o \(x\) y los \(k_i\)
- geometrías mixtas sin especificar conexión y dirección de deformación
