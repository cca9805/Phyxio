# Normal en planos

## Idea clave
La **fuerza normal** es una fuerza de **contacto** que ejerce una superficie sobre un cuerpo.
Siempre actúa:

- **perpendicular** a la superficie
- “empujando” al cuerpo (no “tirando”)

No es lo mismo que el peso.

---

## Qué es la normal (y qué no es)
La normal aparece solo si hay **contacto**. Si el cuerpo pierde contacto:

$$
N = 0
$$

La normal **no** tiene por qué ser igual a \(mg\). Depende del contexto y de cómo “aprieta” el cuerpo contra la superficie.

---

## Caso 1: plano horizontal (sin otras fuerzas verticales)
En reposo o movimiento horizontal sin aceleración vertical, el equilibrio vertical exige:

$$
N - mg = 0
$$

Por tanto:

$$
N = mg
$$

---

## Caso 2: plano inclinado (sin aceleración perpendicular al plano)
Elegimos ejes:
- paralelo al plano
- perpendicular al plano

El peso se descompone respecto al plano. La componente perpendicular tiene módulo:

$$
mg\cos\theta
$$

Si el cuerpo no acelera “atravesando” el plano, la suma de fuerzas perpendiculares es cero, y resulta:

$$
N = mg\cos\theta
$$

Observaciones:
- si \(\theta = 0\), recuperas \(N=mg\)
- si \(\theta\) aumenta, \(\cos\theta\) disminuye y también lo hace \(N\)

---

## Conexión directa con rozamiento
En muchos modelos de rozamiento:

$$
F_r = \mu N
$$

Así que calcular bien la normal es clave para rozamiento estático y dinámico.

---

## Qué es calculable y qué no
Calculable aquí:
- \(N = mg\) (horizontal simple)
- \(N = mg\cos\theta\) (plano inclinado simple)

No calculable aquí (se trata en subtemas posteriores):
- normal con fuerzas aplicadas adicionales
- contacto que se pierde (salto, cresta de rampa)
- sistemas no inerciales (ascensor, marco acelerado)
