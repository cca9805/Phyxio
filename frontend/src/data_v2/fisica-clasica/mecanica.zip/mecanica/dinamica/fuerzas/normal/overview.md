## Qué aprenderás
- Qué es la fuerza normal y por qué aparece.
- Cómo identificar su dirección y sentido.
- A no confundir la normal con otras fuerzas.

## Qué encontrarás aquí
- Definición de la fuerza normal.
- Normal en planos horizontales e inclinados.
- Relación con otras fuerzas del sistema.

## Conexiones
- Presente en la mayoría de sistemas con contacto.
- Fundamental para el análisis del rozamiento.
