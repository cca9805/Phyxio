## Qué aprenderás
- A identificar y clasificar fuerzas en situaciones reales.
- A reconocer el origen físico de cada fuerza.
- A representar fuerzas correctamente en diagramas.

## Qué encontrarás aquí
- Fuerzas de contacto y a distancia.
- Peso, normal, tensión y rozamiento.
- Fuerza elástica y fuerza centrípeta.
- Modelos habituales de fuerza.

## Conexiones
- Presente en todos los problemas dinámicos.
- Clave para plantear correctamente ecuaciones de movimiento.
