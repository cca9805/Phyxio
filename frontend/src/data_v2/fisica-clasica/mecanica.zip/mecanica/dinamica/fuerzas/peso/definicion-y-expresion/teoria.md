# Peso: definición y expresión

## Idea clave
El **peso** es la **fuerza gravitatoria** que ejerce la Tierra sobre un cuerpo con masa.

No es una propiedad del cuerpo, sino una **interacción** entre el cuerpo y la Tierra.

---

## Definición física
La Tierra crea un **campo gravitatorio** que acelera a los cuerpos hacia su centro.

La fuerza asociada a ese campo es el peso:

$$
\vec P = m \vec g
$$

---

## Dirección y sentido
- Dirección: **vertical**
- Sentido: **hacia el centro de la Tierra**
- Punto de aplicación: **centro de masas** del cuerpo

---

## Módulo del peso
Cerca de la superficie terrestre, el módulo del peso es:

$$
P = mg
$$

donde:

$$
g \approx 9.81\,\mathrm{m/s^2}
$$

---

## ¿Quién ejerce el peso?
El peso es la fuerza que **la Tierra ejerce sobre el cuerpo**.

No es:
- una fuerza del cuerpo sobre la Tierra
- una fuerza “debida al movimiento”
- una propiedad intrínseca del objeto

---

## Diferencia entre masa y peso

**Masa**
- Magnitud escalar.
- Se mide en kilogramos (kg).
- No depende del lugar.
- Mide la inercia del cuerpo.

**Peso**
- Magnitud vectorial.
- Se mide en newtons (N).
- Depende del campo gravitatorio.
- Mide la interacción gravitatoria con la Tierra.


---

## Qué es calculable y qué no
- Calculable: el módulo del peso si se conoce la masa.
- No calculable aquí: variaciones del peso con altura o sistemas no inerciales
  (se tratan en subtemas posteriores).
