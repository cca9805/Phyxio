## Qué aprenderás
- Qué es el peso y cómo se calcula.
- A distinguir entre masa y peso.
- Cómo cambia el peso en distintos contextos.

## Qué encontrarás aquí
- Definición y expresión del peso.
- Peso en la superficie terrestre.
- Peso en otros entornos y sistemas acelerados.

## Conexiones
- Relacionado con gravedad y caída libre.
- Aparece en casi todos los problemas de dinámica.
