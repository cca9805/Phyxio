﻿# Peso en diferentes contextos

## Idea clave
El **peso no es una cantidad fija**: depende del campo gravitatorio y del contexto físico
en el que se encuentre el cuerpo.

La masa permanece constante; el peso puede cambiar.

---

## Contexto 1: cerca de la superficie terrestre
En la mayoría de problemas cotidianos se considera un campo gravitatorio uniforme:

$$
\vec P = m \vec g
$$

donde:

$$
g \approx 9.81\,\mathrm{m/s^2}
$$

En este contexto, el peso tiene:
- módulo constante
- dirección vertical
- sentido hacia abajo

---

## Contexto 2: diferentes planetas o astros
El valor de la gravedad depende del cuerpo celeste.

Ejemplos aproximados:
- Luna: \( g \approx 1.6\,\mathrm{m/s^2} \)
- Marte: \( g \approx 3.7\,\mathrm{m/s^2} \)

El peso cambia, aunque la masa sea la misma.

---

## Contexto 3: variación con la altura
Cuando la altura no es despreciable frente al radio del planeta,
el valor de \(g\) disminuye con la distancia al centro:

$$
g(h) = g_0 \left( \frac{R}{R+h} \right)^2
$$

Por tanto, el peso también disminuye con la altura.

---

## Contexto 4: caída libre
En caída libre:
- el peso **no desaparece**
- el cuerpo sigue sometido a la fuerza gravitatoria

Lo que ocurre es que **no hay fuerzas de contacto** (normal).

Este hecho es clave para entender el peso aparente.

---

## Qué cambia y qué no
**Permanece constante**
- la masa del cuerpo

**Puede cambiar**
- el valor del peso
- sus efectos dinámicos

---

## Conexión con próximos temas
- Peso aparente
- Fuerza normal
- Ascensores y sistemas no inerciales
