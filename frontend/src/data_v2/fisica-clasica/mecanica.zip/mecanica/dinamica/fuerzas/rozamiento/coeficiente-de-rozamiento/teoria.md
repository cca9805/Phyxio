# Coeficiente de rozamiento

## Idea clave
El coeficiente de rozamiento es un número adimensional que relaciona el rozamiento con la normal.
Hay dos coeficientes distintos:

$$
mu_s \quad (\text{estático}), \qquad mu_k \quad (\text{dinámico})
$$

Normalmente:

$$
\mu_k < \mu_s
$$

---

## Qué significa μ
- No es una “propiedad universal” del material: depende del par de superficies y su estado (rugosidad, limpieza, lubricación, temperatura).
- Es una aproximación muy útil para problemas básicos.

---

## Cómo se obtiene a partir de fuerzas medidas

### 1) Coeficiente estático (umbral de inicio)
En el instante justo antes de deslizar, el rozamiento estático alcanza su máximo:

$$
f_{s,\max} = \mu_s N
$$

Por tanto:

$$
\mu_s = \frac{f_{s,\max}}{N}
$$

### 2) Coeficiente dinámico (deslizamiento)
Durante el deslizamiento:

$$
f_k = \mu_k N
$$

y:

$$
\mu_k = \frac{f_k}{N}
$$

---

## Método del ángulo crítico (plano inclinado)
Si aumentas la inclinación hasta que el bloque empieza a deslizar, en el ángulo crítico \\(\\theta_c\\):

$$
\mu_s = \tan\theta_c
$$

Este método es muy práctico para estimar \\(\\mu_s\\) sin medir fuerzas directamente.

---

## Errores típicos
- Usar \\(\\mu_s\\) cuando ya hay deslizamiento (debe ser \\(\\mu_k\\)).
- Suponer que \\(\\mu\\) “siempre es el mismo” para cualquier condición.
- Olvidar que la normal cambia con el contexto (plano inclinado, fuerzas adicionales, etc.).
