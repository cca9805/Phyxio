## Qué aprenderás
- Qué es el rozamiento y cuál es su origen.
- A diferenciar rozamiento estático y dinámico.
- A aplicar correctamente los coeficientes de rozamiento.

## Qué encontrarás aquí
- Rozamiento estático.
- Rozamiento dinámico.
- Coeficiente de rozamiento.
- Modelos habituales y limitaciones.

## Conexiones
- Clave en sistemas reales y no ideales.
- Relacionado con disipación de energía.
