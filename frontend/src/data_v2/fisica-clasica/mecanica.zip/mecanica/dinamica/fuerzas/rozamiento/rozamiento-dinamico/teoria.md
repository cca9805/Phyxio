# Rozamiento dinámico

## Idea clave
El **rozamiento dinámico** (o **cinético**) aparece cuando ya existe **deslizamiento relativo**
entre dos superficies en contacto.

Su efecto principal es oponerse al deslizamiento y disipar energía.

---

## Cuándo actúa
Actúa cuando:
- el cuerpo **se desliza** sobre la superficie, o
- la superficie se desliza respecto al cuerpo

La clave es la velocidad relativa:

$$
\\vec v_{rel} \neq 0
$$

---

## Modelo clásico (módulo)
El modelo más usado en problemas de dinámica es:

$$
f_k = \mu_k N
$$

donde:
- \\(\mu_k\) es el coeficiente de rozamiento dinámico (adimensional)
- \\(N\\) es la normal

---

## Dirección y sentido
El rozamiento dinámico siempre es:
- paralelo a la superficie
- opuesto al deslizamiento relativo

En forma conceptual:

$$
\\vec f_k \;\text{se opone a}\; \vec v_{rel}
$$

---

## Diferencia con el rozamiento estático
- El rozamiento estático se ajusta y cumple:

$$
f_s \le \mu_s N
$$

- El rozamiento dinámico se modela con valor (aprox.) constante:

$$
f_k = mu_k N
$$

Normalmente:

$$
mu_k < mu_s
$$

---

## Nota sobre la velocidad
En este modelo ideal, \\(f_k\\) no depende de la velocidad.
En la realidad puede depender (materiales, lubricación, régimen), pero se trata en niveles avanzados.

---

## Conexión con energía (idea útil)
El rozamiento dinámico realiza trabajo negativo y disipa energía.
Más adelante, en trabajo y energía, se formaliza con:

$$
W_{roz} < 0
$$

---

## Qué es calculable y qué no
Calculable:
- \\(f_k\\) a partir de \\(\\mu_k\\) y \\(N\\)

No calculable aquí:
- modelos dependientes de velocidad (fluido, viscosidad)
- rozamiento con lubricación o materiales no ideales
