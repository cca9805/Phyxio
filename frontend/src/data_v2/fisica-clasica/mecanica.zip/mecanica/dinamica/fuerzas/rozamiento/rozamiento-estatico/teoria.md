# Rozamiento estático

## Idea clave
El **rozamiento estático** es la fuerza que **impide que un cuerpo comience a deslizar**
sobre una superficie.

Existe **aunque el cuerpo esté en reposo**.

---

## Qué es el rozamiento estático
Cuando intentas mover un objeto apoyado sobre una superficie, aparece una fuerza que
se opone al intento de deslizamiento.

Esa fuerza es el rozamiento estático.

---

## Propiedad fundamental
El rozamiento estático **no tiene un valor fijo**.  
Se adapta a la fuerza aplicada hasta un máximo:

$$
f_s \le \mu_s N
$$

---

## Valor máximo
El mayor valor que puede alcanzar el rozamiento estático es:

$$
f_{s,\max} = \mu_s N
$$

Si la fuerza aplicada supera este valor:
- el cuerpo **empieza a moverse**
- el rozamiento pasa a ser **dinámico**

---

## Dirección y sentido
- El rozamiento estático actúa **paralelo a la superficie**.
- Su sentido es **opuesto al deslizamiento que se intenta producir**.
- No se opone al movimiento, sino al **deslizamiento relativo**.

---

## Ejemplo conceptual
Empujas una caja:
- mientras no se mueve, \(f_s = F\)
- cuando \(F > f_{s,\max}\), la caja empieza a deslizar

---

## Conexión con la normal
El rozamiento depende directamente de la normal:

$$
f_{s,\max} = \mu_s N
$$

Por eso:
- inclinar un plano cambia el rozamiento
- reducir la normal reduce el rozamiento máximo

---

## Qué es calculable y qué no
Calculable:
- el valor máximo \(f_{s,\max}\)

No calculable directamente:
- el valor exacto de \(f_s\) mientras el cuerpo no se mueve
