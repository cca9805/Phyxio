## Qué aprenderás
- Qué es la tensión y cómo se transmite en sistemas con cuerdas.
- A identificar la tensión en distintos tramos.
- A analizar sistemas con cuerdas y poleas.

## Qué encontrarás aquí
- Definición de tensión.
- Tensión en cuerdas y cables ideales.
- Aplicación en sistemas simples y compuestos.

## Conexiones
- Fundamental en sistemas de varios cuerpos.
- Aparece en problemas clásicos de dinámica traslacional.
