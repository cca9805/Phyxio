# Definición de tensión

La **tensión** es la fuerza interna que se transmite a lo largo de una cuerda, cable o hilo cuando está sometido a tracción.

Desde el punto de vista físico, la tensión es una **fuerza de interacción**:
- la cuerda ejerce una fuerza sobre el cuerpo al que está unida,
- el cuerpo ejerce una fuerza igual y opuesta sobre la cuerda.

La tensión **siempre actúa a lo largo de la cuerda**, tirando del cuerpo hacia el interior del cable.

No es una propiedad del objeto ni de la cuerda por sí sola, sino del **sistema completo**.

---

## Modelo de cuerda ideal

En la mayoría de los problemas de mecánica se utiliza el **modelo de cuerda ideal**, que supone:

- masa despreciable,
- inextensible,
- sin rozamiento con poleas,
- transmite la fuerza instantáneamente.

Bajo estas hipótesis:
- la **magnitud de la tensión es la misma en todos los puntos de la cuerda**,
- la dirección de la tensión coincide con la dirección de la cuerda.

Este modelo es válido en la mayoría de problemas de nivel ESO y Bachillerato.

---

## Tensión en equilibrio (sistemas estáticos)

Consideremos una masa colgando de una cuerda vertical en reposo.

El peso es:

$$
P = mg
$$

Y la tensión es:

$$
T
$$

Como el sistema está en equilibrio:

$$
\sum F = 0
$$

Tomando el eje vertical positivo hacia arriba:

$$
T - mg = 0
$$

Por tanto:

$$
T = mg
$$

Este resultado **no es general**, solo es válido cuando:
- el sistema está en reposo,
- la cuerda es ideal,
- no hay aceleración.

---

## Tensión en sistemas acelerados

Si la masa está acelerada, la tensión **ya no coincide con el peso**.

Aplicando la segunda ley de Newton:

$$
\sum F = ma
$$

En una cuerda vertical, tomando de nuevo el eje vertical positivo hacia arriba:

$$
T - mg = ma
$$

Despejando:

$$
T = m(g + a)
$$

Interpretación rápida:
- si el cuerpo acelera hacia arriba (a > 0), entonces:

$$
T > mg
$$

- si el cuerpo acelera hacia abajo (a < 0), entonces:

$$
T < mg
$$

Esto muestra una idea clave:

> La tensión depende del estado dinámico del sistema, no solo de la masa.

---

## Sistemas con dos masas y polea ideal (Máquina de Atwood)

Consideremos dos masas \(m_1\) y \(m_2\) unidas por una cuerda ideal que pasa por una polea ideal.
Suponemos \(m_2 > m_1\) para fijar el sentido: \(m_2\) baja y \(m_1\) sube con aceleración \(a\).

Ecuaciones (ejes positivos en el sentido del movimiento de cada masa):

Para \(m_1\) (sube):

$$
T - m_1 g = m_1 a
$$

Para \(m_2\) (baja):

$$
m_2 g - T = m_2 a
$$

Resolviendo el sistema:

$$
a = \frac{(m_2 - m_1)g}{m_1 + m_2}
$$

y la tensión:

$$
T = \frac{2m_1 m_2}{m_1 + m_2}\,g
$$

Conclusiones:
- la tensión es la misma en toda la cuerda (modelo ideal),
- no coincide con el peso de ninguna de las masas en general.

---

## Dirección y sentido de la tensión

La tensión:
- siempre actúa **a lo largo de la cuerda**,
- siempre tira del cuerpo, **nunca empuja**.

En diagramas de cuerpo libre:
- la tensión se representa desde el punto de unión,
- dirigida hacia el interior de la cuerda.

Un error típico es invertir el sentido de \(T\) (ponerla empujando).

---

## Cuerdas con masa (nivel universitario)

Si la cuerda tiene masa apreciable:
- la tensión **no es constante** a lo largo del cable,
- cada punto del cable soporta el peso de la porción situada por debajo.

En una cuerda vertical de densidad lineal \( \lambda \):

$$
\frac{dT}{dy} = \lambda g
$$

Integrando:

$$
T(y) = \lambda g y + C
$$

Esto introduce el concepto de **tensión como función de la posición**.

---

## Cable como sistema continuo (ingeniería)

En ingeniería, el cable se trata como un **medio continuo**.

Se estudia:
- distribución de tensiones,
- deformaciones,
- condiciones de contorno.

La tensión deja de ser una fuerza puntual y pasa a ser una **magnitud interna**, relacionada con:
- elasticidad,
- resistencia de materiales,
- diseño estructural.

Este enfoque conecta la dinámica clásica con:
- ecuaciones diferenciales,
- análisis estructural,
- modelos reales de ingeniería.

---

## Resumen conceptual

- La tensión es una fuerza transmitida por un cable en tracción.
- Su valor se obtiene **aplicando las leyes de Newton**, no por definición.
- Puede ser constante o variable según el modelo.
- El mismo concepto escala desde sistemas simples hasta ingeniería estructural.
