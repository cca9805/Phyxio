# Descomposición vectorial (componentes)

## Idea clave
Descomponer un vector significa escribirlo como suma de sus componentes en unos ejes elegidos.

El objetivo práctico es convertir ecuaciones vectoriales en ecuaciones escalares.

---

## Vector y componentes (ejes x-y)
Si una fuerza tiene módulo \(F\) y forma un ángulo \(\theta\) con el eje x:

$$
F_x = F\cos\theta
$$

$$
F_y = F\sin\theta
$$

Y el vector se expresa como:

$$
\vec F = F_x\,\hat i + F_y\,\hat j
$$

---

## ¿Seno o coseno? (truco fiable)
- La componente sobre el eje desde el que mides el ángulo usa **coseno**.
- La componente sobre el eje perpendicular usa **seno**.

---

## Signos (no los regala nadie)
Las fórmulas anteriores dan módulos con signo si eliges el signo de \(\cos\theta\) y \(\sin\theta\)
según el cuadrante.

Regla práctica:
- dibuja el vector
- mira si apunta en +x o −x, +y o −y
- asigna signo a cada componente

---

## Proyecciones en ejes inclinados (plano inclinado)
En un plano inclinado se eligen ejes:
- paralelo al plano
- perpendicular al plano

Para el peso (módulo \(mg\)):

$$
P_{\parallel} = mg\sin\theta
$$

$$
P_{\perp} = mg\cos\theta
$$

Esto es la base para calcular:
- normal
- rozamiento
- aceleración sobre el plano

---

## Relación con Newton
La ecuación:

$$
\sum \vec F = m\vec a
$$

se proyecta en ejes:

$$
\sum F_x = m a_x
$$

$$
\sum F_y = m a_y
$$

---

## Qué es calculable y qué no
- Calculable: \(F_x, F_y\) si se conoce \(F\) y \(\theta\).
- Descriptivo: obtener \(\theta\) de forma única sin contexto (por cuadrantes/ambigüedad).
