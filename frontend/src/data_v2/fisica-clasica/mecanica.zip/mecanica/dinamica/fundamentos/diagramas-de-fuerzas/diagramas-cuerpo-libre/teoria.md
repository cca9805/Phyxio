# Diagramas de Cuerpo Libre (DCL)

## Idea clave
Un **Diagrama de Cuerpo Libre (DCL)** es el método que permite transformar una situación
física real en ecuaciones matemáticas aplicables.

> Sin DCL correcto, no existe problema de dinámica bien planteado.

---

## Paso 1: elegir el cuerpo
Selecciona **un solo cuerpo** (o un conjunto tratado como uno solo).

Ejemplos:
- una caja
- una persona
- una polea
- el sistema “caja + cuerda”

Todo lo demás se considera **entorno**.

---

## Paso 2: aislar el cuerpo
Elimina mentalmente el entorno y deja solo el cuerpo elegido.  
Todas las interacciones con el exterior se convierten en fuerzas sobre el cuerpo.

---

## Paso 3: dibujar TODAS las fuerzas reales
Incluye únicamente fuerzas que provienen de una interacción física clara:
- gravedad
- contacto
- cuerda
- muelle
- fluido

No dibujes:
- fuerzas “del movimiento”
- fuerzas de otros cuerpos (acción–reacción)

---

## Paso 4: elegir sistema de referencia y ejes
Selecciona ejes que **simplifiquen las ecuaciones**.

Ejemplo general:
$$
\text{ejes } x, y \text{ adaptados al movimiento o a la geometría}
$$

---

## Paso 5: proyectar fuerzas
Descompón las fuerzas solo si es necesario.

Ejemplo:
$$
\sum F_x = F_{1x} + F_{2x} + \dots
$$

$$
\sum F_y = F_{1y} + F_{2y} + \dots
$$

---

## Paso 6: aplicar la segunda ley
En forma vectorial:
$$
\sum \vec F = m \vec a
$$

Por componentes:
$$
\sum F_x = m a_x
$$

$$
\sum F_y = m a_y
$$

---

## Paso 7: resolver
Una vez escritas las ecuaciones:
- despeja incógnitas
- interpreta signos
- comprueba coherencia física

---

## Regla de oro
Si una fuerza aparece en el DCL, debes poder decir **quién ejerce esa fuerza sobre el cuerpo**.

Si no puedes responder, **esa fuerza no existe**.

---

## Qué es calculable y qué no
- **Calculable**: aceleraciones, tensiones, normales, rozamientos (según el modelo).
- **No calculable**: el DCL es un **método**, no una fórmula.
