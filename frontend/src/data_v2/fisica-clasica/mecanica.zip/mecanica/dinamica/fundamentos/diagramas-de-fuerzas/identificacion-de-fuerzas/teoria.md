# Diagramas de fuerzas (DCL): identificación de fuerzas

## Idea clave
Un **Diagrama de Cuerpo Libre (DCL)** es el dibujo de un cuerpo **aislado** mostrando **todas las fuerzas reales** que actúan sobre él.

> DCL = “inventario de fuerzas”  
> (no de aceleraciones, no de velocidades, no de fuerzas que actúan sobre otros cuerpos).

---

## Paso 0: elegir el cuerpo
Define el “protagonista”:
- ¿la caja?
- ¿la persona?
- ¿la cuerda?
- ¿la polea?
- ¿el conjunto (caja + cuerda)?

Sin protagonista **no hay DCL**.

---

## Paso 1: aislar (cortar conexiones)
Imagina que cortas la cuerda, separas superficies y “apagas” el resto del mundo.  
Solo queda el cuerpo y **sus interacciones con el exterior**.

---

## Paso 2: identificar fuerzas típicas

### 1) Peso
Fuerza gravitatoria ejercida por la Tierra sobre el cuerpo.

$$
\vec P = m \vec g
$$

- Existe siempre que haya gravedad.
- Apunta hacia abajo (hacia el centro de la Tierra).

---

### 2) Normal
Fuerza de contacto ejercida por una superficie.

$$
\vec N \perp \text{superficie}
$$

- Solo existe si hay contacto.
- No es “siempre hacia arriba”: es **perpendicular a la superficie**.
- Su valor se obtiene con las leyes de Newton.

---

### 3) Tensión
Fuerza transmitida por una cuerda o cable ideal.

$$
\vec T \parallel \text{cuerda}
$$

- Apunta a lo largo de la cuerda.
- Una cuerda **tira**, nunca empuja.

---

### 4) Rozamiento
Fuerza de contacto tangencial que se opone al deslizamiento relativo.

Rozamiento cinético:

$$
f_k = \mu N
$$

Rozamiento estático:

$$
f_s \le \mu_s N
$$

- El rozamiento **no aparece si no hay contacto**.
- El rozamiento estático **no vale siempre** $\mu_s N$; se ajusta hasta un máximo.

---

### 5) Fuerza elástica
Fuerza ejercida por un muelle ideal.

$$
F_{el} = k x
$$

- Apunta hacia la posición de equilibrio.
- Es proporcional a la deformación.

---

## Paso 3: elección de ejes y descomposición
Elegir bien los ejes **simplifica el problema**.

Ejemplo típico: plano inclinado.

Descomposición del peso:

$$
P_{\parallel} = mg \sin \theta
$$

$$
P_{\perp} = mg \cos \theta
$$

Solo descompón fuerzas **si lo necesitas**.

---

## Paso 4: NO confundir acción–reacción
Las fuerzas de acción–reacción **no aparecen juntas** en el DCL de un mismo cuerpo.

Ejemplo:
- En el DCL de la caja aparece:

$$
\vec N_{\text{suelo}\to\text{caja}}
$$

- La reacción:

$$
\vec N_{\text{caja}\to\text{suelo}}
$$

**no aparece**, porque actúa sobre el suelo (otro cuerpo).

---

## Regla de oro del DCL
Si una fuerza aparece en el diagrama, debes poder responder:

> ¿Quién ejerce esta fuerza sobre el cuerpo?

Si no puedes contestar, **esa fuerza no existe**.

---

## Qué es calculable y qué no
- **Calculable**: relaciones como
$$
P = mg,\quad f_k = \mu N,\quad F_{el} = kx
$$

- **No calculable**: el DCL en sí mismo es un **procedimiento**, no una ecuación.
