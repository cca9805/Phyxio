## Qué aprenderás
- A representar correctamente todas las fuerzas que actúan sobre un cuerpo.
- A aislar un sistema físico para su análisis.
- A evitar errores habituales de planteamiento.

## Qué encontrarás aquí
- Diagramas de cuerpo libre.
- Identificación de fuerzas reales.
- Descomposición vectorial de fuerzas.
- Estrategias para simplificar sistemas complejos.

## Conexiones
- Herramienta transversal en dinámica y estática.
- Paso previo imprescindible antes de aplicar las leyes de Newton.
