## Qué aprenderás
- El significado físico de cada ley de Newton.
- A distinguir entre equilibrio y movimiento acelerado.
- A aplicar correctamente fuerza y masa en sistemas reales.

## Qué encontrarás aquí
- Primera ley: principio de inercia.
- Segunda ley: relación fuerza–aceleración.
- Tercera ley: acción y reacción.
- Condiciones de validez de las leyes de Newton.

## Conexiones
- Base conceptual de toda la dinámica clásica.
- Aparece en todos los sistemas mecánicos.
