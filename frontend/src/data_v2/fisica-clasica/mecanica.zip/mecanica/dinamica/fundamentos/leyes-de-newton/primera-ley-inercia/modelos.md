﻿# Modelos y alcance

## Modelo usado
- Marco de referencia **inercial**.
- Cuerpo como partÃ­cula o sÃ³lido sin rotaciÃ³n (no tratamos torque aquÃ­).
- Fuerzas externas representadas como vectores.

## QuÃ© cubre este Tema
- InterpretaciÃ³n correcta de Î£F = 0.
- Equilibrio dinÃ¡mico: a = 0 (reposo o MRU).
- SeparaciÃ³n por componentes (x, y).

## QuÃ© NO cubre (se verÃ¡ despuÃ©s)
- Segunda Ley (Î£F = m a) como cÃ¡lculo general de aceleraciÃ³n.
- Rozamiento, tensiÃ³n, planos inclinados: son aplicaciones de las leyes completas.
- Marcos no inerciales (fuerzas ficticias).
