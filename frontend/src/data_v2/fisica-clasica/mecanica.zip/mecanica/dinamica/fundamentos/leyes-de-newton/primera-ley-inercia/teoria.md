﻿# Primera Ley de Newton (Inercia)

## Idea clave
En un **marco inercial**, un cuerpo:

- permanece en **reposo**, o
- mantiene un **movimiento rectilÃ­neo uniforme (MRU)**

si la **fuerza neta** que actÃºa sobre Ã©l es **nula**.

La forma fÃ­sica y matemÃ¡tica de decirlo:

$$
\sum \vec F = \vec 0 \quad \Rightarrow \quad \vec a = \vec 0
$$

### Variables que aparecen (y quÃ© significan)
- \(\sum \vec F\): **fuerza neta** (suma vectorial de todas las fuerzas externas).
- \(\vec a\): **aceleraciÃ³n**.
- \(\vec v\): **velocidad** (si \(\vec a=\vec 0\), la velocidad se mantiene constante).
- En componentes: \(F_x, F_y\) y \(a_x, a_y\).

---

## â€œNo hay fuerzasâ€ vs â€œla suma de fuerzas es ceroâ€
Este es el punto donde mÃ¡s se equivoca la gente.

- **No hay fuerzas**: literalmente no actÃºa ninguna fuerza.
- **Î£F = 0**: sÃ­ hay fuerzas, pero **se compensan vectorialmente**.

Ejemplo: un libro sobre una mesa
- actÃºa el peso \(\vec P\) hacia abajo
- actÃºa la normal \(\vec N\) hacia arriba
- y \(\vec N + \vec P = \vec 0\)

Resultado: el libro estÃ¡ en reposo **sin â€œnecesitarâ€ una fuerza extra**.

---

## QuÃ© significa Î£F = 0 en componentes
Si trabajas en 2D:

$$
\sum F_x = 0 \quad \text{y} \quad \sum F_y = 0
$$

No es â€œuna ecuaciÃ³nâ€: son **dos condiciones simultÃ¡neas**.  
Si una de ellas no se cumple, hay aceleraciÃ³n en esa direcciÃ³n.

---

## Marco inercial (condiciÃ³n escondida)
La Primera Ley es, en realidad, una forma de **definir marcos inerciales**:

> Un marco es inercial si un cuerpo con \(\sum \vec F = \vec 0\) se mueve con \(\vec v\) constante.

Si tu marco estÃ¡ acelerado (un coche que arranca, un ascensor que acelera, un carrusel), entonces pueden aparecer aparentes â€œfuerzasâ€ extra (ficticias) y el anÃ¡lisis cambia. Eso se verÃ¡ en marcos no inerciales.

---

## Consecuencia directa: MRU cuando a = 0
Si \(\vec a=\vec 0\), la velocidad es constante (en mÃ³dulo y direcciÃ³n en 1D/2D sin rotaciÃ³n):

$$
\vec v = \text{cte}
$$

En 1D, esto significa que la posiciÃ³n varÃ­a linealmente con el tiempo:

$$
x(t) = x_0 + v_x t
$$

No es una â€œfÃ³rmula nuevaâ€ de dinÃ¡mica: es la cinemÃ¡tica que cae como consecuencia.

---

## QuÃ© es calculable y quÃ© no (en Phyxio)
- **Calculable (aquÃ­):** condiciones de equilibrio por componentes (\(F_x=0\), \(F_y=0\)).
- **Descriptivo:** â€œ\(v=\text{cte}\)â€ y las consecuencias cinemÃ¡ticas si no fijamos condiciones iniciales dentro de este Tema.
- **MÃ¡s adelante:** equilibrio con fuerzas concretas (tensiÃ³n, rozamiento, etc.) y marcos no inerciales.
