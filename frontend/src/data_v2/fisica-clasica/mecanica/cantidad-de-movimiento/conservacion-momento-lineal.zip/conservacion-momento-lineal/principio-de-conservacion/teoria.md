# Principio de conservación del momento lineal

## Idea clave
Principio de conservación del momento lineal permite usar p_total,i=p_total,f en interacciones.

## 1- Qué estudia este subtema y por qué es fundamental
Este subtema desarrolla cómo plantear, calcular e interpretar principio de conservación del momento lineal con criterio físico.

## 2- Cómo funciona físicamente
fuerzas internas redistribuyen p pero no el total.

## 3- Magnitudes y parámetros que debes identificar siempre
- Variables de estado inicial y final.
- Parámetros geométricos/dinámicos en SI.
- Magnitud principal del subtema y su sentido físico.

## 4- Fórmulas esenciales y lectura física
$$
p_{tot,i}=p_{tot,f}
$$

$$
p_{tot,i}=p_{tot,f}
$$

$$
p_{tot,f}=p_{tot,i}
$$

## 5- Condiciones de validez y límites del modelo
- Hipótesis del subtema claramente declaradas.
- Consistencia de ejes y signos.
- Aplicación en el rango donde el modelo es válido.

## 6- Método de resolución paso a paso
1. Define sistema y referencia.
2. Selecciona ecuación adecuada.
3. Resuelve en simbólico y luego numérico.
4. Verifica unidades y coherencia física.

## 7- Preguntas lógicas de un alumno (y respuesta corta)
- ¿Qué variable domina el problema? Depende del subtema y del régimen de validez.
- ¿Cuándo falla el modelo? Cuando se incumplen sus hipótesis base.

## 8- Ejemplo guiado completo
- 1D: m1v1i+m2v2i=m1v1f+m2v2f.

## 9- Aplicaciones reales
- peritaje,acoplamientos,dinámica multicuerpo.

## 10- Síntesis final
Dominar Principio de conservación del momento lineal implica justificar: hipótesis -> ecuación -> cálculo -> interpretación -> decisión.
