# Impulso

## Idea clave
Impulso permite relacionar fuerza-tiempo con cambio de momento.

## 1- Qué estudia este subtema y por qué es fundamental
Este subtema desarrolla cómo plantear, calcular e interpretar impulso con criterio físico.

## 2- Cómo funciona físicamente
el área bajo F-t determina J.

## 3- Magnitudes y parámetros que debes identificar siempre
- Variables de estado inicial y final.
- Parámetros geométricos/dinámicos en SI.
- Magnitud principal del subtema y su sentido físico.

## 4- Fórmulas esenciales y lectura física
$$
J = F\Delta t
$$

$$
J = F\Delta t
$$

$$
F = \frac{J}{\Delta t}
$$

## 5- Condiciones de validez y límites del modelo
- Hipótesis del subtema claramente declaradas.
- Consistencia de ejes y signos.
- Aplicación en el rango donde el modelo es válido.

## 6- Método de resolución paso a paso
1. Define sistema y referencia.
2. Selecciona ecuación adecuada.
3. Resuelve en simbólico y luego numérico.
4. Verifica unidades y coherencia física.

## 7- Preguntas lógicas de un alumno (y respuesta corta)
- ¿Qué variable domina el problema? Depende del subtema y del régimen de validez.
- ¿Cuándo falla el modelo? Cuando se incumplen sus hipótesis base.

## 8- Ejemplo guiado completo
- F=150N,dt=0.2s -> J=30 N s.

## 9- Aplicaciones reales
- airbags,cascos,ensayos de impacto.

## 10- Síntesis final
Dominar Impulso implica justificar: hipótesis -> ecuación -> cálculo -> interpretación -> decisión.
