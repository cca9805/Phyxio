# Momento lineal

## Idea clave
Momento lineal permite cuantificar inercia dinámica traslacional.

## 1- Qué estudia este subtema y por qué es fundamental
Este subtema desarrolla cómo plantear, calcular e interpretar momento lineal con criterio físico.

## 2- Cómo funciona físicamente
un cuerpo con m mayor a misma v tiene mayor p.

## 3- Magnitudes y parámetros que debes identificar siempre
- Variables de estado inicial y final.
- Parámetros geométricos/dinámicos en SI.
- Magnitud principal del subtema y su sentido físico.

## 4- Fórmulas esenciales y lectura física
$$
p = mv
$$

$$
p = mv
$$

$$
m = \frac{p}{v}
$$

## 5- Condiciones de validez y límites del modelo
- Hipótesis del subtema claramente declaradas.
- Consistencia de ejes y signos.
- Aplicación en el rango donde el modelo es válido.

## 6- Método de resolución paso a paso
1. Define sistema y referencia.
2. Selecciona ecuación adecuada.
3. Resuelve en simbólico y luego numérico.
4. Verifica unidades y coherencia física.

## 7- Preguntas lógicas de un alumno (y respuesta corta)
- ¿Qué variable domina el problema? Depende del subtema y del régimen de validez.
- ¿Cuándo falla el modelo? Cuando se incumplen sus hipótesis base.

## 8- Ejemplo guiado completo
- m=1200kg,v=20m/s -> p=24000 kg m/s.

## 9- Aplicaciones reales
- seguridad vial,frenado,deportes de impacto.

## 10- Síntesis final
Dominar Momento lineal implica justificar: hipótesis -> ecuación -> cálculo -> interpretación -> decisión.
