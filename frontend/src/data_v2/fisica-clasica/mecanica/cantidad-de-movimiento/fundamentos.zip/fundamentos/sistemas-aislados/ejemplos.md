# Ejemplos guiados

## Ejemplo 1- Caso base de Sistemas aislados
**Enunciado:** Jext=0.03,Jint=6 -> Jext/Jint=0.005.

**Pasos de resolución**
1. Identifica variable objetivo y datos.
2. Aplica la relación principal: $p_{tot,i}=m_1v_{1i}+m_2v_{2i}$.
3. Verifica unidades y lectura física.

## Ejemplo 2- Variación de condición en Sistemas aislados
**Enunciado:** Fext=4N,dt=2.5s -> Jext=10 N s.

**Pasos de resolución**
1. Mantén el modelo y cambia una condición.
2. Recalcula y compara con el caso base.
3. Justifica la tendencia física.

## Criterio didáctico de cierre
No basta un número: debes defender por qué ese valor es coherente.

## Verificación física final (obligatoria)
1. Unidades SI correctas.
2. Signo y dirección coherentes.
3. Resultado compatible con hipótesis.
4. Conclusión técnica breve.
