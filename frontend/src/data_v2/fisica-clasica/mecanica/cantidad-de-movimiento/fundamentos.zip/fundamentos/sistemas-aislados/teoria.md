# Sistemas aislados

## Idea clave
Sistemas aislados permite decidir cuándo p_total se conserva.

## 1- Qué estudia este subtema y por qué es fundamental
Este subtema desarrolla cómo plantear, calcular e interpretar sistemas aislados con criterio físico.

## 2- Cómo funciona físicamente
si J_ext<<J_int el sistema es casi aislado.

## 3- Magnitudes y parámetros que debes identificar siempre
- Variables de estado inicial y final.
- Parámetros geométricos/dinámicos en SI.
- Magnitud principal del subtema y su sentido físico.

## 4- Fórmulas esenciales y lectura física
$$
p_{tot,i}=m_1v_{1i}+m_2v_{2i}
$$

$$
p_{tot,i}=m_1v_{1i}+m_2v_{2i}
$$

$$
p_{tot,f}=m_1v_{1f}+m_2v_{2f}
$$

## 5- Condiciones de validez y límites del modelo
- Hipótesis del subtema claramente declaradas.
- Consistencia de ejes y signos.
- Aplicación en el rango donde el modelo es válido.

## 6- Método de resolución paso a paso
1. Define sistema y referencia.
2. Selecciona ecuación adecuada.
3. Resuelve en simbólico y luego numérico.
4. Verifica unidades y coherencia física.

## 7- Preguntas lógicas de un alumno (y respuesta corta)
- ¿Qué variable domina el problema? Depende del subtema y del régimen de validez.
- ¿Cuándo falla el modelo? Cuando se incumplen sus hipótesis base.

## 8- Ejemplo guiado completo
- Jext=0.03,Jint=6 -> Jext/Jint=0.005.

## 9- Aplicaciones reales
- retroceso,explosiones internas,choques breves.

## 10- Síntesis final
Dominar Sistemas aislados implica justificar: hipótesis -> ecuación -> cálculo -> interpretación -> decisión.
