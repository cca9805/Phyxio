# Modelo y validez

## Modelo base del subtema
Modela definir estado rotacional respecto a eje con ecuaciones de balance y relaciones medibles.

$$
p=mv
$$

## Hipótesis operativas
- Unidades SI.
- Ejes y signos consistentes.
- Dominio de validez explícito.

## Qué explica bien este modelo
- Tendencia dominante del subtema.
- Relación entre variables principales.

## Límites del modelo
- No sustituye validación física final.
- Puede requerir extensión fuera del régimen ideal.

## Señales de que debes cambiar de modelo
- Desviaciones sistemáticas cálculo-medida.
- Incoherencia persistente del resultado.

## Qué, cómo y por qué (cierre didáctico)
- **Qué modela**: el núcleo de Definición de momento angular.
- **Cómo**: con relaciones cuantitativas y supuestos claros.
- **Por qué**: porque captura la causa dominante del fenómeno.

## Checklist de validez antes de calcular
- ¿Modelo correcto?
- ¿Signos y unidades correctos?
- ¿Resultado físicamente razonable?
