# Ejemplos guiados

## Ejemplo 1- Cálculo de amortiguamiento crítico
**Enunciado:** Para $k=400\,\mathrm{N/m}$ y $m=1.5\,\mathrm{kg}$, calcula $c_{crit}$.

**Pasos de resolución**
1. Aplica $c_{crit}=2\sqrt{km}$.
2. Sustituye en SI.
3. Interpreta el valor para selección de amortiguador.

## Ejemplo 2- Clasificación de régimen
**Enunciado:** Si $c=40\,\mathrm{N\,s/m}$ y $c_{crit}=49\,\mathrm{N\,s/m}$, clasifica r?gimen y justifica.

**Pasos de resolución**
1. Calcula $\zeta=c/c_{crit}$.
2. Compara con 1.
3. Concluye comportamiento esperado en el tiempo.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
