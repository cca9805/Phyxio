# Ejemplos guiados

## Ejemplo 1- Identificación del régimen
**Enunciado:** Con $c=90\,\mathrm{N\,s/m}$ y $c_{crit}=60\,\mathrm{N\,s/m}$, clasifica el sistema y describe la respuesta.

**Pasos de resolución**
1. Calcula $\zeta=c/c_{crit}$.
2. Compara $\zeta$ con $1$.
3. Describe cualitativamente la evolución temporal.

## Ejemplo 2- Comparación temporal con crítico
**Enunciado:** Dos sistemas con misma m y k: uno crítico y otro sobreamortiguado ($\zeta=1.8$). ¿Cuál tarda más en asentarse?

**Pasos de resolución**
1. Usa criterio cualitativo de raíces reales separadas para $\zeta>1$.
2. Compara con caso crítico.
3. Justifica por qué la respuesta sobreamortiguada es más lenta.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
