# Historia

## Contexto histórico
El régimen sobreamortiguado se incorporó al diseño cuando la prioridad pasó a ser evitar cualquier oscilación residual.

## Hitos clave
- Clasificación de regímenes en ecuaciones diferenciales lineales de segundo orden.
- Aplicación en ingeniería civil y mecánica de seguridad.
- Uso extendido en actuadores y sistemas de contención.

## Relevancia histórica
Es clave cuando la robustez frente a oscilación prima sobre la rapidez.

## Continuidad en la física e ingeniería actuales
Se mantiene en diseño de mecanismos críticos y amortiguación pasiva.

## Qué aporta hoy este subtema al aprendizaje
Este subtema no se conserva solo por tradición: se mantiene porque permite conectar teoría, laboratorio y diseño con un lenguaje cuantitativo estable que sigue vigente en ingeniería y física aplicada.
