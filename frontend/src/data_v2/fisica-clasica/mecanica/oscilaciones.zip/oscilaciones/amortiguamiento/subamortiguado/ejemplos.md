# Ejemplos guiados

## Ejemplo 1- Frecuencia amortiguada
**Enunciado:** Con $\omega_0=12\,\mathrm{rad/s}$ y $\beta=3\,\mathrm{rad/s}$, calcula $\omega_d$.

**Pasos de resolución**
1. Verifica condición $\beta<\omega_0$.
2. Aplica $\omega_d=\sqrt{\omega_0^2-\beta^2}$.
3. Interpreta diferencia entre frecuencia natural y amortiguada.

## Ejemplo 2- Amplitud tras cierto tiempo
**Enunciado:** Si $A_0=0.05\,\mathrm{m}$ y $\beta=0.4\,\mathrm{s^{-1}}$, calcula envolvente a $t=5\,\mathrm{s}$.

**Pasos de resolución**
1. Usa $A(t)=A_0e^{-\beta t}$.
2. Sustituye y calcula valor numérico.
3. Interpreta pérdida relativa de amplitud.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
