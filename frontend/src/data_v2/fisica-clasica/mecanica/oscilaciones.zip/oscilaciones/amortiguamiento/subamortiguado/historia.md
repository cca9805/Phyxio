# Historia

## Contexto histórico
El estudio del amortiguamiento permitió modelar sistemas reales donde la energía no se conserva ciclo a ciclo.

## Hitos clave
- Rayleigh formalizó tratamientos energéticos de disipación.
- La ingeniería mecánica incorporó modelos viscosos lineales.
- La teoría de control adoptó \zeta como parámetro de diseño estándar.

## Relevancia histórica
Es el régimen más frecuente en aplicaciones reales de vibración.

## Continuidad en la física e ingeniería actuales
Sigue siendo base en diseño de suspensiones y servosistemas.

## Qué aporta hoy este subtema al aprendizaje
Este subtema no se conserva solo por tradición: se mantiene porque permite conectar teoría, laboratorio y diseño con un lenguaje cuantitativo estable que sigue vigente en ingeniería y física aplicada.
