# Ejemplos guiados

## Ejemplo 1- Amplitud estacionaria
**Enunciado:** Con m=1 kg, c=2 N·s/m, k=100 N/m, F0=10 N y \omega=8 rad/s, calcula $X(\omega)$.

**Pasos de resolución**
1. Evalúa términos dinámicos $\left(k-m\omega^2\right)$ y $c\omega$.
2. Sustituye en $X(\omega)$.
3. Interpreta magnitud de respuesta respecto a F0/k.

## Ejemplo 2- Desfase de la respuesta
**Enunciado:** Con los mismos datos, calcula $\phi$ y explica si la respuesta adelanta o atrasa.

**Pasos de resolución**
1. Usa $\tan\phi=\dfrac{c\omega}{k-m\omega^2}$.
2. Determina cuadrante físico de fase.
3. Relaciona desfase con cercanía al régimen resonante.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
