# Historia

## Contexto histórico
La oscilación forzada se volvió central al pasar de sistemas aislados a sistemas reales excitados por el entorno.

## Hitos clave
- Helmholtz y Rayleigh estudiaron respuestas en acústica y vibraciones.
- La teoría de circuitos RLC consolidó analogías mecánico-eléctricas.
- La ingeniería de control formalizó respuesta en frecuencia.

## Relevancia histórica
Permite predecir vibraciones inducidas y diseñar mitigación.

## Continuidad en la física e ingeniería actuales
Es base de análisis modal experimental y mantenimiento predictivo.

## Qué aporta hoy este subtema al aprendizaje
Este subtema no se conserva solo por tradición: se mantiene porque permite conectar teoría, laboratorio y diseño con un lenguaje cuantitativo estable que sigue vigente en ingeniería y física aplicada.
