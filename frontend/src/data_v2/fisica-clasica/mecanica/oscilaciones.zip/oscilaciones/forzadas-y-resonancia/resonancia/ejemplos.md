# Ejemplos guiados

## Ejemplo 1- Estimación de frecuencia resonante
**Enunciado:** Con $\omega_0=20\,\mathrm{rad/s}$ y $\beta=2\,\mathrm{rad/s}$, estima $\omega_r$.

**Pasos de resolución**
1. Verifica régimen subamortiguado.
2. Aplica $\omega_r\approx\sqrt{\omega_0^2-2\beta^2}$.
3. Compara con $\omega_0$ y comenta desplazamiento del pico.

## Ejemplo 2- Evaluación de selectividad
**Enunciado:** Si $\omega_0=50\,\mathrm{rad/s}$ y $\beta=1\,\mathrm{rad/s}$, calcula $Q$ aproximado e interpreta.

**Pasos de resolución**
1. Usa $Q\approx\omega_0/(2\beta)$.
2. Calcula valor numérico.
3. Relaciona Q con ancho de banda y sensibilidad resonante.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
