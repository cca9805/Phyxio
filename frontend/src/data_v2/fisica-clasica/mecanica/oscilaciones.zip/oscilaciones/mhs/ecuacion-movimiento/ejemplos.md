# Ejemplos guiados

## Ejemplo 1- Obtención de estado instantáneo
**Enunciado:** Un oscilador tiene $A=0.08\,\mathrm{m}$, $\omega=10\,\mathrm{rad/s}$ y $\varphi=0$. Calcula $x$, $v$ y $a$ en $t=0$.20\,\mathrm{s}$.

**Pasos de resolución**
1. Calcula la fase: $\theta=\omega t+\varphi=2.0\,\text{rad}$.
2. Aplica $x=A\cos\theta$, $v=-A\omega\sin\theta$ y $a=-\omega^2x$.
3. Interpreta el signo de v y a respecto al sentido de retorno al equilibrio.

## Ejemplo 2- Reconstrucción desde condiciones iniciales
**Enunciado:** Si $x(0)=0.05\,\mathrm{m}$ y $v(0)=0.30\,\mathrm{m/s}$ con $\omega=6\,\mathrm{rad/s}$, determina $A$ y $\varphi$.

**Pasos de resolución**
1. Usa $x(0)=A\cos\varphi$ y $v(0)=-A\omega\sin\varphi$.
2. Resuelve el sistema para obtener $A$ y $\varphi$ con cuadrante correcto.
3. Escribe $x(t)$ completo y verifica sustituyendo $t=0$.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
