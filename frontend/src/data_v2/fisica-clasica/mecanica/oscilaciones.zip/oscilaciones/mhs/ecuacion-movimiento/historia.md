# Historia

## Contexto histórico
El modelo armónico surgió como aproximación universal para oscilaciones pequeñas alrededor del equilibrio.

## Hitos clave
- Galileo estudió regularidades temporales del péndulo.
- Hooke y Newton conectaron elasticidad, fuerza restauradora y dinámica.
- Euler y Lagrange consolidaron la forma analítica del oscilador armónico.

## Relevancia histórica
Se convirtió en una herramienta central porque aparece en mecánica, ondas, electricidad y física moderna.

## Continuidad en la física e ingeniería actuales
Hoy sigue siendo el modelo base para análisis modal, control y vibraciones lineales.

## Qué aporta hoy este subtema al aprendizaje
Este subtema no se conserva solo por tradición: se mantiene porque permite conectar teoría, laboratorio y diseño con un lenguaje cuantitativo estable que sigue vigente en ingeniería y física aplicada.
