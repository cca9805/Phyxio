# Ejemplos guiados

## Ejemplo 1- Energía total desde amplitud
**Enunciado:** Con $k=180\,\mathrm{N/m}$ y $A=0.05\,\mathrm{m}$, calcula la energía mecánica total.

**Pasos de resolución**
1. Usa $E=\tfrac12 kA^2$.
2. Sustituye en SI y calcula E.
3. Interpreta el resultado como cota máxima de intercambio K-U.

## Ejemplo 2- Distribución energética en posición dada
**Enunciado:** Para $k=120\,\mathrm{N/m}$, $m=0.8\,\mathrm{kg}$ y $A=0.10\,\mathrm{m}$, calcula $U$, $K$ y $v$ cuando $x=0.06\,\mathrm{m}$.

**Pasos de resolución**
1. Calcula $E=\tfrac12 kA^2$.
2. Obtén $U=\tfrac12 kx^2$ y luego $K=E-U$.
3. Despeja v desde $K=\tfrac12 mv^2$ y valida que $x<A$.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
