# Ejemplos guiados

## Ejemplo 1- Fase instantánea y estado
**Enunciado:** Con $A=0.03\,\mathrm{m}$, $\omega=15\,\mathrm{rad/s}$, $\varphi=0.4\,\mathrm{rad}$, calcula $\theta$ y $x$ en $t=0$.12\,\mathrm{s}$.

**Pasos de resolución**
1. Evalúa $\theta=\omega t+\varphi$.
2. Sustituye en $x=A\cos\theta$.
3. Interpreta si el oscilador está cerca de cresta, valle o cruce.

## Ejemplo 2- Desfase entre dos osciladores
**Enunciado:** Dos osciladores tienen misma $\omega$ y fases iniciales $0.2\,\mathrm{rad}$ y $1.1\,\mathrm{rad}$. Calcula el desfase y quién adelanta.

**Pasos de resolución**
1. Calcula $\Delta\varphi=\varphi_2-\varphi_1$.
2. Evalúa el signo para identificar adelanto/atraso.
3. Convierte el desfase en fracción de periodo: $\Delta t=\Delta\varphi/\omega$.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
