# Ejemplos guiados

## Ejemplo 1- Periodo natural de diseño
**Enunciado:** Para $m=0.50\,\mathrm{kg}$ y $k=200\,\mathrm{N/m}$, calcula $\omega$ y $T$.

**Pasos de resolución**
1. Calcula $\omega=\sqrt{k/m}$.
2. Obtén $T=\dfrac{2\pi}{\omega}$.
3. Comprueba orden de magnitud físico del resultado.

## Ejemplo 2- Fuerza restauradora máxima
**Enunciado:** Con $k=150\,\mathrm{N/m}$ y amplitud $A=0.04\,\mathrm{m}$, calcula la fuerza máxima y la energía total.

**Pasos de resolución**
1. Evalúa $F_{max}=kA$.
2. Calcula $E=\tfrac12kA^2$.
3. Relaciona ambos resultados con el rango operativo del sistema.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
