# Ejemplos guiados

## Ejemplo 1- Corrección por amplitud finita
**Enunciado:** Para $T_0=1.80\,\mathrm{s}$ y amplitud inicial $0.50\,\mathrm{rad}$, estima T corregido con primer término.

**Pasos de resolución**
1. Usa $T\approx T_0\left(1+\theta_0^2/16\right)$.
2. Sustituye $\theta_0$ en radianes.
3. Compara con $T_0$ y cuantifica el incremento porcentual.

## Ejemplo 2- Cálculo de inercia por periodo medido
**Enunciado:** Con $m=1.8\,\mathrm{kg}$, $d=0.22\,\mathrm{m}$ y $T_{medido}=2.05\,\mathrm{s}$, estima $I$ usando modelo lineal.

**Pasos de resolución**
1. Despeja $I$ desde $T=2\pi\sqrt{I/(mgd)}$.
2. Sustituye datos y calcula $I$.
3. Discute si la amplitud experimental permite usar este modelo.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
