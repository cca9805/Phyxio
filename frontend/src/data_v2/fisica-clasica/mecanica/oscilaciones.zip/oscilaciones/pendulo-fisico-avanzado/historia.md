# Historia

## Contexto histórico
La versión avanzada surge al estudiar desviaciones experimentales del modelo lineal de pequeño ángulo.

## Hitos clave
- La teoría de funciones elípticas describió periodos exactos en no linealidad.
- La mecánica analítica extendió el modelo a oscilaciones finitas.
- La computación moderna permitió simulación precisa y ajuste paramétrico.

## Relevancia histórica
Permite pasar de teoría ideal a modelado de laboratorio de nivel universitario.

## Continuidad en la física e ingeniería actuales
Es referencia en identificación dinámica y análisis no lineal en ingeniería.

## Qué aporta hoy este subtema al aprendizaje
Este subtema no se conserva solo por tradición: se mantiene porque permite conectar teoría, laboratorio y diseño con un lenguaje cuantitativo estable que sigue vigente en ingeniería y física aplicada.
