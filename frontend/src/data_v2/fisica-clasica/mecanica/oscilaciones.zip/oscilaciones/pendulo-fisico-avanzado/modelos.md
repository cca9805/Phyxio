# Modelos y validez

## Modelo base del subtema
Este subtema modela la dinámica no lineal y el ajuste fino del péndulo físico fuera del régimen elemental. Se usa un marco clásico, determinista y con parámetros efectivos constantes en el intervalo de análisis.

## Hipótesis operativas
- Régimen de pequeñas perturbaciones cuando la linealización lo exige.
- Parámetros del sistema aproximadamente constantes durante el ensayo o problema.
- Unidades SI y definición explícita de ejes, signos y referencia temporal.

## Qué explica bien este modelo
- Corrección del periodo por amplitud finita.
- Ajuste de I y d desde medidas de T.
- Evaluación de sensibilidad y propagación de incertidumbre.

## Límites del modelo
- Si aparecen no linealidades fuertes, el modelo lineal pierde precisión.
- Si el amortiguamiento real no es equivalente al supuesto, cambian amplitud y fase.
- Si hay acoplamientos externos relevantes, se requiere un modelo de mayor orden.

## Señales de que debes cambiar de modelo
- Desviaciones sistemáticas entre medida y predicción en más de un ciclo.
- Dependencia clara de parámetros con amplitud o frecuencia fuera del marco esperado.
- Incoherencias físicas persistentes aun con unidades y signos correctos.

## Qué, cómo y por qué (cierre didáctico)
- **Qué modela**: el fenómeno dominante del sistema en el rango estudiado.
- **Cómo lo modela**: mediante ecuaciones idealizadas con parámetros efectivos.
- **Por qué funciona**: porque en ese rango las hipótesis simplificadoras capturan la física principal con error controlado.

## Checklist de validez antes de calcular
- Parámetros en SI y claramente definidos.
- Signos y ejes consistentes con el planteamiento.
- Hipótesis explícitas (linealidad, pequeño ángulo, disipación, etc.).
- Resultado final compatible con orden de magnitud esperado.
