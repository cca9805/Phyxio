# Ejemplos guiados

## Ejemplo 1- Periodo de barra oscilante
**Enunciado:** Una barra con $I=0.32\,\mathrm{kg\,m^2}$·m², $m=2.5\,\mathrm{kg}$ y $d=0.18\,\mathrm{m}$ oscila en $g=9.81\,\mathrm{m/s^2}$². Calcula T.

**Pasos de resolución**
1. Calcula $\omega_0=\sqrt{mgd/I}$.
2. Obtén $T=2\pi/\omega_0$.
3. Comenta cómo cambiaría T si d aumenta.

## Ejemplo 2- Comparación con péndulo simple equivalente
**Enunciado:** Para el sistema anterior, calcula la longitud equivalente $L_{eq}$=I/(md).

**Pasos de resolución**
1. Evalúa $L_{eq}$ con datos.
2. Compara T con el de un péndulo simple de longitud $L_{eq}$.
3. Interpreta la equivalencia y sus límites.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
