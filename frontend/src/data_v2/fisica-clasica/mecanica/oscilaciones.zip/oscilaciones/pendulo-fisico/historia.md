# Historia

## Contexto histórico
El péndulo físico generalizó el péndulo simple al caso real de cuerpos extensos.

## Hitos clave
- Euler y Lagrange formalizaron el tratamiento de sólidos rígidos en rotación.
- La teoría de momentos de inercia permitió predecir periodos de cuerpos complejos.
- La instrumentación moderna usa este modelo para caracterización dinámica.

## Relevancia histórica
Es puente directo entre oscilaciones y dinámica rotacional.

## Continuidad en la física e ingeniería actuales
Se usa en ingeniería estructural, biomecánica y diseño mecánico.

## Qué aporta hoy este subtema al aprendizaje
Este subtema no se conserva solo por tradición: se mantiene porque permite conectar teoría, laboratorio y diseño con un lenguaje cuantitativo estable que sigue vigente en ingeniería y física aplicada.
