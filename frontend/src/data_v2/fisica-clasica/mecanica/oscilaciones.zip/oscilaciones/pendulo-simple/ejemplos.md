# Ejemplos guiados

## Ejemplo 1- Periodo con longitud conocida
**Enunciado:** Un péndulo de $L=0.90\,\mathrm{m}$ oscila en la Tierra. Calcula T y f.

**Pasos de resolución**
1. Aplica $T=2\pi\sqrt{L/g}$.
2. Calcula $f=1/T$.
3. Interpreta si el valor es razonable para laboratorio escolar.

## Ejemplo 2- Longitud para periodo objetivo
**Enunciado:** Diseña un péndulo con $T=2.2\,\mathrm{s}$ en $g=9.81\,\mathrm{m/s^2}$². Halla L.

**Pasos de resolución**
1. Despeja $L=g\left(T/2\pi\right)^2$.
2. Sustituye en SI.
3. Discute margen de error por amplitud no pequeña.

## Criterio didáctico de cierre
En ambos ejemplos, la clave es justificar hipótesis, mantener consistencia de unidades y verificar que el resultado describe de forma coherente el comportamiento oscilatorio esperado.

## Verificación física final (obligatoria)
1. Comprueba dimensiones y unidades de todas las magnitudes del resultado.
2. Verifica que el signo y la tendencia del resultado tengan sentido físico.
3. Revisa si el valor obtenido respeta las hipótesis del modelo usado.
4. Redacta una conclusión breve: qué significa ese resultado en el sistema real.
