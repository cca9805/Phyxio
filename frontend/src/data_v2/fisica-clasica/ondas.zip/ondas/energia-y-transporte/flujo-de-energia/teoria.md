# Flujo De Energia

## Idea clave
La energia ondulatoria se estudia con potencia, intensidad y flujo.

## 1) Que fenomeno explica este tema y por que importa
Este tema distingue magnitudes globales de magnitudes locales.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(P\): potencia (W).
- \(E\): energia (J).
- \(t\): tiempo (s).
- \(I\): intensidad (W/m^2).
- \(A\): area (m^2).

## 4) Formulacion matematica y lectura fisica
### Flujo de energia
$$
P=\frac{E}{t}
$$
Lectura fisica: Expresa como se transporta energia en el tiempo o en el espacio.

### Potencia e intensidad
$$
P=IA
$$
Lectura fisica: Expresa como se transporta energia en el tiempo o en el espacio.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: $E=120\ \\text{J}$ en $t=3\ \\text{s}$.
$$
P=\frac{E}{t}=40\ \\text{W}
$$

## 9) Aplicaciones reales
- analisis de propagacion.
- resolucion de problemas fisicos.
- interpretacion experimental.
- aplicaciones de ingenieria.

## 10) Sintesis final
Dominar **Flujo De Energia** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
