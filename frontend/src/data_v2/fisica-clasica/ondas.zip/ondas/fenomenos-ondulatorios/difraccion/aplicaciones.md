# Difraccion - Aplicaciones

## Idea clave
La difraccion aparece cuando el obstaculo o abertura es comparable con lambda.

## Aplicaciones donde realmente se usa
- resolucion optica.
- antenas.
- ultrasonidos.
- diseno de aperturas.

## Decisiones tecnicas que este tema permite tomar
- comparar tamano de abertura y lambda.
- usar condicion angular correcta.
- diferenciar de simple refraccion.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$a\sin\theta=m\lambda$$
- $$\theta=\arcsin\left(\frac{m\lambda}{a}\right)$$
- $$\theta\approx1.22\frac{\lambda}{D}$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
