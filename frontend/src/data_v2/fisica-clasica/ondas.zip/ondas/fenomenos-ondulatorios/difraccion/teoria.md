# Difraccion

## Idea clave
La difraccion aparece cuando la abertura es comparable con lambda.

## 1) Que fenomeno explica este tema y por que importa
Este tema explica por que una onda no siempre se comporta como rayo.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(a\): abertura (m).
- \(\sin\theta\): sin angulo (1).
- \(m\): orden (1).
- \(\lambda\): longitud onda (m).
- \(\theta\): angulo (rad).
- \(D\): diametro apertura (m).

## 4) Formulacion matematica y lectura fisica
### Condicion de difraccion
$$
a\sin\theta=m\lambda
$$
Lectura fisica: Relacion angular de propagacion entre medios o caminos.

### Angulo por orden
$$
\theta=\arcsin\left(\frac{m\lambda}{a}\right)
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Criterio de Rayleigh
$$
\theta\approx1.22\frac{\lambda}{D}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.
Nota: expresion conceptual (Aproximacion optica de resolucion; requiere hipotesis de apertura circular y angulo pequeno.).

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- interferometria.
- diseno de antenas y arreglos.
- resolucion optica.
- analisis de patrones experimentales.

## 10) Sintesis final
Dominar **Difraccion** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
