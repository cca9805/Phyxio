# Interferencia Constructiva - Aplicaciones

## Idea clave
La interferencia surge por fase relativa y fija maximos y minimos espaciales o temporales.

## Aplicaciones donde realmente se usa
- interferometria.
- control de ruido.
- optica de precision.
- patrones de laboratorio.

## Decisiones tecnicas que este tema permite tomar
- calcular diferencia de camino.
- definir coherencia de fuentes.
- clasificar en constructiva o destructiva.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$\Delta=m\lambda$$
- $$\Delta\phi=2\pi m$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
