# Interferencia Constructiva

## Idea clave
La interferencia depende de la fase relativa entre ondas.

## 1) Que fenomeno explica este tema y por que importa
Este tema formaliza condiciones de maximos y minimos.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(\Delta\): diferencia camino (m).
- \(m\): orden (1).
- \(\lambda\): longitud onda (m).
- \(\Delta\phi\): desfase (rad).

## 4) Formulacion matematica y lectura fisica
### Condicion constructiva
$$
\Delta=m\lambda
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Condicion de fase
$$
\Delta\phi=2\pi m
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: dos fuentes coherentes en fase.
$$
\Delta=m\lambda
$$
Maximo cuando la diferencia de camino es multiplo entero de lambda.

## 9) Aplicaciones reales
- interferometria.
- diseno de antenas y arreglos.
- resolucion optica.
- analisis de patrones experimentales.

## 10) Sintesis final
Dominar **Interferencia Constructiva** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
