# Fenomenos Ondulatorios

## Enfoque del bloque
Este bloque organiza los conceptos de ondas con un hilo didactico: definicion fisica, ecuaciones operativas y lectura grafica.

## Que aprenderas
- Reflexion
- Refraccion
- Superposicion
- Interferencia
- Difraccion

## Como estudiar este bloque
1. Empieza por las magnitudes y relaciones base.
2. Pasa a fenomenos (interferencia, difraccion, refraccion) con ejemplos.
3. Cierra con aplicaciones de sonido, ondas EM y energia.
