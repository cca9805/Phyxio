# Reflexion - Aplicaciones

## Idea clave
La reflexion conserva el angulo respecto a la normal y define la geometria de retorno.

## Aplicaciones donde realmente se usa
- acustica geometrica.
- optica de espejos.
- radar.
- diseo de recintos.

## Decisiones tecnicas que este tema permite tomar
- dibujar normal.
- medir angulos correctamente.
- no mezclar reflexion con refraccion.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$\theta_r=\theta_i$$
- $$\phi_r=\phi_i+\pi$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
