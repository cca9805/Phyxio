# Reflexion

## Idea clave
La reflexion redirige la onda en una frontera.

## 1) Que fenomeno explica este tema y por que importa
Este tema fija el papel de la normal y de las condiciones de borde.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(\theta_i\): angulo incidencia (rad).
- \(\theta_r\): angulo reflexion (rad).
- \(\phi_i\): fase incidente (rad).
- \(\phi_r\): fase reflejada (rad).

## 4) Formulacion matematica y lectura fisica
### Ley de reflexion
$$
\theta_r=\theta_i
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Inversion de fase en extremo fijo
$$
\phi_r=\phi_i+\pi
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.
Nota: expresion conceptual (Depende del tipo de frontera y de la condicion mecanica de sujecion.).

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- analisis de propagacion.
- resolucion de problemas fisicos.
- interpretacion experimental.
- aplicaciones de ingenieria.

## 10) Sintesis final
Dominar **Reflexion** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
