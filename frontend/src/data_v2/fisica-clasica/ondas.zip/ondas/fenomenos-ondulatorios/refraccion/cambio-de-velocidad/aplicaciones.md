# Cambio De Velocidad - Aplicaciones

## Idea clave
La refraccion describe como cambia direccion y velocidad al pasar entre medios.

## Aplicaciones donde realmente se usa
- lentes.
- fibra optica.
- instrumentacion optica.
- acustica interfacial.

## Decisiones tecnicas que este tema permite tomar
- conservar frecuencia.
- usar indices y angulos consistentes.
- evaluar posibilidad de reflexion total.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$v_2=v_1\frac{n_1}{n_2}$$
- $$\lambda_2=\lambda_1\frac{n_1}{n_2}$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
