# Cambio De Velocidad

## Idea clave
La refraccion modifica direccion y velocidad al cambiar de medio.

## 1) Que fenomeno explica este tema y por que importa
Este tema separa que magnitudes se conservan y cuales cambian.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(v_1\): velocidad 1 (m/s).
- \(n_1\): indice 1 (1).
- \(n_2\): indice 2 (1).
- \(v_2\): velocidad 2 (m/s).
- \(\lambda_1\): longitud onda 1 (m).
- \(\lambda_2\): longitud onda 2 (m).

## 4) Formulacion matematica y lectura fisica
### Cambio de velocidad
$$
v_2=v_1\frac{n_1}{n_2}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Cambio de longitud de onda
$$
\lambda_2=\lambda_1\frac{n_1}{n_2}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- lentes y optica geometrica.
- fibra optica.
- instrumentacion optica.
- acustica en interfaces de medios.

## 10) Sintesis final
Dominar **Cambio De Velocidad** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
