# Ley De Snell - Aplicaciones

## Idea clave
La refraccion describe como cambia direccion y velocidad al pasar entre medios.

## Aplicaciones donde realmente se usa
- lentes.
- fibra optica.
- instrumentacion optica.
- acustica interfacial.

## Decisiones tecnicas que este tema permite tomar
- conservar frecuencia.
- usar indices y angulos consistentes.
- evaluar posibilidad de reflexion total.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$n_1\sin\theta_1=n_2\sin\theta_2$$
- $$\theta_2=\arcsin\left(\frac{n_1\sin\theta_1}{n_2}\right)$$
- $$\theta_c=\arcsin\left(\frac{n_2}{n_1}\right)$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
