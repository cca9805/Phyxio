# Superposicion - Aplicaciones

## Idea clave
La superposicion suma desplazamientos y explica patrones complejos con reglas lineales simples.

## Aplicaciones donde realmente se usa
- analisis de senales.
- vibraciones.
- sintesis de audio.
- interferencia.

## Decisiones tecnicas que este tema permite tomar
- sumar con fase.
- distinguir amplitud de energia.
- validar linealidad.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$y=y_1+y_2$$
- $$A_{res}=\sqrt{A_1^2+A_2^2+2A_1A_2\cos\Delta\phi}$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
