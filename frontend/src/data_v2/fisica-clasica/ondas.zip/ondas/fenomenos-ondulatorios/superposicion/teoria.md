# Superposicion

## Idea clave
Este tema desarrolla una pieza clave del bloque de ondas.

## 1) Que fenomeno explica este tema y por que importa
El objetivo es comprender, modelar y resolver con criterio fisico.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(y\): desplazamiento total (m).
- \(y_1\): onda 1 (m).
- \(y_2\): onda 2 (m).
- \(A_{res}\): amplitud resultante (m).
- \(A_1\): amplitud 1 (m).
- \(A_2\): amplitud 2 (m).
- \(\Delta\phi\): desfase (rad).

## 4) Formulacion matematica y lectura fisica
### Superposicion
$$
y=y_1+y_2
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Amplitud resultante
$$
A_{res}=\sqrt{A_1^2+A_2^2+2A_1A_2\cos\Delta\phi}
$$
Lectura fisica: Muestra equilibrio entre rigidez efectiva e inercia del medio.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- analisis de propagacion.
- resolucion de problemas fisicos.
- interpretacion experimental.
- aplicaciones de ingenieria.

## 10) Sintesis final
Dominar **Superposicion** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
