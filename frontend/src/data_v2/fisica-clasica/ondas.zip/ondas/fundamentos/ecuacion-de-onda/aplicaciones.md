# Ecuacion De Onda - Aplicaciones

## Idea clave
La ecuacion de onda unifica la evolucion espacial y temporal de una perturbacion.

## Aplicaciones donde realmente se usa
- modelado de vibraciones.
- simulacion de senales.
- analisis de propagacion.
- diseno de sistemas resonantes.

## Decisiones tecnicas que este tema permite tomar
- identificar parametros A, k, omega, phi.
- determinar direccion de propagacion.
- evaluar y(x,t) en puntos concretos.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$y=A\sin(kx-\omega t+\phi)$$
- $$\psi=kx-\omega t+\phi$$
- $$k=\frac{2\pi}{\lambda}$$
- $$\omega=2\pi f$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
