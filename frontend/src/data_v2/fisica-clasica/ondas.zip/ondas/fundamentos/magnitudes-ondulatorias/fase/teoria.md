# Fase

## Idea clave
La fase compara estado oscilatorio entre puntos y tiempos.

## 1) Que fenomeno explica este tema y por que importa
Este tema explica por que dos ondas se refuerzan o se cancelan.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(\phi\): fase (rad).
- \(\omega\): frecuencia angular (rad/s).
- \(t\): tiempo (s).
- \(k\): numero onda (rad/m).
- \(x\): posicion (m).
- \(\Delta\phi\): desfase (rad).
- \(\Delta x\): separacion espacial (m).
- \(\Delta t\): separacion temporal (s).
- \(\lambda\): longitud onda (m).
- \(T\): periodo (s).
- \(f\): frecuencia (Hz).
- \(n\): indice entero ciclos (1).

## 4) Formulacion matematica y lectura fisica
### Fase instantanea
$$
\phi=\omega t-kx
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Desfase espacial
$$
\Delta\phi=\frac{2\pi\Delta x}{\lambda}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Desfase temporal
$$
\Delta\phi=\frac{2\pi\Delta t}{T}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Conexion frecuencia angular-frecuencia
$$
\omega=2\pi f
$$
Lectura fisica: Conecta descripcion lineal con descripcion angular.

### Conexion numero de onda-longitud de onda
$$
k=\frac{2\pi}{\lambda}
$$
Lectura fisica: Conecta descripcion lineal con descripcion angular.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- analisis de propagacion.
- resolucion de problemas fisicos.
- interpretacion experimental.
- aplicaciones de ingenieria.

## 10) Sintesis final
Dominar **Fase** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
