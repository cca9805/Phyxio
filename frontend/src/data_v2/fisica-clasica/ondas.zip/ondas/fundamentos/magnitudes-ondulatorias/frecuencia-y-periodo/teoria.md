# Frecuencia Y Periodo

## Idea clave
Frecuencia y periodo describen el ritmo temporal de una onda.

## 1) Que fenomeno explica este tema y por que importa
Este tema evita confundir ciclos, segundos y frecuencia angular.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(f\): frecuencia (Hz).
- \(T\): periodo (s).
- \(\omega\): frecuencia angular (rad/s).
- \(N\): numero ciclos (1).
- \(t\): tiempo (s).

## 4) Formulacion matematica y lectura fisica
### Frecuencia
$$
f=\frac{1}{T}
$$
Lectura fisica: Frecuencia y periodo son magnitudes inversas.

### Periodo
$$
T=\frac{1}{f}
$$
Lectura fisica: Frecuencia y periodo son magnitudes inversas.

### Frecuencia angular
$$
\omega=2\pi f
$$
Lectura fisica: Conecta descripcion lineal con descripcion angular.

### Conteo de ciclos
$$
N=ft
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Relacion inversa f-T (conceptual)
$$
fT=1
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.
Nota: expresion conceptual (Relacion conceptual de proporcionalidad inversa usada para interpretacion fisica.).

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: $T=0.02\ \\text{s}$.
$$
f=\frac{1}{T}=50\ \\text{Hz}
$$
$$
\omega=2\pi f=100\pi\ \\text{rad/s}
$$

## 9) Aplicaciones reales
- analisis de propagacion.
- resolucion de problemas fisicos.
- interpretacion experimental.
- aplicaciones de ingenieria.

## 10) Sintesis final
Dominar **Frecuencia Y Periodo** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
