# Longitud De Onda

## Idea clave
La longitud de onda mide la escala espacial de un ciclo.

## 1) Que fenomeno explica este tema y por que importa
Este tema conecta geometria de la onda con propagacion.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(\lambda\): longitud onda (m).
- \(v\): velocidad (m/s).
- \(f\): frecuencia (Hz).
- \(T\): periodo (s).
- \(k\): numero onda (rad/m).

## 4) Formulacion matematica y lectura fisica
### Longitud de onda
$$
\lambda=\frac{v}{f}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Relacion con periodo
$$
\lambda=vT
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Numero de onda
$$
k=\frac{2\pi}{\lambda}
$$
Lectura fisica: Conecta descripcion lineal con descripcion angular.

### Definicion de longitud de onda (conceptual)
$$
\lambda=\Delta x_{\text{fase}}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.
Nota: expresion conceptual (Requiere identificacion geometrica de puntos en fase en el grafico o experimento.).

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: $v=340\ \\text{m/s}$ y $f=170\ \\text{Hz}$.
$$
\lambda=\frac{v}{f}=2\ \\text{m}
$$
$$
T=\frac{1}{f}=5.88\times10^{-3}\ \\text{s}
$$

## 9) Aplicaciones reales
- analisis de propagacion.
- resolucion de problemas fisicos.
- interpretacion experimental.
- aplicaciones de ingenieria.

## 10) Sintesis final
Dominar **Longitud De Onda** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
