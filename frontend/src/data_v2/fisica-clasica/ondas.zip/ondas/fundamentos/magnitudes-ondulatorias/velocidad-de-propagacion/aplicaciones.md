# Velocidad De Propagacion - Aplicaciones

## Idea clave
La velocidad de propagacion depende del medio y determina como se relacionan distancia y tiempo en la onda.

## Aplicaciones donde realmente se usa
- acustica.
- cuerdas.
- oceanografia.
- telecomunicaciones.

## Decisiones tecnicas que este tema permite tomar
- decidir entre v=lambda*f o formula de medio.
- comparar resultados de modelos.
- interpretar el valor en contexto fisico.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$v=\lambda f$$
- $$v=\frac{\lambda}{T}$$
- $$v=\frac{\omega}{k}$$
- $$v=\sqrt{\frac{F_t}{\mu_l}}$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
