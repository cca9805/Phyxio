# Velocidad De Propagacion - Ejemplos Guiados

## Idea clave
Resolver bien implica justificar cada paso, no solo sustituir datos.

## Ruta de practica
### Ejemplo 1 (basico)
Con lambda=0.80 m y f=5 Hz, calcula la velocidad de propagacion.
$$
v=\lambda f=0.80\cdot 5=4.0\ 	ext{m/s}
$$
El resultado indica que el patron ondulatorio avanza 4 m cada segundo.

### Ejemplo 2 (intermedio)
Ejemplo guiado: identifica la incognita, selecciona la formula principal y despeja antes de sustituir.
$$
v=\frac{\lambda}{T}
$$
Cierra el ejercicio verificando unidades SI y sentido fisico del resultado.

### Ejemplo 3 (integrado)
Ejemplo guiado: identifica la incognita, selecciona la formula principal y despeja antes de sustituir.
$$
v=\frac{\omega}{k}
$$
Cierra el ejercicio verificando unidades SI y sentido fisico del resultado.

## Checklist final de revision
- Datos en SI y simbolos correctos.
- Formula adecuada al modelo del tema.
- Resultado con unidad y orden de magnitud razonable.
- Interpretacion fisica coherente con el fenomeno.

## Siguiente paso
Contrasta estos ejemplos con `Graficas` para visualizar como cambian las variables del tema.
