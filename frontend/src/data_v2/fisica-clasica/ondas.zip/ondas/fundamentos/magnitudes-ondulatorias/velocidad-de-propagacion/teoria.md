# Velocidad De Propagacion

## Idea clave
Este tema desarrolla una pieza clave del bloque de ondas.

## 1) Que fenomeno explica este tema y por que importa
El objetivo es comprender, modelar y resolver con criterio fisico.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(v\): velocidad propagacion (m/s).
- \(\lambda\): longitud onda (m).
- \(f\): frecuencia (Hz).
- \(T\): periodo (s).
- \(\omega\): frecuencia angular (rad/s).
- \(k\): numero onda (rad/m).
- \(F_t\): tension (N).
- \(\mu_l\): densidad lineal (kg/m).
- \(B\): modulo compresibilidad (Pa).
- \(\rho\): densidad (kg/m^3).
- \(c\): velocidad luz vacio (m/s).
- \(n\): indice refraccion (1).

## 4) Formulacion matematica y lectura fisica
### Relacion basica de propagacion
$$
v=\lambda f
$$
Lectura fisica: Relaciona escala espacial y temporal de la onda.

### Relacion con periodo
$$
v=\frac{\lambda}{T}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Velocidad de fase
$$
v=\frac{\omega}{k}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Velocidad en cuerda tensa
$$
v=\sqrt{\frac{F_t}{\mu_l}}
$$
Lectura fisica: Muestra equilibrio entre rigidez efectiva e inercia del medio.

### Velocidad en fluido compresible
$$
v=\sqrt{\frac{B}{\rho}}
$$
Lectura fisica: Muestra equilibrio entre rigidez efectiva e inercia del medio.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- analisis de propagacion.
- resolucion de problemas fisicos.
- interpretacion experimental.
- aplicaciones de ingenieria.

## 10) Sintesis final
Dominar **Velocidad De Propagacion** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
