# Comparacion Con Ondas Mecanicas

## Idea clave
Comparar ondas EM y mecanicas aclara que magnitudes dependen del medio.

## 1) Que fenomeno explica este tema y por que importa
Este tema evita mezclar modelos incompatibles en ejercicios de ondas.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(v\): velocidad (m/s).
- \(\lambda\): longitud onda (m).
- \(f\): frecuencia (Hz).
- \(T\): periodo (s).
- \(v_{mec}\): velocidad mecanica (m/s).
- \(F_t\): tension (N).
- \(\mu_l\): densidad lineal (kg/m).

## 4) Formulacion matematica y lectura fisica
### Relacion fundamental
$$
v=\lambda f
$$
Lectura fisica: Relaciona escala espacial y temporal de la onda.

### Periodo
$$
T=\frac{1}{f}
$$
Lectura fisica: Frecuencia y periodo son magnitudes inversas.

### Ejemplo mecanico
$$
v_{mec}=\sqrt{\frac{F_t}{\mu_l}}
$$
Lectura fisica: Muestra equilibrio entre rigidez efectiva e inercia del medio.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- telecomunicaciones.
- imagen medica.
- teledeteccion.
- optica aplicada.

## 10) Sintesis final
Dominar **Comparacion Con Ondas Mecanicas** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
