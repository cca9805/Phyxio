# Espectro Electromagnetico - Ejemplos Guiados

## Idea clave
Resolver bien implica justificar cada paso, no solo sustituir datos.

## Ruta de practica
### Ejemplo 1 (basico)
Con lambda=600 nm y f=5.0e14 Hz, verifica el orden de c.
$$
c=\lambda f=(600\times10^{-9})(5.0\times10^{14})=3.0\times10^8\ 	ext{m/s}
$$
El resultado valida la coherencia de datos espectrales.

### Ejemplo 2 (intermedio)
Para f=5.0e14 Hz, estima la energia por foton.
$$
E=hf=(6.626\times10^{-34})(5.0\times10^{14})\approx 3.31\times10^{-19}\ 	ext{J}
$$
A mayor frecuencia, mayor energia cuantica por foton.

### Ejemplo 3 (integrado)
Ejemplo guiado: identifica la incognita, selecciona la formula principal y despeja antes de sustituir.
$$
E=\frac{hc}{\lambda}
$$
Cierra el ejercicio verificando unidades SI y sentido fisico del resultado.

## Checklist final de revision
- Datos en SI y simbolos correctos.
- Formula adecuada al modelo del tema.
- Resultado con unidad y orden de magnitud razonable.
- Interpretacion fisica coherente con el fenomeno.

## Siguiente paso
Contrasta estos ejemplos con `Graficas` para visualizar como cambian las variables del tema.
