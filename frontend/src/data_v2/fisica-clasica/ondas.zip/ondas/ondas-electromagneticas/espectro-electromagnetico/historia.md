# Espectro Electromagnetico - Historia Util

## Idea clave
La historia aqui se usa para entender por que el modelo actual funciona y cuando se adopto.

## Hitos relevantes
- Maxwell unifico electricidad y magnetismo en una teoria ondulatoria.
- Hertz verifico ondas EM en laboratorio.
- La electronica moderna explota todo el espectro de radio a rayos X.

## Que aporta al estudiante
- Contexto para no aprender formulas como listas aisladas.
- Criterio para distinguir modelo teorico de aproximacion practica.
- Vision de como la teoria se valida con medicion experimental.

## Cierre
Conocer estos hitos ayuda a interpretar mejor el alcance real del tema.
