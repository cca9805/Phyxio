# Espectro Electromagnetico

## Idea clave
El espectro electromagnetico organiza ondas por frecuencia, longitud de onda y energia.

## 1) Que fenomeno explica este tema y por que importa
Este tema conecta bandas EM con aplicaciones tecnologicas y rango fisico.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(c\): velocidad luz (m/s).
- \(\lambda\): longitud onda (m).
- \(f\): frecuencia (Hz).
- \(h\): constante planck (J*s).
- \(E\): energia foton (J).

## 4) Formulacion matematica y lectura fisica
### Relacion c-lambda-f
$$
c=\lambda f
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Energia de foton
$$
E=hf
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Energia y longitud de onda
$$
E=\frac{hc}{\lambda}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- telecomunicaciones.
- imagen medica.
- teledeteccion.
- optica aplicada.

## 10) Sintesis final
Dominar **Espectro Electromagnetico** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
