# Velocidad De La Luz - Aplicaciones

## Idea clave
Las ondas electromagneticas conectan frecuencia, longitud de onda y energia en todo el espectro.

## Aplicaciones donde realmente se usa
- telecomunicaciones.
- sensores.
- imagen medica.
- teledeteccion.

## Decisiones tecnicas que este tema permite tomar
- usar c=lambda*f con ordenes de magnitud correctos.
- interpretar banda espectral segun aplicacion.
- diferenciar energia por foton de potencia total.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$c=\lambda f$$
- $$n=\frac{c}{v}$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
