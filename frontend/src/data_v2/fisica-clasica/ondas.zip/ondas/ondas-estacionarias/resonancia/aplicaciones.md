# Resonancia - Aplicaciones

## Idea clave
Las ondas estacionarias codifican modos permitidos por condiciones de frontera y resonancia.

## Aplicaciones donde realmente se usa
- instrumentos.
- tubos sonoros.
- resonadores.
- analisis modal.

## Decisiones tecnicas que este tema permite tomar
- identificar tipo de extremos.
- calcular modo n valido.
- leer nodos/antinodos en graficas.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$f_n=\frac{nv}{2L}$$
- $$\lambda_n=\frac{2L}{n}$$
- $$f_{res}=f_n$$
- $$Q=\frac{f_{res}}{\Delta f}$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
