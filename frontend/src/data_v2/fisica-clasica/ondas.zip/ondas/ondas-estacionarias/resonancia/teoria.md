# Resonancia

## Idea clave
Ondas estacionarias y armonicos surgen por fronteras y superposicion.

## 1) Que fenomeno explica este tema y por que importa
Este tema conecta modos permitidos con frecuencias resonantes.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(f_n\): frecuencia modo (Hz).
- \(n\): modo (1).
- \(v\): velocidad (m/s).
- \(L\): longitud (m).
- \(\lambda_n\): longitud onda modo (m).
- \(f_{res}\): frecuencia resonancia (Hz).
- \(Q\): factor calidad (1).
- \(\Delta f\): ancho banda (Hz).

## 4) Formulacion matematica y lectura fisica
### Modo n
$$
f_n=\frac{nv}{2L}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Longitud de onda modal
$$
\lambda_n=\frac{2L}{n}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Condicion de resonancia
$$
f_{res}=f_n
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Factor Q
$$
Q=\frac{f_{res}}{\Delta f}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- instrumentos musicales.
- analisis modal estructural.
- diseno de resonadores.
- control de vibraciones.

## 10) Sintesis final
Dominar **Resonancia** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
