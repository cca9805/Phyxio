# Ondas Estacionarias En Cuerdas - Aplicaciones

## Idea clave
Las ondas estacionarias aparecen por superposicion de dos ondas opuestas y solo permiten modos discretos.

## Aplicaciones donde realmente se usa
- instrumentos de cuerda.
- analisis modal.
- resonadores.
- control de vibraciones.

## Decisiones tecnicas que este tema permite tomar
- identificar condicion de frontera.
- elegir modo n correcto.
- distinguir nodos y antinodos.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$f_n=\frac{nv}{2L}$$
- $$\lambda_n=\frac{2L}{n}$$
- $$f_1=\frac{v}{2L}$$
- $$f_n=nf_1$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
