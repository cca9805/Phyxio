# Ondas Estacionarias En Cuerdas

## Idea clave
Ondas estacionarias y armonicos surgen por fronteras y superposicion.

## 1) Que fenomeno explica este tema y por que importa
Este tema conecta modos permitidos con frecuencias resonantes.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(f_n\): frecuencia modo (Hz).
- \(f_1\): frecuencia fundamental (Hz).
- \(n\): modo (1).
- \(v\): velocidad propagacion (m/s).
- \(L\): longitud cuerda (m).
- \(\lambda_n\): longitud onda modal (m).
- \(k_n\): numero onda modal (rad/m).
- \(\omega_n\): frecuencia angular modal (rad/s).
- \(F_t\): tension (N).
- \(\mu_l\): densidad lineal (kg/m).
- \(A\): amplitud viajera (m).
- \(x\): posicion (m).

## 4) Formulacion matematica y lectura fisica
### Frecuencia modal en cuerda fija-fija
$$
f_n=\frac{nv}{2L}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Longitud de onda del modo n
$$
\lambda_n=\frac{2L}{n}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Frecuencia fundamental
$$
f_1=\frac{v}{2L}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Relacion armonica
$$
f_n=nf_1
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Velocidad de propagacion en cuerda tensa
$$
v=\sqrt{\frac{F_t}{\mu_l}}
$$
Lectura fisica: Muestra equilibrio entre rigidez efectiva e inercia del medio.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- instrumentos musicales.
- analisis modal estructural.
- diseno de resonadores.
- control de vibraciones.

## 10) Sintesis final
Dominar **Ondas Estacionarias En Cuerdas** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
