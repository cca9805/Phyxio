# Velocidad De Propagacion En Cuerdas - Aplicaciones

## Idea clave
En cuerdas, la velocidad depende de tension y densidad lineal: v=sqrt(F_t/mu_l).

## Aplicaciones donde realmente se usa
- afinacion de instrumentos.
- laboratorio de vibraciones.
- diagnostico de cuerdas.
- diseno de resonadores lineales.

## Decisiones tecnicas que este tema permite tomar
- usar tension efectiva real.
- expresar mu_l en kg/m.
- conectar modelo de cuerda con v=lambda*f.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$v=\lambda f$$
- $$v=\sqrt{\frac{F_t}{\mu_l}}$$
- $$\mu_l=\frac{m}{L}$$
- $$T=\frac{1}{f}$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
