# Velocidad De Propagacion En Cuerdas - Ejemplos Guiados

## Idea clave
Resolver bien implica justificar cada paso, no solo sustituir datos.

## Ruta de practica
### Ejemplo 1 (basico)
Con lambda=0.80 m y f=5 Hz, calcula la velocidad de propagacion.
$$
v=\lambda f=0.80\cdot 5=4.0\ 	ext{m/s}
$$
El resultado indica que el patron ondulatorio avanza 4 m cada segundo.

### Ejemplo 2 (intermedio)
Con F_t=100 N y mu_l=0.004 kg/m, calcula v en la cuerda.
$$
v=\sqrt{\frac{F_t}{\mu_l}}=\sqrt{\frac{100}{0.004}}\approx 158.1\ 	ext{m/s}
$$
Subir tension o bajar densidad lineal aumenta la velocidad.

### Ejemplo 3 (integrado)
Ejemplo guiado: identifica la incognita, selecciona la formula principal y despeja antes de sustituir.
$$
\mu_l=\frac{m}{L}
$$
Cierra el ejercicio verificando unidades SI y sentido fisico del resultado.

## Checklist final de revision
- Datos en SI y simbolos correctos.
- Formula adecuada al modelo del tema.
- Resultado con unidad y orden de magnitud razonable.
- Interpretacion fisica coherente con el fenomeno.

## Siguiente paso
Contrasta estos ejemplos con `Graficas` para visualizar como cambian las variables del tema.
