# Ondas Longitudinales En Fluidos - Aplicaciones

## Idea clave
En fluidos longitudinales, la compresibilidad y la densidad fijan la velocidad de propagacion.

## Aplicaciones donde realmente se usa
- acustica en fluidos.
- ultrasonidos.
- procesos industriales.
- instrumentacion.

## Decisiones tecnicas que este tema permite tomar
- usar v=sqrt(B/rho).
- conectar con impedancia Z=rho*v.
- diferenciar presion y velocidad de particula.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$v=\lambda f$$
- $$T=\frac{1}{f}$$
- $$k=\frac{2\pi}{\lambda}$$
- $$\omega=2\pi f$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
