# Ondas Longitudinales En Fluidos - Ejemplos Guiados

## Idea clave
Resolver bien implica justificar cada paso, no solo sustituir datos.

## Ruta de practica
### Ejemplo 1 (basico)
Con lambda=0.80 m y f=5 Hz, calcula la velocidad de propagacion.
$$
v=\lambda f=0.80\cdot 5=4.0\ 	ext{m/s}
$$
El resultado indica que el patron ondulatorio avanza 4 m cada segundo.

### Ejemplo 2 (intermedio)
Si f=50 Hz, calcula el periodo.
$$
T=\frac{1}{f}=\frac{1}{50}=0.020\ 	ext{s}
$$
Cada ciclo dura 20 ms.

### Ejemplo 3 (integrado)
Para lambda=0.50 m, calcula el numero de onda.
$$
k=\frac{2\pi}{\lambda}=\frac{2\pi}{0.50}=4\pi\ 	ext{rad/m}
$$
Mayor k implica variacion espacial mas rapida.

## Checklist final de revision
- Datos en SI y simbolos correctos.
- Formula adecuada al modelo del tema.
- Resultado con unidad y orden de magnitud razonable.
- Interpretacion fisica coherente con el fenomeno.

## Siguiente paso
Contrasta estos ejemplos con `Graficas` para visualizar como cambian las variables del tema.
