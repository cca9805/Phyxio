# Ondas Longitudinales En Fluidos

## Idea clave
En fluidos dominan compresibilidad, densidad y gravedad.

## 1) Que fenomeno explica este tema y por que importa
Este tema explica propagacion superficial y longitudinal.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(v\): velocidad de fase (m/s).
- \(\lambda\): longitud de onda (m).
- \(f\): frecuencia (Hz).
- \(T\): periodo (s).
- \(k\): numero de onda (rad/m).
- \(\omega\): frecuencia angular (rad/s).
- \(B\): modulo de compresion (Pa).
- \(\rho\): densidad (kg/m^3).
- \(Z\): impedancia acustica (Pa*s/m).
- \(\hat{p}\): amplitud de presion (Pa).
- \(\hat{u}\): amplitud velocidad particula (m/s).
- \(I\): intensidad acustica (W/m^2).

## 4) Formulacion matematica y lectura fisica
### Relacion general de propagacion
$$
v=\lambda f
$$
Lectura fisica: Relaciona escala espacial y temporal de la onda.

### Vinculo entre periodo y frecuencia
$$
T=\frac{1}{f}
$$
Lectura fisica: Frecuencia y periodo son magnitudes inversas.

### Numero de onda
$$
k=\frac{2\pi}{\lambda}
$$
Lectura fisica: Conecta descripcion lineal con descripcion angular.

### Frecuencia angular
$$
\omega=2\pi f
$$
Lectura fisica: Conecta descripcion lineal con descripcion angular.

### Velocidad longitudinal en fluido
$$
v=\sqrt{\frac{B}{\rho}}
$$
Lectura fisica: Muestra equilibrio entre rigidez efectiva e inercia del medio.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- oceanografia.
- hidraulica.
- acustica en fluidos.
- meteorologia fisica.

## 10) Sintesis final
Dominar **Ondas Longitudinales En Fluidos** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
