# Ondas Superficiales - Aplicaciones

## Idea clave
Las ondas superficiales combinan gravedad e inercia y cambian de comportamiento entre regimen profundo y somero.

## Aplicaciones donde realmente se usa
- oceanografia.
- ingenieria costera.
- hidrodinamica.
- prediccion de oleaje.

## Decisiones tecnicas que este tema permite tomar
- comparar kh para elegir aproximacion.
- usar g y profundidad con unidades SI.
- interpretar velocidad de fase.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$v=\lambda f$$
- $$T=\frac{1}{f}$$
- $$k=\frac{2\pi}{\lambda}$$
- $$\omega=2\pi f$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
