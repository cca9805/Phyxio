# Dispersion Y Atenuacion En Solidos

## Idea clave
En solidos coexisten modos longitudinales, transversales y superficiales.

## 1) Que fenomeno explica este tema y por que importa
Este tema depende de modulos elasticos, densidad y frontera.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(v_p\): velocidad fase (m/s).
- \(\omega\): frecuencia angular (rad/s).
- \(k\): numero onda (rad/m).
- \(r_A\): ratio amplitud (1).
- \(A_x\): amplitud x (1).
- \(A_0\): amplitud 0 (1).
- \(\alpha_{dB}\): atenuacion db m (dB/m).
- \(A_{dB}\): perdida db (dB).
- \(x\): distancia (m).

## 4) Formulacion matematica y lectura fisica
### Velocidad de fase
$$
v_p=\frac{\omega}{k}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Ratio de amplitud
$$
r_A=\frac{A_x}{A_0}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Atenuacion media
$$
\alpha_{dB}=\frac{A_{dB}}{x}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- ensayos no destructivos.
- sismologia.
- diagnostico estructural.
- ingenieria de materiales.

## 10) Sintesis final
Dominar **Dispersion Y Atenuacion En Solidos** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
