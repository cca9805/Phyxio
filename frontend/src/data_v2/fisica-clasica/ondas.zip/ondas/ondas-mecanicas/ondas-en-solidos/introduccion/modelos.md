# Introduccion - Modelo y Validez

## Modelo operativo del tema
En solidos, las ondas dependen de modulos elasticos, densidad y tipo de deformacion.

## Suposiciones de trabajo
- modelo lineal salvo que el enunciado indique no linealidad.
- magnitudes en SI y signos definidos antes de operar.
- medio y fronteras coherentes con la formula elegida.

## Cuando el modelo SI aplica
- Cuando el problema respeta las hipotesis fisicas indicadas.
- Cuando las variables y unidades estan bien definidas.
- Cuando el resultado mantiene coherencia con el medio real.

## Cuando NO aplica
- cuando el fenomeno es fuertemente no lineal.
- cuando faltan datos esenciales del medio o frontera.
- cuando se usan aproximaciones fuera de su rango.

## Ecuaciones de referencia del modelo
- $$v=\lambda f$$
- $$T=\frac{1}{f}$$
- $$v_L=\sqrt{\frac{K+\frac{4}{3}G}{\rho}}$$
- $$v_T=\sqrt{\frac{G}{\rho}}$$

## Checklist de validez antes de cerrar un problema
1. Confirmar que el regimen fisico coincide con la formula.
2. Revisar magnitudes necesarias en `Leyenda`.
3. Verificar unidades SI en todos los pasos.
4. Contrastar el resultado en `Graficas`.

## Cierre
El objetivo no es solo calcular; es saber cuando un calculo representa el fenomeno real.
