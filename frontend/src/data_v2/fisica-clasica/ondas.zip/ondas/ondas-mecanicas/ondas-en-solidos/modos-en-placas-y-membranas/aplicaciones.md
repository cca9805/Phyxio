# Modos En Placas Y Membranas - Aplicaciones

## Idea clave
En solidos, las ondas dependen de modulos elasticos, densidad y tipo de deformacion.

## Aplicaciones donde realmente se usa
- sismologia.
- ensayos no destructivos.
- ingenieria estructural.
- caracterizacion de materiales.

## Decisiones tecnicas que este tema permite tomar
- distinguir modos longitudinal, corte y superficial.
- elegir modulo elastico adecuado.
- validar hipotesis de isotropia.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$v=\sqrt{\frac{T_s}{\mu_s}}$$
- $$f_{mn}=\frac{v}{2}\sqrt{\left(\frac{m}{L_x}\right)^2+\left(\frac{n}{L_y}\right)^2}$$
- $$\omega_{mn}\propto\left[\left(\frac{m\pi}{L_x}\right)^2+\left(\frac{n\pi}{L_y}\right)^2\right]$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
