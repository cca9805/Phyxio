# Ondas Sismicas P Y S - Ejemplos Guiados

## Idea clave
Resolver bien implica justificar cada paso, no solo sustituir datos.

## Ruta de practica
### Ejemplo 1 (basico)
Ejemplo guiado: identifica la incognita, selecciona la formula principal y despeja antes de sustituir.
$$
t_P=\frac{d}{v_P}
$$
Cierra el ejercicio verificando unidades SI y sentido fisico del resultado.

### Ejemplo 2 (intermedio)
Ejemplo guiado: identifica la incognita, selecciona la formula principal y despeja antes de sustituir.
$$
t_S=\frac{d}{v_S}
$$
Cierra el ejercicio verificando unidades SI y sentido fisico del resultado.

### Ejemplo 3 (integrado)
Ejemplo guiado: identifica la incognita, selecciona la formula principal y despeja antes de sustituir.
$$
d=\frac{\Delta t}{\frac{1}{v_S}-\frac{1}{v_P}}
$$
Cierra el ejercicio verificando unidades SI y sentido fisico del resultado.

## Checklist final de revision
- Datos en SI y simbolos correctos.
- Formula adecuada al modelo del tema.
- Resultado con unidad y orden de magnitud razonable.
- Interpretacion fisica coherente con el fenomeno.

## Siguiente paso
Contrasta estos ejemplos con `Graficas` para visualizar como cambian las variables del tema.
