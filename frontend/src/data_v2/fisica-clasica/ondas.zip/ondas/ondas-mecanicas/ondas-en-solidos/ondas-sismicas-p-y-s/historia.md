# Ondas Sismicas P Y S - Historia Util

## Idea clave
La historia aqui se usa para entender por que el modelo actual funciona y cuando se adopto.

## Hitos relevantes
- Navier y Lame desarrollaron elasticidad continua.
- Rayleigh explico ondas superficiales en solidos.
- La metrologia moderna usa ultrasonidos para evaluar defectos.

## Que aporta al estudiante
- Contexto para no aprender formulas como listas aisladas.
- Criterio para distinguir modelo teorico de aproximacion practica.
- Vision de como la teoria se valida con medicion experimental.

## Cierre
Conocer estos hitos ayuda a interpretar mejor el alcance real del tema.
