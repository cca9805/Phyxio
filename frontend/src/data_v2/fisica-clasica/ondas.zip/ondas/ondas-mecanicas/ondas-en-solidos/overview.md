# Ondas En Solidos

## Enfoque del bloque
Este bloque cubre de forma completa la propagacion ondulatoria en medios solidos: propiedades elasticas, tipos de onda, modos, dispersion y aplicaciones tecnicas.

## Que aprenderas
- Introduccion
- Propiedades elasticas del solido
- Tipos de ondas en solidos
- Ondas longitudinales en barras
- Ondas transversales de corte
- Relacion entre modulos elasticos
- Ondas flexionales en vigas
- Ondas superficiales Rayleigh
- Ondas sismicas P y S
- Reflexion y transmision en solidos
- Impedancia mecanica en solidos
- Dispersion y atenuacion en solidos
- Resonancia y modos en barras
- Modos en placas y membranas
- Aplicaciones en ultrasonidos y ensayos

## Como estudiar este bloque
1. Empieza por propiedades elasticas y tipos de onda.
2. Continua con propagacion en barras, vigas y superficies.
3. Cierra con modos, dispersion y aplicaciones de ingenieria.
