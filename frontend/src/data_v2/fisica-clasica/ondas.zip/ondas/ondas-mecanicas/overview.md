# Ondas Mecanicas

## Enfoque del bloque
Este bloque organiza los conceptos de ondas con un hilo didactico: definicion fisica, ecuaciones operativas y lectura grafica.

## Que aprenderas
- Ondas En Cuerdas
- Ondas En Fluidos
- Ondas En Solidos

## Como estudiar este bloque
1. Empieza por las magnitudes y relaciones base.
2. Pasa a fenomenos (interferencia, difraccion, refraccion) con ejemplos.
3. Cierra con aplicaciones de sonido, ondas EM y energia.
