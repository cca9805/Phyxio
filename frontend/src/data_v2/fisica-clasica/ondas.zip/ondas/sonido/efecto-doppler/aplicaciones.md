# Efecto Doppler - Aplicaciones

## Idea clave
El sonido es una onda mecanica longitudinal cuya propagacion y percepcion dependen del medio y del observador.

## Aplicaciones donde realmente se usa
- audio.
- acustica arquitectonica.
- salud auditiva.
- instrumentacion sonora.

## Decisiones tecnicas que este tema permite tomar
- distinguir magnitudes fisicas y perceptivas.
- usar escalas lineales y logaritmicas correctamente.
- controlar convenios de signos.

## Relacion con la calculadora y graficas
1. Usa `Calculadora` para obtener el valor numerico con unidades SI.
2. Pasa a `Graficas` para comprobar si el resultado tiene sentido visual y fisico.
3. Revisa `Errores` y `Modelo y validez` antes de cerrar la respuesta.

## Formulas que se usan en estas aplicaciones
- $$f_{obs}=f_0\frac{v+v_o}{v-v_s}$$
- $$f_{obs}=f_0\frac{v+v_o}{v}$$
- $$f_{obs}=f_0\sqrt{\frac{1+\beta}{1-\beta}}$$

## Cierre
Una aplicacion esta bien resuelta cuando el numero calculado, la grafica y la interpretacion fisica cuentan la misma historia.
