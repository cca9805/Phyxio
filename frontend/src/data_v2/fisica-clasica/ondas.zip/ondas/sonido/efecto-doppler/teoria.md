# Efecto Doppler

## Idea clave
El efecto Doppler mide el cambio de frecuencia por movimiento relativo.

## 1) Que fenomeno explica este tema y por que importa
Este tema separa claramente casos de fuente movil, observador movil y convenio de signos.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(f_{obs}\): frecuencia observada (Hz).
- \(f_0\): frecuencia fuente (Hz).
- \(v\): velocidad onda (m/s).
- \(v_o\): velocidad observador (m/s).
- \(v_s\): velocidad fuente (m/s).

## 4) Formulacion matematica y lectura fisica
### Efecto Doppler
$$
f_{obs}=f_0\frac{v+v_o}{v-v_s}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Caso fuente fija
$$
f_{obs}=f_0\frac{v+v_o}{v}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Doppler relativista (conceptual)
$$
f_{obs}=f_0\sqrt{\frac{1+\beta}{1-\beta}}
$$
Lectura fisica: Relaciona el corrimiento Doppler con movimiento relativo mediante una correccion relativista.
Nota: expresion conceptual (Modelo relativista fuera del alcance de este tema de sonido clasico.).

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- radar y control de velocidad.
- ecografia Doppler.
- astronomia observacional.
- analisis de trafico y navegacion.

## 10) Sintesis final
Dominar **Efecto Doppler** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
