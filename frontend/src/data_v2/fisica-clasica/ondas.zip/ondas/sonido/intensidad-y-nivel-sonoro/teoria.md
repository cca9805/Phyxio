# Intensidad Y Nivel Sonoro

## Idea clave
Nivel sonoro e intensidad conectan energia fisica con escala logaritmica.

## 1) Que fenomeno explica este tema y por que importa
Este tema evita errores al interpretar dB como si fueran lineales.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(I\): intensidad (W/m^2).
- \(P\): potencia (W).
- \(A\): area (m^2).
- \(\beta\): nivel sonoro (dB).
- \(I_0\): intensidad referencia (W/m^2).
- \(r\): distancia (m).

## 4) Formulacion matematica y lectura fisica
### Intensidad sonora
$$
I=\frac{P}{A}
$$
Lectura fisica: Expresa como se transporta energia en el tiempo o en el espacio.

### Nivel sonoro
$$
\beta=10\log_{10}\left(\frac{I}{I_0}\right)
$$
Lectura fisica: Relaciona el corrimiento Doppler con movimiento relativo mediante una correccion relativista.

### Fuente puntual
$$
I=\frac{P}{4\pi r^2}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- acustica arquitectonica.
- audio y electroacustica.
- higiene sonora.
- diagnostico de ruido.

## 10) Sintesis final
Dominar **Intensidad Y Nivel Sonoro** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
