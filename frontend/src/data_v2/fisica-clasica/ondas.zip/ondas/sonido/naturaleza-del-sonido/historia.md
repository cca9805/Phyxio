# Naturaleza Del Sonido - Historia Util

## Idea clave
La historia aqui se usa para entender por que el modelo actual funciona y cuando se adopto.

## Hitos relevantes
- Mersenne y Galileo midieron leyes basicas del sonido.
- Helmholtz conecto fisica con percepcion y timbre.
- Doppler introdujo el corrimiento por movimiento relativo.

## Que aporta al estudiante
- Contexto para no aprender formulas como listas aisladas.
- Criterio para distinguir modelo teorico de aproximacion practica.
- Vision de como la teoria se valida con medicion experimental.

## Cierre
Conocer estos hitos ayuda a interpretar mejor el alcance real del tema.
