# Tono Y Timbre

## Idea clave
Tono y timbre distinguen frecuencia fundamental y contenido armonico.

## 1) Que fenomeno explica este tema y por que importa
Este tema explica por que dos fuentes con igual nota pueden sonar distintas.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(f_n\): armonico n (Hz).
- \(n\): numero armonico (1).
- \(f_1\): fundamental (Hz).
- \(v\): velocidad sonido (m/s).
- \(L\): longitud columna (m).

## 4) Formulacion matematica y lectura fisica
### Serie armonica
$$
f_n=nf_1
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Frecuencia fundamental
$$
f_1=\frac{v}{2L}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Envolvente temporal
$$
A(t)=A_0e^{-\alpha t}
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.
Nota: expresion conceptual (Depende de la fuente y su mecanismo fisico de emision.).

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- acustica arquitectonica.
- audio y electroacustica.
- higiene sonora.
- diagnostico de ruido.

## 10) Sintesis final
Dominar **Tono Y Timbre** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
