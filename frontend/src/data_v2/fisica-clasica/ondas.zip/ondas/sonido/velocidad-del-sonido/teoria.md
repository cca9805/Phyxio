# Velocidad Del Sonido

## Idea clave
La velocidad del sonido depende de propiedades del medio y su estado.

## 1) Que fenomeno explica este tema y por que importa
Este tema conecta modelo fisico con valores realistas en aire, agua y solidos.
Entender este punto evita resolver por memoria y te permite elegir el modelo correcto.

## 2) Base conceptual del tema
- Distingue oscilacion local del medio y propagacion de la perturbacion.
- Separa magnitudes espaciales (como lambda) de magnitudes temporales (como f y T).
- Define siempre el contexto fisico: medio, frontera y condicion de validez.

## 3) Magnitudes y parametros esenciales
- \(v\): velocidad sonido (m/s).
- \(\lambda\): longitud onda (m).
- \(f\): frecuencia (Hz).
- \(T_c\): temperatura celsius (degC).
- \(\gamma\): coeficiente adiabatico (1).
- \(R\): constante gases (J/(mol*K)).
- \(M\): masa molar (kg/mol).

## 4) Formulacion matematica y lectura fisica
### Velocidad del sonido
$$
v=\lambda f
$$
Lectura fisica: Relaciona escala espacial y temporal de la onda.

### Aproximacion en aire
$$
v\approx331+0.6T_c
$$
Lectura fisica: Relacion principal del tema; debe leerse junto a su dominio de validez.

### Modelo de gas ideal
$$
v=\sqrt{\frac{\gamma RT}{M}}
$$
Lectura fisica: Muestra equilibrio entre rigidez efectiva e inercia del medio.

## 5) Modelo y condiciones de validez
El modelo basico del tema funciona cuando las hipotesis del problema (linealidad, medio y frontera) son coherentes.
Si el enunciado cambia de regimen, revisa primero el modelo antes de aceptar el resultado numerico.

## 6) Metodo general de resolucion
1. Pasa todos los datos a SI y define la incognita real.
2. Selecciona la ecuacion minima necesaria para resolver.
3. Despeja simbolicamente y despues sustituye.
4. Verifica unidades y orden de magnitud.
5. Interpreta el numero final en lenguaje fisico.

## 7) Errores frecuentes
- Mezclar formulas de temas distintos sin comprobar validez.
- Confundir magnitudes (por ejemplo, amplitud con longitud de onda).
- Operar con unidades no SI sin convertir.
- Dar por bueno un numero sin interpretacion fisica.

## 8) Ejemplo guiado
Problema orientativo: identifica incognita, elige la relacion principal y despeja antes de sustituir.
Comprueba unidades SI y orden de magnitud del resultado.

## 9) Aplicaciones reales
- acustica arquitectonica.
- audio y electroacustica.
- higiene sonora.
- diagnostico de ruido.

## 10) Sintesis final
Dominar **Velocidad Del Sonido** significa identificar el fenomeno, elegir el modelo correcto y justificar el resultado final.
