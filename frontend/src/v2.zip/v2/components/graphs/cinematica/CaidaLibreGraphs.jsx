import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { pickParam } from "../../../utils/pickParamGraphs";
import { sampleCaidaLibre } from "../../../engine/models/cinematica/caidaLibre";


/* Helpers */
function toNum(v, fallback = NaN) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function NumInput({ label, value, onChange, step = 0.1, min, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="form-control"
        type="number"
        step={step}
        min={min}
        disabled={disabled}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

export default function CaidaLibreGraphs({ params }) {
  const [linked, setLinked] = useState(true);

  const x0 = pickParam(params, ["x0"], 0);
  const v  = pickParam(params, ["v"], 2);
  const t  = pickParam(params, ["t", "tMax"], 10); // si en graphs usas tMax

  const [p, setP] = useState(() => ({
    y0: 10,
    v0: 0,
    g: 9.8,
    tMax: 3,
    tObs: 0,
  }));

  useEffect(() => {
    if (!linked) return;
    setP((prev) => ({
      ...prev,
      y0: toNum(params?.y0, 10),
      v0: toNum(params?.v0, 0),
      g: toNum(params?.g, 9.8),
      tMax: toNum(params?.tMax, 3),
      tObs: 0,
    }));
  }, [linked, params?.y0, params?.v0, params?.g, params?.tMax]);

  const patch = (k, val) => setP((prev) => ({ ...prev, [k]: val }));

  const y0 = toNum(p.y0, 10);
  const v0 = toNum(p.v0, 0);
  const g = toNum(p.g, 9.8);
  const tMax = Math.max(0, toNum(p.tMax, 3));

  const sampled = useMemo(
    () => sampleCaidaLibre({ y0, v0, g, tMax, n: 280, groundY: 0 }),
    [y0, v0, g, tMax]
  );
  const data = sampled?.data || [];
  const tImpact = sampled?.tImpact;
  const tEnd = sampled?.tEnd ?? tMax;

  const tObs = useMemo(() => {
    const raw = toNum(p.tObs, 0);
    if (!Number.isFinite(raw)) return 0;
    return clamp(raw, 0, Math.max(0, tEnd));
  }, [p.tObs, tEnd]);

  const yObs = y0 + v0 * tObs - 0.5 * g * tObs * tObs;
  const vObs = v0 - g * tObs;
  const aObs = -g;

  const reachesGround =
    Number.isFinite(tImpact) && tMax >= tImpact && y0 >= 0 && g > 0;

  useEffect(() => {
    const raw = toNum(p.tObs, 0);
    if (!Number.isFinite(raw)) patch("tObs", 0);
    else if (raw < 0) patch("tObs", 0);
    else if (raw > tEnd) patch("tObs", tEnd);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tEnd]);

  return (
    <div>
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (Caída libre)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Modo experimento (solo gráficas)
          </button>

          {!linked && (
            <button
              type="button"
              className="btn btn-sm btn-light"
              onClick={() =>
                setP({
                  y0: toNum(params?.y0, 10),
                  v0: toNum(params?.v0, 0),
                  g: toNum(params?.g, 9.8),
                  tMax: toNum(params?.tMax, 3),
                  tObs: 0,
                })
              }
            >
              ↩️ Cargar desde calculadora
            </button>
          )}
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput label="y0 (m)" value={p.y0 ?? ""} onChange={(v) => patch("y0", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="v0 (m/s)" value={p.v0 ?? ""} onChange={(v) => patch("v0", v)} step={0.5} disabled={linked} />
          <NumInput label="g (m/s²)" value={p.g ?? ""} onChange={(v) => patch("g", v)} step={0.1} min={0} disabled={linked} />
          <NumInput label="t máximo (s)" value={p.tMax ?? ""} onChange={(v) => patch("tMax", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="t observación (s)" value={String(tObs)} onChange={(v) => patch("tObs", v)} step={0.1} min={0} disabled={false} />
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 12 }}>
          <div className="v2-card">
            <div className="v2-card-title">En t = {fmt(tObs, 4)} s</div>
            <div><strong>y</strong> = {fmt(yObs, 4)} m</div>
            <div><strong>v</strong> = {fmt(vObs, 4)} m/s</div>
            <div><strong>a</strong> = {fmt(aObs, 4)} m/s²</div>
          </div>

          <div className="v2-card">
            <div className="v2-card-title">Impacto (si llega al suelo)</div>
            {reachesGround ? (
              <div><strong>t₍impacto₎</strong> = {fmt(tImpact, 4)} s</div>
            ) : (
              <div className="muted">No llega al suelo dentro de t máximo.</div>
            )}
            <div className="muted" style={{ marginTop: 8 }}>
              Nota: t máximo controla el dibujo. El impacto se calcula con y(t)=0.
            </div>
          </div>
        </div>
      </div>

      {/* y(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">y(t) — posición vertical</div>
        <div style={{ width: "100%", minHeight: 320 }}>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={data}>
              <ReferenceLine y={0} strokeDasharray="3 3" />
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(label) => fmt(label, 4)}
              />
              <Legend />
              <Line dataKey="y" name="y(t)" />
              <ReferenceDot x={tObs} y={yObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* v(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">v(t) — velocidad</div>
        <div style={{ width: "100%", height: 260 }}>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(label) => fmt(label, 4)}
              />
              <Legend />
              <Area dataKey="v" name="v(t)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* a(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">a(t) — aceleración</div>
        <div style={{ width: "100%", minHeight: 220 }}>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(label) => fmt(label, 4)}
              />
              <Legend />
              <Line dataKey="a" name="a(t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
