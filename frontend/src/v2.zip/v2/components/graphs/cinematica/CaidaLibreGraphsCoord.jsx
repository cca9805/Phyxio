import React, { useMemo } from "react";
import { useExperimentParams } from "@/v2/components/graphs_shared/experiment/useExperimentParams";
import ExperimentPanel from "@/v2/components/graphs_shared/experiment/ExperimentPanel";

function fmt(n, d = 2) {
  return Number.isFinite(n) ? n.toFixed(d) : "";
}

function niceDomain(values) {
  if (!values.length) return { min: 0, max: 1 };
  let min = Math.min(...values);
  let max = Math.max(...values);
  if (!Number.isFinite(min) || !Number.isFinite(max)) return { min: 0, max: 1 };
  if (min === max) {
    const d = Math.abs(min) || 1;
    min -= d;
    max += d;
  }
  const pad = (max - min) * 0.12;
  return { min: min - pad, max: max + pad };
}

function Plot({ label, points, marks, xLabel = "t (s)", yLabel = "", height = 240 }) {
  const W = 560;
  const H = height;

  const padL = 54;
  const padR = 14;
  const padT = 18;
  const padB = 34;

  const plotW = W - padL - padR;
  const plotH = H - padT - padB;

  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  const xd = niceDomain(xs);
  const yd = niceDomain(ys);

  const sx = (x) => padL + ((x - xd.min) / (xd.max - xd.min)) * plotW;
  const sy = (y) => padT + (1 - (y - yd.min) / (yd.max - yd.min)) * plotH;

  const x0 = sx(0);
  const y0 = sy(0);

  const ticks = 5;
  const xTicks = Array.from({ length: ticks + 1 }, (_, i) => xd.min + (i / ticks) * (xd.max - xd.min));
  const yTicks = Array.from({ length: ticks + 1 }, (_, i) => yd.min + (i / ticks) * (yd.max - yd.min));

  const d = points
    .map((p, i) => `${i === 0 ? "M" : "L"} ${sx(p.x).toFixed(2)} ${sy(p.y).toFixed(2)}`)
    .join(" ");

  return (
    <div className="rounded-2xl border p-3 text-slate-900 dark:text-slate-100">
      <div className="text-sm font-semibold">{label}</div>

      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto mt-2">
        {/* grid */}
        {xTicks.map((t, i) => {
          const x = sx(t);
          return (
            <g key={`xt-${i}`} opacity="0.16">
              <line x1={x} y1={padT} x2={x} y2={padT + plotH} stroke="currentColor" />
              <text x={x} y={padT + plotH + 16} fontSize="10" textAnchor="middle" fill="currentColor">
                {fmt(t, 2)}
              </text>
            </g>
          );
        })}
        {yTicks.map((t, i) => {
          const y = sy(t);
          return (
            <g key={`yt-${i}`} opacity="0.16">
              <line x1={padL} y1={y} x2={padL + plotW} y2={y} stroke="currentColor" />
              <text x={padL - 6} y={y + 3} fontSize="10" textAnchor="end" fill="currentColor">
                {fmt(t, 2)}
              </text>
            </g>
          );
        })}

        {/* axes */}
        <g opacity="0.45">
          <line x1={padL} y1={y0} x2={padL + plotW} y2={y0} stroke="currentColor" />
          <line x1={x0} y1={padT} x2={x0} y2={padT + plotH} stroke="currentColor" />
        </g>

        {/* labels */}
        <text x={padL + plotW} y={padT + plotH + 28} fontSize="11" textAnchor="end" fill="currentColor" opacity="0.85">
          {xLabel}
        </text>
        <text x={padL} y={padT - 4} fontSize="11" textAnchor="start" fill="currentColor" opacity="0.85">
          {yLabel}
        </text>

        {/* curve */}
        <path d={d} fill="none" stroke="currentColor" strokeWidth="2.2" />

        {/* marks at integer seconds */}
        {marks?.map((m) => (
          <g key={`m-${m.x}`} opacity="0.95">
            <circle cx={sx(m.x)} cy={sy(m.y)} r="3.2" fill="currentColor" />
            <text x={sx(m.x) + 6} y={sy(m.y) - 6} fontSize="10" fill="currentColor" opacity="0.75">
              {m.label}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

export default function CaidaLibreGraphsCoord({ title, params, onSharedParamsChange }) {
  // Inputs de experimento (y0/v0/g y opcionalmente ventana)
  const schema = [
    { key: "y0", label: "Altura inicial (y0)", unit: "m", step: 0.1, default: 15, aliases: ["h", "h0"] },
    { key: "v0", label: "Velocidad inicial (v0)", unit: "m/s", step: 0.1, default: 0, aliases: ["vy0"] },
    { key: "g", label: "Gravedad (g)", unit: "m/s²", step: 0.01, default: 9.81 },
    { key: "tMax", label: "Ventana (opcional)", unit: "s", step: 0.1, default: 0, aliases: ["tmax"] },
  ];

  const exp = useExperimentParams({ params, schema });

  // Blindaje a null/NaN
  const y0 = Number.isFinite(exp.effectiveParams?.y0) ? exp.effectiveParams.y0 : 15;
  const v0 = Number.isFinite(exp.effectiveParams?.v0) ? exp.effectiveParams.v0 : 0;
  const g = Number.isFinite(exp.effectiveParams?.g) ? exp.effectiveParams.g : 9.81;
  const tMaxUser = Number.isFinite(exp.effectiveParams?.tMax) ? exp.effectiveParams.tMax : 0;

  // Tiempo de impacto con suelo y=0 (raíz física)
  const tImpacto = useMemo(() => {
    if (!(g > 0)) return 0;
    // t = (v0 + sqrt(v0^2 + 2 g y0))/g
    const disc = v0 * v0 + 2 * g * Math.max(0, y0);
    const t = (v0 + Math.sqrt(Math.max(0, disc))) / g;
    return Number.isFinite(t) ? Math.max(0, t) : 0;
  }, [y0, v0, g]);

  const { ptsY, ptsV, marksY, marksV, table, T } = useMemo(() => {
    const Treal = tImpacto > 0 ? tImpacto : 6;
    const Twindow = tMaxUser > 0 ? Math.min(tMaxUser, Treal) : Treal; // si usuario pone ventana, la respeta
    const Tfinal = Math.max(0.5, Math.min(30, Twindow));

    const N = 160;
    const ptsY = [];
    const ptsV = [];
    for (let i = 0; i <= N; i++) {
      const t = (i / N) * Tfinal;
      const y = y0 + v0 * t - 0.5 * g * t * t;
      const v = v0 - g * t;
      // modo real: clamp al suelo
      const yClamped = Math.max(0, y);
      ptsY.push({ x: t, y: yClamped });
      ptsV.push({ x: t, y: v });
    }

    const marksY = [];
    const marksV = [];
    const table = [];
    const maxSec = Math.floor(Tfinal + 1e-9);

    for (let s = 0; s <= maxSec; s++) {
      const t = s;
      const y = Math.max(0, y0 + v0 * t - 0.5 * g * t * t);
      const v = v0 - g * t;
      marksY.push({ x: t, y, label: `${s}s` });
      marksV.push({ x: t, y: v, label: `${s}s` });
      table.push({ t, y, v });
    }

    // Añadir marca de impacto exacta si cae dentro de ventana
    if (tImpacto > 0 && tImpacto <= Tfinal + 1e-6) {
      marksY.push({ x: tImpacto, y: 0, label: "impacto" });
      marksV.push({ x: tImpacto, y: v0 - g * tImpacto, label: "impacto" });
    }

    return { ptsY, ptsV, marksY, marksV, table, T: Tfinal };
  }, [y0, v0, g, tImpacto, tMaxUser]);

  return (
    <div className="space-y-3">
      <ExperimentPanel
        schema={schema}
        mode={exp.mode}
        startExperiment={exp.startExperiment}
        resetToCalculator={exp.resetToCalculator}
        values={exp.effectiveParams}
        setValue={exp.setValue}
        onApplyToCalculator={
          onSharedParamsChange
            ? (vals) =>
                onSharedParamsChange({
                  y0: vals.y0,
                  v0: vals.v0,
                  g: vals.g,
                  tMax: vals.tMax,
                  // y=0 implícito (suelo)
                })
            : null
        }
      />

      <div className="rounded-2xl border p-4">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div>
            <div className="font-semibold">{title || "Caída libre"}</div>
            <div className="text-sm opacity-70 mt-1">
              Suelo: <span className="font-mono">y=0</span> ·
              &nbsp; t<sub>impacto</sub> ≈ <span className="font-mono">{fmt(tImpacto, 3)} s</span>
            </div>
          </div>

          <div className="text-xs opacity-70">
            Eje +y hacia arriba · a = −g
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 mt-4">
          <Plot label="Altura y(t)" points={ptsY} marks={marksY} yLabel="y (m)" />
          <Plot label="Velocidad v(t)" points={ptsV} marks={marksV} yLabel="v (m/s)" />
        </div>

        <div className="mt-4 rounded-xl bg-black/5 p-3 text-xs opacity-80">
          <div className="font-semibold mb-2">Lectura por segundo</div>
          <div className="overflow-auto">
            <table className="min-w-[420px] w-full text-left border-separate" style={{ borderSpacing: "0 6px" }}>
              <thead className="opacity-80">
                <tr>
                  <th className="px-2">t (s)</th>
                  <th className="px-2">y (m)</th>
                  <th className="px-2">v (m/s)</th>
                </tr>
              </thead>
              <tbody>
                {table.map((r) => (
                  <tr key={`row-${r.t}`} className="bg-white/40 dark:bg-black/20">
                    <td className="px-2 py-1 rounded-l-lg font-mono">{fmt(r.t, 0)}</td>
                    <td className="px-2 py-1 font-mono">{fmt(r.y, 2)}</td>
                    <td className="px-2 py-1 rounded-r-lg font-mono">{fmt(r.v, 2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-2 opacity-70">
            Nota: y(t) se corta en 0 al impactar (modo real).
          </div>
        </div>
      </div>
    </div>
  );
}
