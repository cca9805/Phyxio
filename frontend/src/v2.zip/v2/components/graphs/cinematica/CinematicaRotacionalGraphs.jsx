import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

import {
  sampleUniformOmega,
  sampleUniformAlpha,
} from "/src/v2/engine/models/cinematica/cinematica-rotacional.js";

function toNum(v, fallback = NaN) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function radToDeg(x) {
  return (Number(x) * 180) / Math.PI;
}

function degToRad(x) {
  return (Number(x) * Math.PI) / 180;
}

function NumInput({ label, value, onChange, step = 0.1, min, max }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="v2-input"
        type="text"
        inputMode="decimal"
        step={step}
        min={min}
        max={max}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

function Toggle({ label, value, options, onChange }) {
  return (
    <div className="v2-card" style={{ display: "grid", gap: 8 }}>
      <div className="v2-card-title">{label}</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {options.map((opt) => {
          const active = value === opt.value;
          return (
            <button
              key={opt.value}
              className={`v2-btn ${active ? "v2-btn-primary" : "v2-btn-ghost"}`}
              type="button"
              onClick={() => onChange?.(opt.value)}
            >
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function CinematicaRotacionalGraphs({ params }) {
  // Soporta params compartidos desde calculadora si existen:
  const theta0p = toNum(params?.theta0 ?? params?.theta ?? params?.th0, 0); // rad
  const omega0p = toNum(params?.omega0 ?? params?.omega ?? params?.w0, 2); // rad/s
  const alphap  = toNum(params?.alpha ?? params?.aAng ?? params?.a, 0.5);  // rad/s^2
  const tMax0p  = toNum(params?.tMax ?? params?.t, 10);

  const [angUnit, setAngUnit] = useState("deg"); // visualización: "deg" | "rad"

  // Estado interno SI (rad, rad/s, rad/s^2, s)
  const [theta0, setTheta0] = useState(Number.isFinite(theta0p) ? theta0p : 0);
  const [omega, setOmega]   = useState(Number.isFinite(omega0p) ? omega0p : 2);

  const [omega0, setOmega0] = useState(Number.isFinite(omega0p) ? omega0p : 2);
  const [alpha, setAlpha]   = useState(Number.isFinite(alphap) ? alphap : 0.5);

  const [tMax, setTMax] = useState(Number.isFinite(tMax0p) ? tMax0p : 10);
  const [n, setN] = useState(240);

  useEffect(() => {
    if (Number.isFinite(theta0p)) setTheta0(theta0p);
    if (Number.isFinite(omega0p)) {
      setOmega(omega0p);
      setOmega0(omega0p);
    }
    if (Number.isFinite(alphap)) setAlpha(alphap);
    if (Number.isFinite(tMax0p)) setTMax(tMax0p);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [theta0p, omega0p, alphap, tMax0p]);

  const dataUniformOmega = useMemo(() => {
    const Tmax = clamp(toNum(tMax, 10), 0.1, 1e6);
    const count = clamp(Math.round(toNum(n, 240)), 50, 2000);
    return sampleUniformOmega({ theta0, omega, tMin: 0, tMax: Tmax, n: count });
  }, [theta0, omega, tMax, n]);

  const dataUniformAlpha = useMemo(() => {
    const Tmax = clamp(toNum(tMax, 10), 0.1, 1e6);
    const count = clamp(Math.round(toNum(n, 240)), 50, 2000);
    return sampleUniformAlpha({ theta0, omega0, alpha, tMin: 0, tMax: Tmax, n: count });
  }, [theta0, omega0, alpha, tMax, n]);

  const thetaLabel = angUnit === "deg" ? "θ (°)" : "θ (rad)";
  const thetaKey = angUnit === "deg" ? "thetaDeg" : "theta";

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Giro con ω constante</div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12, marginTop: 10 }}>
          <Toggle
            label="Unidad de ángulo (visualización)"
            value={angUnit}
            options={[
              { value: "deg", label: "Grados (°)" },
              { value: "rad", label: "Radianes (rad)" },
            ]}
            onChange={setAngUnit}
          />

          <NumInput
            label={`θ₀ (${angUnit === "deg" ? "°" : "rad"})`}
            value={angUnit === "deg" ? radToDeg(theta0) : theta0}
            step={angUnit === "deg" ? 1 : 0.1}
            onChange={(v) => {
              const x = toNum(v, angUnit === "deg" ? radToDeg(theta0) : theta0);
              const th = angUnit === "deg" ? degToRad(x) : x;
              if (Number.isFinite(th)) setTheta0(th);
            }}
          />

          <NumInput label="ω (rad/s)" value={omega} step={0.1} onChange={(v) => setOmega(toNum(v, omega))} />
          <NumInput label="t máx (s)" value={tMax} step={0.5} min={0.1} onChange={(v) => setTMax(toNum(v, tMax))} />
          <NumInput
            label="Puntos (n)"
            value={n}
            step={10}
            min={50}
            max={2000}
            onChange={(v) => setN(clamp(Math.round(toNum(v, n)), 50, 2000))}
          />
        </div>

        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={dataUniformOmega} margin={{ left: 10, right: 20, top: 10, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="t" type="number" domain={["auto", "auto"]}
                     tickFormatter={(v) => String(v).replace(".", ",")}
                     label={{ value: "t (s)", position: "insideBottom", offset: -5 }} />
              <YAxis label={{ value: thetaLabel, angle: -90, position: "insideLeft" }}
                     tickFormatter={(v) => String(v).replace(".", ",")} />
              <Tooltip
                formatter={(value, name) => [String(value).replace(".", ","), name]}
                labelFormatter={(v) => `t = ${String(v).replace(".", ",")} s`}
              />
              <Legend />
              <Line type="monotone" dataKey={thetaKey} dot={false} name="θ" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 6 }}>
          Internamente se calcula en radianes. La vista en grados es solo conversión.
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Giro con α constante</div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12, marginTop: 10 }}>
          <NumInput label="ω₀ (rad/s)" value={omega0} step={0.1} onChange={(v) => setOmega0(toNum(v, omega0))} />
          <NumInput label="α (rad/s²)" value={alpha} step={0.1} onChange={(v) => setAlpha(toNum(v, alpha))} />
          <NumInput label="t máx (s)" value={tMax} step={0.5} min={0.1} onChange={(v) => setTMax(toNum(v, tMax))} />
        </div>

        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={dataUniformAlpha} margin={{ left: 10, right: 20, top: 10, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="t" type="number" domain={["auto", "auto"]}
                     tickFormatter={(v) => String(v).replace(".", ",")}
                     label={{ value: "t (s)", position: "insideBottom", offset: -5 }} />
              <YAxis yAxisId="left" label={{ value: "ω (rad/s)", angle: -90, position: "insideLeft" }}
                     tickFormatter={(v) => String(v).replace(".", ",")} />
              <YAxis yAxisId="right" orientation="right"
                     label={{ value: thetaLabel, angle: -90, position: "insideRight" }}
                     tickFormatter={(v) => String(v).replace(".", ",")} />

              <Tooltip
                formatter={(value, name) => [String(value).replace(".", ","), name]}
                labelFormatter={(v) => `t = ${String(v).replace(".", ",")} s`}
              />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="omega" dot={false} name="ω" />
              <Line yAxisId="right" type="monotone" dataKey={thetaKey} dot={false} name="θ" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 6 }}>
          ω(t) = ω₀ + α·t,  θ(t) = θ₀ + ω₀·t + ½·α·t²
        </div>
      </div>
    </div>
  );
}
