import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { pickParam } from "../../../utils/pickParamGraphs";
import { sampleEncuentroMRU } from "../../../engine/models/cinematica/encuentros";


function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function NumInput({ label, value, onChange, step = 0.1, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input className="form-control" type="number" step={step} disabled={disabled}
        value={value ?? ""} onChange={(e) => onChange?.(e.target.value)} />
    </div>
  );
}

export default function EncuentrosGraphs({ params }) {
  const [linked, setLinked] = useState(true);
  const x0 = pickParam(params, ["x0"], 0);
  const v  = pickParam(params, ["v"], 2);
  const t  = pickParam(params, ["t", "tMax"], 10); // si en graphs usas tMax
  const [p, setP] = useState(() => ({ xA0: 0, xB0: -30, vA: 6, vB: 10, dt: 0, tMax: 20, tObs: 0 }));

  useEffect(() => {
    if (!linked) return;
    setP((prev) => ({
      ...prev,
      xA0: toNum(params?.xA0, prev.xA0),
      xB0: toNum(params?.xB0, prev.xB0),
      vA: toNum(params?.vA, prev.vA),
      vB: toNum(params?.vB, prev.vB),
      dt: Math.max(0, toNum(params?.dt, prev.dt)),
      tMax: Math.max(0, toNum(params?.tMax, prev.tMax)),
      tObs: 0,
    }));
  }, [linked, params?.xA0, params?.xB0, params?.vA, params?.vB, params?.dt, params?.tMax]);

  const patch = (k, v) => setP((prev) => ({ ...prev, [k]: v }));

  const xA0 = toNum(p.xA0, 0);
  const xB0 = toNum(p.xB0, 0);
  const vA = toNum(p.vA, 0);
  const vB = toNum(p.vB, 0);
  const dt = Math.max(0, toNum(p.dt, 0));
  const tMax = Math.max(0, toNum(p.tMax, 20));
  const tObs = Math.max(0, Math.min(tMax, toNum(p.tObs, 0)));

  const { data, tMeet, xMeet } = useMemo(
    () => sampleEncuentroMRU({ xA0, xB0, vA, vB, dt, tMax, n: 320 }),
    [xA0, xB0, vA, vB, dt, tMax]
  );

  const xAObs = xA0 + vA * tObs;
  const xBObs = tObs >= dt ? (xB0 + vB * (tObs - dt)) : xB0;

  return (
    <div>
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (Encuentros MRU)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button type="button" className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`} onClick={() => setLinked(true)}>
            🔗 Seguir calculadora
          </button>
          <button type="button" className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`} onClick={() => setLinked(false)}>
            🧪 Modo experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput label="xA0 (m)" value={p.xA0} onChange={(v) => patch("xA0", v)} step={1} disabled={linked} />
          <NumInput label="xB0 (m)" value={p.xB0} onChange={(v) => patch("xB0", v)} step={1} disabled={linked} />
          <NumInput label="vA (m/s)" value={p.vA} onChange={(v) => patch("vA", v)} step={0.5} disabled={linked} />
          <NumInput label="vB (m/s)" value={p.vB} onChange={(v) => patch("vB", v)} step={0.5} disabled={linked} />
          <NumInput label="Δt (s)" value={p.dt} onChange={(v) => patch("dt", v)} step={0.5} disabled={linked} />
          <NumInput label="t máximo (s)" value={p.tMax} onChange={(v) => patch("tMax", v)} step={1} disabled={linked} />
          <NumInput label="t observación (s)" value={String(tObs)} onChange={(v) => patch("tObs", v)} step={0.1} disabled={false} />
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 12 }}>
          <div className="v2-card">
            <div className="v2-card-title">En t = {fmt(tObs, 4)} s</div>
            <div><strong>xA</strong> = {fmt(xAObs, 4)} m</div>
            <div><strong>xB</strong> = {fmt(xBObs, 4)} m</div>
            <div><strong>Δx</strong> = {fmt(xAObs - xBObs, 4)} m</div>
          </div>
          <div className="v2-card">
            <div className="v2-card-title">Encuentro</div>
            {Number.isFinite(tMeet) ? (
              <>
                <div><strong>t*</strong> = {fmt(tMeet, 4)} s</div>
                <div><strong>x*</strong> = {fmt(xMeet, 4)} m</div>
                <div className="muted" style={{ marginTop: 8 }}>Si t* &lt; Δt, B aún no había salido.</div>
              </>
            ) : (
              <div className="muted">No hay encuentro en el intervalo mostrado.</div>
            )}
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">xA(t) y xB(t)</div>
        <div style={{ width: "100%", minHeight: 320 }}>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(v, n) => [fmt(v, 4), n]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="xA" name="xA(t)" />
              <Line dataKey="xB" name="xB(t)" />
              {Number.isFinite(tMeet) ? <ReferenceDot x={tMeet} y={xMeet} r={4} label="encuentro" /> : null}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
