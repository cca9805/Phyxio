import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { sampleMRUA } from "../../../engine/models/cinematica/mrua";

/* Helpers */
function toNum(v, fallback = NaN) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function NumInput({ label, value, onChange, step = 0.1, min, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="form-control"
        type="number"
        step={step}
        min={min}
        disabled={disabled}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

export default function MRUAGraphs({ params }) {
  const [linked, setLinked] = useState(true);

  const [p, setP] = useState(() => ({
    x0: 0,
    v0: 2,
    a: 1,
    tMax: 10,
    tObs: 0,
  }));

  useEffect(() => {
    if (!linked) return;
    setP((prev) => ({
      ...prev,
      x0: toNum(params?.x0, 0),
      v0: toNum(params?.v0, 2),
      a: toNum(params?.a, 1),
      tMax: toNum(params?.tMax, 10),
      tObs: 0,
    }));
  }, [linked, params?.x0, params?.v0, params?.a, params?.tMax]);

  const patch = (k, val) => setP((prev) => ({ ...prev, [k]: val }));

  const x0 = toNum(p.x0, 0);
  const v0 = toNum(p.v0, 2);
  const a = toNum(p.a, 1);
  const tMax = Math.max(0, toNum(p.tMax, 10));

  const data = useMemo(
    () => sampleMRUA({ x0, v0, a, tMax, n: 280 }) || [],
    [x0, v0, a, tMax]
  );

  const tObs = useMemo(() => {
    const raw = toNum(p.tObs, 0);
    if (!Number.isFinite(raw)) return 0;
    return clamp(raw, 0, tMax);
  }, [p.tObs, tMax]);

  // Derivadas en tObs
  const xObs = x0 + v0 * tObs + 0.5 * a * tObs * tObs;
  const vObs = v0 + a * tObs;

  // Derivadas en tMax
  const xFinal = x0 + v0 * tMax + 0.5 * a * tMax * tMax;
  const vFinal = v0 + a * tMax;

  useEffect(() => {
    const raw = toNum(p.tObs, 0);
    if (!Number.isFinite(raw)) patch("tObs", 0);
    else if (raw < 0) patch("tObs", 0);
    else if (raw > tMax) patch("tObs", tMax);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tMax]);

  return (
    <div>
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (MRUA)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Modo experimento (solo gráficas)
          </button>
          {!linked && (
            <button
              type="button"
              className="btn btn-sm btn-light"
              onClick={() =>
                setP({
                  x0: toNum(params?.x0, 0),
                  v0: toNum(params?.v0, 2),
                  a: toNum(params?.a, 1),
                  tMax: toNum(params?.tMax, 10),
                  tObs: 0,
                })
              }
            >
              ↩️ Cargar desde calculadora
            </button>
          )}
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput label="x0 (m)" value={p.x0 ?? ""} onChange={(v) => patch("x0", v)} step={0.5} disabled={linked} />
          <NumInput label="v0 (m/s)" value={p.v0 ?? ""} onChange={(v) => patch("v0", v)} step={0.5} disabled={linked} />
          <NumInput label="a (m/s²)" value={p.a ?? ""} onChange={(v) => patch("a", v)} step={0.2} disabled={linked} />
          <NumInput label="t máximo (s)" value={p.tMax ?? ""} onChange={(v) => patch("tMax", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="t observación (s)" value={String(tObs)} onChange={(v) => patch("tObs", v)} step={0.1} min={0} disabled={false} />
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 12 }}>
          <div className="v2-card">
            <div className="v2-card-title">En t = {fmt(tObs, 4)} s</div>
            <div><strong>x</strong> = {fmt(xObs, 4)} m</div>
            <div><strong>v</strong> = {fmt(vObs, 4)} m/s</div>
            <div><strong>a</strong> = {fmt(a, 4)} m/s²</div>
          </div>

          <div className="v2-card">
            <div className="v2-card-title">En t máximo</div>
            <div><strong>x(tMax)</strong> = {fmt(xFinal, 4)} m</div>
            <div><strong>v(tMax)</strong> = {fmt(vFinal, 4)} m/s</div>
          </div>
        </div>
      </div>

      {/* x(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">x(t) — posición</div>
        <div style={{ width: "100%", minHeight: 320 }}>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={data}>
              <ReferenceDot x={0} y={x0} r={4} label="(0, x₀)" />
              <ReferenceDot x={tMax} y={xFinal} r={4} label="(tMax, x)" />
              <ReferenceDot x={tObs} y={xObs} r={4} label="t obs" />
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(label) => fmt(label, 4)}
              />
              <Legend />
              <Line dataKey="x" name="x(t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* v(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">v(t) — velocidad</div>
        <div style={{ width: "100%", minHeight: 260 }}>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(label) => fmt(label, 4)}
              />
              <Legend />
              <Area dataKey="v" name="v(t)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* a(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">a(t) — aceleración</div>
        <div style={{ width: "100%", minHeight: 220 }}>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(label) => fmt(label, 4)}
              />
              <Legend />
              <Line dataKey="a" name="a(t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
