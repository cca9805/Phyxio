import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

// ✅ Misma idea que tensión: import estable desde /src/...
import {
  sampleUniformOmega,
  sampleUniformAlpha,
} from "/src/v2/engine/models/cinematica/magnitudes-angulares.js";

function toNum(v, fallback = NaN) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function radToDeg(x) {
  return (Number(x) * 180) / Math.PI;
}

function degToRad(x) {
  return (Number(x) * Math.PI) / 180;
}

function NumInput({ label, value, onChange, step = 0.1, min, max }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="v2-input"
        type="text"
        inputMode="decimal"
        step={step}
        min={min}
        max={max}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

function Toggle({ label, value, options, onChange }) {
  return (
    <div className="v2-card" style={{ display: "grid", gap: 8 }}>
      <div className="v2-card-title">{label}</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {options.map((opt) => {
          const active = value === opt.value;
          return (
            <button
              key={opt.value}
              className={`v2-btn ${active ? "v2-btn-primary" : "v2-btn-ghost"}`}
              type="button"
              onClick={() => onChange?.(opt.value)}
            >
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function MagnitudesAngularesGraphs({ params }) {
  // Params iniciales (si la calculadora comparte)
  const omega0p = toNum(params?.omega ?? params?.w, 2); // rad/s
  const alpha0p = toNum(params?.alpha ?? params?.aAng, 0.5); // rad/s^2
  const theta0p = toNum(params?.theta ?? params?.th, 0); // rad
  const tMax0p = toNum(params?.tMax ?? params?.t, 10);

  // UI: mostrar ángulos en grados o radianes
  const [angUnit, setAngUnit] = useState("deg"); // "deg" | "rad"

  // Estado (mantenemos internamente en rad / rad/s / rad/s² / s)
  const [theta0, setTheta0] = useState(Number.isFinite(theta0p) ? theta0p : 0);
  const [omega, setOmega] = useState(Number.isFinite(omega0p) ? omega0p : 2);

  const [omega0, setOmega0] = useState(Number.isFinite(omega0p) ? omega0p : 2);
  const [alpha, setAlpha] = useState(Number.isFinite(alpha0p) ? alpha0p : 0.5);

  const [tMax, setTMax] = useState(Number.isFinite(tMax0p) ? tMax0p : 10);
  const [n, setN] = useState(240);

  // Re-sincroniza cuando cambian params
  useEffect(() => {
    if (Number.isFinite(theta0p)) setTheta0(theta0p);
    if (Number.isFinite(omega0p)) {
      setOmega(omega0p);
      setOmega0(omega0p);
    }
    if (Number.isFinite(alpha0p)) setAlpha(alpha0p);
    if (Number.isFinite(tMax0p)) setTMax(tMax0p);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [theta0p, omega0p, alpha0p, tMax0p]);

  // Datos 1: ω constante -> θ(t) lineal
  const dataUniformOmega = useMemo(() => {
    const Tmax = clamp(toNum(tMax, 10), 0.1, 1e6);
    const count = clamp(Math.round(toNum(n, 240)), 50, 2000);

    return sampleUniformOmega({
      theta0: Number(theta0) || 0,
      omega: Number(omega) || 0,
      tMin: 0,
      tMax: Tmax,
      n: count,
    });
  }, [theta0, omega, tMax, n]);

  // Datos 2: α constante -> ω(t) lineal y θ(t) cuadrática
  const dataUniformAlpha = useMemo(() => {
    const Tmax = clamp(toNum(tMax, 10), 0.1, 1e6);
    const count = clamp(Math.round(toNum(n, 240)), 50, 2000);

    return sampleUniformAlpha({
      theta0: Number(theta0) || 0,
      omega0: Number(omega0) || 0,
      alpha: Number(alpha) || 0,
      tMin: 0,
      tMax: Tmax,
      n: count,
    });
  }, [theta0, omega0, alpha, tMax, n]);

  const thetaFormatter = (thRad) => {
    const val = Number(thRad);
    if (!Number.isFinite(val)) return "";
    if (angUnit === "deg") return String(radToDeg(val).toFixed(1)).replace(".", ",");
    return String(val.toFixed(3)).replace(".", ",");
  };

  const thetaLabel = angUnit === "deg" ? "θ (°)" : "θ (rad)";

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Rotación con ω constante (θ(t) = θ₀ + ω·t)</div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
            gap: 12,
            marginTop: 10,
          }}
        >
          <Toggle
            label="Unidad de ángulo (visualización)"
            value={angUnit}
            options={[
              { value: "deg", label: "Grados (°)" },
              { value: "rad", label: "Radianes (rad)" },
            ]}
            onChange={setAngUnit}
          />

          <NumInput
            label={`θ₀ (${angUnit === "deg" ? "°" : "rad"})`}
            value={angUnit === "deg" ? radToDeg(theta0) : theta0}
            step={angUnit === "deg" ? 1 : 0.1}
            onChange={(v) => {
              const x = toNum(v, angUnit === "deg" ? radToDeg(theta0) : theta0);
              const th = angUnit === "deg" ? degToRad(x) : x;
              setTheta0(Number.isFinite(th) ? th : theta0);
            }}
          />

          <NumInput label="ω (rad/s)" value={omega} step={0.1} onChange={(v) => setOmega(toNum(v, omega))} />
          <NumInput label="t máx (s)" value={tMax} step={0.5} min={0.1} onChange={(v) => setTMax(toNum(v, tMax))} />
          <NumInput
            label="Puntos (n)"
            value={n}
            step={10}
            min={50}
            max={2000}
            onChange={(v) => setN(clamp(Math.round(toNum(v, n)), 50, 2000))}
          />
        </div>

        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={dataUniformOmega} margin={{ left: 10, right: 20, top: 10, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="t"
                type="number"
                domain={["auto", "auto"]}
                tickFormatter={(v) => String(v).replace(".", ",")}
                label={{ value: "t (s)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => (angUnit === "deg" ? String(v).replace(".", ",") : String(v).replace(".", ","))}
                label={{ value: thetaLabel, angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(value, name) => [String(value).replace(".", ","), name]}
                labelFormatter={(v) => `t = ${String(v).replace(".", ",")} s`}
              />
              <Legend />
              <Line type="monotone" dataKey={angUnit === "deg" ? "thetaDeg" : "theta"} dot={false} name="θ" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 6 }}>
          Nota: internamente se calcula en radianes. La vista en grados es solo conversión.
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Rotación con α constante (ω(t), θ(t))</div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
            gap: 12,
            marginTop: 10,
          }}
        >
          <NumInput label="ω₀ (rad/s)" value={omega0} step={0.1} onChange={(v) => setOmega0(toNum(v, omega0))} />
          <NumInput label="α (rad/s²)" value={alpha} step={0.1} onChange={(v) => setAlpha(toNum(v, alpha))} />
          <NumInput label="t máx (s)" value={tMax} step={0.5} min={0.1} onChange={(v) => setTMax(toNum(v, tMax))} />
        </div>

        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={dataUniformAlpha} margin={{ left: 10, right: 20, top: 10, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="t"
                type="number"
                domain={["auto", "auto"]}
                tickFormatter={(v) => String(v).replace(".", ",")}
                label={{ value: "t (s)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                yAxisId="left"
                tickFormatter={(v) => String(v).replace(".", ",")}
                label={{ value: "ω (rad/s)", angle: -90, position: "insideLeft" }}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                tickFormatter={(v) => String(v).replace(".", ",")}
                label={{ value: thetaLabel, angle: -90, position: "insideRight" }}
              />

              <Tooltip
                formatter={(value, name) => [String(value).replace(".", ","), name]}
                labelFormatter={(v) => `t = ${String(v).replace(".", ",")} s`}
              />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="omega" dot={false} name="ω" />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey={angUnit === "deg" ? "thetaDeg" : "theta"}
                dot={false}
                name="θ"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 6 }}>
          Fórmulas: <b>ω = ω₀ + α·t</b>, <b>θ = θ₀ + ω₀·t + ½·α·t²</b>.
        </div>
      </div>
    </div>
  );
}
