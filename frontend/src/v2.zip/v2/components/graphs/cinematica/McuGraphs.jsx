import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { sampleMCU } from "../../../engine/models/cinematica/mcu";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function NumInput({ label, value, onChange, step = 0.1, min, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="form-control"
        type="number"
        step={step}
        min={min}
        disabled={disabled}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

export default function MCUGraphs({ params }) {
  const [linked, setLinked] = useState(true);

  const [p, setP] = useState(() => ({
    cx: 0,
    cy: 0,
    R: 2,
    theta0: 0,
    omega: 1,
    tMax: 10,
    tObs: 0,
  }));

  useEffect(() => {
    if (!linked) return;
    setP((prev) => ({
      ...prev,
      cx: toNum(params?.cx, 0),
      cy: toNum(params?.cy, 0),
      R: toNum(params?.R, 2),
      theta0: toNum(params?.theta0, 0),
      omega: toNum(params?.omega, 1),
      tMax: toNum(params?.tMax, 10),
      tObs: 0,
    }));
  }, [linked, params?.cx, params?.cy, params?.R, params?.theta0, params?.omega, params?.tMax]);

  const patch = (k, v) => setP((prev) => ({ ...prev, [k]: v }));

  const cx = toNum(p.cx, 0);
  const cy = toNum(p.cy, 0);
  const R = Math.max(0, toNum(p.R, 2));
  const theta0 = toNum(p.theta0, 0);
  const omega = toNum(p.omega, 1);
  const tMax = Math.max(0, toNum(p.tMax, 10));
  const tObs = Math.max(0, Math.min(tMax, toNum(p.tObs, 0)));

  const sampled = useMemo(
    () => sampleMCU({ cx, cy, R, theta0, omega, tMax, n: 340 }),
    [cx, cy, R, theta0, omega, tMax]
  );

  const data = sampled?.data || [];
  const v = sampled?.v ?? Math.abs(omega) * R;
  const ac = sampled?.ac ?? omega * omega * R;

  const thetaObs = theta0 + omega * tObs;
  const xObs = cx + R * Math.cos(thetaObs);
  const yObs = cy + R * Math.sin(thetaObs);

  return (
    <div>
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (MCU)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Modo experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput label="cx (m)" value={p.cx} onChange={(v) => patch("cx", v)} step={0.5} disabled={linked} />
          <NumInput label="cy (m)" value={p.cy} onChange={(v) => patch("cy", v)} step={0.5} disabled={linked} />
          <NumInput label="R (m)" value={p.R} onChange={(v) => patch("R", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="θ0 (rad)" value={p.theta0} onChange={(v) => patch("theta0", v)} step={0.1} disabled={linked} />
          <NumInput label="ω (rad/s)" value={p.omega} onChange={(v) => patch("omega", v)} step={0.1} disabled={linked} />
          <NumInput label="t máximo (s)" value={p.tMax} onChange={(v) => patch("tMax", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="t observación (s)" value={String(tObs)} onChange={(v) => patch("tObs", v)} step={0.1} min={0} disabled={false} />
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 12 }}>
          <div className="v2-card">
            <div className="v2-card-title">Magnitudes</div>
            <div><strong>v</strong> = {fmt(v, 4)} m/s</div>
            <div><strong>a_c</strong> = {fmt(ac, 4)} m/s²</div>
            <div className="muted" style={{ marginTop: 8 }}>
              En MCU: ω constante, a_t = 0, a_c constante.
            </div>
          </div>

          <div className="v2-card">
            <div className="v2-card-title">En t = {fmt(tObs, 4)} s</div>
            <div><strong>θ</strong> = {fmt(thetaObs, 4)} rad</div>
            <div><strong>x</strong> = {fmt(xObs, 4)} m</div>
            <div><strong>y</strong> = {fmt(yObs, 4)} m</div>
          </div>
        </div>
      </div>

      {/* Trayectoria (x,y) paramétrica */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">Trayectoria (x,y)</div>
        <div style={{ width: "100%", minHeight: 340 }}>
          <ResponsiveContainer width="100%" height={340}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="x" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} />
              <Legend />
              <Line dataKey="y" name="y(x)" />
              <ReferenceDot x={xObs} y={yObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* θ(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">θ(t)</div>
        <div style={{ width: "100%", minHeight: 280 }}>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(l) => fmt(l, 4)}
              />
              <Legend />
              <Line dataKey="theta" name="θ(t)" />
              <ReferenceDot x={tObs} y={thetaObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ω(t), a_c(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">ω(t) y a_c(t)</div>
        <div style={{ width: "100%", minHeight: 300 }}>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(l) => fmt(l, 4)}
              />
              <Legend />
              <Line dataKey="omega" name="ω(t)" />
              <Line dataKey="ac" name="a_c(t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
