import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { sampleMCUA } from "../../../engine/models/cinematica/mcua";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function NumInput({ label, value, onChange, step = 0.1, min, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="form-control"
        type="number"
        step={step}
        min={min}
        disabled={disabled}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

export default function MCUAGraphs({ params }) {
  const [linked, setLinked] = useState(true);

  const [p, setP] = useState(() => ({
    cx: 0,
    cy: 0,
    R: 2,
    theta0: 0,
    omega0: 0.5,
    alpha: 0.2,
    tMax: 10,
    tObs: 0,
  }));

  useEffect(() => {
    if (!linked) return;
    setP((prev) => ({
      ...prev,
      cx: toNum(params?.cx, 0),
      cy: toNum(params?.cy, 0),
      R: toNum(params?.R, 2),
      theta0: toNum(params?.theta0, 0),
      omega0: toNum(params?.omega0, 0.5),
      alpha: toNum(params?.alpha, 0.2),
      tMax: toNum(params?.tMax, 10),
      tObs: 0,
    }));
  }, [linked, params?.cx, params?.cy, params?.R, params?.theta0, params?.omega0, params?.alpha, params?.tMax]);

  const patch = (k, v) => setP((prev) => ({ ...prev, [k]: v }));

  const cx = toNum(p.cx, 0);
  const cy = toNum(p.cy, 0);
  const R = Math.max(0, toNum(p.R, 2));
  const theta0 = toNum(p.theta0, 0);
  const omega0 = toNum(p.omega0, 0.5);
  const alpha = toNum(p.alpha, 0.2);
  const tMax = Math.max(0, toNum(p.tMax, 10));
  const tObs = Math.max(0, Math.min(tMax, toNum(p.tObs, 0)));

  const sampled = useMemo(
    () => sampleMCUA({ cx, cy, R, theta0, omega0, alpha, tMax, n: 340 }),
    [cx, cy, R, theta0, omega0, alpha, tMax]
  );

  const data = sampled?.data || [];

  // analíticos en tObs
  const omegaObs = omega0 + alpha * tObs;
  const thetaObs = theta0 + omega0 * tObs + 0.5 * alpha * tObs * tObs;

  const xObs = cx + R * Math.cos(thetaObs);
  const yObs = cy + R * Math.sin(thetaObs);

  const vObs = Math.abs(omegaObs) * R;
  const atObs = Math.abs(alpha) * R;
  const acObs = omegaObs * omegaObs * R;

  return (
    <div>
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (MCUA)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Modo experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput label="cx (m)" value={p.cx} onChange={(v) => patch("cx", v)} step={0.5} disabled={linked} />
          <NumInput label="cy (m)" value={p.cy} onChange={(v) => patch("cy", v)} step={0.5} disabled={linked} />
          <NumInput label="R (m)" value={p.R} onChange={(v) => patch("R", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="θ0 (rad)" value={p.theta0} onChange={(v) => patch("theta0", v)} step={0.1} disabled={linked} />
          <NumInput label="ω0 (rad/s)" value={p.omega0} onChange={(v) => patch("omega0", v)} step={0.1} disabled={linked} />
          <NumInput label="α (rad/s²)" value={p.alpha} onChange={(v) => patch("alpha", v)} step={0.05} disabled={linked} />
          <NumInput label="t máximo (s)" value={p.tMax} onChange={(v) => patch("tMax", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="t observación (s)" value={String(tObs)} onChange={(v) => patch("tObs", v)} step={0.1} min={0} disabled={false} />
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 12 }}>
          <div className="v2-card">
            <div className="v2-card-title">En t = {fmt(tObs, 4)} s</div>
            <div><strong>θ</strong> = {fmt(thetaObs, 4)} rad</div>
            <div><strong>ω</strong> = {fmt(omegaObs, 4)} rad/s</div>
            <div><strong>v</strong> = {fmt(vObs, 4)} m/s</div>
            <div><strong>a_t</strong> = {fmt(atObs, 4)} m/s²</div>
            <div><strong>a_c</strong> = {fmt(acObs, 4)} m/s²</div>
          </div>

          <div className="v2-card">
            <div className="v2-card-title">Posición (x,y)</div>
            <div><strong>x</strong> = {fmt(xObs, 4)} m</div>
            <div><strong>y</strong> = {fmt(yObs, 4)} m</div>
            <div className="muted" style={{ marginTop: 8 }}>
              a_c cambia porque depende de ω(t)².
            </div>
          </div>
        </div>
      </div>

      {/* Trayectoria */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">Trayectoria (x,y)</div>
        <div style={{ width: "100%", minHeight: 340 }}>
          <ResponsiveContainer width="100%" height={340}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="x" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} />
              <Legend />
              <Line dataKey="y" name="y(x)" />
              <ReferenceDot x={xObs} y={yObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* θ(t), ω(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">θ(t) y ω(t)</div>
        <div style={{ width: "100%", minHeight: 300 }}>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="theta" name="θ(t)" />
              <Line dataKey="omega" name="ω(t)" />
              <ReferenceDot x={tObs} y={thetaObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* α(t), a_t(t), a_c(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">α(t), a_t(t) y a_c(t)</div>
        <div style={{ width: "100%", minHeight: 320 }}>
          <ResponsiveContainer width="100%" height={320}>
            <AreaChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Area dataKey="alpha" name="α(t)" />
              <Area dataKey="at" name="a_t(t)" />
              <Area dataKey="ac" name="a_c(t)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ax(t), ay(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">Componentes de la aceleración (a_x, a_y)</div>
        <div style={{ width: "100%", minHeight: 280 }}>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="ax" name="a_x(t)" />
              <Line dataKey="ay" name="a_y(t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
