import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { sampleMovimiento2D } from "../../../engine/models/cinematica/movimiento2d";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function NumInput({ label, value, onChange, step = 0.1, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input className="form-control" type="number" step={step} disabled={disabled}
        value={value ?? ""} onChange={(e) => onChange?.(e.target.value)} />
    </div>
  );
}

export default function Movimiento2DGraphs({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({
    x0: 0, y0: 0, vx0: 3, vy0: 2, ax: 0, ay: 0,
    tMax: 10, tObs: 0
  }));

  useEffect(() => {
    if (!linked) return;
    setP((prev) => ({
      ...prev,
      x0: toNum(params?.x0, prev.x0),
      y0: toNum(params?.y0, prev.y0),
      vx0: toNum(params?.vx0 ?? params?.vx, prev.vx0),
      vy0: toNum(params?.vy0 ?? params?.vy, prev.vy0),
      ax: toNum(params?.ax, prev.ax),
      ay: toNum(params?.ay, prev.ay),
      tMax: Math.max(0, toNum(params?.tMax, prev.tMax)),
      tObs: 0,
    }));
  }, [linked, params?.x0, params?.y0, params?.vx0, params?.vy0, params?.vx, params?.vy, params?.ax, params?.ay, params?.tMax]);

  const patch = (k, v) => setP((prev) => ({ ...prev, [k]: v }));

  const x0 = toNum(p.x0, 0);
  const y0 = toNum(p.y0, 0);
  const vx0 = toNum(p.vx0, 0);
  const vy0 = toNum(p.vy0, 0);
  const ax = toNum(p.ax, 0);
  const ay = toNum(p.ay, 0);
  const tMax = Math.max(0, toNum(p.tMax, 10));
  const tObs = Math.max(0, Math.min(tMax, toNum(p.tObs, 0)));

  const { data, xObs, yObs, vxObs, vyObs } = useMemo(
    () => sampleMovimiento2D({ x0, y0, vx0, vy0, ax, ay, tMax, tObs, n: 320 }),
    [x0, y0, vx0, vy0, ax, ay, tMax, tObs]
  );

  return (
    <div>
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (Movimiento 2D)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button type="button" className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`} onClick={() => setLinked(true)}>
            🔗 Seguir calculadora
          </button>
          <button type="button" className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`} onClick={() => setLinked(false)}>
            🧪 Modo experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput label="x0 (m)" value={p.x0} onChange={(v) => patch("x0", v)} step={0.5} disabled={linked} />
          <NumInput label="y0 (m)" value={p.y0} onChange={(v) => patch("y0", v)} step={0.5} disabled={linked} />
          <NumInput label="vx0 (m/s)" value={p.vx0} onChange={(v) => patch("vx0", v)} step={0.5} disabled={linked} />
          <NumInput label="vy0 (m/s)" value={p.vy0} onChange={(v) => patch("vy0", v)} step={0.5} disabled={linked} />
          <NumInput label="ax (m/s²)" value={p.ax} onChange={(v) => patch("ax", v)} step={0.2} disabled={linked} />
          <NumInput label="ay (m/s²)" value={p.ay} onChange={(v) => patch("ay", v)} step={0.2} disabled={linked} />
          <NumInput label="t máximo (s)" value={p.tMax} onChange={(v) => patch("tMax", v)} step={0.5} disabled={linked} />
          <NumInput label="t observación (s)" value={String(tObs)} onChange={(v) => patch("tObs", v)} step={0.1} disabled={false} />
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 12 }}>
          <div className="v2-card">
            <div className="v2-card-title">En t = {fmt(tObs, 4)} s</div>
            <div><strong>x</strong> = {fmt(xObs, 4)} m</div>
            <div><strong>y</strong> = {fmt(yObs, 4)} m</div>
            <div><strong>vx</strong> = {fmt(vxObs, 4)} m/s</div>
            <div><strong>vy</strong> = {fmt(vyObs, 4)} m/s</div>
          </div>
          <div className="v2-card">
            <div className="v2-card-title">Pistas</div>
            <div className="muted">
              Si ax=ay=0 obtienes MRU 2D. Si solo ay≠0 (por ejemplo -g), conectas con tiros.
            </div>
          </div>
        </div>
      </div>

      {/* Trayectoria y(x) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">Trayectoria (x,y)</div>
        <div style={{ width: "100%", minHeight: 340 }}>
          <ResponsiveContainer width="100%" height={340}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="x" />
              <YAxis />
              <Tooltip formatter={(v, n) => [fmt(v, 4), n]} />
              <Legend />
              <Line dataKey="y" name="y(x)" />
              <ReferenceDot x={xObs} y={yObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* x(t) y y(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">x(t) y y(t)</div>
        <div style={{ width: "100%", minHeight: 320 }}>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(v, n) => [fmt(v, 4), n]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="x" name="x(t)" />
              <Line dataKey="y_t" name="y(t)" />
              <ReferenceDot x={tObs} y={xObs} r={4} label="x@t" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* vx(t) y vy(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">vx(t) y vy(t)</div>
        <div style={{ width: "100%", minHeight: 280 }}>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(v, n) => [fmt(v, 4), n]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="vx" name="vx(t)" />
              <Line dataKey="vy" name="vy(t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
