import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { computeRelative2D, sampleRelative1D } from "../../../engine/models/cinematica/movimientoRelativo";

function toNum(v, fallback = 0) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function NumInput({ label, value, onChange, step = 0.1, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="form-control"
        type="number"
        step={step}
        disabled={disabled}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

function ArrowSvg({ vAB, vBO, vAO }) {
  // vAB, vBO, vAO: {x,y}
  const W = 520, H = 120;

  // márgenes
  const pad = 30;

  // puntos para método punta-cola
  const O = { x: 0, y: 0 };
  const A = { x: vAB.x, y: vAB.y };                 // punta de vAB
  const B = { x: vAB.x + vBO.x, y: vAB.y + vBO.y }; // punta final (O->B = vAO)

  // bounding box para autoescalar y centrar
  const xs = [O.x, A.x, B.x];
  const ys = [O.y, A.y, B.y];
  const minX = Math.min(...xs), maxX = Math.max(...xs);
  const minY = Math.min(...ys), maxY = Math.max(...ys);

  const spanX = Math.max(1e-6, maxX - minX);
  const spanY = Math.max(1e-6, maxY - minY);

  // escala uniforme para que quepa
  const s = Math.min((W - 2 * pad) / spanX, (H - 2 * pad) / spanY);

  // centrado
  const midX = (minX + maxX) / 2;
  const midY = (minY + maxY) / 2;

  const cx = W / 2;
  const cy = H / 2;

  const toX = (x) => cx + (x - midX) * s;
  const toY = (y) => cy - (y - midY) * s;

  const markerId = "arrowhead-relative";

  const drawArrow = (from, to, label, labelOffset = { dx: 6, dy: -6 }) => {
    const x1 = toX(from.x), y1 = toY(from.y);
    const x2 = toX(to.x), y2 = toY(to.y);
    return (
      <g>
        <line
          x1={x1} y1={y1}
          x2={x2} y2={y2}
          stroke="currentColor"
          strokeWidth="3"
          markerEnd={`url(#${markerId})`}
        />
        <text x={x2 + labelOffset.dx} y={y2 + labelOffset.dy} fontSize="12">
          {label}
        </text>
      </g>
    );
  };

  return (
    <svg width="80%" viewBox={`0 0 ${W} ${H}`} style={{ display: "block" }}>
      <defs>
        <marker
          id={markerId}
          markerWidth="10"
          markerHeight="10"
          refX="8"
          refY="5"
          orient="auto"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" fill="currentColor" />
        </marker>
      </defs>

      {/* Ejes (centrados en el origen real O=0,0 proyectado) */}
      {/* Dibujamos ejes pasando por el punto O */}
      {(() => {
        const ox = toX(0), oy = toY(0);
        return (
          <>
            <line x1={pad} y1={oy} x2={W - pad} y2={oy} stroke="currentColor" strokeWidth="1" opacity="0.35" />
            <line x1={ox} y1={pad} x2={ox} y2={H - pad} stroke="currentColor" strokeWidth="1" opacity="0.35" />
            <text x={W - pad - 20} y={oy - 20} fontSize="10" opacity="0.7">x</text>
            <text x={ox + 6} y={pad + 10} fontSize="10" opacity="0.7">y</text>
            <circle cx={ox} cy={oy} r="3" fill="currentColor" />
            <text x={ox + 6} y={oy + 10} fontSize="10" opacity="0.8">O</text>
          </>
        );
      })()}

      {/* Línea guía punta-cola (segmento desde A hasta B) */}
      <line
        x1={toX(A.x)} y1={toY(A.y)}
        x2={toX(B.x)} y2={toY(B.y)}
        stroke="currentColor"
        strokeWidth="1"
        opacity="0.2"
        strokeDasharray="4 4"
      />

      {/* vAB: O -> A */}
      {drawArrow(O, A, "vAB")}

      {/* vBO: A -> B (punta-cola) */}
      {drawArrow(A, B, "vBO", { dx: 6, dy: 14 })}

      {/* vAO: O -> B (resultado) */}
      {drawArrow(O, B, "vAO", { dx: 6, dy: -12 })}

      {/* Etiquetas numéricas (opcionales, muy útiles) */}
      <g opacity="0.85">
        <text x={pad} y={H - pad} fontSize="12">
          vAB=({fmt(vAB.x, 2)}, {fmt(vAB.y, 2)})  vBO=({fmt(vBO.x, 2)}, {fmt(vBO.y, 2)})  vAO=({fmt(vAO.x, 2)}, {fmt(vAO.y, 2)})
        </text>
      </g>
    </svg>
  );
}


export default function RelativeMotionGraphs({ params }) {
  const [linked, setLinked] = useState(true);

  // Inputs 2D (componentes)
  const [p, setP] = useState(() => ({
    // 2D
    uAB: 2,
    wAB: 0,
    uBO: 20,
    wBO: 0,

    // 1D extra (posición)
    xA0: 0,
    xB0: 0,
    tMax: 10,
    tObs: 0,
  }));

  // Sync desde calculadora si linked.
  // Nota: tu calculadora puede dar vAO/vAB/vBO (1D) o u/w (2D). Priorizo u/w si existen.
  useEffect(() => {
    if (!linked) return;

    const has2D =
      params?.uAB != null || params?.wAB != null || params?.uBO != null || params?.wBO != null;

    setP((prev) => ({
      ...prev,

      uAB: toNum(has2D ? params?.uAB : prev.uAB, prev.uAB),
      wAB: toNum(has2D ? params?.wAB : prev.wAB, prev.wAB),
      uBO: toNum(has2D ? params?.uBO : prev.uBO, prev.uBO),
      wBO: toNum(has2D ? params?.wBO : prev.wBO, prev.wBO),

      // 1D: si hay vAB/vBO en params, úsalo como fallback para uAB/uBO
      ...(has2D
        ? {}
        : {
            uAB: toNum(params?.vAB, prev.uAB),
            uBO: toNum(params?.vBO, prev.uBO),
            wAB: 0,
            wBO: 0,
          }),

      xA0: toNum(params?.xA0, prev.xA0),
      xB0: toNum(params?.xB0, prev.xB0),
      tMax: Math.max(0, toNum(params?.tMax, prev.tMax)),
      tObs: 0,
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    linked,
    params?.uAB, params?.wAB, params?.uBO, params?.wBO,
    params?.vAB, params?.vBO,
    params?.xA0, params?.xB0, params?.tMax
  ]);

  const patch = (k, v) => setP((prev) => ({ ...prev, [k]: v }));

  const uAB = toNum(p.uAB, 0);
  const wAB = toNum(p.wAB, 0);
  const uBO = toNum(p.uBO, 0);
  const wBO = toNum(p.wBO, 0);

  const xA0 = toNum(p.xA0, 0);
  const xB0 = toNum(p.xB0, 0);
  const tMax = Math.max(0, toNum(p.tMax, 10));
  const tObs = clamp(toNum(p.tObs, 0), 0, Math.max(0, tMax));

  const rel2D = useMemo(
    () => computeRelative2D({ uAB, wAB, uBO, wBO }),
    [uAB, wAB, uBO, wBO]
  );

  const has1DPlot = true; // siempre útil, aunque sea simple
  const sample1D = useMemo(() => {
    return sampleRelative1D({
      xA0,
      xB0,
      vAB: uAB, // interpretamos u como 1D si w=0
      vBO: uBO,
      tMax,
      n: 240,
    });
  }, [xA0, xB0, uAB, uBO, tMax]);

  const data1D = sample1D?.data || [];
  const vAO = sample1D?.vAO ?? (uAB + uBO);

  // valores observados
  const thetaObs = 0; // no aplica; mantenemos el patrón visual con dot
  const xAObs = xA0 + vAO * tObs;
  const xBObs = xB0 + uBO * tObs;
  const xRelObs = xAObs - xBObs;

  return (
    <div>
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (Movimiento relativo)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Modo experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput label="uAB (m/s)" value={p.uAB} onChange={(v) => patch("uAB", v)} step={0.5} disabled={linked} />
          <NumInput label="wAB (m/s)" value={p.wAB} onChange={(v) => patch("wAB", v)} step={0.5} disabled={linked} />
          <NumInput label="uBO (m/s)" value={p.uBO} onChange={(v) => patch("uBO", v)} step={0.5} disabled={linked} />
          <NumInput label="wBO (m/s)" value={p.wBO} onChange={(v) => patch("wBO", v)} step={0.5} disabled={linked} />
          <NumInput label="t máximo (s)" value={p.tMax} onChange={(v) => patch("tMax", v)} step={1} disabled={linked} />
          <NumInput label="t observación (s)" value={String(tObs)} onChange={(v) => patch("tObs", v)} step={0.1} disabled={false} />
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 12 }}>
          <div className="v2-card">
            <div className="v2-card-title">Resultado (2D)</div>
            <div><strong>uAO</strong> = uAB + uBO = <strong>{fmt(rel2D.uAO, 4)}</strong> m/s</div>
            <div><strong>wAO</strong> = wAB + wBO = <strong>{fmt(rel2D.wAO, 4)}</strong> m/s</div>
            <div style={{ marginTop: 8 }}><strong>|vAB|</strong> = {fmt(rel2D.vAB, 4)} m/s</div>
            <div><strong>|vBO|</strong> = {fmt(rel2D.vBO, 4)} m/s</div>
            <div><strong>|vAO|</strong> = {fmt(rel2D.vAO, 4)} m/s</div>
          </div>

          <div className="v2-card">
            <div className="v2-card-title">Posiciones (1D opcional)</div>
            <div className="muted">Útil para “tren-andén”.</div>
            <div style={{ marginTop: 8 }}>
              <NumInput label="xA0 (m)" value={p.xA0} onChange={(v) => patch("xA0", v)} step={1} disabled={linked} />
              <NumInput label="xB0 (m)" value={p.xB0} onChange={(v) => patch("xB0", v)} step={1} disabled={linked} />
            </div>
            <div style={{ marginTop: 8 }}>
              <div><strong>xA(t)</strong> = {fmt(xAObs, 4)} m</div>
              <div><strong>xB(t)</strong> = {fmt(xBObs, 4)} m</div>
              <div><strong>xA−xB</strong> = {fmt(xRelObs, 4)} m</div>
            </div>
          </div>
        </div>
      </div>

      {/* Diagrama vectorial 2D */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">Diagrama vectorial (2D)</div>
        <div className="muted" style={{ marginBottom: 10 }}>
          Se dibujan vAB, vBO y vAO = vAB + vBO (suma vectorial).
        </div>
        <div className="v2-card" style={{ padding: 0 }}>
          <ArrowSvg
            vAB={{ x: rel2D.uAB, y: rel2D.wAB }}
            vBO={{ x: rel2D.uBO, y: rel2D.wBO }}
            vAO={{ x: rel2D.uAO, y: rel2D.wAO }}
            />
        </div>
      </div>

      {/* Plot 1D */}
      {has1DPlot && (
        <div className="v2-card" style={{ marginTop: 12 }}>
          <div className="v2-card-title">Movimiento en 1D (ejemplo tipo tren)</div>

          <div style={{ width: "100%", minHeight: 320 }}>
            <ResponsiveContainer width="100%" height={320}>
              <LineChart data={data1D}>
                <CartesianGrid />
                <XAxis dataKey="t" />
                <YAxis />
                <Tooltip
                  formatter={(value, name) => [fmt(value, 4), name]}
                  labelFormatter={(l) => fmt(l, 4)}
                />
                <Legend />
                <Line dataKey="xA" name="xA(t) (A visto por O)" />
                <Line dataKey="xB" name="xB(t) (B visto por O)" />
                <Line dataKey="xRel" name="xA-xB (A visto por B)" />
                <ReferenceDot x={tObs} y={xRelObs} r={4} label="t obs" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="muted" style={{ marginTop: 8 }}>
            Aquí interpretamos uAB y uBO como velocidades en 1D (cuando w=0).
          </div>
        </div>
      )}
    </div>
  );
}
