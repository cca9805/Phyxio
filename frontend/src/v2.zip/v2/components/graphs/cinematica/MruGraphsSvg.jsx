import { useMemo } from "react";
import { SvgFrame, Arrow, TrajectoryPath } from "@/v2/components/graphs_shared/svg2";

/**
 * MRU - Vista SVG
 * Movimiento Rectilíneo Uniforme con velocidad constante
 */
export default function MruGraphsSvg({ title, params }) {
  const pick = (k, fb) => {
    const v = params?.[k];
    const n = typeof v === "number" ? v : Number(String(v ?? "").replace(",", "."));
    return Number.isFinite(n) ? n : fb;
  };

  const v = pick("v", 10);
  const x0 = pick("x0", 0);

  const formula = "x(t) = x₀ + v·t     |     v = constante     |     a = 0";

  // Calcular posiciones en diferentes instantes
  const trajectory = useMemo(() => {
    const positions = [];
    const tMax = 5;
    const steps = 5;
    
    for (let i = 0; i <= steps; i++) {
      const t = (tMax * i) / steps;
      positions.push({
        t: t.toFixed(1),
        svgX: 140 + i * 80,
      });
    }
    return positions;
  }, []);

  const objectY = 170;

  return (
    <SvgFrame
      title={title || "MRU - Esquema"}
      subtitle="Movimiento Rectilíneo Uniforme con velocidad constante"
      formula={formula}
      showGrid={false}
    >
      {/* Eje X (trayectoria) */}
      <g opacity="0.75">
        <line x1="120" y1={objectY} x2="600" y2={objectY} stroke="currentColor" strokeWidth="2" />
        <polygon points={`610,${objectY} 598,${objectY - 6} 598,${objectY + 6}`} fill="currentColor" />
        <text x="615" y={objectY + 5} fontSize="14" fill="currentColor">x</text>
      </g>

      {/* Línea de trayectoria */}
      <TrajectoryPath
        d={`M ${trajectory[0].svgX} ${objectY} L ${trajectory[trajectory.length - 1].svgX} ${objectY}`}
      />

      {/* Posiciones en diferentes instantes */}
      {trajectory.map((pos, idx) => (
        <g key={idx}>
          <circle
            cx={pos.svgX}
            cy={objectY}
            r={idx === 0 ? 18 : 8}
            fill="none"
            stroke="currentColor"
            strokeWidth={idx === 0 ? 2.5 : 1.5}
            opacity={idx === 0 ? 1 : 0.4}
          />
          {idx === 0 && (
            <text
              x={pos.svgX + 25}
              y={objectY + 5}
              fontSize="13"
              fill="currentColor"
            >
              m
            </text>
          )}
          {/* Etiqueta de tiempo */}
          <text
            x={pos.svgX}
            y={objectY + 35}
            fontSize="11"
            textAnchor="middle"
            fill="currentColor"
            opacity="0.7"
          >
            t={pos.t}s
          </text>
          {/* Marca en el eje */}
          <line
            x1={pos.svgX}
            y1={objectY + 5}
            x2={pos.svgX}
            y2={objectY + 15}
            stroke="currentColor"
            strokeWidth="1.5"
            opacity="0.5"
          />
        </g>
      ))}

      {/* Vector velocidad sobre el objeto inicial */}
      <Arrow
        x={trajectory[0].svgX + 20}
        y={objectY - 50}
        dx={60}
        dy={0}
        label={`v = ${v.toFixed(1)} m/s`}
        labelDx={0}
        labelDy={-15}
      />

      {/* Dimensión de desplazamiento */}
      <g opacity="0.45">
        <line
          x1={trajectory[0].svgX}
          y1={objectY + 60}
          x2={trajectory[trajectory.length - 1].svgX}
          y2={objectY + 60}
          stroke="currentColor"
          strokeWidth="2"
          strokeDasharray="6 6"
        />
        <text
          x={(trajectory[0].svgX + trajectory[trajectory.length - 1].svgX) / 2}
          y={objectY + 80}
          fontSize="12"
          textAnchor="middle"
          fill="currentColor"
        >
          Δx = v·t
        </text>
      </g>
    </SvgFrame>
  );
}
