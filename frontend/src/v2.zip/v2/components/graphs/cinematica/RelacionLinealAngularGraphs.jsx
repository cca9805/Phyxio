import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

import {
  sampleArcVsAngle,
  sampleVAndAFromOmega,
} from "/src/v2/engine/models/cinematica/relacion-lineal-angular.js";

function toNum(v, fallback = NaN) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function radToDeg(x) {
  return (Number(x) * 180) / Math.PI;
}

function degToRad(x) {
  return (Number(x) * Math.PI) / 180;
}

function NumInput({ label, value, onChange, step = 0.1, min, max }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="v2-input"
        type="text"
        inputMode="decimal"
        step={step}
        min={min}
        max={max}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

function Toggle({ label, value, options, onChange }) {
  return (
    <div className="v2-card" style={{ display: "grid", gap: 8 }}>
      <div className="v2-card-title">{label}</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {options.map((opt) => {
          const active = value === opt.value;
          return (
            <button
              key={opt.value}
              className={`v2-btn ${active ? "v2-btn-primary" : "v2-btn-ghost"}`}
              type="button"
              onClick={() => onChange?.(opt.value)}
            >
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function RelacionLinealAngularGraphs({ params }) {
  const rp = toNum(params?.r ?? params?.radio, 0.3);
  const omegap = toNum(params?.omega ?? params?.w, 8);
  const alphap = toNum(params?.alpha ?? params?.aAng, 1);

  const [angUnit, setAngUnit] = useState("deg"); // visualización
  const [r, setR] = useState(Number.isFinite(rp) ? rp : 0.3);
  const [omega, setOmega] = useState(Number.isFinite(omegap) ? omegap : 8);
  const [alpha, setAlpha] = useState(Number.isFinite(alphap) ? alphap : 1);

  const [thetaMax, setThetaMax] = useState(Math.PI * 4); // 720° en rad
  const [omegaMax, setOmegaMax] = useState(20);
  const [n, setN] = useState(240);

  useEffect(() => {
    if (Number.isFinite(rp)) setR(rp);
    if (Number.isFinite(omegap)) setOmega(omegap);
    if (Number.isFinite(alphap)) setAlpha(alphap);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rp, omegap, alphap]);

  const dataArc = useMemo(() => {
    const count = clamp(Math.round(toNum(n, 240)), 50, 2000);
    const thMax = clamp(toNum(thetaMax, Math.PI * 4), 0.1, 1e6);
    return sampleArcVsAngle({ r: Number(r) || 0, thetaMin: 0, thetaMax: thMax, n: count });
  }, [r, thetaMax, n]);

  const dataVA = useMemo(() => {
    const count = clamp(Math.round(toNum(n, 240)), 50, 2000);
    const wMax = clamp(toNum(omegaMax, 20), 0.1, 1e6);
    return sampleVAndAFromOmega({ r: Number(r) || 0, alpha: Number(alpha) || 0, omegaMin: 0, omegaMax: wMax, n: count });
  }, [r, alpha, omegaMax, n]);

  const thetaKey = angUnit === "deg" ? "thetaDeg" : "theta";
  const thetaLabel = angUnit === "deg" ? "θ (°)" : "θ (rad)";

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Arco s frente a ángulo θ (s = r·θ)</div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12, marginTop: 10 }}>
          <Toggle
            label="Unidad de θ (visualización)"
            value={angUnit}
            options={[
              { value: "deg", label: "Grados (°)" },
              { value: "rad", label: "Radianes (rad)" },
            ]}
            onChange={setAngUnit}
          />
          <NumInput label="r (m)" value={r} step={0.05} min={0.0001} onChange={(v) => setR(toNum(v, r))} />
          <NumInput
            label={`θ máx (${angUnit === "deg" ? "°" : "rad"})`}
            value={angUnit === "deg" ? radToDeg(thetaMax) : thetaMax}
            step={angUnit === "deg" ? 30 : 0.5}
            min={0.1}
            onChange={(v) => {
              const x = toNum(v, angUnit === "deg" ? radToDeg(thetaMax) : thetaMax);
              const th = angUnit === "deg" ? degToRad(x) : x;
              if (Number.isFinite(th)) setThetaMax(th);
            }}
          />
          <NumInput label="Puntos (n)" value={n} step={10} min={50} max={2000} onChange={(v) => setN(clamp(Math.round(toNum(v, n)), 50, 2000))} />
        </div>

        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={dataArc} margin={{ left: 10, right: 20, top: 10, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={thetaKey} type="number" domain={["auto", "auto"]} label={{ value: thetaLabel, position: "insideBottom", offset: -5 }} />
              <YAxis dataKey="s" label={{ value: "s (m)", angle: -90, position: "insideLeft" }} />
              <Tooltip
                formatter={(value, name) => [String(value).replace(".", ","), name]}
                labelFormatter={(v) => `θ = ${String(v).replace(".", ",")}`}
              />
              <Legend />
              <Line type="monotone" dataKey="s" dot={false} name="s" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Conversión de ω a v_t y a_n (y a_t si α ≠ 0)</div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12, marginTop: 10 }}>
          <NumInput label="r (m)" value={r} step={0.05} min={0.0001} onChange={(v) => setR(toNum(v, r))} />
          <NumInput label="α (rad/s²)" value={alpha} step={0.2} onChange={(v) => setAlpha(toNum(v, alpha))} />
          <NumInput label="ω máx (rad/s)" value={omegaMax} step={1} min={0.1} onChange={(v) => setOmegaMax(toNum(v, omegaMax))} />
          <NumInput label="ω (rad/s) (referencia)" value={omega} step={0.5} onChange={(v) => setOmega(toNum(v, omega))} />
        </div>

        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={dataVA} margin={{ left: 10, right: 20, top: 10, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="omega" type="number" domain={["auto", "auto"]} label={{ value: "ω (rad/s)", position: "insideBottom", offset: -5 }} />
              <YAxis yAxisId="left" label={{ value: "v_t (m/s)", angle: -90, position: "insideLeft" }} />
              <YAxis yAxisId="right" orientation="right" label={{ value: "a (m/s²)", angle: -90, position: "insideRight" }} />
              <Tooltip
                formatter={(value, name) => [String(value).replace(".", ","), name]}
                labelFormatter={(v) => `ω = ${String(v).replace(".", ",")} rad/s`}
              />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="vt" dot={false} name="v_t = ωr" />
              <Line yAxisId="right" type="monotone" dataKey="an" dot={false} name="a_n = ω²r" />
              <Line yAxisId="right" type="monotone" dataKey="at" dot={false} name="a_t = αr (constante)" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 6 }}>
          Referencia: con ω = {String(omega).replace(".", ",")} rad/s y r = {String(r).replace(".", ",")} m, v_t = {(omega*r).toFixed(3).replace(".", ",")} m/s.
        </div>
      </div>
    </div>
  );
}
