import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

import {
  sampleRollingRelations,
  samplePointSpeedsVsOmega,
} from "/src/v2/engine/models/cinematica/rodadura-sin-deslizamiento.js";

function toNum(v, fallback = NaN) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function NumInput({ label, value, onChange, step = 0.1, min, max }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="v2-input"
        type="text"
        inputMode="decimal"
        step={step}
        min={min}
        max={max}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

export default function RodaduraGraphs({ params }) {
  const Rp = toNum(params?.R ?? params?.r ?? params?.radio, 0.3);
  const omegap = toNum(params?.omega ?? params?.w, 10);
  const alphap = toNum(params?.alpha ?? params?.aAng, 1);

  const [R, setR] = useState(Number.isFinite(Rp) ? Rp : 0.3);
  const [omegaRef, setOmegaRef] = useState(Number.isFinite(omegap) ? omegap : 10);
  const [alpha, setAlpha] = useState(Number.isFinite(alphap) ? alphap : 1);

  const [thetaMax, setThetaMax] = useState(Math.PI * 6); // 3 vueltas
  const [omegaMax, setOmegaMax] = useState(25);
  const [n, setN] = useState(240);

  useEffect(() => {
    if (Number.isFinite(Rp)) setR(Rp);
    if (Number.isFinite(omegap)) setOmegaRef(omegap);
    if (Number.isFinite(alphap)) setAlpha(alphap);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [Rp, omegap, alphap]);

  // Gráfica 1: x(θ), v_cm(ω), a_cm(α) como relaciones de rodadura pura
  const dataRel = useMemo(() => {
    const count = clamp(Math.round(toNum(n, 240)), 50, 2000);
    const thMax = clamp(toNum(thetaMax, Math.PI * 6), 0.1, 1e6);
    return sampleRollingRelations({
      R: Number(R) || 0,
      alpha: Number(alpha) || 0,
      thetaMin: 0,
      thetaMax: thMax,
      n: count,
    });
  }, [R, alpha, thetaMax, n]);

  // Gráfica 2: velocidades puntos (contacto, centro, arriba) frente a ω
  const dataSpeeds = useMemo(() => {
    const count = clamp(Math.round(toNum(n, 240)), 50, 2000);
    const wMax = clamp(toNum(omegaMax, 25), 0.1, 1e6);
    return samplePointSpeedsVsOmega({
      R: Number(R) || 0,
      omegaMin: 0,
      omegaMax: wMax,
      n: count,
    });
  }, [R, omegaMax, n]);

  const vcmRef = (Number(omegaRef) || 0) * (Number(R) || 0);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Rodadura pura: x(θ) y conversiones</div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12, marginTop: 10 }}>
          <NumInput label="R (m)" value={R} step={0.05} min={0.0001} onChange={(v) => setR(toNum(v, R))} />
          <NumInput label="α (rad/s²)" value={alpha} step={0.2} onChange={(v) => setAlpha(toNum(v, alpha))} />
          <NumInput label="θ máx (rad)" value={thetaMax} step={0.5} min={0.1} onChange={(v) => setThetaMax(toNum(v, thetaMax))} />
          <NumInput label="Puntos (n)" value={n} step={10} min={50} max={2000} onChange={(v) => setN(clamp(Math.round(toNum(v, n)), 50, 2000))} />
        </div>

        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={dataRel} margin={{ left: 10, right: 20, top: 10, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="theta" type="number" domain={["auto", "auto"]}
                     label={{ value: "θ (rad)", position: "insideBottom", offset: -5 }} />
              <YAxis yAxisId="left" label={{ value: "x (m)", angle: -90, position: "insideLeft" }} />
              <YAxis yAxisId="right" orientation="right" label={{ value: "a_cm (m/s²)", angle: -90, position: "insideRight" }} />

              <Tooltip
                formatter={(value, name) => [String(value).replace(".", ","), name]}
                labelFormatter={(v) => `θ = ${String(v).replace(".", ",")} rad`}
              />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="x" dot={false} name="x = Rθ" />
              <Line yAxisId="right" type="monotone" dataKey="acm" dot={false} name="a_cm = αR (const.)" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 6 }}>
          Referencia: con ω = {String(omegaRef).replace(".", ",")} rad/s y R = {String(R).replace(".", ",")} m, v_cm = {String(vcmRef.toFixed(3)).replace(".", ",")} m/s.
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Velocidades de puntos del borde (rodadura pura)</div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12, marginTop: 10 }}>
          <NumInput label="R (m)" value={R} step={0.05} min={0.0001} onChange={(v) => setR(toNum(v, R))} />
          <NumInput label="ω máx (rad/s)" value={omegaMax} step={1} min={0.1} onChange={(v) => setOmegaMax(toNum(v, omegaMax))} />
          <NumInput label="ω (rad/s) (referencia)" value={omegaRef} step={0.5} onChange={(v) => setOmegaRef(toNum(v, omegaRef))} />
        </div>

        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={dataSpeeds} margin={{ left: 10, right: 20, top: 10, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="omega" type="number" domain={["auto", "auto"]}
                     label={{ value: "ω (rad/s)", position: "insideBottom", offset: -5 }} />
              <YAxis label={{ value: "v (m/s)", angle: -90, position: "insideLeft" }} />

              <Tooltip
                formatter={(value, name) => [String(value).replace(".", ","), name]}
                labelFormatter={(v) => `ω = ${String(v).replace(".", ",")} rad/s`}
              />
              <Legend />
              <Line type="monotone" dataKey="vcontact" dot={false} name="v_contacto = 0" />
              <Line type="monotone" dataKey="vcm" dot={false} name="v_cm = ωR" />
              <Line type="monotone" dataKey="vtop" dot={false} name="v_arriba = 2v_cm" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 6 }}>
          En rodadura pura: el punto inferior está instantáneamente en reposo; el superior va al doble del centro.
        </div>
      </div>
    </div>
  );
}
