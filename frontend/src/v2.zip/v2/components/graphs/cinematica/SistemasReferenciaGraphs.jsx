import React, { useMemo } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceDot,
} from "recharts";

import GraphPageV2 from "../GraphPageV2"; // ajusta ruta
import { fmt } from "../../../utils/graphFormat"; // la misma que ya usas
import { makeSeries, defaultParams } from "../../../engine/models/cinematica/sistemas-referencia"; // ajusta ruta

export default function SistemasReferenciaGraphs({ params }) {
  const controls = useMemo(
    () => [
      { id: "x0", label: "x0 (m)", step: 1 },
      { id: "v0", label: "v0 (m/s)", step: 0.1 },
      { id: "xp0", label: "x'0 (m)", step: 1 },
      { id: "vp", label: "v' (m/s)", step: 0.1 },
      { id: "tMax", label: "tMax (s)", step: 1, min: 0.1 },
      { id: "tObs", label: "tObs (s)", step: 0.1, min: 0 },
    ],
    []
  );

  const compute = (p) => {
    const data = makeSeries(p);
    return { data, extra: null };
  };

  return (
    <GraphPageV2
      title="Sistemas de referencia"
      paramsFromCalculator={params}
      defaultParams={defaultParams()}
      controls={controls}
      compute={compute}
    >
      {({ p, data }) => {
        // punto observado
        const tObs = Number(p?.tObs ?? 0);
        const closest = data.reduce(
          (best, d) => (Math.abs(d.t - tObs) < Math.abs(best.t - tObs) ? d : best),
          data[0] || { t: 0, x: 0, xp: 0 }
        );

        return (
          <>
            <div className="v2-card" style={{ marginTop: 12 }}>
              <div className="v2-card-title">x'(t) en S' (marco móvil)</div>
              <div style={{ width: "100%", minHeight: 280 }}>
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={data}>
                    <CartesianGrid />
                    <XAxis dataKey="t" />
                    <YAxis />
                    <Tooltip
                      formatter={(value, name) => [fmt(value, 4), name]}
                      labelFormatter={(l) => `t=${fmt(l, 3)} s`}
                    />
                    <Legend />
                    <Line dataKey="xp" name="x'(t)" />
                    <ReferenceDot x={closest.t} y={closest.xp} r={4} label="t obs" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="v2-card" style={{ marginTop: 12 }}>
              <div className="v2-card-title">x(t) en S (marco principal)</div>
              <div style={{ width: "100%", minHeight: 280 }}>
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={data}>
                    <CartesianGrid />
                    <XAxis dataKey="t" />
                    <YAxis />
                    <Tooltip
                      formatter={(value, name) => [fmt(value, 4), name]}
                      labelFormatter={(l) => `t=${fmt(l, 3)} s`}
                    />
                    <Legend />
                    <Line dataKey="x" name="x(t)" />
                    <ReferenceDot x={closest.t} y={closest.x} r={4} label="t obs" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </>
        );
      }}
    </GraphPageV2>
  );
}
