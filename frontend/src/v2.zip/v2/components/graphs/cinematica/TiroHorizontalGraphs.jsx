import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { sampleTiroHorizontal } from "../../../engine/models/cinematica/tiroHorizontal";

/* Helpers */
function toNum(v, fallback = NaN) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function NumInput({ label, value, onChange, step = 0.1, min, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="form-control"
        type="number"
        step={step}
        min={min}
        disabled={disabled}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

export default function TiroHorizontalGraphs({ params }) {
  const [linked, setLinked] = useState(true);

  const [p, setP] = useState(() => ({
    x0: 0,
    y0: 10,
    v0: 6,
    g: 9.8,
    tMax: 3,
    tObs: 0,
  }));

  useEffect(() => {
    if (!linked) return;
    setP((prev) => ({
      ...prev,
      x0: toNum(params?.x0, 0),
      y0: toNum(params?.y0, 10),
      v0: toNum(params?.v0, 6),
      g: toNum(params?.g, 9.8),
      tMax: toNum(params?.tMax, 3),
      tObs: 0,
    }));
  }, [linked, params?.x0, params?.y0, params?.v0, params?.g, params?.tMax]);

  const patch = (k, val) => setP((prev) => ({ ...prev, [k]: val }));

  const x0 = toNum(p.x0, 0);
  const y0 = toNum(p.y0, 10);
  const v0 = toNum(p.v0, 6);
  const g = toNum(p.g, 9.8);
  const tMax = Math.max(0, toNum(p.tMax, 3));

  const sampled = useMemo(
    () => sampleTiroHorizontal({ x0, y0, v0, g, tMax, n: 300, groundY: 0 }),
    [x0, y0, v0, g, tMax]
  );
  const data = sampled?.data || [];
  const tImpact = sampled?.tImpact;
  const tEnd = sampled?.tEnd ?? tMax;

  const tObs = useMemo(() => {
    const raw = toNum(p.tObs, 0);
    if (!Number.isFinite(raw)) return 0;
    return clamp(raw, 0, Math.max(0, tEnd));
  }, [p.tObs, tEnd]);

  const xObs = x0 + v0 * tObs;
  const yObs = y0 - 0.5 * g * tObs * tObs;
  const vxObs = v0;
  const vyObs = -g * tObs;
  const vObs = Math.sqrt(vxObs * vxObs + vyObs * vyObs);

  const reachesGround =
    Number.isFinite(tImpact) && tMax >= tImpact && y0 >= 0 && g > 0;

  const RImpact = Number.isFinite(tImpact) ? v0 * tImpact : NaN;

  useEffect(() => {
    const raw = toNum(p.tObs, 0);
    if (!Number.isFinite(raw)) patch("tObs", 0);
    else if (raw < 0) patch("tObs", 0);
    else if (raw > tEnd) patch("tObs", tEnd);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tEnd]);

  return (
    <div>
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (Tiro horizontal)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Modo experimento (solo gráficas)
          </button>
          {!linked && (
            <button
              type="button"
              className="btn btn-sm btn-light"
              onClick={() =>
                setP({
                  x0: toNum(params?.x0, 0),
                  y0: toNum(params?.y0, 10),
                  v0: toNum(params?.v0, 6),
                  g: toNum(params?.g, 9.8),
                  tMax: toNum(params?.tMax, 3),
                  tObs: 0,
                })
              }
            >
              ↩️ Cargar desde calculadora
            </button>
          )}
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput label="x0 (m)" value={p.x0 ?? ""} onChange={(v) => patch("x0", v)} step={0.5} disabled={linked} />
          <NumInput label="y0 (m)" value={p.y0 ?? ""} onChange={(v) => patch("y0", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="v0 (m/s)" value={p.v0 ?? ""} onChange={(v) => patch("v0", v)} step={0.5} disabled={linked} />
          <NumInput label="g (m/s²)" value={p.g ?? ""} onChange={(v) => patch("g", v)} step={0.1} min={0} disabled={linked} />
          <NumInput label="t máximo (s)" value={p.tMax ?? ""} onChange={(v) => patch("tMax", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="t observación (s)" value={String(tObs)} onChange={(v) => patch("tObs", v)} step={0.1} min={0} disabled={false} />
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 12 }}>
          <div className="v2-card">
            <div className="v2-card-title">En t = {fmt(tObs, 4)} s</div>
            <div><strong>x</strong> = {fmt(xObs, 4)} m</div>
            <div><strong>y</strong> = {fmt(yObs, 4)} m</div>
            <div><strong>vₓ</strong> = {fmt(vxObs, 4)} m/s</div>
            <div><strong>vᵧ</strong> = {fmt(vyObs, 4)} m/s</div>
            <div><strong>|v|</strong> = {fmt(vObs, 4)} m/s</div>
          </div>

          <div className="v2-card">
            <div className="v2-card-title">Impacto (si llega al suelo)</div>
            {reachesGround ? (
              <>
                <div><strong>t₍impacto₎</strong> = {fmt(tImpact, 4)} s</div>
                <div><strong>R</strong> = {fmt(RImpact, 4)} m</div>
              </>
            ) : (
              <div className="muted">No llega al suelo dentro de t máximo.</div>
            )}
          </div>
        </div>
      </div>

      {/* y(x) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">Trayectoria — y(x)</div>
        <div style={{ width: "100%", minHeight: 340 }}>
          <ResponsiveContainer width="100%" height={340}>
            <LineChart data={data}>
              <ReferenceLine y={0} strokeDasharray="3 3" />
              <CartesianGrid />
              <XAxis dataKey="x" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} />
              <Legend />
              <Line dataKey="y" name="y(x)" />
              <ReferenceDot x={xObs} y={yObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* x(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">x(t) — posición horizontal</div>
        <div style={{ width: "100%", minHeight: 280 }}>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(label) => fmt(label, 4)}
              />
              <Legend />
              <Line dataKey="x" name="x(t)" />
              <ReferenceDot x={tObs} y={xObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* y(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">y(t) — posición vertical</div>
        <div style={{ width: "100%", minHeight: 320 }}>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={data}>
              <ReferenceLine y={0} strokeDasharray="3 3" />
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(label) => fmt(label, 4)}
              />
              <Legend />
              <Line dataKey="y" name="y(t)" />
              <ReferenceDot x={tObs} y={yObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* vy(t) y |v|(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">vᵧ(t) y |v|(t)</div>
        <div style={{ width: "100%", minHeight: 280 }}>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(label) => fmt(label, 4)}
              />
              <Legend />
              <Area dataKey="vy" name="vᵧ(t)" />
              <Area dataKey="v" name="|v|(t)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* a(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">a(t) — aceleraciones</div>
        <div style={{ width: "100%", minHeight: 260 }}>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(label) => fmt(label, 4)}
              />
              <Legend />
              <Line dataKey="ax" name="aₓ(t)" />
              <Line dataKey="ay" name="aᵧ(t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
