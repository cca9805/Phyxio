import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { sampleTiroParabolico } from "../../../engine/models/cinematica/tiroParabolico";

/* Helpers */
function toNum(v, fallback = NaN) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}
function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}
function NumInput({ label, value, onChange, step = 0.1, min, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="form-control"
        type="number"
        step={step}
        min={min}
        disabled={disabled}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

export default function TiroParabolicoGraphs({ params }) {
  const [linked, setLinked] = useState(true);

  const [p, setP] = useState(() => ({
    x0: 0,
    y0: 10,
    v0: 12,
    theta: Math.PI / 4, // RAD
    g: 9.8,
    tMax: 5,
    tObs: 0,
  }));

  // Sync desde calculadora si linked
  useEffect(() => {
    if (!linked) return;
    setP((prev) => ({
      ...prev,
      x0: toNum(params?.x0, 0),
      y0: toNum(params?.y0, 10),
      v0: toNum(params?.v0, 12),
      theta: toNum(params?.theta, Math.PI / 4),
      g: toNum(params?.g, 9.8),
      tMax: toNum(params?.tMax, 5),
      tObs: 0,
    }));
  }, [linked, params?.x0, params?.y0, params?.v0, params?.theta, params?.g, params?.tMax]);

  const patch = (k, val) => setP((prev) => ({ ...prev, [k]: val }));

  const x0 = toNum(p.x0, 0);
  const y0 = toNum(p.y0, 10);
  const v0 = toNum(p.v0, 12);
  const theta = toNum(p.theta, Math.PI / 4); // rad
  const g = toNum(p.g, 9.8);
  const tMax = Math.max(0, toNum(p.tMax, 5));

  const sampled = useMemo(
    () => sampleTiroParabolico({ x0, y0, v0, theta, g, tMax, n: 340, groundY: 0 }),
    [x0, y0, v0, theta, g, tMax]
  );

  const data = sampled?.data || [];
  const tImpact = sampled?.tImpact;
  const tEnd = sampled?.tEnd ?? tMax;
  const R = sampled?.R;
  const vx0 = sampled?.vx0 ?? v0 * Math.cos(theta);
  const vy0 = sampled?.vy0 ?? v0 * Math.sin(theta);
  const tPeak = sampled?.tPeak;
  const yPeak = sampled?.yPeak;

  const tObs = useMemo(() => {
    const raw = toNum(p.tObs, 0);
    if (!Number.isFinite(raw)) return 0;
    return clamp(raw, 0, Math.max(0, tEnd));
  }, [p.tObs, tEnd]);

  // valores en tObs (analíticos)
  const xObs = x0 + vx0 * tObs;
  const yObs = y0 + vy0 * tObs - 0.5 * g * tObs * tObs;
  const vxObs = vx0;
  const vyObs = vy0 - g * tObs;
  const vObs = Math.sqrt(vxObs * vxObs + vyObs * vyObs);

  const reachesGround = Number.isFinite(tImpact) && tMax >= tImpact && y0 >= 0 && g > 0;

  // mantener tObs en rango
  useEffect(() => {
    const raw = toNum(p.tObs, 0);
    if (!Number.isFinite(raw)) patch("tObs", 0);
    else if (raw < 0) patch("tObs", 0);
    else if (raw > tEnd) patch("tObs", tEnd);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tEnd]);

  return (
    <div>
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (Tiro parabólico)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Modo experimento (solo gráficas)
          </button>
          {!linked && (
            <button
              type="button"
              className="btn btn-sm btn-light"
              onClick={() =>
                setP({
                  x0: toNum(params?.x0, 0),
                  y0: toNum(params?.y0, 10),
                  v0: toNum(params?.v0, 12),
                  theta: toNum(params?.theta, Math.PI / 4),
                  g: toNum(params?.g, 9.8),
                  tMax: toNum(params?.tMax, 5),
                  tObs: 0,
                })
              }
            >
              ↩️ Cargar desde calculadora
            </button>
          )}
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput label="x0 (m)" value={p.x0 ?? ""} onChange={(v) => patch("x0", v)} step={0.5} disabled={linked} />
          <NumInput label="y0 (m)" value={p.y0 ?? ""} onChange={(v) => patch("y0", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="v0 (m/s)" value={p.v0 ?? ""} onChange={(v) => patch("v0", v)} step={0.5} disabled={linked} />
          <NumInput label="θ (rad)" value={p.theta ?? ""} onChange={(v) => patch("theta", v)} step={0.01} disabled={linked} />
          <NumInput label="g (m/s²)" value={p.g ?? ""} onChange={(v) => patch("g", v)} step={0.1} min={0} disabled={linked} />
          <NumInput label="t máximo (s)" value={p.tMax ?? ""} onChange={(v) => patch("tMax", v)} step={0.5} min={0} disabled={linked} />
          <NumInput label="t observación (s)" value={String(tObs)} onChange={(v) => patch("tObs", v)} step={0.1} min={0} disabled={false} />
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 12 }}>
          <div className="v2-card">
            <div className="v2-card-title">Descomposición inicial</div>
            <div><strong>vₓ0</strong> = {fmt(vx0, 4)} m/s</div>
            <div><strong>vᵧ0</strong> = {fmt(vy0, 4)} m/s</div>
            <div className="muted" style={{ marginTop: 8 }}>
              Nota: aquí θ se interpreta en radianes.
            </div>
          </div>

          <div className="v2-card">
            <div className="v2-card-title">En t = {fmt(tObs, 4)} s</div>
            <div><strong>x</strong> = {fmt(xObs, 4)} m</div>
            <div><strong>y</strong> = {fmt(yObs, 4)} m</div>
            <div><strong>vₓ</strong> = {fmt(vxObs, 4)} m/s</div>
            <div><strong>vᵧ</strong> = {fmt(vyObs, 4)} m/s</div>
            <div><strong>|v|</strong> = {fmt(vObs, 4)} m/s</div>
          </div>

          <div className="v2-card">
            <div className="v2-card-title">Eventos</div>
            {Number.isFinite(tPeak) ? (
              <div><strong>t pico</strong> = {fmt(tPeak, 4)} s</div>
            ) : (
              <div className="muted">Sin pico (vᵧ0 ≤ 0).</div>
            )}
            {Number.isFinite(yPeak) ? (
              <div><strong>y pico</strong> = {fmt(yPeak, 4)} m</div>
            ) : null}

            <div style={{ marginTop: 8 }}>
              {reachesGround ? (
                <>
                  <div><strong>t impacto</strong> = {fmt(tImpact, 4)} s</div>
                  <div><strong>R</strong> = {fmt(R, 4)} m</div>
                </>
              ) : (
                <div className="muted">No llega al suelo dentro de t máximo.</div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Trayectoria y(x) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">Trayectoria — y(x)</div>
        <div style={{ width: "100%", minHeight: 340 }}>
          <ResponsiveContainer width="100%" height={340}>
            <LineChart data={data}>
              <ReferenceLine y={0} strokeDasharray="3 3" />
              <CartesianGrid />
              <XAxis dataKey="x" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} />
              <Legend />
              <Line dataKey="y" name="y(x)" />
              <ReferenceDot x={xObs} y={yObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* x(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">x(t) — posición horizontal</div>
        <div style={{ width: "100%", minHeight: 280 }}>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="x" name="x(t)" />
              <ReferenceDot x={tObs} y={xObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* y(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">y(t) — posición vertical</div>
        <div style={{ width: "100%", minHeight: 320 }}>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={data}>
              <ReferenceLine y={0} strokeDasharray="3 3" />
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="y" name="y(t)" />
              <ReferenceDot x={tObs} y={yObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* vx(t), vy(t), |v|(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">vₓ(t), vᵧ(t) y |v|(t)</div>
        <div style={{ width: "100%", minHeight: 300 }}>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Area dataKey="vx" name="vₓ(t)" />
              <Area dataKey="vy" name="vᵧ(t)" />
              <Area dataKey="v" name="|v|(t)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* a(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">a(t) — aceleraciones</div>
        <div style={{ width: "100%", minHeight: 260 }}>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(value, name) => [fmt(value, 4), name]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="ax" name="aₓ(t)" />
              <Line dataKey="ay" name="aᵧ(t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
