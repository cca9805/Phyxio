import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { sampleTiroVertical } from "../../../engine/models/cinematica/tiroVertical";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function NumInput({ label, value, onChange, step = 0.1, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input className="form-control" type="number" step={step} disabled={disabled}
        value={value ?? ""} onChange={(e) => onChange?.(e.target.value)} />
    </div>
  );
}

export default function TiroVerticalGraphs({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({ y0: 0, v0: 12, g: 9.8, tMax: 6, tObs: 0 }));

  useEffect(() => {
    if (!linked) return;
    setP((prev) => ({
      ...prev,
      y0: toNum(params?.y0, prev.y0),
      v0: toNum(params?.v0, prev.v0),
      g: toNum(params?.g, prev.g),
      tMax: Math.max(0, toNum(params?.tMax, prev.tMax)),
      tObs: 0,
    }));
  }, [linked, params?.y0, params?.v0, params?.g, params?.tMax]);

  const patch = (k, v) => setP((prev) => ({ ...prev, [k]: v }));

  const y0 = toNum(p.y0, 0);
  const v0 = toNum(p.v0, 0);
  const g = Math.max(0.0001, toNum(p.g, 9.8));
  const tMax = Math.max(0, toNum(p.tMax, 6));
  const tObs = Math.max(0, Math.min(tMax, toNum(p.tObs, 0)));

  const { data, tPeak, yPeak } = useMemo(
    () => sampleTiroVertical({ y0, v0, g, tMax, n: 320 }),
    [y0, v0, g, tMax]
  );

  const vObs = v0 - g * tObs;
  const yObs = y0 + v0 * tObs - 0.5 * g * tObs * tObs;
  const aObs = -g;

  return (
    <div>
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (Tiro vertical)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button type="button" className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`} onClick={() => setLinked(true)}>
            🔗 Seguir calculadora
          </button>
          <button type="button" className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`} onClick={() => setLinked(false)}>
            🧪 Modo experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput label="y0 (m)" value={p.y0} onChange={(v) => patch("y0", v)} step={0.5} disabled={linked} />
          <NumInput label="v0 (m/s)" value={p.v0} onChange={(v) => patch("v0", v)} step={0.5} disabled={linked} />
          <NumInput label="g (m/s²)" value={p.g} onChange={(v) => patch("g", v)} step={0.1} disabled={linked} />
          <NumInput label="t máximo (s)" value={p.tMax} onChange={(v) => patch("tMax", v)} step={0.5} disabled={linked} />
          <NumInput label="t observación (s)" value={String(tObs)} onChange={(v) => patch("tObs", v)} step={0.1} disabled={false} />
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 12 }}>
          <div className="v2-card">
            <div className="v2-card-title">En t = {fmt(tObs, 4)} s</div>
            <div><strong>y</strong> = {fmt(yObs, 4)} m</div>
            <div><strong>v</strong> = {fmt(vObs, 4)} m/s</div>
            <div><strong>a</strong> = {fmt(aObs, 4)} m/s²</div>
          </div>
          <div className="v2-card">
            <div className="v2-card-title">Altura máxima (marcador)</div>
            <div><strong>t*</strong> = {fmt(tPeak, 4)} s</div>
            <div><strong>y*</strong> = {fmt(yPeak, 4)} m</div>
            <div className="muted" style={{ marginTop: 8 }}>
              En el máximo: v = 0 (si v0&gt;0).
            </div>
          </div>
        </div>
      </div>

      {/* y(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">y(t)</div>
        <div style={{ width: "100%", minHeight: 320 }}>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(v, n) => [fmt(v, 4), n]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="y" name="y(t)" />
              <ReferenceDot x={tObs} y={yObs} r={4} label="t obs" />
              <ReferenceDot x={tPeak} y={yPeak} r={4} label="máximo" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* v(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">v(t)</div>
        <div style={{ width: "100%", minHeight: 280 }}>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(v, n) => [fmt(v, 4), n]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="v" name="v(t)" />
              <ReferenceDot x={tObs} y={vObs} r={4} label="t obs" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* a(t) */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">a(t)</div>
        <div style={{ width: "100%", minHeight: 220 }}>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip formatter={(v, n) => [fmt(v, 4), n]} labelFormatter={(l) => fmt(l, 4)} />
              <Legend />
              <Line dataKey="a" name="a(t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <p className="muted" style={{ margin: "8px 0 0" }}>En tiro vertical: a(t) = -g constante.</p>
      </div>
    </div>
  );
}
