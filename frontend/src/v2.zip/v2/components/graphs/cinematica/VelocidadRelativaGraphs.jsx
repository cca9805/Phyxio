import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceDot,
} from "recharts";
import { fmt } from "../../../utils/graphFormat";
import { makeSeries, defaultParams } from "../../../engine/models/cinematica/velocidadRelativa";

/* Helpers (igual que tu TiroParabolicoGraphs) */
function toNum(v, fallback = NaN) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}
function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}
function NumInput({ label, value, onChange, step = 0.1, min, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="form-control"
        type="number"
        step={step}
        min={min}
        disabled={disabled}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
    </div>
  );
}

export default function VelocidadRelativaGraphs({ params }) {
  const [linked, setLinked] = useState(true);

  // defaults de experimento
  const [p, setP] = useState(() => ({
    ...defaultParams(),
  }));

  // si linked, sincroniza desde calculadora
  useEffect(() => {
    if (!linked) return;
    if (!params) return;

    setP((prev) => ({
      ...prev,
      vAB: toNum(params?.vAB, prev.vAB),
      vBC: toNum(params?.vBC, prev.vBC),
      tMax: toNum(params?.tMax, prev.tMax),
      // tObs lo dejamos del modo graphs, como en tiro parabólico
      tObs: prev.tObs ?? 0,
    }));
  }, [linked, params]);

  const loadFromCalculator = () => {
    if (!params) return;
    setP((prev) => ({
      ...prev,
      vAB: toNum(params?.vAB, prev.vAB),
      vBC: toNum(params?.vBC, prev.vBC),
      tMax: toNum(params?.tMax, prev.tMax),
      tObs: 0,
    }));
  };

  const safeP = useMemo(() => {
    const tMax = clamp(toNum(p.tMax, 10), 0.1, 1e6);
    const tObs = clamp(toNum(p.tObs, 0), 0, tMax);
    return {
      ...p,
      vAB: toNum(p.vAB, 0),
      vBC: toNum(p.vBC, 0),
      tMax,
      tObs,
    };
  }, [p]);

  const data = useMemo(() => makeSeries(safeP), [safeP]);

  const closest = useMemo(() => {
    if (!data?.length) return null;
    const tObs = safeP.tObs ?? 0;
    return data.reduce((best, d) =>
      Math.abs(d.t - tObs) < Math.abs(best.t - tObs) ? d : best
    );
  }, [data, safeP.tObs]);

  return (
    <div>
      {/* Card de parámetros (igual que tiro parabólico) */}
      <div className="v2-card">
        <div className="v2-card-title">Parámetros (Velocidad relativa)</div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Modo experimento (solo gráficas)
          </button>

          {!linked && (
            <button
              type="button"
              className="btn btn-sm btn-light"
              onClick={loadFromCalculator}
            >
              ↩️ Cargar desde calculadora
            </button>
          )}
        </div>

        <div className="v2-grid-fill-inputs">
          <NumInput
            label="vAB (m/s)"
            value={safeP.vAB ?? ""}
            onChange={(v) => setP((s) => ({ ...s, vAB: toNum(v, s.vAB) }))}
            step={0.1}
            disabled={linked}
          />
          <NumInput
            label="vBC (m/s)"
            value={safeP.vBC ?? ""}
            onChange={(v) => setP((s) => ({ ...s, vBC: toNum(v, s.vBC) }))}
            step={0.1}
            disabled={linked}
          />
          <NumInput
            label="tMax (s)"
            value={safeP.tMax ?? ""}
            onChange={(v) => setP((s) => ({ ...s, tMax: toNum(v, s.tMax) }))}
            step={0.5}
            min={0.1}
            disabled={linked}
          />
          <NumInput
            label="tObs (s)"
            value={safeP.tObs ?? ""}
            onChange={(v) => setP((s) => ({ ...s, tObs: toNum(v, s.tObs) }))}
            step={0.1}
            min={0}
            disabled={false}
          />
        </div>

        <div className="muted" style={{ marginTop: 8, fontSize: 13 }}>
          Se visualiza cómo la regla de cadena vAC = vAB + vBC se traduce en posiciones
          relativas x(t) con velocidades constantes.
        </div>
      </div>

      {/* Charts */}
      <div className="v2-card" style={{ marginTop: 12 }}>
        <div className="v2-card-title">x(t): A/B, B/C y A/C</div>
        <div style={{ width: "100%", minHeight: 320 }}>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis dataKey="t" />
              <YAxis />
              <Tooltip
                formatter={(value, name) => [fmt(value, 4), name]}
                labelFormatter={(l) => `t=${fmt(l, 3)} s`}
              />
              <Legend />
              <Line dataKey="xAB" name="xAB (A respecto B)" />
              <Line dataKey="xBC" name="xBC (B respecto C)" />
              <Line dataKey="xAC" name="xAC (A respecto C)" />
              {closest ? (
                <ReferenceDot x={closest.t} y={closest.xAC} r={4} label="t obs" />
              ) : null}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
