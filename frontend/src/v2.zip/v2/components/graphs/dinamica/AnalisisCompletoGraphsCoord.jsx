import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function buildData({ m, g, mu_k, Fmax }, n = 220) {
  const data = [];
  for (let i = 0; i <= n; i++) {
    const F = (Fmax * i) / n;
    const aNo = F / m;
    const aK = Math.max(0, (F - mu_k * m * g) / m);
    data.push({ F, aNo, aK });
  }
  return data;
}

export default function AnalisisCompletoGraphsCoord() {
  const [p, setP] = useState({
    m: 3,
    g: 9.8,
    mu_k: 0.25,
    Fmax: 40,
  });

  const safe = useMemo(() => {
    const m = Math.max(0.001, Number(p.m) || 3);
    const g = Math.max(0, Number(p.g) || 9.8);
    const mu_k = Math.max(0, Number(p.mu_k) || 0.25);
    const Fmax = Math.max(1, Number(p.Fmax) || 40);
    return { m, g, mu_k, Fmax };
  }, [p]);

  const data = useMemo(() => buildData(safe, 220), [safe]);
  const Fcrit = safe.mu_k * safe.m * safe.g;

  return (
    <div className="v2-card" style={{ padding: 12 }}>
      <div className="v2-card-title">Análisis completo (Coord)</div>
      <div className="muted" style={{ marginTop: 6 }}>
        Aceleración frente a fuerza aplicada (bloque horizontal) · umbral cinético:{" "}
        <b>F = μ_k m g = {fmt(Fcrit)} N</b>
      </div>

      <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
        <div className="v2-card">
          <div className="v2-card-title">m (kg)</div>
          <input className="form-control" inputMode="decimal" value={p.m} onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))} />
        </div>
        <div className="v2-card">
          <div className="v2-card-title">μ_k</div>
          <input className="form-control" inputMode="decimal" value={p.mu_k} onChange={(e) => setP((s) => ({ ...s, mu_k: e.target.value }))} />
        </div>
        <div className="v2-card">
          <div className="v2-card-title">F max (N)</div>
          <input className="form-control" inputMode="decimal" value={p.Fmax} onChange={(e) => setP((s) => ({ ...s, Fmax: e.target.value }))} />
        </div>
      </div>

      <div style={{ width: "100%", height: 340, marginTop: 12 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid />
            <XAxis dataKey="F" label={{ value: "F (N)", position: "insideBottom", offset: -5 }} />
            <YAxis label={{ value: "a (m/s²)", angle: -90, position: "insideLeft" }} tickFormatter={(v) => fmt(v, 4)} />
            <Tooltip formatter={(v) => fmt(v, 6)} labelFormatter={(x) => `F = ${fmt(x, 6)} N`} />
            <ReferenceLine y={0} />
            <Line type="monotone" dataKey="aNo" dot={false} name="Sin rozamiento" strokeDasharray="5 4" />
            <Line type="monotone" dataKey="aK" dot={false} name="Con rozamiento (cinético)" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
