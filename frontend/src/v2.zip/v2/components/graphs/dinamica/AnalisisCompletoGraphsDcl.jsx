import React, { useMemo, useState } from "react";

export default function AnalisisCompletoDcl() {
  const [p, setP] = useState({
    m: 3,
    g: 9.8,
    F: 12,
    mu_s: 0.4,
    mu_k: 0.25,
    mode: "static", // "static" | "kinetic"
    showComponents: false,
  });

  const safe = useMemo(() => {
    const num = (x, fb) => {
      const n = typeof x === "number" ? x : Number(String(x ?? "").replace(",", "."));
      return Number.isFinite(n) ? n : fb;
    };
    const m = Math.max(0.001, num(p.m, 3));
    const g = Math.max(0, num(p.g, 9.8));
    const F = num(p.F, 12);
    const mu_s = Math.max(0, num(p.mu_s, 0.4));
    const mu_k = Math.max(0, num(p.mu_k, 0.25));
    const mode = p.mode === "kinetic" ? "kinetic" : "static";
    return { m, g, F, mu_s, mu_k, mode, showComponents: !!p.showComponents };
  }, [p]);

  const N = safe.m * safe.g;
  const fMax = safe.mu_s * N;
  const fK = safe.mu_k * N;

  // en estático, el rozamiento “se ajusta” hasta fMax
  const f = safe.mode === "static" ? clampAbs(safe.F, 0, fMax) : clampAbs(safe.F, 0, fK);
  const isSlip = safe.mode === "static" && Math.abs(safe.F) > fMax;

  return (
    <div className="v2-card" style={{ padding: 12 }}>
      <div className="v2-card-title">DCL: análisis completo con rozamiento</div>
      <div className="muted" style={{ marginTop: 6 }}>
        Plantilla horizontal: {safe.mode === "static" ? "estático" : "cinético"} · N = mg · f = μN (según caso)
      </div>

      <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
        <div className="v2-card">
          <div className="v2-card-title">m (kg)</div>
          <input className="form-control" inputMode="decimal" value={p.m} onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))} />
        </div>
        <div className="v2-card">
          <div className="v2-card-title">F (N)</div>
          <input className="form-control" inputMode="decimal" value={p.F} onChange={(e) => setP((s) => ({ ...s, F: e.target.value }))} />
        </div>
        <div className="v2-card">
          <div className="v2-card-title">μ_s</div>
          <input className="form-control" inputMode="decimal" value={p.mu_s} onChange={(e) => setP((s) => ({ ...s, mu_s: e.target.value }))} />
        </div>
        <div className="v2-card">
          <div className="v2-card-title">μ_k</div>
          <input className="form-control" inputMode="decimal" value={p.mu_k} onChange={(e) => setP((s) => ({ ...s, mu_k: e.target.value }))} />
        </div>
        <div className="v2-card">
          <div className="v2-card-title">Modo</div>
          <select className="form-control" value={p.mode} onChange={(e) => setP((s) => ({ ...s, mode: e.target.value }))}>
            <option value="static">Estático</option>
            <option value="kinetic">Cinético</option>
          </select>
          <label style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 8 }}>
            <input type="checkbox" checked={!!p.showComponents} onChange={(e) => setP((s) => ({ ...s, showComponents: e.target.checked }))} />
            <span className="muted">Mostrar valores</span>
          </label>
        </div>
      </div>

      <div className="muted" style={{ marginTop: 10 }}>
        N = <b>{fmt(N)} N</b> · f_max = <b>{fmt(fMax)} N</b> · f_k = <b>{fmt(fK)} N</b>{" "}
        {isSlip ? <b style={{ color: "rgba(248,113,113,0.95)" }}> · (En estático: esto implicaría deslizamiento)</b> : null}
      </div>

      <div style={{ marginTop: 12, width: "100%", height: 600 }}>
        <svg viewBox="0 0 820 560" width="100%" height="100%">
          <defs>
            <marker id="arr" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto">
              <path d="M0,0 L10,5 L0,10 Z" fill="rgba(226,232,240,0.92)" />
            </marker>
          </defs>

          <rect x="18" y="18" width="784" height="264" rx="18" fill="rgba(148,163,184,0.06)" stroke="rgba(255,255,255,0.08)" />

          {/* suelo */}
          <line x1="80" y1="170" x2="740" y2="170" stroke="rgba(226,232,240,0.35)" strokeWidth="4" />

          {/* bloque (reducido en 1/3 y centrado) */}
          <rect x="320" y="120" width="80" height="47" rx="8" fill="rgba(226,232,240,0.20)" stroke="rgba(226,232,240,0.25)" />
          <text x="360" y="140" textAnchor="middle" fontSize="10" fill="rgba(226,232,240,0.75)">
            bloque
          </text>

          {/* origen */}
          {(() => {
            const ox = 360; // centrado en el bloque
            const oy = 145; // centro del bloque

            const Fdir = safe.F >= 0 ? 1 : -1;
            const fdir = -Fdir;

            const LF = clampLen(Math.abs(safe.F) * 6.7, 23, 147); // reducido en 1/3
            const Lf = clampLen(Math.abs(f) * 6.7, 13, 133); // reducido en 1/3
            const Lmg = 93; // ~140 * 2/3
            const LN = 80; // ~120 * 2/3

            return (
              <g>
                <circle cx={ox} cy={oy} r="4.5" fill="rgba(226,232,240,0.9)" />

                {/* F */}
                <line x1={ox} y1={oy} x2={ox + Fdir * LF} y2={oy} stroke="rgba(96,165,250,0.95)" strokeWidth="3" markerEnd="url(#arr)" />
                <text x={ox + Fdir * (LF + 10)} y={oy + 4} fontSize="11" fill="rgba(96,165,250,0.95)" fontWeight="700">
                  F
                </text>

                {/* f */}
                <line x1={ox} y1={oy} x2={ox + fdir * Lf} y2={oy} stroke="rgba(251,146,60,0.95)" strokeWidth="3" markerEnd="url(#arr)" />
                <text x={ox + fdir * (Lf + 10)} y={oy + 4} fontSize="11" fill="rgba(251,146,60,0.95)" fontWeight="700">
                  f
                </text>

                {/* N */}
                <line x1={ox} y1={oy} x2={ox} y2={oy - LN} stroke="rgba(34,197,94,0.95)" strokeWidth="3" markerEnd="url(#arr)" />
                <text x={ox + 8} y={oy - LN + 5} fontSize="11" fill="rgba(34,197,94,0.95)" fontWeight="700">
                  N
                </text>

                {/* mg */}
                <line x1={ox} y1={oy} x2={ox} y2={oy + Lmg} stroke="rgba(248,113,113,0.95)" strokeWidth="3" markerEnd="url(#arr)" />
                <text x={ox + 8} y={oy + Lmg + 10} fontSize="11" fill="rgba(248,113,113,0.95)" fontWeight="700">
                  mg
                </text>

                {safe.showComponents ? (
                  <g>
                    <text x="90" y="60" fontSize="11" fill="rgba(226,232,240,0.75)">
                      Estático: f = min(|F|, μ_s N) · Cinético: f = μ_k N
                    </text>
                  </g>
                ) : null}
              </g>
            );
          })()}
        </svg>
      </div>
    </div>
  );
}

function clampAbs(x, minAbs, maxAbs) {
  const s = Math.sign(x) || 1;
  const a = Math.min(maxAbs, Math.max(minAbs, Math.abs(x)));
  return s * a;
}
function clampLen(x, a, b) {
  const n = Number(x);
  if (!Number.isFinite(n)) return a;
  return Math.min(b, Math.max(a, n));
}
function fmt(x) {
  const n = Number(x);
  if (!Number.isFinite(n)) return "—";
  const a = Math.abs(n);
  const digits = a >= 100 ? 1 : a >= 10 ? 2 : 3;
  return n.toFixed(digits).replace(/\.?0+$/, "");
}
