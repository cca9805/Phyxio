import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
  ReferenceLine,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function buildData({ m, g, aMin, aMax }, n = 240) {
  const data = [];
  for (let i = 0; i <= n; i++) {
    const a = aMin + ((aMax - aMin) * i) / n;
    const T = m * (g - a);
    data.push({ a, T });
  }
  return data;
}

export default function BloqueColganteGraphs() {
  const [p, setP] = useState({
    m: 2.0,
    g: 9.8,
    a: 1.5, // positivo = hacia abajo (según la teoría)
    aMin: -5,
    aMax: 10,
  });

  const safe = useMemo(() => {
    const m = Math.max(0.0001, Number(p.m) || 2.0);
    const g = Math.max(0, Number(p.g) || 9.8);
    const aMin = Number.isFinite(Number(p.aMin)) ? Number(p.aMin) : -5;
    const aMax = Number.isFinite(Number(p.aMax)) ? Number(p.aMax) : 10;
    const lo = Math.min(aMin, aMax);
    const hi = Math.max(aMin, aMax);
    const a = Math.max(lo, Math.min(hi, Number(p.a) || 0));
    return { m, g, aMin: lo, aMax: hi, a };
  }, [p]);

  const data = useMemo(() => buildData(safe, 240), [safe]);
  const Tnow = useMemo(() => safe.m * (safe.g - safe.a), [safe]);

  return (
    <div className="v2-card" style={{ padding: 12 }}>
      <div className="v2-card-title">Bloque colgante</div>
      <div className="muted" style={{ marginTop: 6 }}>
        Relación: <b>T = m(g − a)</b> (tomando <b>a positiva hacia abajo</b>)
      </div>

      <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
        <div className="v2-card">
          <div className="v2-card-title">m (kg)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.m}
            onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">g (m/s²)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.g}
            onChange={(e) => setP((s) => ({ ...s, g: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">a (m/s²)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.a}
            onChange={(e) => setP((s) => ({ ...s, a: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">rango a: [min, max]</div>
          <div style={{ display: "flex", gap: 8 }}>
            <input
              className="form-control"
              inputMode="decimal"
              value={p.aMin}
              onChange={(e) => setP((s) => ({ ...s, aMin: e.target.value }))}
            />
            <input
              className="form-control"
              inputMode="decimal"
              value={p.aMax}
              onChange={(e) => setP((s) => ({ ...s, aMax: e.target.value }))}
            />
          </div>
        </div>
      </div>

      <div className="muted" style={{ marginTop: 10 }}>
        T = <b>{fmt(Tnow, 6)} N</b>
      </div>

      <div style={{ width: "100%", height: 340, marginTop: 12 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid />
            <XAxis
              dataKey="a"
              type="number"
              domain={[safe.aMin, safe.aMax]}
              tickFormatter={(v) => fmt(v, 3)}
              label={{ value: "a (m/s²)", position: "insideBottom", offset: -5 }}
            />
            <YAxis
              tickFormatter={(v) => fmt(v, 4)}
              label={{ value: "T (N)", angle: -90, position: "insideLeft" }}
            />
            <Tooltip
              formatter={(v) => fmt(v, 6)}
              labelFormatter={(x) => `a = ${fmt(x, 6)} m/s²`}
            />
            <ReferenceLine y={0} />
            <Line type="monotone" dataKey="T" dot={false} name="T(a)" />
            <ReferenceDot x={safe.a} y={Tnow} r={5} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
