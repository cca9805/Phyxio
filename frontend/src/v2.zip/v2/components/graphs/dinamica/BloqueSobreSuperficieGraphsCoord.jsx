import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function buildData({ m, mu, g, Fmax = 40 }, n = 200) {
  const data = [];
  for (let i = 0; i <= n; i++) {
    const F = (Fmax * i) / n;
    const aNo = F / m;
    const aYes = Math.max(0, (F - mu * m * g) / m);
    data.push({ F, aNo, aYes });
  }
  return data;
}

export default function BloqueSobreSuperficieGraphs() {
  const [p, setP] = useState({
    m: 2,
    mu: 0.2,
    g: 9.8,
    Fmax: 40,
  });

  const data = useMemo(() => buildData(p, 200), [p]);

  return (
    <div className="v2-card" style={{ padding: 12 }}>
      <div className="v2-card-title">Bloque sobre superficie</div>
      <div className="muted" style={{ marginBottom: 8 }}>
        Aceleración en función de la fuerza aplicada
      </div>

      <div className="v2-grid-fill-inputs">
        <div className="v2-card">
          <div className="v2-card-title">m (kg)</div>
          <input
            className="form-control"
            value={p.m}
            inputMode="decimal"
            onChange={(e) => setP({ ...p, m: Number(e.target.value) })}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">μ</div>
          <input
            className="form-control"
            value={p.mu}
            inputMode="decimal"
            onChange={(e) => setP({ ...p, mu: Number(e.target.value) })}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">F max (N)</div>
          <input
            className="form-control"
            value={p.Fmax}
            inputMode="decimal"
            onChange={(e) => setP({ ...p, Fmax: Number(e.target.value) })}
          />
        </div>
      </div>

      <div style={{ width: "100%", height: 340, marginTop: 12 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid />
            <XAxis
              dataKey="F"
              label={{ value: "F (N)", position: "insideBottom", offset: -5 }}
            />
            <YAxis
              label={{ value: "a (m/s²)", angle: -90, position: "insideLeft" }}
            />
            <Tooltip formatter={(v) => fmt(v, 4)} />
            <ReferenceLine y={0} />
            <Line
              type="monotone"
              dataKey="aNo"
              name="Sin rozamiento"
              strokeDasharray="5 4"
            />
            <Line
              type="monotone"
              dataKey="aYes"
              name="Con rozamiento"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
