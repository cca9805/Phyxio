
// CoeficienteDeRozamientoGraphsCoord.jsx
// Estilo y estructura alineados con DiagramasCuerpoLibreGraphsCoord.jsx

import { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function toNum(v, d) {
  if (v == null || v === "") return d;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : d;
}

export default function CoeficienteDeRozamientoGraphsCoord() {
  const [mode, setMode] = useState("measure"); // measure | incline
  const [mu, setMu] = useState(0.3);
  const [N, setN] = useState(120);
  const [f, setF] = useState(30);
  const [theta, setTheta] = useState(20);
  
  const [showGrid, setShowGrid] = useState(true);
  const [showPoint, setShowPoint] = useState(true);

  const safe = useMemo(() => ({
    mu: Math.max(0, Math.min(2.5, toNum(mu, 0.3))),
    N: Math.max(0, Math.min(400, toNum(N, 120))),
    f: Math.max(0, Math.min(400, toNum(f, 30))),
    theta: Math.max(0, Math.min(60, toNum(theta, 20)))
  }), [mu, N, f, theta]);

  const muFromPoint = safe.N > 0 ? safe.f / safe.N : null;
  const muMin = Math.tan((safe.theta * Math.PI) / 180);

  const data = useMemo(() => {
    if (mode === "measure") {
      return Array.from({ length: 41 }, (_, i) => {
        const N = i * 10;
        return { N, f: safe.mu * N };
      });
    }
    return Array.from({ length: 61 }, (_, i) => {
      const rad = (i * Math.PI) / 180;
      return { theta: i, muMin: Math.tan(rad) };
    });
  }, [mode, safe.mu]);

  return (
    <div className="v2-graphs">
      {/* Card azul - Configuración principal */}
      <div className="v2-card" style={{ background: 'rgba(59, 130, 246, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div className="v2-grid-fill-inputs">
          <div className="v2-input-group">
            <label>📊 Modo</label>
            <select className="form-control" value={mode} onChange={e => setMode(e.target.value)}>
              <option value="measure">f vs N</option>
              <option value="incline">μmin vs θ</option>
            </select>
          </div>

          {mode === "measure" ? (
            <>
              <div className="v2-input-group">
                <label>⚙️ μ</label>
                <input className="form-control" value={mu} onChange={e => setMu(e.target.value)} />
              </div>
              <div className="v2-input-group">
                <label>⬆️ N (N)</label>
                <input className="form-control" value={N} onChange={e => setN(e.target.value)} />
              </div>
              <div className="v2-input-group">
                <label>↔️ f (N)</label>
                <input className="form-control" value={f} onChange={e => setF(e.target.value)} />
              </div>
            </>
          ) : (
            <div className="v2-input-group">
              <label>📐 θ (°)</label>
              <input className="form-control" value={theta} onChange={e => setTheta(e.target.value)} />
            </div>
          )}
        </div>
      </div>

      {/* Card verde - Controles de visualización */}
      <div className="v2-card" style={{ background: 'rgba(34, 197, 94, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div style={{ 
          display: "flex", 
          gap: 18, 
          alignItems: "center", 
          flexWrap: "wrap",
          justifyContent: "center"
        }}>
          <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
          
          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showGrid"
              checked={showGrid}
              onChange={(e) => setShowGrid(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showGrid">Cuadrícula</label>
          </div>

          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showPoint"
              checked={showPoint}
              onChange={(e) => setShowPoint(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showPoint">Punto de referencia</label>
          </div>
        </div>
      </div>

      <div className="v2-card">
        <ResponsiveContainer width="100%" height={320}>
          <LineChart data={data}>
            {showGrid && <CartesianGrid />}
            {mode === "measure" ? (
              <>
                <XAxis dataKey="N" />
                <YAxis />
                <Tooltip formatter={v => fmt(v, 4)} />
                <Line dataKey="f" dot={false} />
                {showPoint && <ReferenceDot x={safe.N} y={safe.f} r={5} />}
              </>
            ) : (
              <>
                <XAxis dataKey="theta" />
                <YAxis />
                <Tooltip formatter={v => fmt(v, 4)} />
                <Line dataKey="muMin" dot={false} />
                {showPoint && <ReferenceDot x={safe.theta} y={muMin} r={5} />}
              </>
            )}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
