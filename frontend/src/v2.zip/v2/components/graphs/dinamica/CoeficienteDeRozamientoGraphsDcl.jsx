import { useMemo, useState } from "react";

/**
 * Coeficiente de rozamiento (DCL)
 * - Dibuja W, N y el rozamiento máximo f_max = μ·N como vectores.
 * - Escenas: mesa y plano inclinado (con ejes paralelos/perpendiculares opcionales).
 */
export default function CoeficienteDeRozamientoGraphsDcl() {
  const [scene, setScene] = useState("horizontal"); // horizontal | incline
  const [mu, setMu] = useState(0.3);
  const [theta, setTheta] = useState(20);

  const [showAxes, setShowAxes] = useState(true);
  const [showLocalAxes, setShowLocalAxes] = useState(true);
  const [showLabels, setShowLabels] = useState(true);

  const muu = useMemo(() => {
    const n = Number(String(mu).replace(",", "."));
    return Number.isFinite(n) ? Math.max(0, Math.min(2.5, n)) : 0.3;
  }, [mu]);

  const thDeg = useMemo(() => {
    const n = Number(String(theta).replace(",", "."));
    return Number.isFinite(n) ? Math.max(0, Math.min(60, n)) : 20;
  }, [theta]);

  const th = (thDeg * Math.PI) / 180;

  // Estilo (coherente con tu paleta DCL)
  const C = {
    bg: "#b8c5ffff",
    card: "#ffffff",
    stroke: "#d6e5ff",
    ink: "#0f172a",
    muted: "#64748b",
    axis: "#5b7aa8",
    W: "#ff2d55",
    N: "#34c759",
    fr: "#7c3aed",
    helper: "#64748b",
  };

  const fmt = (x) => {
    const n = Number(x);
    if (!Number.isFinite(n)) return "—";
    return n.toFixed(3).replace(".", ",");
  };

  // Geometría
  const Wsvg = 880;
  const Hsvg = 420;
  const O = { x: 560, y: 235 }; // origen vectorial
  const pxPerUnit = 16;

  // Vectores didácticos (magnitudes relativas)
  const Wmag = 10; // peso base
  const Nmag = scene === "incline" ? Wmag * Math.cos(th) : Wmag;
  const fMax = muu * Nmag;

  // Direcciones
  const eX = { x: 1, y: 0 };
  const eY = { x: 0, y: -1 }; // en SVG y crece hacia abajo, por eso y negativa para "arriba"

  // Ejes locales en el plano
  const ePar = { x: Math.cos(th), y: -Math.sin(th) };   // paralelo (sube la rampa a la derecha)
  const ePerp = { x: -Math.sin(th), y: -Math.cos(th) }; // perpendicular hacia fuera

  // W siempre vertical hacia abajo (en SVG +y)
  const vW = { x: 0, y: +Wmag };

  // N: vertical arriba (mesa) o perpendicular al plano
  const vN = scene === "incline"
    ? { x: ePerp.x * Nmag, y: -ePerp.y * Nmag } // ojo: ePerp ya tiene y invertida
    : { x: 0, y: -Nmag };

  // f_max: sobre superficie, opuesto al posible deslizamiento
  const vF = scene === "incline"
    ? { x: -ePar.x * fMax, y: +ePar.y * fMax } // hacia arriba del plano (izquierda si ePar apunta derecha)
    : { x: -fMax, y: 0 };

  // Umbral (estático): μ_min = tanθ
  const muMin = Math.tan(th);
  const ok = scene === "incline" ? muu >= muMin : true;

  const toPt = (v) => ({ x: O.x + v.x * pxPerUnit, y: O.y + v.y * pxPerUnit });

  const Arrow = ({ v, stroke, label }) => {
    const p1 = O;
    const p2 = toPt(v);
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const L = Math.hypot(dx, dy) || 1;
    const ux = dx / L;
    const uy = dy / L;

    const head = 14;
    const wing = 8;

    const hx = p2.x;
    const hy = p2.y;
    const lx = hx - ux * head - uy * wing;
    const ly = hy - uy * head + ux * wing;
    const rx = hx - ux * head + uy * wing;
    const ry = hy - uy * head - ux * wing;

    return (
      <g>
        <line x1={p1.x} y1={p1.y} x2={hx} y2={hy} stroke={stroke} strokeWidth={8} strokeLinecap="round" />
        <polygon points={`${hx},${hy} ${lx},${ly} ${rx},${ry}`} fill={stroke} opacity="0.96" />
        {showLabels && (
          <text x={hx + 10} y={hy + 6} fontSize="18" fontWeight="900" fill={stroke}>
            {label}
          </text>
        )}
      </g>
    );
  };

  const Axis = ({ dir, label }) => {
    const len = 11;
    const v = { x: dir.x * len, y: -dir.y * len }; // dir en coord “física” (y arriba), ajustamos a SVG
    const p2 = toPt(v);
    return (
      <g opacity="0.9">
        <line x1={O.x} y1={O.y} x2={p2.x} y2={p2.y} stroke={C.axis} strokeWidth={4} strokeLinecap="round" />
        <text x={p2.x + 8} y={p2.y + 6} fontSize="14" fill={C.axis} fontWeight="800">
          {label}
        </text>
      </g>
    );
  };

  return (
    <div className="v2-graphs">
      {/* Card azul - Configuración principal */}
      <div className="v2-card" style={{ background: 'rgba(59, 130, 246, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div className="v2-grid-fill-inputs">
          <div className="v2-input-group">
            <label>🏗️ Escena</label>
            <select className="form-control" value={scene} onChange={(e) => setScene(e.target.value)}>
              <option value="horizontal">Mesa</option>
              <option value="incline">Plano inclinado</option>
            </select>
          </div>

          <div className="v2-input-group">
            <label>⚙️ μ</label>
            <input className="form-control" inputMode="decimal" value={mu} onChange={(e) => setMu(e.target.value)} />
          </div>

          <div className="v2-input-group" style={{ opacity: scene === "incline" ? 1 : 0.55 }}>
            <label>📐 θ (°)</label>
            <input
              className="form-control"
              inputMode="numeric"
              value={theta}
              onChange={(e) => setTheta(e.target.value)}
              disabled={scene !== "incline"}
            />
          </div>
        </div>
      </div>

      {/* Card verde - Controles de visualización */}
      <div className="v2-card" style={{ background: 'rgba(34, 197, 94, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div style={{ 
          display: "flex", 
          gap: 18, 
          alignItems: "center", 
          flexWrap: "wrap",
          justifyContent: "center"
        }}>
          <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
          
          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showLabels"
              checked={showLabels}
              onChange={(e) => setShowLabels(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showLabels">Etiquetas</label>
          </div>

          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showAxes"
              checked={showAxes}
              onChange={(e) => setShowAxes(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showAxes">Ejes</label>
          </div>

          <div className="v2-checkbox-container" style={{ opacity: scene === "incline" ? 1 : 0.55 }}>
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showLocalAxes"
              checked={showLocalAxes}
              onChange={(e) => setShowLocalAxes(e.target.checked)}
              disabled={scene !== "incline"}
            />
            <label className="v2-checkbox-label" htmlFor="showLocalAxes">Ejes (∥, ⟂)</label>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12, overflow: "hidden" }}>
        <svg viewBox={`0 0 ${Wsvg} ${Hsvg}`} width="100%" height="340" style={{ display: "block" }}>
          <rect x="0" y="0" width={Wsvg} height={Hsvg} fill={C.bg} />

          {/* Panel info */}
          <rect x="18" y="18" width="360" height="132" rx="14" fill={C.card} stroke={C.stroke} strokeWidth="3" opacity="0.96" />
          <text x="34" y="50" fontSize="18" fontWeight="900" fill={C.ink}>
            Datos
          </text>
          <text x="34" y="78" fontSize="14" fill={C.muted}>
            f_max = μ·N = {fmt(fMax)} (u.)
          </text>
          {scene === "incline" ? (
            <>
              <text x="34" y="100" fontSize="14" fill={C.muted}>
                μ_min = tanθ = {fmt(muMin)}
              </text>
              <text x="34" y="122" fontSize="14" fill={ok ? C.N : C.W} fontWeight="800">
                {ok ? "μ ≥ tanθ → NO desliza ✅" : "μ < tanθ → DESLIZA ⚠️"}
              </text>
            </>
          ) : (
            <text x="34" y="100" fontSize="14" fill={C.muted}>
              En mesa: N ≈ W y f_max es el límite de rozamiento.
            </text>
          )}

          {/* Punto */}
          <circle cx={O.x} cy={O.y} r="10" fill={C.ink} opacity="0.85" />

          {/* Ejes globales */}
          {showAxes && (
            <>
              <Axis dir={eX} label="x" />
              <Axis dir={{ x: 0, y: 1 }} label="y" />
            </>
          )}

          {/* Ejes locales */}
          {scene === "incline" && showLocalAxes && (
            <g opacity="0.9">
              <Axis dir={{ x: ePar.x, y: -ePar.y }} label="∥" />
              <Axis dir={{ x: -ePerp.x, y: ePerp.y }} label="⟂" />
            </g>
          )}

          {/* Vectores */}
          <Arrow v={vW} stroke={C.W} label="W" />
          <Arrow v={vN} stroke={C.N} label="N" />
          <Arrow v={vF} stroke={C.fr} label="f_max" />
        </svg>
      </div>
    </div>
  );
}
