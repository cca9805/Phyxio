import React, { useMemo, useState } from "react";

/**
 * DCL: bloque sobre plano inclinado con rozamiento.
 * Muestra: Peso (mg), Normal (N), Rozamiento (f), componente paralela (mg sinθ),
 * componente perpendicular (mg cosθ) y ejes paralelo/perpendicular al plano.
 *
 * Convención: el plano sube hacia la derecha (θ). El bloque tendería a deslizar hacia abajo del plano.
 * Rozamiento cinético dibujado "hacia arriba del plano" (opuesto al deslizamiento).
 */
export default function PlanoInclinadoConRozamientoDcl() {
  const [p, setP] = useState({
    thetaDeg: 30,
    mu: 0.2,
    m: 2,
    g: 9.8,
    showComponents: true,
    showEjes: true,
  });

  const safe = useMemo(() => {
    const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
    const thetaDeg = clamp(Number(p.thetaDeg) || 30, 0, 70);
    const mu = clamp(Number(p.mu) || 0.2, 0, 1.2);
    const m = Math.max(0.001, Number(p.m) || 2);
    const g = Math.max(0, Number(p.g) || 9.8);
    return {
      thetaDeg,
      theta: (thetaDeg * Math.PI) / 180,
      mu,
      m,
      g,
      showComponents: !!p.showComponents,
      showEjes: !!p.showEjes,
    };
  }, [p]);

  const mg = safe.m * safe.g;
  const N = mg * Math.cos(safe.theta);
  const f = safe.mu * N;
  const mgPar = mg * Math.sin(safe.theta);
  const mgPer = mg * Math.cos(safe.theta);

  // escala de fuerzas a pixeles (no física exacta, solo visual estable)
  const k = 6.7; // px por N aproximado (reducido de 10 a ~6.7)
  const Lmg = clampLen(mg * k, 27, 147); // reducido en 1/3
  const LN = clampLen(N * k, 20, 133); // reducido en 1/3
  const Lf = clampLen(f * k, 13, 120); // reducido en 1/3
  const Lpar = clampLen(mgPar * k, 13, 120); // reducido en 1/3
  const Lper = clampLen(mgPer * k, 13, 120); // reducido en 1/3

  return (
    <div className="v2-card" style={{ padding: 12 }}>
      <div className="v2-card-title">DCL: plano inclinado con rozamiento</div>
      <div className="muted" style={{ marginTop: 6 }}>
        Fuerzas: <b>mg</b>, <b>N</b>, <b>f = μN</b> (rozamiento hacia arriba del plano si el bloque tiende a bajar)
      </div>

      <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
        <div className="v2-card">
          <div className="v2-card-title">θ (°)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.thetaDeg}
            onChange={(e) => setP((s) => ({ ...s, thetaDeg: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">μ</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.mu}
            onChange={(e) => setP((s) => ({ ...s, mu: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">m (kg)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.m}
            onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">g (m/s²)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.g}
            onChange={(e) => setP((s) => ({ ...s, g: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <label style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <input
              type="checkbox"
              checked={!!p.showComponents}
              onChange={(e) => setP((s) => ({ ...s, showComponents: e.target.checked }))}
            />
            <span className="muted">Mostrar componentes</span>
          </label>
          <label style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 8 }}>
            <input
              type="checkbox"
              checked={!!p.showEjes}
              onChange={(e) => setP((s) => ({ ...s, showEjes: e.target.checked }))}
            />
            <span className="muted">Mostrar ejes del plano</span>
          </label>
        </div>
      </div>

      <div className="muted" style={{ marginTop: 10 }}>
        Valores (aprox):{" "}
        <b>N = {fmt(N)} N</b>, <b>f = μN = {fmt(f)} N</b>,{" "}
        <b>mg·sinθ = {fmt(mgPar)} N</b>
      </div>

      <div style={{ marginTop: 12, width: "100%", height: 820 }}>
        <svg viewBox="0 0 820 820" width="100%" height="100%">
          <defs>
            <marker id="arr" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto">
              <path d="M0,0 L10,5 L0,10 Z" fill="rgba(226,232,240,0.92)" />
            </marker>
          </defs>

          {/* panel */}
          <rect x="18" y="18" width="784" height="384" rx="18" fill="rgba(252, 2, 2, 0.06)" stroke="rgba(255,255,255,0.08)" />

          {/* Sistema plano + bloque (rotan juntos alrededor del centro del plano) */}
          {(() => {
            // Centro fijo del card donde estará el centro del plano (desplazado a la izquierda)
            const centerX = 300; // desplazado de 410 a 300
            const centerY = 210; // centro vertical del panel
            
            // Dimensiones del plano (reducidas en 1/3)
            const planoWidth = 307; // ~460 * 2/3
            const planoHeight = 8; // ~12 * 2/3
            
            // Posición del bloque relativa al centro del plano (en coordenadas del plano)
            const bloqueOffsetX = 0; // centrado horizontalmente en el plano
            const bloqueOffsetY = -21; // justo sobre el plano: -(planoHeight/2 + bloqueHeight/2)
            // bloqueHeight = 33, planoHeight = 8 -> offset = -(4 + 17) = -21
            
            return (
              <g transform={`translate(${centerX},${centerY}) rotate(${-safe.thetaDeg})`}>
                {/* plano (centrado en el origen) */}
                <rect 
                  x={-planoWidth/2} 
                  y={-planoHeight/2} 
                  width={planoWidth} 
                  height={planoHeight} 
                  rx="6" 
                  fill="rgba(226,232,240,0.16)" 
                  stroke="rgba(226,232,240,0.18)" 
                />
                
                {/* bloque sobre el plano (reducido en 1/3) */}
                <g transform={`translate(${bloqueOffsetX},${bloqueOffsetY})`}>
                  <rect x="-27" y="-17" width="53" height="33" rx="7" fill="rgba(226,232,240,0.20)" stroke="rgba(226,232,240,0.28)" />
                  <text x="0" y="-8" textAnchor="middle" fontSize="10" fill="rgba(226,232,240,0.75)">
                    bloque
                  </text>
                </g>
              </g>
            );
          })()}

          {/* origen de fuerzas (centro del bloque) */}
          {(() => {
            // Calcular posición del centro del bloque en coordenadas mundo
            const centerX = 300; // mismo valor que arriba
            const centerY = 210;
            const bloqueOffsetX = 0;
            const bloqueOffsetY = -21; // mismo valor que arriba (actualizado)
            
            // Aplicar rotación para obtener coordenadas mundo
            const theta = safe.theta;
            const cosT = Math.cos(-theta); // negativo porque rotamos -thetaDeg
            const sinT = Math.sin(-theta);
            
            const ox = centerX + bloqueOffsetX * cosT - bloqueOffsetY * sinT;
            const oy = centerY + bloqueOffsetX * sinT + bloqueOffsetY * cosT;

            // vectores en coordenadas mundo:
            // mg: vertical hacia abajo
            // N: perpendicular al plano (mundo) -> dirección normal
            // f: paralelo al plano hacia arriba (opuesto a deslizar abajo)

            // En SVG: Y crece hacia abajo, X crece hacia la derecha
            // Plano inclinado: sube de izquierda-abajo a derecha-arriba
            // Para θ positivo (plano subiendo a la derecha):
            const tx = Math.cos(theta);   // tangente x (hacia la derecha)
            const ty = -Math.sin(theta);  // tangente y (hacia arriba en SVG = negativo)
            const nx = Math.sin(theta);   // normal x (hacia la derecha)
            const ny = Math.cos(theta);   // normal y (hacia abajo en SVG = positivo, pero "saliendo" del plano)

            // longitudes visuales
            const mgx = 0, mgy = Lmg;
            const Nvx = nx * LN, Nvy = ny * LN;
            const fvx = tx * Lf, fvy = ty * Lf;

            return (
              <g>
                {/* punto */}
                <circle cx={ox} cy={oy} r="4.5" fill="rgba(226,232,240,0.9)" />

                {/* ejes */}
                {safe.showEjes ? (
                  <g>
                    <line x1={ox} y1={oy} x2={ox + tx * 180} y2={oy + ty * 180} stroke="rgba(96,165,250,0.75)" strokeWidth="2.5" markerEnd="url(#arr)" />
                    <text x={ox + tx * 187} y={oy + ty * 187} fontSize="11" fill="rgba(96,165,250,0.95)">
                      eje ∥
                    </text>

                    <line x1={ox} y1={oy} x2={ox + nx * 73} y2={oy + ny * 73} stroke="rgba(34,197,94,0.75)" strokeWidth="2.5" markerEnd="url(#arr)" />
                    <text x={ox + nx * 107} y={oy + ny * 67} fontSize="11" fill="rgba(34,197,94,0.95)">
                      eje ⟂
                    </text>
                  </g>
                ) : null}

                {/* mg */}
                <line x1={ox} y1={oy} x2={ox + mgx} y2={oy + mgy} stroke="rgba(248,113,113,0.95)" strokeWidth="3" markerEnd="url(#arr)" />
                <text x={ox + 10} y={oy + mgy + 12} fontSize="11" fill="rgba(248,113,113,0.95)" fontWeight="700">
                  mg
                </text>

                {/* N */}
                <line x1={ox} y1={oy} x2={ox + Nvx} y2={oy + Nvy} stroke="rgba(34,197,94,0.95)" strokeWidth="3" markerEnd="url(#arr)" />
                <text x={ox + Nvx + 6} y={oy + Nvy + 4} fontSize="11" fill="rgba(34,197,94,0.95)" fontWeight="700">
                  N
                </text>

                {/* f */}
                <line x1={ox} y1={oy} x2={ox + fvx} y2={oy + fvy} stroke="rgba(251,146,60,0.95)" strokeWidth="3" markerEnd="url(#arr)" />
                <text x={ox + fvx - 16} y={oy + fvy - 14} fontSize="11" fill="rgba(251,146,60,0.95)" fontWeight="700">
                  f
                </text>

                {/* componentes de mg */}
                {safe.showComponents ? (
                  <g>
                    {/* mg paralela (hacia abajo del plano) */}
                    <line
                      x1={ox}
                      y1={oy}
                      x2={ox - tx * Lpar}
                      y2={oy - ty * Lpar}
                      stroke="rgba(148,163,184,0.95)"
                      strokeWidth="2.5"
                      markerEnd="url(#arr)"
                      strokeDasharray="5 4"
                    />
                    <text x={ox - tx * (Lpar + 48)} y={oy - ty * (Lpar + 28)} fontSize="10" fill="rgba(148,163,184,0.95)">
                      mg·sinθ
                    </text>

                    {/* mg perpendicular (hacia dentro del plano) */}
                    <line
                      x1={ox}
                      y1={oy}
                      x2={ox - nx * Lper}
                      y2={oy - ny * Lper}
                      stroke="rgba(148,163,184,0.95)"
                      strokeWidth="2.5"
                      markerEnd="url(#arr)"
                      strokeDasharray="5 4"
                    />
                    <text x={ox - nx * (Lper + 78)} y={oy - ny * (Lper + 18)} fontSize="10" fill="rgba(148,163,184,0.95)">
                      mg·cosθ
                    </text>
                  </g>
                ) : null}
              </g>
            );
          })()}

          {/* cajita de ecuaciones */}
          <g transform="translate(520, 85)">
            <rect x="0" y="0" width="270" height="140" rx="14" fill="rgba(0,0,0,0.55)" stroke="rgba(255,255,255,0.12)" />
            <text x="14" y="26" fontSize="13" fill="rgba(226,232,240,0.92)" fontWeight="700">
              Ecuaciones (sobre el plano)
            </text>
            <text x="14" y="52" fontSize="12" fill="rgba(226,232,240,0.78)">
              N = mg·cosθ
            </text>
            <text x="14" y="74" fontSize="12" fill="rgba(226,232,240,0.78)">
              f = μN = μmg·cosθ
            </text>
            <text x="14" y="96" fontSize="12" fill="rgba(226,232,240,0.78)">
              a = g(sinθ − μcosθ)
            </text>
            <text x="14" y="122" fontSize="12" fill="rgba(226,232,240,0.72)">
              θ = {safe.thetaDeg}°, μ = {safe.mu}
            </text>
          </g>
        </svg>
      </div>
    </div>
  );
}

function clampLen(x, a, b) {
  const n = Number(x);
  if (!Number.isFinite(n)) return a;
  return Math.min(b, Math.max(a, n));
}

function fmt(x) {
  const n = Number(x);
  if (!Number.isFinite(n)) return "—";
  const a = Math.abs(n);
  const digits = a >= 100 ? 1 : a >= 10 ? 2 : 3;
  return n.toFixed(digits).replace(/\.?0+$/, "");
}
