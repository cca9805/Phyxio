import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

export default function ConceptoFuerzaCentripetaGraphsCoord() {
  const [m, setM] = useState(1);
  const [r, setR] = useState(2);
  const [v, setV] = useState(10);

  const ac = (v * v) / r;
  const Fc = m * ac;

  const data = useMemo(() => {
    const out = [];
    for (let vv = 0; vv <= 30; vv += 0.5) {
      const a = (vv * vv) / r;
      out.push({ v: vv, ac: a, Fc: m * a });
    }
    return out;
  }, [m, r]);

  return (
    <div className="v2-card">
      <div className="v2-card-title">Centrípeta: dependencia con la velocidad</div>

      <div className="v2-grid-fill-inputs">
        <div className="v2-card">
          <div className="v2-card-title">m (kg)</div>
          <input className="form-control" value={m} onChange={(e) => setM(e.target.value)} />
        </div>
        <div className="v2-card">
          <div className="v2-card-title">r (m)</div>
          <input className="form-control" value={r} onChange={(e) => setR(e.target.value)} />
        </div>
        <div className="v2-card">
          <div className="v2-card-title">v (m/s)</div>
          <input className="form-control" value={v} onChange={(e) => setV(e.target.value)} />
        </div>
      </div>

      <div className="muted" style={{ marginTop: 8 }}>
        a<sub>c</sub> = <b>{fmt(ac)}</b> m/s² · F<sub>c</sub> = <b>{fmt(Fc)}</b> N
      </div>

      <div style={{ width: "100%", height: 320, marginTop: 12 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid />
            <XAxis dataKey="v" label={{ value: "v (m/s)", position: "insideBottom", offset: -5 }} />
            <YAxis label={{ value: "a_c (m/s²)", angle: -90, position: "insideLeft" }} />
            <Tooltip />
            <Line dataKey="ac" dot={false} />
            <ReferenceDot x={v} y={ac} r={5} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
