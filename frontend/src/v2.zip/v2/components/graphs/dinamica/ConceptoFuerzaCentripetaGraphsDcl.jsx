import { useMemo, useState } from "react";

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}
function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  const n = typeof v === "number" ? v : Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

/**
 * DCL – Concepto de fuerza centrípeta
 *
 * Representa:
 * - Fuerzas reales (ejemplo: tensión)
 * - Resultante radial hacia el centro
 *
 * NO introduce fuerza centrífuga
 * NO introduce una "fuerza centrípeta" como agente independiente
 */

export default function ConceptoFuerzaCentripetaGraphsDcl() {
  const [T, setT] = useState(20);
  const [showResultant, setShowResultant] = useState(true);
  const [showLabels, setShowLabels] = useState(true);

  const tension = useMemo(() => clamp(toNum(T, 20), 0, 100), [T]);

  // Escala gráfica
  const scale = 6;
  const Ft = tension * scale;

  // Geometría base
  const W = 900;
  const H = 260;
  const O = { x: 750, y: 130 }; // punto material

  const C = {
    bg: "#b8c5ffff",
    ink: "#0f172a",
    muted: "#64748b",
    tension: "#7c3aed",
    resultant: "#ff2d55",
  };

  const Arrow = ({ dx, dy, color, label, labelOffset = -35 }) => {
    const x2 = O.x + dx;
    const y2 = O.y + dy;

    const L = Math.hypot(dx, dy) || 1;
    const ux = dx / L;
    const uy = dy / L;

    const head = 14;
    const wing = 8;

    const hx = x2;
    const hy = y2;
    const lx = hx - ux * head - uy * wing;
    const ly = hy - uy * head + ux * wing;
    const rx = hx - ux * head + uy * wing;
    const ry = hy - uy * head - ux * wing;

    return (
      <g>
        <line
          x1={O.x}
          y1={O.y}
          x2={hx}
          y2={hy}
          stroke={color}
          strokeWidth="8"
          strokeLinecap="round"
        />
        <polygon points={`${hx - 15},${hy} ${lx - 15},${ly} ${rx - 15},${ry}`} fill={color} />
        {showLabels && (
          <text x={hx + labelOffset} y={hy + 6} fontSize="18" fontWeight="900" fill={color}>
            {label}
          </text>
        )}
      </g>
    );
  };

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Fuerza centrípeta (DCL)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          DCL: el cuerpo es un punto. La "centrípeta" es la <b>resultante radial</b> de las fuerzas reales.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#a78bfa" }}>🔗</span> Tensión (N)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 100 }}
                  inputMode="decimal"
                  value={T}
                  onChange={(e) => setT(e.target.value)}
                />
              </label>
            </div>
          </div>

          {/* Segunda fila: Controles de visualización */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
            
            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showLabels"
                checked={showLabels}
                onChange={(e) => setShowLabels(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showLabels">Etiquetas</label>
            </div>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showResultant"
                checked={showResultant}
                onChange={(e) => setShowResultant(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showResultant">ΣF<sub>rad</sub></label>
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Diagrama de cuerpo libre</div>
        
        <svg viewBox={`0 0 ${W} ${H}`} width="100%" height="340" style={{ marginTop: 10 }}>
          {/* Fondo */}
          <rect width={W} height={H} fill={C.bg} />

          {/* Panel de datos */}
          <rect x="20" y="20" width="200" height="100" rx="12" fill="rgba(255,255,255,0.92)" stroke="#d6e5ff" strokeWidth="2" />
          <text x="35" y="45" fontSize="14" fontWeight="900" fill={C.ink}>
            Datos
          </text>
          <text x="35" y="65" fontSize="12" fill={C.muted}>
            T = {tension.toFixed(2)} N
          </text>
          <text x="35" y="85" fontSize="12" fill={C.resultant}>
            ΣF₍rad₎ = m·a₍c₎
          </text>
          <text x="35" y="105" fontSize="12" fill={C.muted}>
            a₍c₎ = v²/r
          </text>

          {/* Centro de curvatura */}
          <circle cx="330" cy={O.y} r="6" fill={C.muted} />
          <text x="300" y={O.y - 10} fontSize="14" fill={C.muted}>
            Centro
          </text>

          {/* Punto material */}
          <circle cx={O.x} cy={O.y} r="10" fill={C.ink} />
          <line x1={O.x - 12} y1={O.y} x2={O.x + 12} y2={O.y} stroke={C.ink} strokeWidth="2" opacity="0.35" />
          <line x1={O.x} y1={O.y - 12} x2={O.x} y2={O.y + 12} stroke={C.ink} strokeWidth="2" opacity="0.35" />

          {/* Línea radial (guía visual) */}
          <line
            x1={O.x}
            y1={O.y}
            x2={330}
            y2={O.y}
            stroke="#94a3b8"
            strokeWidth="3"
            strokeDasharray="6 6"
          />

          {/* Fuerza real: tensión */}
          <Arrow
            dx={-Ft}
            dy={0}
            color={C.tension}
            label="T"
          />

          {/* Resultante radial (desplazada verticalmente para no solaparse) */}
          {showResultant && (
            <g transform="translate(0, -20)">
              <Arrow
                dx={-Ft}
                dy={0}
                color={C.resultant}
                label="ΣF₍rad₎"
                labelOffset={-80}
              />
            </g>
          )}

          {/* Nota */}
          <text x="40" y="230" fontSize="14" fill={C.muted}>
            ΣF₍rad₎ = m·a₍c₎  →  a₍c₎ = v²/r
          </text>
        </svg>
      </div>
    </div>
  );
}
