
import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";

import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

import {
  defaultParams,
  fictitiousForce,
  relativeAcceleration,
  seriesXandV,
} from "../../../engine/models/dinamica/ConceptoFuerzasFicticias";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

export default function ConceptoFuerzasFicticiasGraphs({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => defaultParams());

  // 🔗 enlazar con calculadora (si viene params)
  useEffect(() => {
    if (!linked || !params) return;
    setP((prev) => ({
      ...prev,
      m: pickParam(params, ["m", "masa"], prev.m),
      a_marco: pickParam(params, ["a_marco", "aMarco", "a_frame", "aFrame", "a"], prev.a_marco),
      x0: pickParam(params, ["x0"], prev.x0),
      v0: pickParam(params, ["v0"], prev.v0),
      tMax: pickParam(params, ["tMax", "t"], prev.tMax),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const m = Math.max(0.01, toNum(p.m, 10));
    const a_marco = toNum(p.a_marco, 2);
    const x0 = toNum(p.x0, 0);
    const v0 = toNum(p.v0, 0);
    const tMax = Math.max(0.5, toNum(p.tMax, 6));
    const nPts = Math.max(60, Math.round(toNum(p.nPts, 200)));
    return { m, a_marco, x0, v0, tMax, nPts };
  }, [p]);

  const a_rel = useMemo(() => relativeAcceleration(safe), [safe]);
  const Ff = useMemo(() => fictitiousForce(safe), [safe]);

  const data = useMemo(() => {
    return seriesXandV({
      x0: safe.x0,
      v0: safe.v0,
      a_rel,
      tMax: safe.tMax,
      nPts: safe.nPts,
    });
  }, [safe, a_rel]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Fuerzas ficticias (Coord)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Ideal (1D, sin fuerzas reales en x): <b>a' = -a_marco</b> · <b>F_fict = -m·a_marco</b>
        </div>

        <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">m (kg)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.m}
              onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">a_marco (m/s²)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.a_marco}
              onChange={(e) => setP((s) => ({ ...s, a_marco: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">x0 (m)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.x0}
              onChange={(e) => setP((s) => ({ ...s, x0: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">v0 (m/s)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.v0}
              onChange={(e) => setP((s) => ({ ...s, v0: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">tMax (s)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.tMax}
              onChange={(e) => setP((s) => ({ ...s, tMax: e.target.value }))}
            />
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Resultado: <b>a' = {fmt(a_rel, 6)} m/s²</b> ·{" "}
          <b>F_fict = {fmt(Ff, 6)} N</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">x'(t) y v'(t) en el marco no inercial</div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis
                dataKey="t"
                type="number"
                domain={[0, safe.tMax]}
                label={{ value: "t (s)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                yAxisId="y1"
                tickFormatter={(v) => fmt(v, 4)}
                label={{ value: "x' (m)", angle: -90, position: "insideLeft" }}
              />
              <YAxis
                yAxisId="y2"
                orientation="right"
                tickFormatter={(v) => fmt(v, 4)}
                label={{ value: "v' (m/s)", angle: -90, position: "insideRight" }}
              />
              <Tooltip
                formatter={(v) => fmt(v, 6)}
                labelFormatter={(x) => `t = ${fmt(x, 4)} s`}
              />
              <ReferenceLine y={0} yAxisId="y1" />
              <ReferenceLine y={0} yAxisId="y2" />

              <Line yAxisId="y1" type="monotone" dataKey="x" dot={false} name="x'(t)" />
              <Line yAxisId="y2" type="monotone" dataKey="v" dot={false} name="v'(t)" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Si no hay fuerzas reales horizontales: <b>a' = -a_marco</b>. La fuerza ficticia actúa como{" "}
          <b>F_fict = -m·a_marco</b>.
        </div>
      </div>
    </div>
  );
}
