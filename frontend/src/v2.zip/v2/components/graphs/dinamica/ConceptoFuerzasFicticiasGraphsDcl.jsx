import React, { useMemo } from "react";
import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

export default function ConceptoFuerzasFicticiasDcl({ params }) {
  const m = useMemo(() => pickParam(params, ["m", "masa"], 10), [params]);
  const a = useMemo(
    () => pickParam(params, ["a_marco", "aMarco", "a_frame", "aFrame", "a"], 2),
    [params]
  );

  const Ff = -m * a; // F_fict = -m a_marco
  const dir = a >= 0 ? 1 : -1;

  const cx = 430;
  const cy = 170;

  return (
    <svg viewBox="0 0 860 340" style={{ width: "100%", height: "auto" }}>
      <defs>
        <marker id="arrRed" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto">
          <path d="M0,0 L10,5 L0,10 Z" fill="rgba(248,113,113,0.95)" />
        </marker>
        <marker id="arr" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto">
          <path d="M0,0 L10,5 L0,10 Z" fill="rgba(226,232,240,0.90)" />
        </marker>
      </defs>

      <rect x="10" y="10" width="840" height="320" rx="18" fill="rgba(15,23,42,0.35)" stroke="rgba(255,255,255,0.08)" />
      <text x="30" y="44" fontSize="14" fill="rgba(226,232,240,0.9)" fontWeight="700">
        DCL (marco no inercial)
      </text>

      {/* cuerpo */}
      <rect x={cx - 55} y={cy - 40} width="110" height="80" rx="14" fill="rgba(226,232,240,0.10)" stroke="rgba(226,232,240,0.22)" />
      <text x={cx} y={cy + 5} textAnchor="middle" fontSize="12" fill="rgba(226,232,240,0.85)" fontWeight="700">
        m
      </text>

      {/* fuerza ficticia */}
      <line
        x1={cx}
        y1={cy}
        x2={cx - dir * 180}
        y2={cy}
        stroke="rgba(248,113,113,0.95)"
        strokeWidth="4"
        markerEnd="url(#arrRed)"
      />
      <text x={cx} y={cy - 18} textAnchor="middle" fontSize="12" fill="rgba(248,113,113,0.95)" fontWeight="700">
        F_fict = {fmt(Ff, 6)} N
      </text>

      {/* peso y normal (guía) */}
      <line x1={cx} y1={cy + 40} x2={cx} y2={cy + 140} stroke="rgba(226,232,240,0.9)" strokeWidth="4" markerEnd="url(#arr)" />
      <text x={cx + 10} y={cy + 132} fontSize="12" fill="rgba(226,232,240,0.85)" fontWeight="700">
        W=mg
      </text>

      <line x1={cx} y1={cy - 40} x2={cx} y2={cy - 140} stroke="rgba(226,232,240,0.9)" strokeWidth="4" markerEnd="url(#arr)" />
      <text x={cx + 10} y={cy - 132} fontSize="12" fill="rgba(226,232,240,0.85)" fontWeight="700">
        N
      </text>
    </svg>
  );
}
