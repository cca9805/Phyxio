import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function buildData(R, wMax = 10, n = 201) {
  const data = [];
  const N = Math.max(60, n);
  for (let i = 0; i < N; i++) {
    const w = -wMax + (2 * wMax * i) / (N - 1);
    const v = R * w;
    data.push({ w, v });
  }
  return data;
}

export default function RodaduraCondicionCinematicaGraphs({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({
    R: 0.3,
    w: 6,
    wMax: 10,
  }));

  useEffect(() => {
    if (!linked || !params) return;
    setP((prev) => ({
      ...prev,
      R: pickParam(params, ["R", "r"], prev.R),
      w: pickParam(params, ["omega", "w", "ω"], prev.w),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const R = Math.max(0.0001, toNum(p.R, 0.3));
    const wMax = Math.max(1, toNum(p.wMax, 10));
    const w = Math.max(-wMax, Math.min(wMax, toNum(p.w, 6)));
    return { R, w, wMax };
  }, [p]);

  const data = useMemo(() => buildData(safe.R, safe.wMax, 201), [safe.R, safe.wMax]);
  const vNow = useMemo(() => safe.R * safe.w, [safe.R, safe.w]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Condición cinemática</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Recta: <b>v = ωR</b>
        </div>

        <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">R (m)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.R}
              onChange={(e) => setP((s) => ({ ...s, R: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">ω (rad/s)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.w}
              onChange={(e) => setP((s) => ({ ...s, w: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">ω_max (rad/s)</div>
            <input
              className="form-control"
              inputMode="decimal"
              value={p.wMax}
              onChange={(e) => setP((s) => ({ ...s, wMax: e.target.value }))}
            />
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          v = ωR → <b>v = {fmt(vNow, 6)} m/s</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Gráfica v(ω)</div>
        <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>
          La pendiente es R: si aumenta R, la recta se inclina más.
        </div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis
                dataKey="w"
                type="number"
                domain={[-safe.wMax, safe.wMax]}
                tickFormatter={(v) => fmt(v, 3)}
                label={{ value: "ω (rad/s)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 4)}
                label={{ value: "v (m/s)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(val) => fmt(val, 6)}
                labelFormatter={(x) => `ω = ${fmt(x, 6)} rad/s`}
              />
              <Line type="monotone" dataKey="v" dot={false} name="v = ωR" />
              <ReferenceDot x={safe.w} y={vNow} r={5} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
