import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function toNum(v, fb) {
  if (v == null || v === "") return fb;
  if (typeof v === "number") return Number.isFinite(v) ? v : fb;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fb;
}
function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}
const deg2rad = (d) => (d * Math.PI) / 180;

function buildSeries({ F1, F2, stepDeg = 2 }) {
  const out = [];
  for (let th = 0; th <= 360 + 1e-9; th += stepDeg) {
    const c = Math.cos(deg2rad(th));
    const s = Math.sin(deg2rad(th));

    const sumFx = F1 + F2 * c;
    const sumFy = 0 + F2 * s;

    const R = Math.hypot(sumFx, sumFy); // “resultante” si NO ponemos equilibrante
    const F3mag = R; // para equilibrio, |F3| = |R| (y apuntaría opuesto a R)

    out.push({ th, sumFx, sumFy, R, F3mag });
  }
  return out;
}

export default function CondicionSumatoriaFuerzasGraphsCoord() {
  const [F1, setF1] = useState(20);
  const [F2, setF2] = useState(15);
  const [theta, setTheta] = useState(60);

  const safe = useMemo(() => {
    const f1 = clamp(toNum(F1, 20), 0, 1e6);
    const f2 = clamp(toNum(F2, 15), 0, 1e6);
    const th = clamp(toNum(theta, 60), 0, 360);
    return { F1: f1, F2: f2, theta: th };
  }, [F1, F2, theta]);

  const data = useMemo(() => buildSeries({ F1: safe.F1, F2: safe.F2, stepDeg: 2 }), [safe.F1, safe.F2]);

  const inst = useMemo(() => {
    const c = Math.cos(deg2rad(safe.theta));
    const s = Math.sin(deg2rad(safe.theta));
    const sumFx = safe.F1 + safe.F2 * c;
    const sumFy = safe.F2 * s;
    const R = Math.hypot(sumFx, sumFy);
    // equilibrante
    const F3x = -sumFx;
    const F3y = -sumFy;
    return { sumFx, sumFy, R, F3x, F3y };
  }, [safe.F1, safe.F2, safe.theta]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Equilibrio traslacional (Coord): ΣFx = 0 y ΣFy = 0</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Ejemplo: F1 fija en +x, F2 con ángulo θ. Para equilibrio, F3 = -(F1+F2).
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">F1 (N) (en +x)</div>
            <input className="form-control" inputMode="decimal" value={F1} onChange={(e) => setF1(e.target.value)} />
          </div>
          <div className="v2-card">
            <div className="v2-card-title">F2 (N)</div>
            <input className="form-control" inputMode="decimal" value={F2} onChange={(e) => setF2(e.target.value)} />
          </div>
          <div className="v2-card">
            <div className="v2-card-title">θ (°) de F2</div>
            <input className="form-control" inputMode="decimal" value={theta} onChange={(e) => setTheta(e.target.value)} />
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10, lineHeight: 1.55 }}>
          ΣFx = <b>{fmt(inst.sumFx, 6)} N</b>, ΣFy = <b>{fmt(inst.sumFy, 6)} N</b>
          <br />
          Resultante si no equilibras: R = <b>{fmt(inst.R, 6)} N</b>
          <br />
          Fuerza equilibrante (componentes): F3x = <b>{fmt(inst.F3x, 6)} N</b>, F3y = <b>{fmt(inst.F3y, 6)} N</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Cómo cambia la equilibrante con el ángulo</div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis
                dataKey="th"
                type="number"
                domain={[0, 360]}
                label={{ value: "θ (°)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 2)}
                label={{ value: "N", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(val) => fmt(val, 6)}
                labelFormatter={(x) => `θ = ${fmt(x, 1)}°`}
              />
              <Line type="monotone" dataKey="F3mag" dot={false} name="|F3| para equilibrio" />
              <Line type="monotone" dataKey="R" dot={false} name="|R| sin equilibrar (igual a |F3|)" />
              <ReferenceDot x={safe.theta} y={inst.R} r={5} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          En este ejemplo, la equilibrante siempre tiene módulo |F3| = |R|, y dirección opuesta a la resultante.
        </div>
      </div>
    </div>
  );
}
