import React, { useMemo } from "react";
import SvgFrame from "@/v2/components/graphs_shared/svg2/SvgFrame";
import { useExperimentParams } from "@/v2/components/graphs_shared/experiment/useExperimentParams";
import { fmt } from "@/v2/utils/graphFormat";


const toNum = (v, fb) => {
  const n = typeof v === "number" ? v : Number(String(v ?? "").replace(",", "."));
  return Number.isFinite(n) ? n : fb;
};

const deg2rad = (d) => (d * Math.PI) / 180;



const rad2deg = (r) => (r * 180) / Math.PI;

const thetaToDegSmart = (t) => {
  const n = toNum(t, 0);
  if (Math.abs(n) <= 6.5) return rad2deg(n); // probablemente rad
  return n; // probablemente deg
};

function Slider({ value, min, max, step, onChange }) {
  return (
    <input
      type="range"
      value={value}
      min={min}
      max={max}
      step={step}
      onChange={(e) => onChange(Number(e.target.value))}
      style={{ width: "100%", accentColor: "#6366f1", cursor: "pointer" }}
    />
  );
}

function Arrow({ x, y, dx, dy, color, label, strokeWidth = 4 }) {
  const x2 = x + dx;
  const y2 = y - dy;
  const ang = Math.atan2(-dy, dx) * (180 / Math.PI);

  return (
    <g>
      <line x1={x} y1={y} x2={x2} y2={y2} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" />
      <g transform={`translate(${x2},${y2}) rotate(${ang})`}>
        <path d="M 0 0 L -12 -6 L -12 6 Z" fill={color} />
      </g>
      {label ? (
        <text x={x2} y={y2 - 18} fontSize="14" fontWeight="800" fill={color} textAnchor="middle">
          {label}
        </text>
      ) : null}
    </g>
  );
}

export default function CondicionSumatoriaFuerzasGraphsDcl({
  title,
  params,
  sharedParams,
  onSharedParamsChange,
}) {
  const p = sharedParams ?? params ?? {};

  // ¿Tenemos datos suficientes para dibujar F1 y F2?
  const hasFmag = p.F1 != null || p.F2 != null || p.F != null || p.f1 != null || p.f2 != null;
  const hasFcomp =
    p.F1x != null || p.F1y != null || p.F2x != null || p.F2y != null;

  const hasCalcSum = p.Fx != null || p.Fy != null || p.sumFx != null || p.sumFy != null;

  // Si hay magnitudes, preferimos modo “didáctico” (porque sí podemos dibujar fuerzas reales)
  // Si hay componentes de fuerzas, también podemos dibujarlas.
  // Si solo hay suma (Fx,Fy), NO podemos inventar F1/F2.
  const canDrawF1F2 = hasFmag || hasFcomp;

  // Defaults
  const defaultThetaDeg = thetaToDegSmart(p.theta ?? p.angulo ?? p.angle ?? 60);

  const schema = useMemo(() => {
    // si puedo dibujar F1/F2, expone sliders de F1/F2/theta
    if (canDrawF1F2) {
      return [
        { key: "F1", label: "F1", unit: "N", step: 0.5, default: toNum(p.F1 ?? p.F ?? p.f1, 50), aliases: ["F", "f1"] },
        { key: "F2", label: "F2", unit: "N", step: 0.5, default: toNum(p.F2 ?? p.f2, 40), aliases: ["f2"] },
        { key: "theta", label: "θ", unit: "°", step: 1, default: defaultThetaDeg, aliases: ["angulo", "angle"] },
      ];
    }

    // si no puedo dibujar F1/F2, al menos permito jugar con la suma
    return [
      { key: "Fx", label: "ΣFx", unit: "N", step: 0.5, default: toNum(p.Fx ?? p.sumFx, 20), aliases: ["sumFx"] },
      { key: "Fy", label: "ΣFy", unit: "N", step: 0.5, default: toNum(p.Fy ?? p.sumFy, 10), aliases: ["sumFy"] },
    ];
  }, [canDrawF1F2, p.F1, p.F2, p.F, p.theta, defaultThetaDeg, p.Fx, p.Fy, p.sumFx, p.sumFy]);

  const exp = useExperimentParams({ params: p, schema, modeDefault: "follow" });
  const ep = exp.effectiveParams;

  // --- Cálculos ---
  let F1 = 0, F2 = 0, thetaDeg = 0;
  let F1x = 0, F1y = 0, F2x = 0, F2y = 0;

  // ΣF
  let Fx = 0, Fy = 0;

  if (canDrawF1F2) {
    // Si vienen componentes explícitas desde calculadora, dales prioridad
    const hasExplicitComps =
      p.F1x != null || p.F1y != null || p.F2x != null || p.F2y != null;

    if (hasExplicitComps) {
      F1x = toNum(p.F1x, 0);
      F1y = toNum(p.F1y, 0);
      F2x = toNum(p.F2x, 0);
      F2y = toNum(p.F2y, 0);

      // magnitudes “informativas”
      F1 = Math.hypot(F1x, F1y);
      F2 = Math.hypot(F2x, F2y);

      Fx = F1x + F2x;
      Fy = F1y + F2y;
    } else {
      // Modo clásico con magnitudes + theta
      F1 = toNum(ep.F1, 50);
      F2 = toNum(ep.F2, 40);
      thetaDeg = toNum(ep.theta, 60);

      F1x = F1;
      F1y = 0;

      F2x = F2 * Math.cos(deg2rad(thetaDeg));
      F2y = F2 * Math.sin(deg2rad(thetaDeg));

      Fx = F1x + F2x;
      Fy = F1y + F2y;
    }
  } else {
    // Solo conocemos la suma (Fx,Fy)
    Fx = toNum(ep.Fx, toNum(p.Fx ?? p.sumFx, 0));
    Fy = toNum(ep.Fy, toNum(p.Fy ?? p.sumFy, 0));
  }

  const F3x = -(Fx);
  const F3y = -(Fy);

  const resultante = toNum(p.R, Math.hypot(Fx, Fy));
  const equilibrante = toNum(p.F3, Math.hypot(F3x, F3y));

  const enEquilibrio = resultante < 0.1;

  const applyToCalculator = onSharedParamsChange
    ? () =>
        onSharedParamsChange({
          ...(canDrawF1F2 ? { F1, F2, theta: thetaDeg } : {}),
          F1x,
          F1y,
          F2x,
          F2y,
          Fx,
          Fy,
          R: resultante,
          F3x,
          F3y,
          F3: equilibrante,
        })
    : null;

  // escala
  const scale = 2.5;
  const centerX = 425;
  const centerY = 300;

  return (
    <SvgFrame
      title={title || "DCL: Condición ΣF = 0"}
      subtitle={canDrawF1F2 ? "F1, F2, F3 y resultante" : "Resultante ΣF y equilibrante"}
      badgeLabel="ESTADO"
      badgeValue={enEquilibrio ? "EQUILIBRIO" : "NO EQUILIBRIO"}
      controls={
        <>
          <button
            type="button"
            onClick={() => exp.startExperiment()}
            style={{
              padding: "10px 14px",
              borderRadius: 14,
              border: "1px solid rgba(255,255,255,0.14)",
              background: "rgba(99,102,241,0.35)",
              color: "rgba(255,255,255,0.92)",
              fontWeight: 900,
              cursor: "pointer",
            }}
          >
            Experimentar
          </button>

          <button
            type="button"
            onClick={exp.resetToCalculator}
            style={{
              padding: "10px 14px",
              borderRadius: 14,
              border: "1px solid rgba(255,255,255,0.14)",
              background: "rgba(0,0,0,0.35)",
              color: "rgba(255,255,255,0.88)",
              fontWeight: 900,
              cursor: "pointer",
            }}
          >
            Seguir calculadora
          </button>

          {applyToCalculator ? (
            <button
              type="button"
              onClick={applyToCalculator}
              style={{
                padding: "10px 14px",
                borderRadius: 14,
                border: "1px solid rgba(255,255,255,0.14)",
                background: "rgba(2,6,243,0.75)",
                color: "white",
                fontWeight: 900,
                cursor: "pointer",
              }}
            >
              Aplicar
            </button>
          ) : null}
        </>
      }
      aside={
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div className="v2-panel m-2" style={{ background: "rgba(0,0,0,0.55)" }}>
            <div style={{ fontSize: 11, letterSpacing: 1, opacity: 0.75, fontWeight: 900 }}>PARÁMETROS</div>

            <div style={{ marginTop: 10, display: "grid", gap: 12 }}>
              {canDrawF1F2 ? (
                <>
                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                      <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>F1</div>
                      <div style={{ fontSize: 12, opacity: 0.7 }}>{F1.toFixed(1)} N</div>
                    </div>
                    <div style={{ marginTop: 8 }}>
                      <Slider
                        value={F1}
                        min={0}
                        max={100}
                        step={0.5}
                        onChange={(v) => {
                          exp.startExperiment();
                          exp.setValue("F1", v);
                        }}
                      />
                    </div>
                  </div>

                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                      <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>F2</div>
                      <div style={{ fontSize: 12, opacity: 0.7 }}>{F2.toFixed(1)} N</div>
                    </div>
                    <div style={{ marginTop: 8 }}>
                      <Slider
                        value={F2}
                        min={0}
                        max={100}
                        step={0.5}
                        onChange={(v) => {
                          exp.startExperiment();
                          exp.setValue("F2", v);
                        }}
                      />
                    </div>
                  </div>

                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                      <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>θ</div>
                      <div style={{ fontSize: 12, opacity: 0.7 }}>{thetaDeg.toFixed(0)}°</div>
                    </div>
                    <div style={{ marginTop: 8 }}>
                      <Slider
                        value={thetaDeg}
                        min={0}
                        max={360}
                        step={1}
                        onChange={(v) => {
                          exp.startExperiment();
                          exp.setValue("theta", v);
                        }}
                      />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                      <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>ΣFx</div>
                      <div style={{ fontSize: 12, opacity: 0.7 }}>{Fx.toFixed(1)} N</div>
                    </div>
                    <div style={{ marginTop: 8 }}>
                      <Slider
                        value={Fx}
                        min={-100}
                        max={100}
                        step={0.5}
                        onChange={(v) => {
                          exp.startExperiment();
                          exp.setValue("Fx", v);
                        }}
                      />
                    </div>
                  </div>

                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                      <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>ΣFy</div>
                      <div style={{ fontSize: 12, opacity: 0.7 }}>{Fy.toFixed(1)} N</div>
                    </div>
                    <div style={{ marginTop: 8 }}>
                      <Slider
                        value={Fy}
                        min={-100}
                        max={100}
                        step={0.5}
                        onChange={(v) => {
                          exp.startExperiment();
                          exp.setValue("Fy", v);
                        }}
                      />
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          <div className="v2-panel m-2 mt-0" style={{ background: "rgba(0,0,0,0.35)" }}>
            <div style={{ fontWeight: 900, opacity: 0.95, marginBottom: 8 }}>Lectura</div>
            <div style={{ fontSize: 12, opacity: 0.82, lineHeight: 1.6, fontFamily: "ui-monospace, monospace" }}>
              <div><b>ΣFx</b> = {Fx.toFixed(2)} N</div>
              <div><b>ΣFy</b> = {Fy.toFixed(2)} N</div>
              <div style={{ marginTop: 6 }}><b>|R|</b> = {resultante.toFixed(2)} N</div>
              <div style={{ marginTop: 6, paddingTop: 6, borderTop: "1px solid rgba(255,255,255,0.15)" }}>
                <b>F3x</b> = {F3x.toFixed(2)} N
              </div>
              <div><b>F3y</b> = {F3y.toFixed(2)} N</div>
              <div style={{ marginTop: 6 }}><b>|F3|</b> = {equilibrante.toFixed(2)} N</div>
            </div>
          </div>
        </div>
      }
    >
      <defs>
        <filter id="softGlow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="4" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        <radialGradient id="pointGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="rgba(99,102,241,0.8)" />
          <stop offset="100%" stopColor="rgba(99,102,241,0)" />
        </radialGradient>

        <linearGradient id="bgGradient" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="rgba(0, 0, 0, 0.92)" />
          <stop offset="100%" stopColor="rgba(81, 97, 168, 0.35)" />
        </linearGradient>
      </defs>

      <rect width="850" height="600" fill="url(#bgGradient)" />

      {/* ejes */}
      <line x1="50" y1={centerY} x2="800" y2={centerY} stroke="rgba(255,255,255,0.15)" strokeWidth="2" strokeDasharray="5,5" />
      <line x1={centerX} y1="50" x2={centerX} y2="550" stroke="rgba(255,255,255,0.15)" strokeWidth="2" strokeDasharray="5,5" />

      <text x="780" y={centerY - 10} fontSize="14" fill="rgba(255,255,255,0.5)" fontWeight="700">+x</text>
      <text x={centerX + 10} y="70" fontSize="14" fill="rgba(255,255,255,0.5)" fontWeight="700">+y</text>

      {/* punto */}
      <circle cx={centerX} cy={centerY} r="30" fill="url(#pointGlow)" opacity="0.6" />
      <circle cx={centerX} cy={centerY} r="8" fill="rgba(99,102,241,0.9)" filter="url(#softGlow)" />
      <circle cx={centerX} cy={centerY} r="4" fill="rgba(255,255,255,0.95)" />

      {/* fuerzas reales si existen */}
      {canDrawF1F2 ? (
        <>
          <Arrow x={centerX} y={centerY} dx={F1x * scale} dy={F1y * scale} color="#3b82f6" label="F1" strokeWidth={5} />
          <Arrow x={centerX} y={centerY} dx={F2x * scale} dy={F2y * scale} color="#a855f7" label="F2" strokeWidth={5} />
        </>
      ) : null}

      {/* resultante */}
      <Arrow
        x={centerX}
        y={centerY}
        dx={Fx * scale}
        dy={Fy * scale}
        color="rgba(255,255,255,0.65)"
        label={`R=${fmt(resultante, 3)}N`}
        strokeWidth={4}
      />

      {/* equilibrante */}
      <Arrow
        x={centerX}
        y={centerY}
        dx={F3x * scale}
        dy={F3y * scale}
        color="#ef4444"
        label={`F3=${fmt(equilibrante, 3)}N`}
        strokeWidth={5}
      />
    </SvgFrame>
  );
}
