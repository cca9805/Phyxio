import React, { useMemo } from "react";
import SvgFrame from "@/v2/components/graphs_shared/svg2/SvgFrame";
import MathInline from "@/v2/components/shared/MathInline";

/**
 * SVG CONCEPTUAL
 * Momento de una fuerza (torque) – Definición
 *
 * Objetivo didáctico:
 * - Mostrar eje de rotación
 * - Fuerza aplicada F
 * - Vector posición r
 * - Brazo perpendicular d
 * - Sentido del torque τ (sin flecha)
 * - Leyenda clara
 */
export default function DefinicionTorqueSvg(props) {
  const p = props.params ?? props.sharedParams ?? {};

  const cfg = useMemo(() => {
    return {
      showAngle: p?.showAngle ?? true,
    };
  }, [p?.showAngle]);

  const W = 640;
  const H = 420;

  // Geometría base
  const pivot = { x: 160, y: 280 };
  const point = { x: 430, y: 210 };
  const forceEnd = { x: 430, y: 110 };

  const lineActionX = point.x;

  const dStart = { x: pivot.x, y: pivot.y };
  const dEnd = { x: lineActionX, y: pivot.y };

  const rStart = pivot;
  const rEnd = point;

  return (
    <SvgFrame
      title="Momento de una fuerza (torque)"
      subtitle="Definición visual: eje, brazo y efecto de giro"
      badgeLabel="TIPO"
      badgeValue="SVG CONCEPTUAL"
      controls={null}
      aside={
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div className="v2-panel m-3 mb-1" style={{ background: "rgba(0,0,0,0.55)" }}>
            <div style={{ fontSize: 11, letterSpacing: 1, opacity: 0.75, fontWeight: 900 }}>
              IDEA CLAVE
            </div>
            <div style={{ marginTop: 10, fontSize: 13, opacity: 0.85, lineHeight: 1.45 }}>
              El torque mide la <b>tendencia a girar</b> de una fuerza respecto a un eje.
              Depende tanto de <b>F</b> como del <b>brazo perpendicular d</b>.
              Una llave inglesa sobre una barra o una tuerca es el ejemplo físico perfecto
               de todo lo que aparece en el gráfico 🔧.
            </div>
          </div>

          <div className="v2-panel m-3 mt-0" style={{ background: "rgba(0,0,0,0.55)" }}>
            <div style={{ fontSize: 11, letterSpacing: 1, opacity: 0.75, fontWeight: 900 }}>
              EXPRESIONES
            </div>

            <div style={{ marginTop: 10, display: "grid", gap: 8 }}>
              <div className="v2-panel" style={{ background: "rgba(0,0,0,0.75)" }}>
                <div style={{ fontSize: 12, opacity: 0.75 }}>Módulo</div>
                <div style={{ marginTop: 2, color: "#fb923c" }}>
                  <MathInline latex={"\\tau = F\\,d"} />
                </div>
                <div style={{ marginTop: 6, fontSize: 12, opacity: 0.8 }}>
                  <b>d</b> es la distancia perpendicular del eje a la línea de acción.
                </div>
              </div>

              <div className="v2-panel" style={{ background: "rgba(0,0,0,0.75)" }}>
                <div style={{ fontSize: 12, opacity: 0.75 }}>Forma vectorial</div>
                <div style={{ marginTop: 2, color: "#fb923c" }}>
                  <MathInline latex={"\\vec{\\tau}=\\vec{r}\\times\\vec{F}"} />
                </div>
                <div style={{ marginTop: 6, fontSize: 12, opacity: 0.8 }}>
                  La dirección de <b>τ</b> viene dada por la regla de la mano derecha.
                </div>
              </div>
            </div>
          </div>
        </div>
      }
    >
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ display: "block" }}>
        <defs>
          <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="rgba(148,163,184,0.10)" />
            <stop offset="1" stopColor="rgba(148,163,184,0.02)" />
          </linearGradient>

          <marker id="arrowF" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto">
            <path d="M0,0 L10,5 L0,10 Z" fill="rgba(251,146,60,0.95)" />
          </marker>

          <marker id="arrowR" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto">
            <path d="M0,0 L10,5 L0,10 Z" fill="rgba(96,165,250,0.95)" />
          </marker>
        </defs>

        <rect x="18" y="18" width={W - 36} height={H - 36} rx="18" fill="url(#bgGrad)" stroke="rgba(255,255,255,0.08)" />

        {/* Referencia */}
        <line x1="40" y1="320" x2={W - 40} y2="320" stroke="rgba(148,163,184,0.25)" strokeWidth="2" />

        {/* Eje */}
        <circle cx={pivot.x} cy={pivot.y} r="10" fill="rgba(226,232,240,0.9)" />
        <circle cx={pivot.x} cy={pivot.y} r="4" fill="rgba(2,6,23,0.9)" />
        <text x={pivot.x - 12} y={pivot.y + 32} fontSize="12" fill="rgba(226,232,240,0.8)">
          eje
        </text>

        {/* Barra */}
        <line
          x1={pivot.x}
          y1={pivot.y}
          x2={point.x}
          y2={point.y}
          stroke="rgba(226,232,240,0.75)"
          strokeWidth="8"
          strokeLinecap="round"
        />

        {/* Vector r */}
        <line
          x1={rStart.x}
          y1={rStart.y}
          x2={rEnd.x}
          y2={rEnd.y}
          stroke="rgba(96,165,250,0.95)"
          strokeWidth="3"
          markerEnd="url(#arrowR)"
        />
        <text x={(rStart.x + rEnd.x) / 2 - 10} y={(rStart.y + rEnd.y) / 2 - 10} fontSize="13" fill="rgba(96,165,250,0.95)">
          r
        </text>

        {/* Fuerza F */}
        <line
          x1={point.x}
          y1={point.y}
          x2={forceEnd.x}
          y2={forceEnd.y}
          stroke="rgba(251,146,60,0.95)"
          strokeWidth="4"
          markerEnd="url(#arrowF)"
        />
        <text x={point.x + 12} y={(point.y + forceEnd.y) / 2} fontSize="13" fill="rgba(251,146,60,0.95)">
          F
        </text>

        {/* Línea de acción */}
        <line
          x1={lineActionX}
          y1="60"
          x2={lineActionX}
          y2="340"
          stroke="rgba(203,213,225,0.35)"
          strokeWidth="2"
          strokeDasharray="6 6"
        />

        {/* Brazo perpendicular d */}
        <line
          x1={dStart.x}
          y1={dStart.y}
          x2={dEnd.x}
          y2={dEnd.y}
          stroke="rgba(203,213,225,0.9)"
          strokeWidth="3"
        />
        <text x={(dStart.x + dEnd.x) / 2 - 6} y={dStart.y - 10} fontSize="13" fill="rgba(226,232,240,0.9)">
          d
        </text>

        {/* Curva de torque τ (sin flecha) */}
        <path
          d={`M ${pivot.x + 48} ${pivot.y - 58}
              A 70 70 0 0 1 ${pivot.x + 78} ${pivot.y + 6}`}
          fill="none"
          stroke="rgba(34,197,94,0.85)"
          strokeWidth="4"
        />
        <text
          x={pivot.x + 96}
          y={pivot.y - 18}
          fontSize="16"
          fontWeight="700"
          fill="rgba(187,247,208,0.95)"
        >
          τ
        </text>

        {/* Leyenda */}
        <g transform={`translate(${W - 600}, ${H - 380})`}>
          <rect
            x="0"
            y="0"
            width="200"
            height="120"
            rx="12"
            fill="rgba(0,0,0,0.55)"
            stroke="rgba(255,255,255,0.12)"
          />

          <text x="14" y="22" fontSize="13" fill="rgba(226,232,240,0.9)" fontWeight="700">
            Leyenda
          </text>

          <text x="14" y="44" fontSize="12" fill="rgba(251,146,60,0.95)">F</text>
          <text x="30" y="44" fontSize="12" fill="rgba(226,232,240,0.8)">Fuerza aplicada</text>

          <text x="14" y="62" fontSize="12" fill="rgba(96,165,250,0.95)">r</text>
          <text x="30" y="62" fontSize="12" fill="rgba(226,232,240,0.8)">Vector posición</text>

          <text x="14" y="80" fontSize="12" fill="rgba(226,232,240,0.9)">d</text>
          <text x="30" y="80" fontSize="12" fill="rgba(226,232,240,0.8)">Brazo perpendicular</text>

          <text x="14" y="98" fontSize="12" fill="rgba(187,247,208,0.95)">τ</text>
          <text x="30" y="98" fontSize="12" fill="rgba(226,232,240,0.8)">Efecto de giro</text>
        </g>
      </svg>
    </SvgFrame>
  );
}
