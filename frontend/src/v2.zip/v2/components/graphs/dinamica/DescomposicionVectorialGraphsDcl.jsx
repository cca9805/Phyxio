import React, { useMemo, useState } from "react";

/**
 * Descomposición vectorial (DCL)
 * - Modo "vector": A con ángulo θ respecto a +x y componentes Ax/Ay
 * - Modo "plano": peso mg vertical y componentes mg‖/mg⟂ respecto al plano inclinado de ángulo θ
 *
 * Nota: Este componente está pensado para el tab de Gráficos (v2) que importa Graphs* desde graphs/index.js.
 */
export default function DescomposicionVectorialGraphsDcl() {
  const [mode, setMode] = useState("incline"); // cartesian | incline
  const [A, setA] = useState(9.8);
  const [theta, setTheta] = useState(30);

  const [showAxes, setShowAxes] = useState(true);
  const [showComponents, setShowComponents] = useState(true);
  const [showProjections, setShowProjections] = useState(true);
  const [showLabels, setShowLabels] = useState(true);

  const th = useMemo(() => {
    const n = Number(String(theta).replace(",", "."));
    if (!Number.isFinite(n)) return 30;
    return Math.max(0, Math.min(80, n));
  }, [theta]);

  const aMag = useMemo(() => {
    const n = Number(String(A).replace(",", "."));
    if (!Number.isFinite(n)) return 9.8;
    return Math.max(1, Math.min(30, n));
  }, [A]);

  // Geometry / helpers
  const W = 760;
  const H = 340;

  const DEG = Math.PI / 180;
  const rad = th * DEG;

  const C = {
    bg: "#b8c5ffff",
    axis: "#5b7aa8",
    body: "#0f172a",
    main: "#006aff",
    c1: "#ff2d55",
    c2: "#34c759",
    dash: "#64748b",
    panel: "#ffffff",
    panelStroke: "#d6e5ff",
    muted: "#64748b",
    purple: "#7c3aed",
  };

  const center = { x: 500, y: 180 };
  const scale = 8;
  const vecTo = (v) => ({ x: center.x + v.x * scale, y: center.y - v.y * scale });

  const Arrow = ({ from, to, stroke, w = 7, label }) => {
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const L = Math.hypot(dx, dy) || 1;
    const ux = dx / L;
    const uy = dy / L;
    const head = 14;

    const hx = to.x;
    const hy = to.y;

    const leftx = hx - ux * head - uy * (head * 0.6);
    const lefty = hy - uy * head + ux * (head * 0.6);
    const rightx = hx - ux * head + uy * (head * 0.6);
    const righty = hy - uy * head - ux * (head * 0.6);

    return (
      <g>
        <line x1={from.x} y1={from.y} x2={hx} y2={hy} stroke={stroke} strokeWidth={w} strokeLinecap="round" />
        <polygon points={`${hx},${hy} ${leftx},${lefty} ${rightx},${righty}`} fill={stroke} opacity="0.95" />
        {showLabels && label && (
          <text x={hx + 10} y={hy + 6} fontSize="18" fontWeight="800" fill={stroke}>
            {label}
          </text>
        )}
      </g>
    );
  };

  const Dashed = ({ a, b }) => (
    <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={C.dash} strokeWidth="3" strokeDasharray="8 8" opacity="0.85" />
  );

  // Incline basis
  const epar = { x: Math.cos(rad), y: Math.sin(rad) };
  const eperp = { x: -Math.sin(rad), y: Math.cos(rad) };

  let main = { x: 0, y: 0 };
  let c1 = { x: 0, y: 0 };
  let c2 = { x: 0, y: 0 };
  let labels = { main: "A", c1: "Ax", c2: "Ay" };
  let panelLines = [];

  if (mode === "cartesian") {
    main = { x: aMag * Math.cos(rad), y: aMag * Math.sin(rad) };
    c1 = { x: main.x, y: 0 };
    c2 = { x: 0, y: main.y };
    labels = { main: "A", c1: "Ax", c2: "Ay" };
    panelLines = ["A = (Ax, Ay)", "Ax = A·cosθ", "Ay = A·senθ"];
  } else {
    // weight downward
    main = { x: 0, y: -aMag }; // mg (magnitud)
    const Apar = main.x * epar.x + main.y * epar.y; // -mg·senθ
    const Aperp = main.x * eperp.x + main.y * eperp.y; // -mg·cosθ
    c1 = { x: Apar * epar.x, y: Apar * epar.y }; // parallel
    c2 = { x: Aperp * eperp.x, y: Aperp * eperp.y }; // perpendicular
    labels = { main: "mg", c1: "mg‖", c2: "mg⟂" };
    panelLines = ["mg = mg‖ + mg⟂", "mg‖ = mg·senθ (cuesta abajo)", "mg⟂ = mg·cosθ (hacia el plano)"];
  }

  const P0 = center;
  const Pm = vecTo(main);
  const Pc1 = vecTo(c1);
  const Pc2 = vecTo(c2);

  const axes = () => {
    if (!showAxes) return null;

    const xEnd = { x: center.x + 120, y: center.y };
    const yEnd = { x: center.x, y: center.y - 120 };

    return (
      <g opacity="0.95">
        <Arrow from={center} to={xEnd} stroke={C.axis} w={5} label={showLabels ? "x" : ""} />
        <Arrow from={center} to={yEnd} stroke={C.axis} w={5} label={showLabels ? "y" : ""} />
        {mode === "incline" && (
          <>
            <Arrow from={center} to={vecTo({ x: 16 * epar.x, y: 16 * epar.y })} stroke={C.purple} w={4} label={showLabels ? "‖" : ""} />
            <Arrow from={center} to={vecTo({ x: 12 * eperp.x, y: 12 * eperp.y })} stroke={C.purple} w={4} label={showLabels ? "⟂" : ""} />
          </>
        )}
      </g>
    );
  };

  const components = () => {
    if (!showComponents) return null;

    if (mode === "cartesian") {
      const foot = { x: Pc1.x, y: Pc2.y };
      return (
        <g>
          <Arrow from={P0} to={Pc1} stroke={C.c1} w={6} label={labels.c1} />
          <Arrow from={P0} to={Pc2} stroke={C.c2} w={6} label={labels.c2} />
          {showProjections && (
            <>
              <Dashed a={Pm} b={foot} />
              <Dashed a={foot} b={Pc1} />
              <Dashed a={foot} b={Pc2} />
            </>
          )}
        </g>
      );
    }

    return (
      <g>
        <Arrow from={P0} to={Pc1} stroke={C.c1} w={6} label={labels.c1} />
        <Arrow from={P0} to={Pc2} stroke={C.c2} w={6} label={labels.c2} />
        {showProjections && (
          <>
            <Dashed a={Pc1} b={Pm} />
            <Dashed a={Pc2} b={Pm} />
          </>
        )}
      </g>
    );
  };

  const infoPanel = () => (
    <g>
      <rect x="38" y="44" width="260" height="146" rx="18" fill={C.panel} opacity="0.95" stroke={C.panelStroke} strokeWidth="3" />
      <text x="58" y="78" fontSize="18" fontWeight="900" fill={C.body}>
        {mode === "cartesian" ? "Componentes (x/y)" : "Componentes (‖/⟂)"}
      </text>
      {panelLines.map((t, i) => (
        <text key={i} x="58" y={108 + i * 24} fontSize="16" fill={C.muted}>
          {t}
        </text>
      ))}
    </g>
  );

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Descomposición vectorial (DCL)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Un <b>vector</b> puede expresarse como suma de <b>componentes</b> sobre un sistema de ejes.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🎯 Modo:</span>
              <select className="form-control" style={{ width: 280 }} value={mode} onChange={(e) => setMode(e.target.value)}>
                <option value="incline">Peso en plano inclinado (mg → ‖/⟂)</option>
                <option value="cartesian">Vector genérico (x/y)</option>
              </select>
            </div>

            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#fbbf24" }}>📏</span> Módulo
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input className="form-control" style={{ width: 90 }} value={A} onChange={(e) => setA(e.target.value)} />
              </label>
              <span style={{ color: "#f87171" }}>📐</span> θ (°)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}> 
                <input className="form-control" style={{ width: 90 }} value={theta} onChange={(e) => setTheta(e.target.value)} />
              </label>
            </div>
          </div>

          {/* Segunda fila: Controles de visualización */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
            
            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showAxes" 
                checked={showAxes} 
                onChange={(e) => setShowAxes(e.target.checked)} 
              />
              <label className="v2-checkbox-label" htmlFor="showAxes">Ejes</label>
            </div>

            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showComponents" 
                checked={showComponents} 
                onChange={(e) => setShowComponents(e.target.checked)} 
              />
              <label className="v2-checkbox-label" htmlFor="showComponents">Componentes</label>
            </div>

            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showProjections" 
                checked={showProjections} 
                onChange={(e) => setShowProjections(e.target.checked)} 
              />
              <label className="v2-checkbox-label" htmlFor="showProjections">Proyecciones</label>
            </div>

            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showLabels" 
                checked={showLabels} 
                onChange={(e) => setShowLabels(e.target.checked)} 
              />
              <label className="v2-checkbox-label" htmlFor="showLabels">Etiquetas</label>
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Gráfico</div>

        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: "auto", display: "block" }}>
          <rect x="0" y="0" width={W} height={H} fill={C.bg} />

          {infoPanel()}

          {/* cuerpo (punto) */}
          <circle cx={center.x} cy={center.y} r="8" fill={C.body} />
          <line x1={center.x - 14} y1={center.y} x2={center.x + 14} y2={center.y} stroke={C.body} strokeWidth="2" opacity="0.35" />
          <line x1={center.x} y1={center.y - 14} x2={center.x} y2={center.y + 14} stroke={C.body} strokeWidth="2" opacity="0.35" />

          {axes()}

          {/* vector principal */}
          <Arrow from={P0} to={Pm} stroke={C.main} w={7} label={labels.main} />

          {components()}

          {showLabels && (
            <text x="38" y={H - 30} fontSize="14" fill={C.muted}>
              Idea clave: “componente” = proyección del vector sobre un eje.
            </text>
          )}
        </svg>
      </div>
    </div>
  );
}
