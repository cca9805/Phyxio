import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function buildSeries({ m, g, stepDeg = 1 }) {
  const out = [];
  for (let th = 0; th <= 60; th += stepDeg) {
    const rad = (th * Math.PI) / 180;
    const W = m * g;
    out.push({
      theta: th,
      Wpar: W * Math.sin(rad),
      Wperp: W * Math.cos(rad),
      W,
    });
  }
  return out;
}

export default function DiagramasCuerpoLibreCoord() {
  const [m, setM] = useState(10);
  const [g, setG] = useState(9.81);
  const [theta, setTheta] = useState(25);

  const safe = useMemo(() => {
    const mm = Math.max(0.001, toNum(m, 10));
    const gg = Math.max(0, toNum(g, 9.81));
    const th = Math.max(0, Math.min(60, Math.round(toNum(theta, 25))));
    return { m: mm, g: gg, theta: th };
  }, [m, g, theta]);

  const data = useMemo(() => buildSeries({ m: safe.m, g: safe.g, stepDeg: 1 }), [safe.m, safe.g]);

  const W = safe.m * safe.g;
  const rad = (safe.theta * Math.PI) / 180;
  const Wpar = W * Math.sin(rad);
  const Wperp = W * Math.cos(rad);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">DCL (Coord): componentes del peso en plano inclinado</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Ideal: <b>W∥ = mg·sinθ</b> · <b>W⟂ = mg·cosθ</b>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Parámetros principales */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>⚙️ Parámetros:</span>
            
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#fbbf24" }}>⚖️</span> m (kg)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={m}
                  onChange={(e) => setM(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#34d399" }}>🌍</span> g (m/s²)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={g}
                  onChange={(e) => setG(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#f87171" }}>📐</span> θ (°)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="numeric"
                  value={theta}
                  onChange={(e) => setTheta(e.target.value)}
                />
              </label>
            </div>
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          W = <b>{fmt(W, 6)} N</b> · W∥ = <b>{fmt(Wpar, 6)} N</b> · W⟂ = <b>{fmt(Wperp, 6)} N</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">W∥ y W⟂ vs θ</div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis
                dataKey="theta"
                type="number"
                domain={[0, 60]}
                label={{ value: "θ (°)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 4)}
                label={{ value: "Fuerza (N)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(v) => fmt(v, 6)}
                labelFormatter={(x) => `θ = ${x}°`}
              />
              <Line type="monotone" dataKey="Wpar" dot={false} name="W∥ = mg·sinθ" />
              <Line type="monotone" dataKey="Wperp" dot={false} name="W⟂ = mg·cosθ" />
              <ReferenceDot x={safe.theta} y={Wpar} r={5} />
              <ReferenceDot x={safe.theta} y={Wperp} r={5} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Interpretación: si θ aumenta, <b>W∥</b> crece y <b>W⟂</b> disminuye.
        </div>
      </div>
    </div>
  );
}
