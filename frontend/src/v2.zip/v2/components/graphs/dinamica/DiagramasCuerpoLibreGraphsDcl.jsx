import React, { useMemo, useState } from "react";

export default function DiagramasCuerpoLibreDcl() {
  const [scene, setScene] = useState("table");
  const [theta, setTheta] = useState(25);
  const [showFriction, setShowFriction] = useState(true);

  const th = useMemo(() => {
    const n = Number(String(theta).replace(",", "."));
    if (!Number.isFinite(n)) return 25;
    return Math.max(5, Math.min(60, n));
  }, [theta]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Diagramas de cuerpo libre (DCL)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Aquí el “cuerpo” es un punto. Dibuja fuerzas: <b>mg</b>, <b>N</b>, <b>T</b>, <b>f</b>.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración de escena */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🏗️ Escena:</span>
              <select className="form-control" style={{ width: 240 }} value={scene} onChange={(e) => setScene(e.target.value)}>
                <option value="table">Bloque en mesa</option>
                <option value="incline">Bloque en plano inclinado</option>
                <option value="hanging">Masa colgante</option>
              </select>
            </div>

            {scene === "incline" && (
              <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                <span style={{ color: "#f87171" }}>📐</span>
                <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                  θ (°)
                  <input className="form-control" style={{ width: 80 }} inputMode="numeric" value={theta} onChange={(e) => setTheta(e.target.value)} />
                </label>
              </div>
            )}
          </div>

          {/* Segunda fila: Opciones de fuerzas */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>⚡ Fuerzas:</span>
            
            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showFriction" 
                checked={showFriction} 
                onChange={(e) => setShowFriction(e.target.checked)} 
              />
              <label className="v2-checkbox-label" htmlFor="showFriction">Rozamiento</label>
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">DCL</div>

        <svg viewBox="0 0 560 300" width="100%" height="260" style={{ marginTop: 10 }}>
          <rect x="0" y="0" width="560" height="300" fill="#f0f9ff" />
          {/* cuerpo */}
          <circle cx="280" cy="150" r="10" fill="#0f172a" />
          <line x1="268" y1="150" x2="292" y2="150" stroke="#0f172a" strokeWidth="2" opacity="0.4" />
          <line x1="280" y1="138" x2="280" y2="162" stroke="#0f172a" strokeWidth="2" opacity="0.4" />

          {/* mg */}
          <line x1="280" y1="150" x2="280" y2="225" stroke="#dc2626" strokeWidth="3" />
          <polygon points="280,238 274,226 286,226" fill="#dc2626" />
          <text x="292" y="215" fontSize="13" fill="#dc2626" fontWeight="bold">
            mg
          </text>

          {scene !== "hanging" && (
            <>
              {/* N */}
              <line x1="280" y1="150" x2="280" y2="80" stroke="#16a34a" strokeWidth="3" />
              <polygon points="280,70 274,82 286,82" fill="#16a34a" />
              <text x="292" y="98" fontSize="13" fill="#16a34a" fontWeight="bold">
                N
              </text>
            </>
          )}

          {scene === "hanging" && (
            <>
              {/* T */}
              <line x1="280" y1="150" x2="280" y2="80" stroke="#6366f1" strokeWidth="3" />
              <polygon points="280,70 274,82 286,82" fill="#6366f1" />
              <text x="292" y="98" fontSize="13" fill="#6366f1" fontWeight="bold">
                T
              </text>
            </>
          )}

          {(scene === "table" || scene === "incline") && showFriction && (
            <>
              {/* f (ejemplo) */}
              <line x1="280" y1="150" x2="200" y2="150" stroke="#f59e0b" strokeWidth="3" />
              <polygon points="190,150 202,144 202,156" fill="#f59e0b" />
              <text x="184" y="144" textAnchor="end" fontSize="12" fill="#f59e0b" fontWeight="bold">
                f
              </text>
            </>
          )}

          {scene === "incline" && (
            <text x="280" y="286" textAnchor="middle" fontSize="12" fill="#64748b">
              En plano inclinado: N ⟂ al plano y f ∥ al plano (aquí simplificado). θ = {th}°
            </text>
          )}
        </svg>
      </div>
    </div>
  );
}
