import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
  ReferenceLine,
} from "recharts";

import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

function toNum(v, fb) {
  if (v == null || v === "") return fb;
  if (typeof v === "number") return Number.isFinite(v) ? v : fb;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fb;
}

function accel(m1, m2, g) {
  const den = m1 + m2;
  if (den <= 0) return 0;
  return ((m2 - m1) * g) / den;
}

function tension(m1, m2, g) {
  const a = accel(m1, m2, g);
  // T = m1(g + a) si m1 sube cuando m2>m1. Esta fórmula vale con el convenio del texto.
  return m1 * (g + a);
}

function buildData({ m1, g, m2Min, m2Max }, n = 220) {
  const data = [];
  const N = Math.max(80, n);
  for (let i = 0; i < N; i++) {
    const m2 = m2Min + ((m2Max - m2Min) * i) / (N - 1);
    const a = accel(m1, m2, g);
    data.push({ m2, a });
  }
  return data;
}

export default function DosMasasUnidasPorCuerdaGraphs({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({
    m1: 2,
    m2: 5,
    g: 9.8,
    m2Min: 0.5,
    m2Max: 10,
  }));

  useEffect(() => {
    if (!linked || !params) return;
    setP((prev) => ({
      ...prev,
      m1: pickParam(params, ["m1"], prev.m1),
      m2: pickParam(params, ["m2"], prev.m2),
      g: pickParam(params, ["g"], prev.g),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const m1 = Math.max(0.001, toNum(p.m1, 2));
    const m2 = Math.max(0.001, toNum(p.m2, 5));
    const g = Math.max(0, toNum(p.g, 9.8));
    const m2Min = Math.max(0.001, toNum(p.m2Min, 0.5));
    const m2Max = Math.max(m2Min + 0.001, toNum(p.m2Max, 10));
    return { m1, m2, g, m2Min, m2Max };
  }, [p]);

  const data = useMemo(() => buildData(safe, 240), [safe]);
  const aNow = useMemo(() => accel(safe.m1, safe.m2, safe.g), [safe.m1, safe.m2, safe.g]);
  const TNow = useMemo(() => tension(safe.m1, safe.m2, safe.g), [safe.m1, safe.m2, safe.g]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Dos masas unidas por cuerda (Coord)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          a(m2) con m1 fijo: <b>a = ((m2 − m1)g)/(m1 + m2)</b>
        </div>

        <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">m1 (kg)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.m1}
              onChange={(e) => setP((s) => ({ ...s, m1: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">m2 (kg)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.m2}
              onChange={(e) => setP((s) => ({ ...s, m2: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">m2 min</div>
            <input
              className="form-control"
              inputMode="decimal"
              value={p.m2Min}
              onChange={(e) => setP((s) => ({ ...s, m2Min: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">m2 max</div>
            <input
              className="form-control"
              inputMode="decimal"
              value={p.m2Max}
              onChange={(e) => setP((s) => ({ ...s, m2Max: e.target.value }))}
            />
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Resultado actual: <b>a = {fmt(aNow, 6)} m/s²</b> · <b>T = {fmt(TNow, 6)} N</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">a en función de m2</div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis
                dataKey="m2"
                type="number"
                domain={[safe.m2Min, safe.m2Max]}
                tickFormatter={(v) => fmt(v, 3)}
                label={{ value: "m2 (kg)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 4)}
                label={{ value: "a (m/s²)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(v) => fmt(v, 6)}
                labelFormatter={(x) => `m2 = ${fmt(x, 6)} kg`}
              />
              <ReferenceLine y={0} />
              <Line type="monotone" dataKey="a" dot={false} name="a(m2)" />
              <ReferenceDot x={safe.m2} y={aNow} r={5} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
