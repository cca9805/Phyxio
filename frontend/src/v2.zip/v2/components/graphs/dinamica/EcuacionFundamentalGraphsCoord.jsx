import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";
import {
  defaultParams,
  computeAlpha,
} from "../../../engine/models/dinamica/ecuacionFundamentalRotacional";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function buildAlphaVsSumTau({ I }, n = 140) {
  const data = [];
  const N = Math.max(40, n);
  const tauMin = 0;
  const tauMax = 10; // rango didáctico

  for (let i = 0; i < N; i++) {
    const sum_tau = tauMin + (i / (N - 1)) * (tauMax - tauMin);
    data.push({ x: sum_tau, y: computeAlpha({ sum_tau, I }) });
  }
  return data;
}

export default function EcuacionFundamentalGraphsCoord({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => defaultParams());

  useEffect(() => {
    if (!linked || !params) return;
    setP((prev) => ({
      ...prev,
      sum_tau: pickParam(params, ["sum_tau", "sumTau", "Στ", "tau", "τ"], prev.sum_tau),
      I: pickParam(params, ["I"], prev.I),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const sum_tau = toNum(p.sum_tau, 3);
    const I = Math.max(1e-9, toNum(p.I, 0.75));
    return { sum_tau, I };
  }, [p]);

  const alphaNow = useMemo(() => computeAlpha(safe), [safe]);
  const curve = useMemo(() => buildAlphaVsSumTau({ I: safe.I }, 160), [safe.I]);

  const slope = useMemo(() => (safe.I !== 0 ? 1 / safe.I : NaN), [safe.I]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {/* Controles */}
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Στ = I·α (ecuación fundamental)</div>

        <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">Στ (N·m)</div>
            <input
              className="form-control"
              disabled={linked}
              value={p.sum_tau}
              inputMode="decimal"
              onChange={(e) => setP((s) => ({ ...s, sum_tau: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">I (kg·m²)</div>
            <input
              className="form-control"
              disabled={linked}
              value={p.I}
              inputMode="decimal"
              onChange={(e) => setP((s) => ({ ...s, I: e.target.value }))}
            />
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10, display: "grid", gap: 6 }}>
          <div>
            Resultado: <b>α = {fmt(alphaNow, 6)} rad/s²</b>
          </div>
          <div style={{ fontSize: 12, opacity: 0.75 }}>
            La gráfica es una recta con pendiente <b>1/I</b>. Aquí: 1/I = <b>{fmt(slope, 6)}</b>.
          </div>
        </div>
      </div>

      {/* Gráfica */}
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Gráfico Coord: α en función de Στ (I fijo)</div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={curve}>
              <CartesianGrid />
              <XAxis
                dataKey="x"
                type="number"
                domain={[0, 10]}
                tickFormatter={(v) => fmt(v, 2)}
                label={{ value: "Στ (N·m)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 2)}
                label={{ value: "α (rad/s²)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(v) => fmt(v, 6)}
                labelFormatter={(x) => `Στ = ${fmt(x, 6)} N·m`}
              />
              <Line type="monotone" dataKey="y" dot={false} name="α" />
              {Number.isFinite(safe.sum_tau) && Number.isFinite(alphaNow) ? (
                <ReferenceDot x={safe.sum_tau} y={alphaNow} r={5} />
              ) : null}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
