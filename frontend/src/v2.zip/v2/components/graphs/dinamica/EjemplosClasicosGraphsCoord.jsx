import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
  ReferenceLine,
} from "recharts";

import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function buildData(R, wMax = 12, n = 241) {
  const data = [];
  const N = Math.max(80, n);
  for (let i = 0; i < N; i++) {
    const w = -wMax + (2 * wMax * i) / (N - 1);
    const v = R * w;
    data.push({ w, v });
  }
  return data;
}

export default function EjemplosClasicosGraphs({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({
    R: 0.3,
    omega: 8,
    v: 2.4,
    wMax: 12,
  }));

  // 🔗 enlazar con calculadora si llega
  useEffect(() => {
    if (!linked || !params) return;
    setP((prev) => ({
      ...prev,
      R: pickParam(params, ["R", "r"], prev.R),
      omega: pickParam(params, ["omega", "w", "ω"], prev.omega),
      v: pickParam(params, ["v"], prev.v),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const R = Math.max(0.0001, toNum(p.R, 0.3));
    const wMax = Math.max(2, toNum(p.wMax, 12));
    const omega = Math.max(-wMax, Math.min(wMax, toNum(p.omega, 8)));
    const v = toNum(p.v, R * omega);
    return { R, omega, v, wMax };
  }, [p]);

  const data = useMemo(() => buildData(safe.R, safe.wMax, 241), [safe.R, safe.wMax]);

  const vRodadura = useMemo(() => safe.R * safe.omega, [safe.R, safe.omega]);
  const delta = useMemo(() => safe.v - vRodadura, [safe.v, vRodadura]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Ejemplos clásicos (rodadura)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Recta de rodadura: <b>v = ωR</b> (pendiente = R)
        </div>

        <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">R (m)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.R}
              onChange={(e) => setP((s) => ({ ...s, R: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">ω (rad/s)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.omega}
              onChange={(e) => setP((s) => ({ ...s, omega: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">v (m/s)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.v}
              onChange={(e) => setP((s) => ({ ...s, v: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">ω_max</div>
            <input
              className="form-control"
              inputMode="decimal"
              value={p.wMax}
              onChange={(e) => setP((s) => ({ ...s, wMax: e.target.value }))}
            />
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Rodadura ideal: <b>v̂ = ωR = {fmt(vRodadura, 6)} m/s</b>{" "}
          · Consistencia: <b>Δ = v − ωR = {fmt(delta, 6)} m/s</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Gráfica v(ω)</div>
        <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>
          El punto debería caer sobre la recta si hay rodadura sin deslizamiento.
        </div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis
                dataKey="w"
                type="number"
                domain={[-safe.wMax, safe.wMax]}
                tickFormatter={(v) => fmt(v, 3)}
                label={{ value: "ω (rad/s)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 4)}
                label={{ value: "v (m/s)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(val) => fmt(val, 6)}
                labelFormatter={(x) => `ω = ${fmt(x, 6)} rad/s`}
              />

              <Line type="monotone" dataKey="v" dot={false} name="v = ωR" />

              {/* Punto actual (ω, v) */}
              <ReferenceDot x={safe.omega} y={safe.v} r={5} />

              {/* Guías */}
              <ReferenceLine x={0} />
              <ReferenceLine y={0} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
