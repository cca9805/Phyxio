import React, { useMemo } from "react";
import SvgFrame from "@/v2/components/graphs_shared/svg2/SvgFrame";
import { useExperimentParams } from "@/v2/components/graphs_shared/experiment/useExperimentParams";

const toNum = (v, fb) => {
  const n = typeof v === "number" ? v : Number(String(v ?? "").replace(",", "."));
  return Number.isFinite(n) ? n : fb;
};

function Slider({ value, min, max, step, onChange }) {
  return (
    <input
      type="range"
      value={value}
      min={min}
      max={max}
      step={step}
      onChange={(e) => onChange(Number(e.target.value))}
      style={{ width: "100%", accentColor: "#6366f1", cursor: "pointer" }}
    />
  );
}

function Arrow({ x1, y1, x2, y2, label }) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const ang = Math.atan2(dy, dx) * (180 / Math.PI);
  return (
    <g>
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="rgba(255,255,255,0.9)" strokeWidth="3" />
      <g transform={`translate(${x2},${y2}) rotate(${ang})`}>
        <path d="M 0 0 L -12 -6 L -12 6 Z" fill="rgba(255,255,255,0.9)" />
      </g>
      {label ? (
        <text x={(x1 + x2) / 2} y={(y1 + y2) / 2 - 8} fontSize="12" fill="rgba(255,255,255,0.85)" textAnchor="middle">
          {label}
        </text>
      ) : null}
    </g>
  );
}

export default function EjemplosEquilibrioGraphsDcl({ title, params, onSharedParamsChange }) {
  const p = params ?? {};

  const schema = useMemo(
    () => [
      { key: "m", label: "Masa", unit: "kg", step: 0.1, default: toNum(p.m, 10), aliases: ["masa"] },
      { key: "g", label: "Gravedad", unit: "m/s²", step: 0.01, default: toNum(p.g, 9.81), aliases: ["grav"] },
      { key: "F", label: "Fuerza aplicada", unit: "N", step: 0.5, default: toNum(p.F, 20), aliases: ["f"] },
      { key: "mu", label: "μs", unit: "", step: 0.01, default: toNum(p.mu, 0.4), aliases: ["mu_s", "mus"] },
    ],
    [p.m, p.g, p.F, p.mu]
  );

  const exp = useExperimentParams({ params: p, schema, modeDefault: "follow" });
  const ep = exp.effectiveParams;

  const m = toNum(ep.m, 10);
  const g = toNum(ep.g, 9.81);
  const F = toNum(ep.F, 20);
  const mu = toNum(ep.mu, 0.4);

  const P = m * g;
  const N = P; // caso horizontal ideal
  const fsMax = mu * N;

  const fsNeeded = F; // equilibrio en x => fs = F (si puede)
  const ok = fsNeeded <= fsMax + 1e-9;

  const applyToCalculator = onSharedParamsChange
    ? () => onSharedParamsChange({ m, g, F, mu })
    : null;

  return (
    <SvgFrame
      title={title || "DCL: equilibrio traslacional"}
      subtitle="Bloque en mesa con rozamiento estático"
      badgeLabel="ESTADO"
      badgeValue={ok ? "EQUILIBRIO POSIBLE" : "SE DESLIZA"}
      controls={
        <>
          <button
            type="button"
            onClick={() => exp.startExperiment()}
            style={{
              padding: "10px 14px",
              borderRadius: 14,
              border: "1px solid rgba(255,255,255,0.14)",
              background: "rgba(99,102,241,0.35)",
              color: "rgba(255,255,255,0.92)",
              fontWeight: 900,
              cursor: "pointer",
            }}
            title="Activa modo experimento (desacopla de la calculadora)"
          >
            Experimentar
          </button>

          <button
            type="button"
            onClick={exp.resetToCalculator}
            style={{
              padding: "10px 14px",
              borderRadius: 14,
              border: "1px solid rgba(255,255,255,0.14)",
              background: "rgba(0,0,0,0.35)",
              color: "rgba(255,255,255,0.88)",
              fontWeight: 900,
              cursor: "pointer",
            }}
            title="Volver a seguir a la calculadora"
          >
            Seguir calculadora
          </button>

          {applyToCalculator ? (
            <button
              type="button"
              onClick={applyToCalculator}
              style={{
                padding: "10px 14px",
                borderRadius: 14,
                border: "1px solid rgba(255,255,255,0.14)",
                background: "rgba(2,6,243,0.75)",
                color: "white",
                fontWeight: 900,
                cursor: "pointer",
              }}
              title="Enviar parámetros a la calculadora"
            >
              Aplicar
            </button>
          ) : null}
        </>
      }
      aside={
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div className="v2-panel m-2" style={{ background: "rgba(0,0,0,0.55)" }}>
            <div style={{ fontSize: 11, letterSpacing: 1, opacity: 0.75, fontWeight: 900 }}>
              PARÁMETROS
            </div>

            <div style={{ marginTop: 10, display: "grid", gap: 12 }}>
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>Masa</div>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>{m.toFixed(1)} kg</div>
                </div>
                <div style={{ marginTop: 8 }}>
                  <Slider value={m} min={0.5} max={50} step={0.1} onChange={(v) => { exp.startExperiment(); exp.setValue("m", v); }} />
                </div>
              </div>

              <div>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>F aplicada</div>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>{F.toFixed(1)} N</div>
                </div>
                <div style={{ marginTop: 8 }}>
                  <Slider value={F} min={0} max={400} step={0.5} onChange={(v) => { exp.startExperiment(); exp.setValue("F", v); }} />
                </div>
              </div>

              <div>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>μs</div>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>{mu.toFixed(2)}</div>
                </div>
                <div style={{ marginTop: 8 }}>
                  <Slider value={mu} min={0} max={1.2} step={0.01} onChange={(v) => { exp.startExperiment(); exp.setValue("mu", v); }} />
                </div>
              </div>
            </div>
          </div>

          <div className="v2-panel m-2 mt-0" style={{ background: "rgba(0,0,0,0.35)" }}>
            <div style={{ fontWeight: 900, opacity: 0.95 }}>Lectura rápida</div>
            <div style={{ marginTop: 8, fontSize: 13, opacity: 0.82, lineHeight: 1.45 }}>
              <div><b>P</b> = m g = <span style={{ fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" }}>{P.toFixed(2)} N</span></div>
              <div><b>N</b> ≈ P = <span style={{ fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" }}>{N.toFixed(2)} N</span></div>
              <div><b>fₛ(max)</b> = μs·N = <span style={{ fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" }}>{fsMax.toFixed(2)} N</span></div>
              <div style={{ marginTop: 6, opacity: 0.85 }}>
                Equilibrio si <b>F ≤ fₛ(max)</b>.
              </div>
            </div>
          </div>
        </div>
      }
    >
      <defs>
        <linearGradient id="blockGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#60a5fa" stopOpacity="0.95" />
          <stop offset="1" stopColor="#1d4ed8" stopOpacity="0.95" />
        </linearGradient>
        <filter id="softGlow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="6" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* Suelo */}
      <rect x="70" y="320" width="520" height="10" rx="5" fill="rgba(255,255,255,0.12)" />

      {/* Bloque */}
      <g filter="url(#softGlow)">
        <rect x="260" y="250" width="120" height="70" rx="18" fill="url(#blockGrad)" />
        <rect x="268" y="258" width="104" height="54" rx="14" fill="rgba(255,255,255,0.10)" />
      </g>

      {/* Arrows (DCL) */}
      <Arrow x1={320} y1={250} x2={320} y2={190} label={`N = ${N.toFixed(1)}N`} />
      <Arrow x1={320} y1={320} x2={320} y2={380} label={`P = ${P.toFixed(1)}N`} />
      <Arrow x1={380} y1={285} x2={460} y2={285} label={`F = ${F.toFixed(1)}N`} />
      <Arrow
        x1={260}
        y1={285}
        x2={Math.max(190, 260 - Math.min(80, (fsNeeded / Math.max(1, fsMax)) * 80))}
        y2={285}
        label={ok ? `fₛ = ${fsNeeded.toFixed(1)}N` : `fₛ(max) = ${fsMax.toFixed(1)}N`}
      />

      {/* Estado */}
      <g transform="translate(90,110)">
        <rect width="210" height="44" rx="18" fill={ok ? "rgba(34,197,94,0.20)" : "rgba(239,68,68,0.20)"} stroke="rgba(255,255,255,0.12)" />
        <text x="105" y="27" textAnchor="middle" fontSize="13" fill="rgba(255,255,255,0.92)" style={{ fontWeight: 900 }}>
          {ok ? "ΣF = 0 (equilibrio)" : "F supera el rozamiento"}
        </text>
      </g>
    </SvgFrame>
  );
}
