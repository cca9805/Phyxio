import React, { useMemo, useCallback } from "react";
import SvgFrame from "@/v2/components/graphs_shared/svg2/SvgFrame";
import SvgGround from "@/v2/components/graphs_shared/svg2/SvgGround";
import { useExperimentParams } from "@/v2/components/graphs_shared/experiment/useExperimentParams";

const toNum = (v, fb) => {
  const n = typeof v === "number" ? v : Number(String(v ?? "").replace(",", "."));
  return Number.isFinite(n) ? n : fb;
};

function Slider({ value, min, max, step, onChange }) {
  return (
    <input
      type="range"
      value={value}
      min={min}
      max={max}
      step={step}
      onChange={(e) => onChange(Number(e.target.value))}
      style={{ width: "100%", accentColor: "#6366f1", cursor: "pointer" }}
    />
  );
}

export default function EjemplosEquilibrioSim({ title, params, onSharedParamsChange }) {
  const p = params ?? {};

  const schema = useMemo(
    () => [
      { key: "m", label: "Masa", unit: "kg", step: 0.1, default: toNum(p.m, 10), aliases: ["masa"] },
      { key: "g", label: "Gravedad", unit: "m/s²", step: 0.01, default: toNum(p.g, 9.81), aliases: ["grav"] },
      { key: "F", label: "Fuerza", unit: "N", step: 0.5, default: toNum(p.F, 20), aliases: ["f"] },
      { key: "mu", label: "μs", unit: "", step: 0.01, default: toNum(p.mu, 0.4), aliases: ["mu_s", "mus"] },
    ],
    [p.m, p.g, p.F, p.mu]
  );

  const exp = useExperimentParams({ params: p, schema, modeDefault: "follow" });
  const ep = exp.effectiveParams;

  const m = toNum(ep.m, 10);
  const g = toNum(ep.g, 9.81);
  const F = toNum(ep.F, 20);
  const mu = toNum(ep.mu, 0.4);

  const P = m * g;
  const N = P;
  const fsMax = mu * N;
  const ok = F <= fsMax + 1e-9;

  const setVal = useCallback((k, v) => {
    exp.startExperiment();
    exp.setValue(k, v);
  }, [exp]);

  const applyToCalculator = onSharedParamsChange
    ? () => onSharedParamsChange({ m, g, F, mu })
    : null;

  // Pequeña “ilusión” visual: desplazamiento proporcional al “exceso” de F
  const overflow = Math.max(0, F - fsMax);
  const xShift = Math.min(26, overflow / 6); // px

  return (
    <SvgFrame
      title={title || "Equilibrio: escena"}
      subtitle="Bloque sobre superficie (rozamiento estático)"
      badgeLabel="ESTADO"
      badgeValue={ok ? "ESTABLE" : "INESTABLE"}
      controls={
        <>
          {applyToCalculator ? (
            <button
              type="button"
              onClick={applyToCalculator}
              style={{
                padding: "10px 14px",
                borderRadius: 14,
                border: "1px solid rgba(255,255,255,0.14)",
                background: "rgba(2,6,243,0.75)",
                color: "white",
                fontWeight: 900,
                cursor: "pointer",
              }}
            >
              Aplicar
            </button>
          ) : null}

          <button
            type="button"
            onClick={exp.resetToCalculator}
            style={{
              padding: "10px 14px",
              borderRadius: 14,
              border: "1px solid rgba(255,255,255,0.14)",
              background: "rgba(0,0,0,0.35)",
              color: "rgba(255,255,255,0.88)",
              fontWeight: 900,
              cursor: "pointer",
            }}
            title="Volver a seguir a la calculadora"
          >
            Seguir calculadora
          </button>
        </>
      }
      aside={
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div className="v2-panel m-2" style={{ background: "rgba(0,0,0,0.55)" }}>
            <div style={{ fontSize: 11, letterSpacing: 1, opacity: 0.75, fontWeight: 900 }}>
              CONTROLES
            </div>

            <div style={{ marginTop: 10, display: "grid", gap: 12 }}>
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>Masa</div>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>{m.toFixed(1)} kg</div>
                </div>
                <div style={{ marginTop: 8 }}>
                  <Slider value={m} min={0.5} max={50} step={0.1} onChange={(v) => setVal("m", v)} />
                </div>
              </div>

              <div>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>F aplicada</div>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>{F.toFixed(1)} N</div>
                </div>
                <div style={{ marginTop: 8 }}>
                  <Slider value={F} min={0} max={400} step={0.5} onChange={(v) => setVal("F", v)} />
                </div>
              </div>

              <div>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <div style={{ fontSize: 13, fontWeight: 900, opacity: 0.9 }}>μs</div>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>{mu.toFixed(2)}</div>
                </div>
                <div style={{ marginTop: 8 }}>
                  <Slider value={mu} min={0} max={1.2} step={0.01} onChange={(v) => setVal("mu", v)} />
                </div>
              </div>
            </div>
          </div>

          <div className="v2-panel m-2 mt-0" style={{ background: "rgba(0,0,0,0.35)" }}>
            <div style={{ fontWeight: 900, opacity: 0.95 }}>Resumen</div>
            <div style={{ marginTop: 8, fontSize: 13, opacity: 0.82, lineHeight: 1.45 }}>
              <div><b>fₛ(max)</b> = μs·N = {fsMax.toFixed(2)} N</div>
              <div><b>F</b> = {F.toFixed(2)} N</div>
              <div style={{ marginTop: 6 }}>
                {ok ? "Equilibrio posible: el rozamiento compensa." : "No hay equilibrio: F supera el rozamiento."}
              </div>
            </div>
          </div>
        </div>
      }
    >
      <defs>
        <linearGradient id="sceneSky" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1e3a8a" stopOpacity="0.35" />
          <stop offset="1" stopColor="#0b1220" stopOpacity="0.65" />
        </linearGradient>

        <linearGradient id="blockGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#93c5fd" stopOpacity="0.95" />
          <stop offset="1" stopColor="#2563eb" stopOpacity="0.95" />
        </linearGradient>

        <filter id="glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="7" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* Fondo */}
      <rect x="70" y="78" width="520" height="290" rx="26" fill="url(#sceneSky)" />

      {/* Suelo */}
      <SvgGround x={80} y={340} width={500} />

      {/* Bloque */}
      <g transform={`translate(${xShift},0)`} filter="url(#glow)">
        <rect x="280" y="260" width="120" height="70" rx="18" fill="url(#blockGrad)" />
        <rect x="288" y="268" width="104" height="54" rx="14" fill="rgba(255,255,255,0.10)" />

        {/* Etiqueta */}
        <g transform="translate(280,220)">
          <rect width="120" height="32" rx="16" fill="rgba(15,23,42,0.55)" stroke="rgba(255,255,255,0.10)" />
          <text x="60" y="21" fontSize="12" fill="rgba(255,255,255,0.92)" textAnchor="middle" style={{ fontWeight: 900 }}>
            {ok ? "Equilibrio" : "Deslizamiento"}
          </text>
        </g>
      </g>

      {/* Indicadores */}
      <g transform="translate(92,100)">
        <rect width="220" height="54" rx="18" fill="rgba(0,0,0,0.35)" stroke="rgba(255,255,255,0.10)" />
        <text x="16" y="22" fontSize="12" fill="rgba(255,255,255,0.85)" style={{ fontWeight: 900 }}>
          ΣFx = 0
        </text>
        <text x="16" y="40" fontSize="12" fill="rgba(255,255,255,0.75)">
          F {ok ? "≤" : ">"} μs·N
        </text>

        <text x="130" y="22" fontSize="12" fill="rgba(255,255,255,0.85)" style={{ fontWeight: 900 }}>
          N = mg
        </text>
        <text x="130" y="40" fontSize="12" fill="rgba(255,255,255,0.75)">
          {N.toFixed(2)} N
        </text>
      </g>
    </SvgFrame>
  );
}
