import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function toNum(v, fb) {
  if (v == null || v === "") return fb;
  if (typeof v === "number") return Number.isFinite(v) ? v : fb;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fb;
}
function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function buildSeries({ m, r, vMax = 30, step = 0.5 }) {
  const rr = Math.max(1e-6, r);
  const out = [];
  for (let v = 0; v <= vMax + 1e-12; v += step) {
    const ac = (v * v) / rr;
    const Fc = m * ac;
    out.push({ v, ac, Fc });
  }
  return out;
}

export default function EjemplosTipicosFuerzaCentripetaGraphsCoord() {
  const [example, setExample] = useState("cuerda"); // cuerda | curva | loop | orbita
  const [m, setM] = useState(1);
  const [r, setR] = useState(2);
  const [v, setV] = useState(10);

  const presets = useMemo(
    () => ({
      cuerda: { m: 0.2, r: 0.8, v: 6 },
      curva: { m: 1200, r: 50, v: 15 },
      loop: { m: 60, r: 12, v: 14 },
      orbita: { m: 500, r: 6.8e6, v: 7700 },
    }),
    []
  );

  const applyPreset = (key) => {
    const p = presets[key] || presets.cuerda;
    setM(p.m);
    setR(p.r);
    setV(p.v);
  };

  const safe = useMemo(() => {
    const mm = clamp(toNum(m, 1), 0.001, 1e9);
    const rr = clamp(toNum(r, 2), 0.05, 1e12);
    const vv = clamp(toNum(v, 10), 0, 1e6);
    return { m: mm, r: rr, v: vv };
  }, [m, r, v]);

  const ac = useMemo(() => (safe.v * safe.v) / safe.r, [safe.v, safe.r]);
  const Fc = useMemo(() => safe.m * ac, [safe.m, ac]);

  const vMax = useMemo(() => {
    if (example === "orbita") return Math.max(8000, safe.v * 1.2);
    return 30;
  }, [example, safe.v]);

  const step = useMemo(() => {
    if (example === "orbita") return Math.max(50, vMax / 120);
    return 0.5;
  }, [example, vMax]);

  const data = useMemo(
    () => buildSeries({ m: safe.m, r: safe.r, vMax, step }),
    [safe.m, safe.r, vMax, step]
  );

  const labelExample = {
    cuerda: "Piedra con cuerda (tensión aporta la centrípeta)",
    curva: "Coche en curva plana (rozamiento aporta la centrípeta)",
    loop: "Loop vertical (tensión y peso aportan la resultante radial)",
    orbita: "Órbita circular (gravitatoria aporta la centrípeta)",
  }[example];

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Ejemplos típicos de fuerza centrípeta (Coord)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          {labelExample}
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">Ejemplo</div>
            <select
              className="form-control"
              value={example}
              onChange={(e) => {
                const k = e.target.value;
                setExample(k);
                applyPreset(k);
              }}
            >
              <option value="cuerda">Cuerda</option>
              <option value="curva">Curva</option>
              <option value="loop">Loop</option>
              <option value="orbita">Órbita</option>
            </select>
          </div>

          <div className="v2-card">
            <div className="v2-card-title">m (kg)</div>
            <input className="form-control" inputMode="decimal" value={m} onChange={(e) => setM(e.target.value)} />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">r (m)</div>
            <input className="form-control" inputMode="decimal" value={r} onChange={(e) => setR(e.target.value)} />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">v (m/s)</div>
            <input className="form-control" inputMode="decimal" value={v} onChange={(e) => setV(e.target.value)} />
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10, lineHeight: 1.45 }}>
          a<sub>c</sub> = <b>{fmt(ac, 6)}</b> m/s² · F<sub>c</sub> = <b>{fmt(Fc, 6)}</b> N
          <br />
          Regla: a<sub>c</sub> ∝ v² (si duplicas v, a<sub>c</sub> y F<sub>c</sub> se multiplican por 4).
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Curvas: a_c(v) y F_c(v)</div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis
                dataKey="v"
                type="number"
                domain={[0, vMax]}
                tickFormatter={(vv) => fmt(vv, 2)}
                label={{ value: "v (m/s)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                yAxisId="left"
                tickFormatter={(vv) => fmt(vv, 3)}
                label={{ value: "a_c (m/s²)", angle: -90, position: "insideLeft" }}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                tickFormatter={(vv) => fmt(vv, 3)}
                label={{ value: "F_c (N)", angle: -90, position: "insideRight" }}
              />
              <Tooltip
                formatter={(val) => fmt(val, 6)}
                labelFormatter={(x) => `v = ${fmt(x, 3)} m/s`}
              />
              <Line yAxisId="left" type="monotone" dataKey="ac" dot={false} name="a_c = v²/r" />
              <Line yAxisId="right" type="monotone" dataKey="Fc" dot={false} name="F_c = m·v²/r" />
              <ReferenceDot yAxisId="left" x={safe.v} y={ac} r={5} />
              <ReferenceDot yAxisId="right" x={safe.v} y={Fc} r={5} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          En todos los casos, “centrípeta” significa <b>resultante radial</b> de fuerzas reales.
        </div>
      </div>
    </div>
  );
}
