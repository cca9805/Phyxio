import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceDot,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";
import { pickParam } from "../../../utils/pickParamGraphs";
import { defaultParams, seriesFcf, Fcf_v, Fcf_omega } from "../../../engine/models/dinamica/fuerzaCentrifuga";

function toNum(v, f = NaN) {
  if (v == null || v === "") return f;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : f;
}

function NumInput({ label, value, onChange, disabled }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="form-control"
        type="number"
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

export default function FuerzaCentrifugaGraphs({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({ ...defaultParams() }));

  // 🔗 leer desde calculadora
  useEffect(() => {
    if (!linked || !params) return;

    setP((prev) => ({
      ...prev,
      m: pickParam(params, ["m"], prev.m),
      v: pickParam(params, ["v"], prev.v),
      omega: pickParam(params, ["omega", "w"], prev.omega),
    }));
  }, [linked, params]);

  const safe = useMemo(() => ({
    ...p,
    m: Math.max(0.1, toNum(p.m, 70)),
    v: Math.max(0, toNum(p.v, 10)),
    omega: Math.max(0, toNum(p.omega, 1)),
    rObs: Math.max(0.1, toNum(p.rObs, 10)),
  }), [p]);

  const data = useMemo(() => seriesFcf(safe), [safe]);

  const FvObs = Fcf_v(safe.m, safe.v, safe.rObs);
  const FwObs = Fcf_omega(safe.m, safe.omega, safe.rObs);

  return (
    <div className="v2-card" style={{ padding: 12 }}>
      <div className="v2-card-title">Fuerza centrífuga vs radio</div>

      {/* BOTONES */}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8 }}>
        <button className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`} onClick={() => setLinked(true)}>
          🔗 Seguir calculadora
        </button>
        <button className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`} onClick={() => setLinked(false)}>
          🧪 Experimento
        </button>
      </div>

      {/* INPUTS */}
      <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
        <NumInput label="Masa (kg)" value={safe.m} disabled={linked} onChange={(v) => setP(s => ({ ...s, m: v }))} />
        <NumInput label="Velocidad v (m/s)" value={safe.v} disabled={linked} onChange={(v) => setP(s => ({ ...s, v: v }))} />
        <NumInput label="ω (rad/s)" value={safe.omega} disabled={linked} onChange={(v) => setP(s => ({ ...s, omega: v }))} />
        <NumInput label="Radio marcador (m)" value={safe.rObs} disabled={linked} onChange={(v) => setP(s => ({ ...s, rObs: v }))} />
      </div>

      {/* INFO */}
      <div className="muted" style={{ marginTop: 8 }}>
        En r = {fmt(safe.rObs)} m →  
        F(v) = <b>{fmt(FvObs)} N</b> ··  
        F(ω) = <b>{fmt(FwObs)} N</b>
      </div>

      {/* GRÁFICO */}
      <div style={{ width: "100%", height: 320, marginTop: 10 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid />
            <XAxis dataKey="r" label={{ value: "Radio r (m)", position: "insideBottom", offset: -5 }} />
            <YAxis label={{ value: "Fuerza (N)", angle: -90, position: "insideLeft" }} />
            <Tooltip formatter={(v) => fmt(v)} />
            <Legend />
            <Line dataKey="F_v" name="F = m v² / r" dot={false} />
            <Line dataKey="F_omega" name="F = m ω² r" dot={false} />
            <ReferenceDot x={safe.rObs} y={FvObs} r={4} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
