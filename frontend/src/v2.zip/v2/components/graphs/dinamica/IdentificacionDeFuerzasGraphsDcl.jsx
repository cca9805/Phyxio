import React, { useMemo, useState } from "react";

export default function IdentificacionDeFuerzasDcl() {
  const [scene, setScene] = useState("table"); // table | incline | hanging
  const [theta, setTheta] = useState(25);
  const [showFriction, setShowFriction] = useState(true);

  const t = useMemo(() => {
    const th = Number(theta);
    return Number.isFinite(th) ? Math.max(5, Math.min(60, th)) : 25;
  }, [theta]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Identificación de fuerzas (DCL)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Aísla el cuerpo y dibuja solo fuerzas reales: <b>mg</b>, <b>N</b>, <b>T</b>, <b>f</b>.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración de escena */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🔍 Escenario:</span>
              <select className="form-control" style={{ width: 240 }} value={scene} onChange={(e) => setScene(e.target.value)}>
                <option value="table">Bloque en mesa</option>
                <option value="incline">Bloque en plano inclinado</option>
                <option value="hanging">Masa colgante</option>
              </select>
            </div>

            {scene === "incline" && (
              <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                <span>📐 θ (°)</span>
                <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                  
                  <input className="form-control" style={{ width: 80 }} inputMode="numeric" value={theta} onChange={(e) => setTheta(e.target.value)} />
                </label>
              </div>
            )}
          </div>

          {/* Segunda fila: Opciones de fuerzas */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>⚡ Fuerzas:</span>
            
            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showFriction" 
                checked={showFriction} 
                onChange={(e) => setShowFriction(e.target.checked)} 
              />
              <label className="v2-checkbox-label" htmlFor="showFriction">Rozamiento</label>
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Identificación de Fuerzas</div>

        <svg viewBox="0 0 560 240" width="100%" height="240" style={{ marginTop: 10 }}>
          <rect x="0" y="0" width="560" height="240" fill="#b8c5ffff" />
          {/* cuerpo */}
          <rect x="240" y="70" width="90" height="60" rx="10" fill="#e5e7eb" stroke="#0f172a" strokeWidth="2" />
          <circle cx="285" cy="100" r="4" fill="#0f172a" />

          {/* mg */}
          <line x1="285" y1="130" x2="285" y2="180" stroke="#dc2626" strokeWidth="3" />
          <polygon points="285,192 279,180 291,180" fill="#dc2626" />
          <text x="295" y="192" fontSize="13" fill="#dc2626" fontWeight="bold">
            mg
          </text>

          {/* depending on scene */}
          {scene !== "hanging" && (
            <>
              {/* N */}
              <line x1="285" y1="70" x2="285" y2="20" stroke="#16a34a" strokeWidth="3" />
              <polygon points="285,10 279,22 291,22" fill="#16a34a" />
              <text x="295" y="22" fontSize="13" fill="#16a34a" fontWeight="bold">
                N
              </text>
            </>
          )}

          {scene === "hanging" && (
            <>
              {/* T */}
              <line x1="285" y1="120" x2="285" y2="60" stroke="#16a34a" strokeWidth="3" />
              <polygon points="285,50 279,62 291,62" fill="#16a34a" />
              <text x="295" y="74" fontSize="13" fill="#16a34a" fontWeight="bold">
                T
              </text>
            </>
          )}

          {(scene === "table" || scene === "incline") && showFriction && (
            <>
              {/* f (horizontal example) */}
              <line x1="240" y1="100" x2="175" y2="100" stroke="#f59e0b" strokeWidth="3" />
              <polygon points="165,100 177,94 177,106" fill="#f59e0b" />
              <text x="155" y="104" textAnchor="end" fontSize="12" fill="#f59e0b" fontWeight="bold">
                f
              </text>
            </>
          )}

          {scene === "incline" && (
            <text x="90" y="220" fontSize="8" fill="#64748b">
              Plano inclinado: N es perpendicular al plano. Aquí se dibuja vertical por simplicidad (en SVG lo verás bien).
            </text>
          )}
        </svg>
      </div>
    </div>
  );
}
