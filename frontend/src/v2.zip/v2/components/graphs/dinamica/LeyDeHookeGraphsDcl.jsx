import React, { useMemo, useState } from "react";

/**
 * Ley de Hooke (DCL)
 * - Escenas: muelle horizontal (bloque en mesa) y muelle vertical (masa colgante).
 * - Vectores: Fs (elástica), W, N (si aplica) y Fext (opcional, para equilibrio).
 * Estilo: fondo #b8c5ffff + panel + flechas con punta.
 */
export default function LeyDeHookeGraphsDcl() {
  const [scene, setScene] = useState("horizontal"); // horizontal | vertical
  const [k, setK] = useState(80);
  const [x, setX] = useState(0.12);
  const [m, setM] = useState(1.2);
  const [g, setG] = useState(9.81);

  const [showAxes, setShowAxes] = useState(true);
  const [showLabels, setShowLabels] = useState(true);
  const [showFext, setShowFext] = useState(true);

  const toNum = (v, d) => {
    if (v == null || v === "") return d;
    const n = Number(String(v).replace(",", "."));
    return Number.isFinite(n) ? n : d;
  };
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));

  const safe = useMemo(() => {
    const kk = clamp(toNum(k, 80), 0.1, 2000);
    const xx = clamp(toNum(x, 0.12), -0.4, 0.4);
    const mm = clamp(toNum(m, 1.2), 0.05, 100);
    const gg = clamp(toNum(g, 9.81), 0.1, 30);
    return { k: kk, x: xx, m: mm, g: gg };
  }, [k, x, m, g]);

  const Fs = -safe.k * safe.x;
  const W = safe.m * safe.g;

  const fmt = (val) => {
    const n = Number(val);
    if (!Number.isFinite(n)) return "—";
    return n.toFixed(3).replace(".", ",");
  };

  const C = {
    bg: "#b8c5ffff",
    card: "#ffffff",
    stroke: "#d6e5ff",
    ink: "#0f172a",
    muted: "#64748b",
    axis: "#5b7aa8",
    W: "#ff2d55",
    N: "#34c759",
    Fs: "#7c3aed",
    Fext: "#006aff",
  };

  const Wsvg = 920;
  const Hsvg = 420;
  const O = { x: 610, y: 240 };
  const px = 18;

  const toPt = (v) => ({ x: O.x + v.x * px, y: O.y + v.y * px });

  const Arrow = ({ v, stroke, label, w = 8, dashed = false }) => {
    const p1 = O;
    const p2 = toPt(v);
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const L = Math.hypot(dx, dy) || 1;
    const ux = dx / L;
    const uy = dy / L;

    const head = 14;
    const wing = 8;

    const hx = p2.x;
    const hy = p2.y;
    const lx = hx - ux * head - uy * wing;
    const ly = hy - uy * head + ux * wing;
    const rx = hx - ux * head + uy * wing;
    const ry = hy - uy * head - ux * wing;

    return (
      <g>
        <line
          x1={p1.x}
          y1={p1.y}
          x2={hx}
          y2={hy}
          stroke={stroke}
          strokeWidth={w}
          strokeLinecap="round"
          strokeDasharray={dashed ? "10 10" : undefined}
        />
        <polygon points={`${hx},${hy} ${lx},${ly} ${rx},${ry}`} fill={stroke} opacity="0.96" />
        {showLabels && (
          <text x={hx + 10} y={hy + 6} fontSize="18" fontWeight="900" fill={stroke}>
            {label}
          </text>
        )}
      </g>
    );
  };

  const Axis = ({ dir, label }) => {
    const len = 12;
    const v = { x: dir.x * len, y: -dir.y * len };
    const p2 = toPt(v);
    return (
      <g opacity="0.9">
        <line x1={O.x} y1={O.y} x2={p2.x} y2={p2.y} stroke={C.axis} strokeWidth={4} strokeLinecap="round" />
        <text x={p2.x + 8} y={p2.y + 6} fontSize="14" fill={C.axis} fontWeight="800">
          {label}
        </text>
      </g>
    );
  };

  // Escalado visual para que sea estable
  const Fscale = useMemo(() => {
    const base = Math.max(Math.abs(Fs), W, 1);
    return 10 / base;
  }, [Fs, W]);

  // Horizontal: Fs en x, y añadimos W y N pequeños
  const vFs_h = { x: clamp(Fs * Fscale, -12, 12), y: 0 };
  const vFext_h = { x: clamp(-Fs * Fscale, -12, 12), y: 0 };
  const vW_small = { x: 0, y: 6 };
  const vN_small = { x: 0, y: -6 };

  // Vertical: W abajo, Fs arriba (si x>0 estirado), Fext opcional
  const vW_v = { x: 0, y: clamp(+W * Fscale, -12, 12) };
  const vFs_v = { x: 0, y: clamp(-Fs * Fscale, -12, 12) }; // signo para mostrar restauradora
  const vFext_v = { x: 0, y: clamp(-W * Fscale, -12, 12) };

  return (
    <div className="v2-graphs">
      {/* Card azul - Configuración principal */}
      <div className="v2-card" style={{ background: 'rgba(59, 130, 246, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div className="v2-grid-fill-inputs">
          <div className="v2-input-group">
            <label>🎬 Escena</label>
            <select className="form-control" value={scene} onChange={(e) => setScene(e.target.value)}>
              <option value="horizontal">Muelle horizontal (bloque)</option>
              <option value="vertical">Muelle vertical (masa colgante)</option>
            </select>
          </div>

          <div className="v2-input-group">
            <label>🔧 k (N/m)</label>
            <input className="form-control" inputMode="decimal" value={k} onChange={(e) => setK(e.target.value)} />
          </div>

          <div className="v2-input-group">
            <label>📏 x (m)</label>
            <input className="form-control" inputMode="decimal" value={x} onChange={(e) => setX(e.target.value)} />
          </div>

          <div className="v2-input-group" style={{ opacity: scene === "vertical" ? 1 : 0.55 }}>
            <label>⚖️ m (kg)</label>
            <input className="form-control" inputMode="decimal" value={m} onChange={(e) => setM(e.target.value)} disabled={scene !== "vertical"} />
          </div>

          <div className="v2-input-group" style={{ opacity: scene === "vertical" ? 1 : 0.55 }}>
            <label>🌍 g (m/s²)</label>
            <input className="form-control" inputMode="decimal" value={g} onChange={(e) => setG(e.target.value)} disabled={scene !== "vertical"} />
          </div>
        </div>
      </div>

      {/* Card verde - Controles de visualización */}
      <div className="v2-card" style={{ background: 'rgba(34, 197, 94, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div style={{ 
          display: "flex", 
          gap: 18, 
          alignItems: "center", 
          flexWrap: "wrap",
          justifyContent: "center"
        }}>
          <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
          
          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showLabels"
              checked={showLabels}
              onChange={(e) => setShowLabels(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showLabels">Etiquetas</label>
          </div>

          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showAxes"
              checked={showAxes}
              onChange={(e) => setShowAxes(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showAxes">Ejes</label>
          </div>

          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showFext"
              checked={showFext}
              onChange={(e) => setShowFext(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showFext">F externa (equilibrio)</label>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12, overflow: "hidden" }}>
        <svg viewBox={`0 0 ${Wsvg} ${Hsvg}`} width="100%" height="340" style={{ display: "block" }}>
          <rect x="0" y="0" width={Wsvg} height={Hsvg} fill={C.bg} />

          <rect x="18" y="18" width="450" height="154" rx="14" fill={C.card} stroke={C.stroke} strokeWidth="3" opacity="0.96" />
          <text x="34" y="50" fontSize="18" fontWeight="900" fill={C.ink}>
            Datos
          </text>
          <text x="34" y="78" fontSize="14" fill={C.muted}>
            Fs = −k·x = {fmt(Fs)} N
          </text>
          {scene === "vertical" ? (
            <>
              <text x="34" y="100" fontSize="14" fill={C.muted}>
                W = mg = {fmt(W)} N
              </text>
              <text x="34" y="122" fontSize="14" fill={C.muted}>
                Equilibrio: Fs ≈ W  → x ≈ mg/k
              </text>
            </>
          ) : (
            <>
              <text x="34" y="100" fontSize="14" fill={C.muted}>
                En mesa: Fs apunta hacia el equilibrio
              </text>
              <text x="34" y="122" fontSize="14" fill={C.muted}>
                Equilibrio: Fext = −Fs
              </text>
            </>
          )}

          <circle cx={O.x} cy={O.y} r="10" fill={C.ink} opacity="0.85" />

          {showAxes && (
            <>
              <Axis dir={{ x: 1, y: 0 }} label="x" />
              <Axis dir={{ x: 0, y: 1 }} label="y" />
            </>
          )}

          {scene === "horizontal" ? (
            <>
              <Arrow v={vFs_h} stroke={C.Fs} label="Fs" />
              {showFext && <Arrow v={vFext_h} stroke={C.Fext} label="Fext" dashed />}
              <Arrow v={vW_small} stroke={C.W} label="W" w={7} />
              <Arrow v={vN_small} stroke={C.N} label="N" w={7} />
            </>
          ) : (
            <>
              <Arrow v={vW_v} stroke={C.W} label="W" />
              <Arrow v={vFs_v} stroke={C.Fs} label="Fs" />
              {showFext && <Arrow v={vFext_v} stroke={C.Fext} label="Fext" dashed />}
            </>
          )}
        </svg>
      </div>
    </div>
  );
}
