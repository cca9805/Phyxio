import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function buildSeries({ m, g, stepDeg = 1, thetaMax = 60 }) {
  const out = [];
  for (let th = 0; th <= thetaMax; th += stepDeg) {
    const rad = (th * Math.PI) / 180;
    const W = m * g;
    const N = W * Math.cos(rad);
    out.push({
      theta: th,
      W,
      N,
      Wpar: W * Math.sin(rad),
      Wperp: W * Math.cos(rad),
    });
  }
  return out;
}

export default function NormalEnPlanosGraphsCoord() {
  const [m, setM] = useState(10);
  const [g, setG] = useState(9.81);
  const [theta, setTheta] = useState(25);

  const [showN, setShowN] = useState(true);
  const [showW, setShowW] = useState(true);
  const [showComponents, setShowComponents] = useState(true);

  const mm = useMemo(() => clamp(toNum(m, 10), 0.1, 200), [m]);
  const gg = useMemo(() => clamp(toNum(g, 9.81), 0.1, 30), [g]);
  const thDeg = useMemo(() => clamp(toNum(theta, 25), 0, 60), [theta]);

  const data = useMemo(() => buildSeries({ m: mm, g: gg, stepDeg: 1, thetaMax: 60 }), [mm, gg]);

  const current = useMemo(() => {
    const rad = (thDeg * Math.PI) / 180;
    const W = mm * gg;
    return {
      theta: thDeg,
      W,
      N: W * Math.cos(rad),
      Wpar: W * Math.sin(rad),
      Wperp: W * Math.cos(rad),
    };
  }, [mm, gg, thDeg]);

  const yMax = useMemo(() => {
    const W = mm * gg;
    return Math.max(W, 1) * 1.05;
  }, [mm, gg]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Normal en planos (Coord)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Gráfico de coordenadas: cómo cambia la <b>normal</b> con el ángulo del plano.
          En reposo (sin aceleración perpendicular): <b>N = mg·cosθ</b>.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Parámetros principales */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>⚙️ Parámetros:</span>
            
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#fbbf24" }}>⚖️</span> m (kg)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={m}
                  onChange={(e) => setM(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#34d399" }}>🌍</span> g (m/s²)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={g}
                  onChange={(e) => setG(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#f87171" }}>📐</span> θ actual (°)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="numeric"
                  value={theta}
                  onChange={(e) => setTheta(e.target.value)}
                />
              </label>
            </div>
          </div>

          {/* Segunda fila: Controles de visualización */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
            
            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showN"
                checked={showN}
                onChange={(e) => setShowN(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showN">N(θ)</label>
            </div>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showW"
                checked={showW}
                onChange={(e) => setShowW(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showW">W = mg</label>
            </div>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showComponents"
                checked={showComponents}
                onChange={(e) => setShowComponents(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showComponents">mg‖ / mg⟂</label>
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="muted" style={{ marginBottom: 10 }}>
          Punto actual: θ = <b>{fmt(current.theta, 0)}°</b> · N = <b>{fmt(current.N, 2)} N</b> · W = <b>{fmt(current.W, 2)} N</b>
        </div>

        <div style={{ width: "100%", height: 360 }}>
          <ResponsiveContainer>
            <LineChart data={data} margin={{ top: 10, right: 18, left: 8, bottom: 10 }}>
              <CartesianGrid strokeDasharray="4 4" />
              <XAxis
                dataKey="theta"
                type="number"
                domain={[0, 60]}
                tickFormatter={(v) => `${v}°`}
                label={{ value: "θ (°)", position: "insideBottomRight", offset: -5 }}
              />
              <YAxis
                domain={[0, yMax]}
                tickFormatter={(v) => fmt(v, 0)}
                label={{ value: "F (N)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(value, name) => [fmt(value, 2), name]}
                labelFormatter={(label) => `θ = ${fmt(label, 0)}°`}
              />

              {showW && (
                <Line
                  type="monotone"
                  dataKey="W"
                  name="W = mg"
                  strokeWidth={3}
                  dot={false}
                />
              )}

              {showN && (
                <Line
                  type="monotone"
                  dataKey="N"
                  name="N = mg·cosθ"
                  strokeWidth={3}
                  dot={false}
                />
              )}

              {showComponents && (
                <>
                  <Line
                    type="monotone"
                    dataKey="Wpar"
                    name="mg‖ = mg·senθ"
                    strokeWidth={2}
                    dot={false}
                    strokeDasharray="6 6"
                  />
                  <Line
                    type="monotone"
                    dataKey="Wperp"
                    name="mg⟂ = mg·cosθ"
                    strokeWidth={2}
                    dot={false}
                    strokeDasharray="6 6"
                  />
                </>
              )}

              {/* Marca el punto actual */}
              {showN && (
                <ReferenceDot x={current.theta} y={current.N} r={5} isFront />
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
