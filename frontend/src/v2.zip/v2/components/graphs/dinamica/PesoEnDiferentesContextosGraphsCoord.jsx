import React, { useMemo, useState } from "react";

const BG = "#b8c5ffff";

// Contextos típicos (puedes ajustar valores si quieres)
const CONTEXTS = [
  { value: "earth", label: "Tierra (g ≈ 9.81)", g: 9.81 },
  { value: "moon", label: "Luna (g ≈ 1.62)", g: 1.62 },
  { value: "mars", label: "Marte (g ≈ 3.71)", g: 3.71 },
  { value: "jupiter", label: "Júpiter (g ≈ 24.79)", g: 24.79 },
  { value: "elevator", label: "Ascensor (g + a)", g: 9.81 },
];

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function num(v, fb) {
  if (v == null || v === "") return fb;
  const n = typeof v === "number" ? v : Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fb;
}

export default function PesoEnDiferentesContextosGraphsCoord() {
  const [context, setContext] = useState("earth");
  const [m, setM] = useState(10);
  const [a, setA] = useState(0); // solo ascensor (m/s²), + arriba

  const ctx = useMemo(() => CONTEXTS.find((c) => c.value === context) ?? CONTEXTS[0], [context]);

  const mm = useMemo(() => clamp(num(m, 10), 0.1, 200), [m]);
  const aa = useMemo(() => clamp(num(a, 0), -9.5, 9.5), [a]);

  const gEff = ctx.value === "elevator" ? ctx.g + aa : ctx.g;
  const W = mm * ctx.g; // peso real mg (siempre con g "del lugar")
  const N = mm * gEff; // aparente (si a!=0)

  // Para el "gráfico Coord" lo representamos con una escala vertical común
  const Fmax = Math.max(W, Math.abs(N), 1) * 1.2;

  const H = 520;
  const Wsvg = 860;

  // Layout dentro del SVG (para evitar reboses y solapes)
  const sceneBox = { x: 44, y: 78, w: 520, h: 360 };
  const panelBox = { x: 592, y: 78, w: 224, h: 220 };
  const barsBox = { x: 592, y: 320, w: 224, h: 118 };

  const C = {
    ink: "#0f172a",
    muted: "#64748b",
    card: "rgba(255,255,255,0.92)",
    stroke: "#e2e8f0",
    mg: "#dc2626",
    N: "#60a5fa",
    axis: "#6366f1",
  };

  // Helpers SVG
  const Arrow = ({ x1, y1, x2, y2, color, w = 8 }) => {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const L = Math.hypot(dx, dy) || 1;
    const ux = dx / L;
    const uy = dy / L;
    const head = 16;

    const hx = x2;
    const hy = y2;
    const leftx = hx - ux * head - uy * (head * 0.6);
    const lefty = hy - uy * head + ux * (head * 0.6);
    const rightx = hx - ux * head + uy * (head * 0.6);
    const righty = hy - uy * head - ux * (head * 0.6);

    return (
      <g>
        <line x1={x1} y1={y1} x2={hx} y2={hy} stroke={color} strokeWidth={w} strokeLinecap="round" />
        <polygon points={`${hx},${hy} ${leftx},${lefty} ${rightx},${righty}`} fill={color} opacity="0.95" />
      </g>
    );
  };

  // Bar helpers
  const barH = (val) => clamp((Math.abs(val) / Fmax) * (barsBox.h - 36), 0, barsBox.h - 36);

  const mgBar = barH(W);
  const nBar = barH(N);

  const fmt = (x) => {
    const n = Number(x);
    if (!Number.isFinite(n)) return "—";
    return n.toFixed(2).replace(".", ",");
  };

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Peso en diferentes contextos (Coord)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Compara el <b>peso real</b> (<b>W = m·g</b>) con el <b>peso aparente</b> (lectura de báscula: <b>N = m·(g+a)</b> en
          ascensor).
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🌍 Contexto:</span>
              <select
                className="form-control"
                style={{ width: 200 }}
                value={context}
                onChange={(e) => setContext(e.target.value)}
              >
                {CONTEXTS.map((c) => (
                  <option key={c.value} value={c.value}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#fbbf24" }}>⚖️</span> m (kg)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={m}
                  onChange={(e) => setM(e.target.value)}
                />
              </label>
              
              {context === "elevator" && (
                <>
                  <span style={{ color: "#f87171" }}>🚀</span> a (m/s²)
                  <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                    <input
                      className="form-control"
                      style={{ width: 80 }}
                      inputMode="decimal"
                      value={a}
                      onChange={(e) => setA(e.target.value)}
                    />
                  </label>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12, overflow: "hidden" }}>
        <svg width="100%" height={H} viewBox={`0 0 ${Wsvg} ${H}`} preserveAspectRatio="xMidYMid meet">
          {/* Fondo pedido */}
          <rect x="0" y="0" width={Wsvg} height={H} fill={BG} />

          {/* Título */}
          <text x="44" y="44" fontSize="20" fontWeight="900" fill={C.ink}>
            Visual: fuerzas verticales y comparación W vs N
          </text>

          {/* Caja escena */}
          <rect x={sceneBox.x} y={sceneBox.y} width={sceneBox.w} height={sceneBox.h} rx="18" fill={C.card} stroke={C.stroke} strokeWidth="2" />

          {/* Eje vertical simple dentro de escena */}
          <g>
            <line
              x1={sceneBox.x + 70}
              y1={sceneBox.y + 40}
              x2={sceneBox.x + 70}
              y2={sceneBox.y + sceneBox.h - 40}
              stroke={C.axis}
              strokeWidth="4"
              opacity="0.85"
            />
            <text x={sceneBox.x + 52} y={sceneBox.y + 34} fontSize="14" fill={C.muted}>
              F
            </text>
          </g>

          {/* "cuerpo" (bloque) */}
          {(() => {
            const bx = sceneBox.x + 220;
            const by = sceneBox.y + 165;
            const bw = 120;
            const bh = 120;

            const cx = bx + bw / 2;
            const cy = by + bh / 2;

            const arrowLen = 120;

            return (
              <g>
                <rect x={bx} y={by} width={bw} height={bh} rx="16" fill="#ffffff" stroke={C.stroke} strokeWidth="2" />
                <text x={cx} y={cy + 8} textAnchor="middle" fontSize="18" fontWeight="900" fill={C.ink}>
                  m
                </text>

                {/* Flecha N */}
                <Arrow x1={cx} y1={by} x2={cx} y2={by - arrowLen * clamp(N / Fmax, 0, 1)} color={C.N} w={9} />
                <text x={cx + 16} y={by - arrowLen * clamp(N / Fmax, 0, 1) - 4} fontSize="16" fontWeight="800" fill={C.N}>
                  N
                </text>

                {/* Flecha mg */}
                <Arrow x1={cx} y1={by + bh} x2={cx} y2={by + bh + arrowLen * clamp(W / Fmax, 0, 1)} color={C.mg} w={9} />
                <text x={cx + 16} y={by + bh + arrowLen * clamp(W / Fmax, 0, 1) + 18} fontSize="16" fontWeight="800" fill={C.mg}>
                  W = mg
                </text>

                {/* Nota ascensor */}
                {context === "elevator" && (
                  <text x={sceneBox.x + 30} y={sceneBox.y + sceneBox.h - 18} fontSize="14" fill={C.muted}>
                    En ascensor: N = m·(g+a)
                  </text>
                )}
              </g>
            );
          })()}

          {/* Panel de componentes/datos (derecha) */}
          <rect x={panelBox.x} y={panelBox.y} width={panelBox.w} height={panelBox.h} rx="18" fill={C.card} stroke={C.stroke} strokeWidth="2" />
          <text x={panelBox.x + 16} y={panelBox.y + 34} fontSize="16" fontWeight="900" fill={C.ink}>
            Valores
          </text>

          <g fontSize="14" fill={C.ink}>
            <text x={panelBox.x + 16} y={panelBox.y + 64}>
              g (lugar) = <tspan fontWeight="900">{fmt(ctx.g)}</tspan> m/s²
            </text>
            <text x={panelBox.x + 16} y={panelBox.y + 92}>
              m = <tspan fontWeight="900">{fmt(mm)}</tspan> kg
            </text>
            <text x={panelBox.x + 16} y={panelBox.y + 120}>
              W = m·g = <tspan fontWeight="900">{fmt(W)}</tspan> N
            </text>
            <text x={panelBox.x + 16} y={panelBox.y + 148} fill={C.N}>
              N (aparente) = <tspan fontWeight="900">{fmt(N)}</tspan> N
            </text>

            {context === "elevator" ? (
              <text x={panelBox.x + 16} y={panelBox.y + 176} fill={C.muted}>
                a = {fmt(aa)} m/s² → g+a = {fmt(gEff)} m/s²
              </text>
            ) : (
              <text x={panelBox.x + 16} y={panelBox.y + 176} fill={C.muted}>
                Si no hay aceleración: N ≈ W
              </text>
            )}
          </g>

          {/* Mini barras comparativas (derecha abajo) */}
          <rect x={barsBox.x} y={barsBox.y} width={barsBox.w} height={barsBox.h} rx="18" fill={C.card} stroke={C.stroke} strokeWidth="2" />
          <text x={barsBox.x + 16} y={barsBox.y + 30} fontSize="14" fontWeight="900" fill={C.ink}>
            Comparación (magnitud)
          </text>

          {/* Barras */}
          {(() => {
            const baseY = barsBox.y + barsBox.h - 18;
            const x0 = barsBox.x + 26;
            const barW = 62;
            const gap = 44;

            return (
              <g>
                {/* eje base */}
                <line x1={barsBox.x + 16} y1={baseY} x2={barsBox.x + barsBox.w - 16} y2={baseY} stroke={C.stroke} strokeWidth="2" />

                {/* mg */}
                <rect x={x0} y={baseY - mgBar} width={barW} height={mgBar} rx="10" fill={C.mg} opacity="0.9" />
                <text x={x0 + barW / 2} y={baseY + 16} textAnchor="middle" fontSize="12" fill={C.ink}>
                  W
                </text>

                {/* N */}
                <rect x={x0 + barW + gap} y={baseY - nBar} width={barW} height={nBar} rx="10" fill={C.N} opacity="0.9" />
                <text x={x0 + barW + gap + barW / 2} y={baseY + 16} textAnchor="middle" fontSize="12" fill={C.ink}>
                  N
                </text>
              </g>
            );
          })()}

          {/* Borde externo suave para “contener” */}
          <rect x="10" y="10" width={Wsvg - 20} height={H - 20} rx="22" fill="none" stroke="rgba(15,23,42,0.08)" strokeWidth="3" />
        </svg>
      </div>
    </div>
  );
}
