import React, { useMemo } from "react";
import DclBase from "../_base/DclBase";

export default function PlanosInclinadosGraphsDcl({ title, params }) {
  const forces = useMemo(() => {
    return [
      { id: "P", label: "P", angleDeg: -90 },
      { id: "N", label: "N", angleDeg: 90 },
      { id: "fr", label: "fr", angleDeg: 180 },
    ];
  }, []);

  return (
    <DclBase
      title={title || "Plano inclinado (DCL)"}
      subtitle="Fuerzas principales"
      body="block"
      forces={forces}
      showAxes
    />
  );
}
