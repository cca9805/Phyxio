import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
  ReferenceLine,
} from "recharts";

import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";
import {
  defaultParams,
  forceRequired,
  pullDistance,
  seriesForceVsN,
} from "../../../engine/models/dinamica/poleasCompuestas";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

export default function PoleasCompuestasGraphs({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => defaultParams());

  // 🔗 enlazar con calculadora si viene params (si no, funciona en modo experimento)
  useEffect(() => {
    if (!linked || !params) return;
    setP((prev) => ({
      ...prev,
      W: pickParam(params, ["W", "w", "peso"], prev.W),
      n: pickParam(params, ["n"], prev.n),
      dx_load: pickParam(params, ["dx_load", "dxLoad", "h"], prev.dx_load),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const W = Math.max(1, toNum(p.W, 800));
    const n = Math.max(1, Math.round(toNum(p.n, 4)));
    const dx_load = Math.max(0, toNum(p.dx_load, 0.3));
    const nMax = Math.max(2, Math.round(toNum(p.nMax, 10)));
    return { W, n, dx_load, nMax };
  }, [p]);

  const F = useMemo(() => forceRequired(safe), [safe]);
  const dx_pull = useMemo(() => pullDistance(safe), [safe]);
  const data = useMemo(() => seriesForceVsN(safe), [safe]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Poleas compuestas (Coord)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Ideal: <b>F = W/n</b> y <b>Δx_pull = n·Δx_load</b>
        </div>

        <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">W (N)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.W}
              onChange={(e) => setP((s) => ({ ...s, W: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">n (tramos)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="numeric"
              value={p.n}
              onChange={(e) => setP((s) => ({ ...s, n: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">Δx_load (m)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.dx_load}
              onChange={(e) => setP((s) => ({ ...s, dx_load: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">n max (gráfica)</div>
            <input
              className="form-control"
              inputMode="numeric"
              value={p.nMax}
              onChange={(e) => setP((s) => ({ ...s, nMax: e.target.value }))}
            />
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Resultado: <b>F = {fmt(F, 6)} N</b> · <b>Δx_pull = {fmt(dx_pull, 6)} m</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">F en función de n</div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <CartesianGrid />
              <XAxis
                dataKey="n"
                type="number"
                domain={[1, safe.nMax]}
                label={{ value: "n (tramos)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 4)}
                label={{ value: "F (N)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(v) => fmt(v, 6)}
                labelFormatter={(x) => `n = ${x}`}
              />
              <ReferenceLine y={0} />
              <Line type="monotone" dataKey="F" dot={false} name="F = W/n" />
              <ReferenceDot x={safe.n} y={F} r={5} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Ratio recorridos: <b>Δx_pull/Δx_load = n</b> ⇒ aquí vale <b>{safe.n}</b>.
        </div>
      </div>
    </div>
  );
}
