import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
  ReferenceLine,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function buildData({ W, nMax }, N = 120) {
  const data = [];
  const max = Math.max(1, Math.floor(nMax));
  for (let n = 1; n <= max; n++) {
    data.push({ n, F: W / n });
  }
  return data;
}

export default function PoleasSimplesGraphs() {
  const [p, setP] = useState({
    W: 200,
    nMax: 6,
    nSel: 2,
  });

  const safe = useMemo(() => {
    const W = Math.max(1, Number(p.W) || 200);
    const nMax = Math.max(2, Math.floor(Number(p.nMax) || 6));
    const nSel = Math.min(nMax, Math.max(1, Math.floor(Number(p.nSel) || 2)));
    return { W, nMax, nSel };
  }, [p]);

  const data = useMemo(() => buildData(safe, 120), [safe]);
  const Fsel = safe.W / safe.nSel;

  return (
    <div className="v2-card" style={{ padding: 12 }}>
      <div className="v2-card-title">Poleas simples (Coord)</div>
      <div className="muted" style={{ marginTop: 6 }}>
        Fuerza requerida ideal: <b>F = W / n</b> (n = tramos que sostienen la carga)
      </div>

      <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
        <div className="v2-card">
          <div className="v2-card-title">W (N)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.W}
            onChange={(e) => setP((s) => ({ ...s, W: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">n max</div>
          <input
            className="form-control"
            inputMode="numeric"
            value={p.nMax}
            onChange={(e) => setP((s) => ({ ...s, nMax: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">n (selección)</div>
          <input
            className="form-control"
            inputMode="numeric"
            value={p.nSel}
            onChange={(e) => setP((s) => ({ ...s, nSel: e.target.value }))}
          />
        </div>
      </div>

      <div className="muted" style={{ marginTop: 10 }}>
        Para n = <b>{safe.nSel}</b> ⇒ F ≈ <b>{fmt(Fsel, 6)} N</b>
      </div>

      <div style={{ width: "100%", height: 340, marginTop: 12 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid />
            <XAxis dataKey="n" type="number" domain={[1, safe.nMax]} label={{ value: "n", position: "insideBottom", offset: -5 }} />
            <YAxis tickFormatter={(v) => fmt(v, 4)} label={{ value: "F (N)", angle: -90, position: "insideLeft" }} />
            <Tooltip
              formatter={(v) => fmt(v, 6)}
              labelFormatter={(x) => `n = ${x}`}
            />
            <ReferenceLine y={0} />
            <Line type="monotone" dataKey="F" dot={false} name="F(n)" />
            <ReferenceDot x={safe.nSel} y={Fsel} r={5} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
