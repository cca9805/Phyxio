// frontend/src/v2/components/graphs/dinamica/PrimeraLeyInerciaDcl.jsx
import React, { useState } from "react";

export default function PrimeraLeyInerciaDcl() {
  const [showForces, setShowForces] = useState(true);
  const [showLabels, setShowLabels] = useState(true);
  const [showEquation, setShowEquation] = useState(true);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Primera Ley de Newton (Inercia)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Si la fuerza resultante es nula, el cuerpo permanece en <b>reposo</b> o en <b>movimiento rectilíneo uniforme</b>.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración del diagrama */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>⚖️ Equilibrio:</span>
              <span style={{ color: "#e2e8f0", fontSize: "14px" }}>Fuerzas equilibradas (ΣF = 0)</span>
            </div>
          </div>

          {/* Segunda fila: Opciones de visualización */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
            
            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showForces" 
                checked={showForces} 
                onChange={(e) => setShowForces(e.target.checked)} 
              />
              <label className="v2-checkbox-label" htmlFor="showForces">Fuerzas</label>
            </div>

            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showLabels" 
                checked={showLabels} 
                onChange={(e) => setShowLabels(e.target.checked)} 
              />
              <label className="v2-checkbox-label" htmlFor="showLabels">Etiquetas</label>
            </div>

            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showEquation" 
                checked={showEquation} 
                onChange={(e) => setShowEquation(e.target.checked)} 
              />
              <label className="v2-checkbox-label" htmlFor="showEquation">Ecuación</label>
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Diagrama de Cuerpo Libre</div>

        <svg
          viewBox="0 0 350 140"
          width="100%"
          height="150"
          style={{ marginTop: 6 }}
        >
          <rect x="0" y="0" width="350" height="140" fill="#b8c5ffff" />
          
          {/* Suelo */}
          <line x1="30" y1="70" x2="320" y2="70" stroke="#334155" strokeWidth="2.5" />
          {showLabels && <text x="55" y="65" fontSize="10" fill="#334155">Suelo</text>}

          {/* Bloque (reducido) */}
          <rect
            x="160"
            y="50"
            width="30"
            height="20"
            rx="5"
            fill="#e5e7eb"
            stroke="#1e293b"
            strokeWidth="2"
          />

          {/* Centro de masas */}
          <circle cx="175" cy="60" r="2" fill="#1e293b" />

          {showForces && (
            <>
              {/* Fuerza Normal */}
              <line x1="175" y1="25" x2="175" y2="50" stroke="#16a34a" strokeWidth="2.0" />
              <polygon points="175,15 170,25 180,25" fill="#16a34a" />
              {showLabels && <text x="182" y="25" fontSize="10" fill="#16a34a">N</text>}

              {/* Peso */}
              <line x1="175" y1="70" x2="175" y2="95" stroke="#dc2626" strokeWidth="2.0" />
              <polygon points="175,105 170,95 180,95" fill="#dc2626" />
              {showLabels && <text x="182" y="105" fontSize="10" fill="#dc2626">P = mg</text>}

              {/* Fuerzas horizontales equilibradas (reducidas) */}
              <line x1="160" y1="60" x2="130" y2="60" stroke="#2563eb" strokeWidth="2.0" />
              <polygon points="120,60 130,55 130,65" fill="#2563eb" />
              {showLabels && <text x="105" y="65" fontSize="12" fill="#2563eb">F</text>}

              <line x1="190" y1="60" x2="220" y2="60" stroke="#2563eb" strokeWidth="2.0" />
              <polygon points="230,60 220,55 220,65" fill="#2563eb" />
              {showLabels && <text x="240" y="65" fontSize="12" fill="#2563eb">F</text>}
            </>
          )}

          {/* Resultante */}
          {showEquation && (
            <text
              x="175"
              y="130"
              textAnchor="middle"
              fontSize="13"
              fill="#0f172a"
              fontWeight="bold"
            >
              ΣF = 0  ⇒  a = 0
            </text>
          )}
        </svg>
      </div>
    </div>
  );
}
