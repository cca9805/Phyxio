import React, { useMemo, useState } from "react";

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}
function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  const n = typeof v === "number" ? v : Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

export default function RozamientoDinamicoGraphsDcl() {
  const [scene, setScene] = useState("horizontal"); // horizontal | incline
  const [m, setM] = useState(10);
  const [mu, setMu] = useState(0.25);
  const [g, setG] = useState(9.81);

  const [F, setF] = useState(60); // horizontal
  const [theta, setTheta] = useState(25); // incline

  const [showAxes, setShowAxes] = useState(false);
  const [showLabels, setShowLabels] = useState(true);

  const mm = useMemo(() => clamp(toNum(m, 10), 0.1, 200), [m]);
  const muu = useMemo(() => clamp(toNum(mu, 0.25), 0, 2), [mu]);
  const gg = useMemo(() => clamp(toNum(g, 9.81), 0.1, 30), [g]);
  const FF = useMemo(() => clamp(toNum(F, 60), 0, 300), [F]);
  const thDeg = useMemo(() => clamp(toNum(theta, 25), 0, 60), [theta]);

  const th = (thDeg * Math.PI) / 180;

  const W = mm * gg;
  const N = scene === "incline" ? W * Math.cos(th) : W;
  const fk = muu * N;

  const Fnet_h = FF - fk; // →
  const a_h = Fnet_h / mm;

  const Fdown = W * Math.sin(th);
  const Fnet_i = Fdown - fk; // cuesta abajo
  const a_i = Fnet_i / mm;

  const Fmax = Math.max(W, N, fk, Math.abs(FF), 1) * 1.15;

  // Colores (aprox) tipo tus DCL: fondo celeste, vectores saturados.
  const C = {
    bg: "#b8c5ffff",
    ink: "#0f172a",
    muted: "#64748b",
    mg: "#dc2626",
    N: "#22c55e",
    fk: "#f59e0b",
    F: "#3b82f6",
    axis: "#6366f1",
    stroke: "#e2e8f0",
  };

  const Arrow = ({ x1, y1, x2, y2, stroke, w = 10 }) => {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const L = Math.hypot(dx, dy) || 1;
    const ux = dx / L;
    const uy = dy / L;
    const head = 16;

    const hx = x2;
    const hy = y2;
    const leftx = hx - ux * head - uy * (head * 0.6);
    const lefty = hy - uy * head + ux * (head * 0.6);
    const rightx = hx - ux * head + uy * (head * 0.6);
    const righty = hy - uy * head - ux * (head * 0.6);

    return (
      <g>
        <line x1={x1} y1={y1} x2={hx} y2={hy} stroke={stroke} strokeWidth={w} strokeLinecap="round" />
        <polygon points={`${hx},${hy} ${leftx},${lefty} ${rightx},${righty}`} fill={stroke} opacity="0.95" />
      </g>
    );
  };

  const scale = (val, base = 175) => base * clamp(Math.abs(val) / Fmax, 0, 1);

  const fmt = (x) => {
    const n = Number(x);
    if (!Number.isFinite(n)) return "—";
    return n.toFixed(2).replace(".", ",");
  };

  const cx = 610;
  const cy = 200;

  const wLen = scale(W, 150);
  const nLen = scale(N, 150);
  const fkLen = scale(fk, 150);
  const fLen = scale(FF, 150);

  const Wend = { x: cx, y: cy + wLen };

  let nDir = { x: 0, y: -1 };
  if (scene === "incline") nDir = { x: -Math.sin(th), y: -Math.cos(th) };
  const Nend = { x: cx + nDir.x * nLen, y: cy + nDir.y * nLen };

  let fkDir = { x: -1, y: 0 };
  let Fdir = { x: 1, y: 0 };
  if (scene === "incline") fkDir = { x: -Math.cos(th), y: -Math.sin(th) }; // cuesta arriba

  const FKend = { x: cx + fkDir.x * fkLen, y: cy + fkDir.y * fkLen };
  const Fend = { x: cx + Fdir.x * fLen, y: cy + Fdir.y * fLen };

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Rozamiento dinámico (DCL)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          DCL con vectores: <b>W</b>, <b>N</b>, <b>fₖ</b> (opuesto al movimiento) y <b>F</b> (si aplica).
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🎬 Escena:</span>
              <select
                className="form-control"
                style={{ width: 220 }}
                value={scene}
                onChange={(e) => setScene(e.target.value)}
              >
                <option value="horizontal">Mesa + fuerza F</option>
                <option value="incline">Plano inclinado (baja)</option>
              </select>
            </div>

            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#fbbf24" }}>⚖️</span> m (kg)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={m}
                  onChange={(e) => setM(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#34d399" }}>🌍</span> g (m/s²)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={g}
                  onChange={(e) => setG(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#a855f7" }}>🔧</span> μₖ
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={mu}
                  onChange={(e) => setMu(e.target.value)}
                />
              </label>
              
              {scene === "horizontal" ? (
                <>
                  <span style={{ color: "#60a5fa" }}>💪</span> F (N)
                  <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                    <input
                      className="form-control"
                      style={{ width: 80 }}
                      inputMode="decimal"
                      value={F}
                      onChange={(e) => setF(e.target.value)}
                    />
                  </label>
                </>
              ) : (
                <>
                  <span style={{ color: "#f87171" }}>📐</span> θ (°)
                  <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                    <input
                      className="form-control"
                      style={{ width: 80 }}
                      inputMode="numeric"
                      value={theta}
                      onChange={(e) => setTheta(e.target.value)}
                    />
                  </label>
                </>
              )}
            </div>
          </div>

          {/* Segunda fila: Controles de visualización */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
            
            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showLabels"
                checked={showLabels}
                onChange={(e) => setShowLabels(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showLabels">Etiquetas</label>
            </div>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showAxes"
                checked={showAxes}
                onChange={(e) => setShowAxes(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showAxes">Ejes</label>
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12, overflow: "hidden" }}>
        <div className="v2-card-title">Diagrama de cuerpo libre</div>
        
        <svg width="100%" height="380" viewBox="0 0 860 380" preserveAspectRatio="xMidYMid meet">
          <rect x="0" y="0" width="860" height="520" fill={C.bg} />

          <rect x="44" y="54" width="340" height="135" rx="18" fill="white" opacity="0.92" stroke={C.stroke} strokeWidth="2" />
          <text x="64" y="88" fontSize="16" fontWeight="900" fill={C.ink}>Datos</text>
          <text x="64" y="116" fontSize="14" fill={C.muted}>
            W={fmt(W)} N · N={fmt(N)} N · fₖ={fmt(fk)} N
          </text>
          <text x="64" y="140" fontSize="14" fill={C.muted}>
            {scene === "horizontal"
              ? `Fₙₑₜ=${fmt(Fnet_h)} N → a=${fmt(a_h)} m/s²`
              : `mg·senθ=${fmt(Fdown)} N · Fₙₑₜ=${fmt(Fnet_i)} N → a=${fmt(a_i)} m/s²`}
          </text>
          <text x="64" y="164" fontSize="14" fill={C.muted}>
            {scene === "incline" ? `θ=${fmt(thDeg)}° (desliza ↓)` : "movimiento supuesto: →"}
          </text>

          {showAxes && (
            <g opacity="0.85">
              <line x1="500" y1="240" x2="750" y2="240" stroke={C.axis} strokeWidth="4" />
              <line x1="500" y1="240" x2="500" y2="100" stroke={C.axis} strokeWidth="4" />
              <text x="760" y="243" fontSize="14" fill={C.muted}>x</text>
              <text x="480" y="120" fontSize="14" fill={C.muted}>y</text>
            </g>
          )}

          <circle cx={cx} cy={cy} r="12" fill={C.ink} opacity="0.85" />
          <line x1={cx - 18} y1={cy} x2={cx + 18} y2={cy} stroke={C.ink} strokeWidth="2" opacity="0.25" />
          <line x1={cx} y1={cy - 18} x2={cx} y2={cy + 18} stroke={C.ink} strokeWidth="2" opacity="0.25" />

          <Arrow x1={cx} y1={cy} x2={Wend.x} y2={Wend.y} stroke={C.mg} w={5} />
          {showLabels && <text x={Wend.x - 7} y={Wend.y + 25} fontSize="16" fontWeight="900" fill={C.mg}>W</text>}

          <Arrow x1={cx} y1={cy} x2={Nend.x} y2={Nend.y} stroke={C.N} w={5} />
          {showLabels && <text x={Nend.x - 5} y={Nend.y - 16} fontSize="16" fontWeight="900" fill={C.N}>N</text>}

          <Arrow x1={cx} y1={cy} x2={FKend.x} y2={FKend.y} stroke={C.fk} w={5} />
          {showLabels && <text x={FKend.x - 20} y={FKend.y + 6} fontSize="16" fontWeight="900" fill={C.fk}>fₖ</text>}

          {scene === "horizontal" && (
            <>
              <Arrow x1={cx} y1={cy} x2={Fend.x} y2={Fend.y} stroke={C.F} w={5} />
              {showLabels && <text x={Fend.x + 14} y={Fend.y + 6} fontSize="16" fontWeight="900" fill={C.F}>F</text>}
            </>
          )}

          {/* mini icono de movimiento */}
          {scene === "horizontal" ? (
            <g opacity="0.9">
              <line x1="560" y1="460" x2="680" y2="460" stroke={C.muted} strokeWidth="6" strokeLinecap="round" />
              <polygon points="680,460 664,452 664,468" fill={C.muted} />
              <text x="560" y="490" fontSize="13" fill={C.muted}>v</text>
            </g>
          ) : (
            <g opacity="0.9">
              <line x1="560" y1="260" x2="660" y2="210" stroke={C.muted} strokeWidth="6" strokeLinecap="round" />
              <polygon points="670,203 656,203 664,217" fill={C.muted} />
              <text x="540" y="270" fontSize="13" fill={C.muted}>v</text>
            </g>
          )}
        </svg>
      </div>
    </div>
  );
}
