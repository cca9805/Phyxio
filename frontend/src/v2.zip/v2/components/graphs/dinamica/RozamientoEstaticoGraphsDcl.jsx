import React, { useMemo, useState } from "react";

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}
function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  const n = typeof v === "number" ? v : Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

export default function RozamientoEstaticoGraphsDcl() {
  const [scene, setScene] = useState("push"); // push | incline
  const [m, setM] = useState(10);
  const [g, setG] = useState(9.81);
  const [muS, setMuS] = useState(0.4);

  const [theta, setTheta] = useState(25);   // incline
  const [F, setF] = useState(50);           // push

  const [showLabels, setShowLabels] = useState(true);
  const [showAxes, setShowAxes] = useState(false);
  const [showNotes, setShowNotes] = useState(true);

  const mm = useMemo(() => clamp(toNum(m, 10), 0.1, 200), [m]);
  const gg = useMemo(() => clamp(toNum(g, 9.81), 0.1, 30), [g]);
  const mu = useMemo(() => clamp(toNum(muS, 0.4), 0, 2), [muS]);

  const thDeg = useMemo(() => clamp(toNum(theta, 25), 0, 60), [theta]);
  const FF = useMemo(() => clamp(toNum(F, 50), 0, 300), [F]);

  const th = (thDeg * Math.PI) / 180;
  const W = mm * gg;

  // push (horizontal)
  const Npush = W;
  const fMaxPush = mu * Npush;
  const fPush = Math.min(FF, fMaxPush);
  const slipsPush = FF > fMaxPush + 1e-9;

  // incline
  const Ninc = W * Math.cos(th);
  const fMaxInc = mu * Ninc;
  const fReqInc = W * Math.sin(th);
  const fInc = Math.min(fReqInc, fMaxInc);
  const slipsInc = fReqInc > fMaxInc + 1e-9;

  const C = {
    bg: "#b8c5ffff",
    ink: "#0f172a",
    muted: "#64748b",
    mg: "#dc2626",
    N: "#16a34a",
    fr: "#f59e0b",
    frOk: "#f59e0b",
    frBad: "#f87171",
    stroke: "#e2e8f0",
    axis: "#6366f1",
  };

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Rozamiento estático (DCL)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Vectores del DCL: <b>mg</b> (rojo), <b>N</b> (verde) y <b>fₛ</b> (amarillo). El estático cumple: <b>fₛ ≤ μₛ·N</b>.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🎬 Escena:</span>
              <select
                className="form-control"
                style={{ width: 250 }}
                value={scene}
                onChange={(e) => setScene(e.target.value)}
              >
                <option value="push">Bloque en mesa con empuje F</option>
                <option value="incline">Bloque en plano inclinado (reposo)</option>
              </select>
            </div>

            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#fbbf24" }}>⚖️</span> m (kg)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={m}
                  onChange={(e) => setM(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#34d399" }}>🌍</span> g (m/s²)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={g}
                  onChange={(e) => setG(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#a855f7" }}>🔧</span> μₛ
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={muS}
                  onChange={(e) => setMuS(e.target.value)}
                />
              </label>
              
              {scene === "incline" ? (
                <>
                  <span style={{ color: "#f87171" }}>📐</span> θ (°)
                  <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                    <input
                      className="form-control"
                      style={{ width: 80 }}
                      inputMode="numeric"
                      value={theta}
                      onChange={(e) => setTheta(e.target.value)}
                    />
                  </label>
                </>
              ) : (
                <>
                  <span style={{ color: "#60a5fa" }}>💪</span> F (N)
                  <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                    <input
                      className="form-control"
                      style={{ width: 80 }}
                      inputMode="decimal"
                      value={F}
                      onChange={(e) => setF(e.target.value)}
                    />
                  </label>
                </>
              )}
            </div>
          </div>

          {/* Segunda fila: Controles de visualización */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
            
            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showLabels"
                checked={showLabels}
                onChange={(e) => setShowLabels(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showLabels">Etiquetas</label>
            </div>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showAxes"
                checked={showAxes}
                onChange={(e) => setShowAxes(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showAxes">Ejes</label>
            </div>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showNotes"
                checked={showNotes}
                onChange={(e) => setShowNotes(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showNotes">Notas</label>
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Diagrama de cuerpo libre</div>
        
        <svg viewBox="0 0 560 300" width="100%" height="260" style={{ marginTop: 10 }}>
          <rect x="0" y="0" width="560" height="300" fill={C.bg} />

          {/* Panel de datos */}
          <rect x="20" y="20" width="140" height="150" rx="12" fill="rgba(255,255,255,0.92)" stroke="#d6e5ff" strokeWidth="2" />
          <text x="35" y="45" fontSize="14" fontWeight="900" fill={C.ink}>
            Datos
          </text>
          <text x="35" y="65" fontSize="12" fill={C.muted}>
            m = {mm.toFixed(1)} kg
          </text>
          <text x="35" y="80" fontSize="12" fill={C.muted}>
            μₛ = {mu.toFixed(2)}
          </text>
          <text x="35" y="95" fontSize="12" fill={C.muted}>
            g = {gg.toFixed(2)} m/s²
          </text>
          {scene === "incline" ? (
            <>
              <text x="35" y="110" fontSize="12" fill={C.muted}>
                θ = {thDeg}°
              </text>
              <text x="35" y="125" fontSize="12" fill={C.mg}>
                W = {W.toFixed(1)} N
              </text>
              <text x="35" y="140" fontSize="12" fill={C.N}>
                N = {Ninc.toFixed(1)} N
              </text>
              <text x="35" y="155" fontSize="12" fill={slipsInc ? C.frBad : C.frOk}>
                fₛ = {fInc.toFixed(1)} N
              </text>
            </>
          ) : (
            <>
              <text x="35" y="110" fontSize="12" fill={C.axis}>
                F = {FF.toFixed(1)} N
              </text>
              <text x="35" y="125" fontSize="12" fill={C.mg}>
                W = {W.toFixed(1)} N
              </text>
              <text x="35" y="140" fontSize="12" fill={C.N}>
                N = {Npush.toFixed(1)} N
              </text>
              <text x="35" y="155" fontSize="12" fill={slipsPush ? C.frBad : C.frOk}>
                fₛ = {fPush.toFixed(1)} N
              </text>
            </>
          )}

          {/* Ejes opcionales */}
          {showAxes && (
            <g opacity="0.9">
              <line x1="290" y1="150" x2="490" y2="150" stroke={C.axis} strokeWidth="2" />
              <line x1="290" y1="150" x2="290" y2="30" stroke={C.axis} strokeWidth="2" />
              <text x="495" y="153" fontSize="12" fill={C.muted}>x</text>
              <text x="275" y="40" fontSize="12" fill={C.muted}>y</text>
            </g>
          )}

          {(() => {
            const cx = 370;
            const cy = 120;

            // Escala para flechas
            const Fmax = Math.max(W, scene === "push" ? Math.max(Npush, fMaxPush, FF) : Math.max(Ninc, fMaxInc, fReqInc), 1) * 1.1;
            const scale = (val, base = 150) => base * clamp(val / Fmax, 0, 1);

            // Flechas básicas (mismo estilo que tu muestra: line + polygon)
            const arrow = (x1, y1, x2, y2, color, w = 3) => {
              const dx = x2 - x1;
              const dy = y2 - y1;
              const L = Math.hypot(dx, dy) || 1;
              const ux = dx / L;
              const uy = dy / L;
              const head = 12;

              const hx = x2;
              const hy = y2;
              const leftx = hx - ux * head - uy * (head * 0.6);
              const lefty = hy - uy * head + ux * (head * 0.6);
              const rightx = hx - ux * head + uy * (head * 0.6);
              const righty = hy - uy * head - ux * (head * 0.6);

              return (
                <g>
                  <line x1={x1} y1={y1} x2={hx} y2={hy} stroke={color} strokeWidth={w} strokeLinecap="round" />
                  <polygon points={`${hx},${hy} ${leftx},${lefty} ${rightx},${righty}`} fill={color} />
                </g>
              );
            };

            // Peso siempre vertical hacia abajo
            const wLen = scale(W, 100);
            const WEND = { x: cx, y: cy + wLen };

            // Normal: vertical arriba en push, perpendicular en incline (simplificado: arriba-izq)
            let nDir = { x: 0, y: -1 };
            if (scene === "incline") nDir = { x: -Math.sin(th), y: -Math.cos(th) };
            const Nval = scene === "push" ? Npush : Ninc;
            const nLen = scale(Nval, 100);
            const NEND = { x: cx + nDir.x * nLen, y: cy + nDir.y * nLen };

            // Fricción: en push se opone a F, en incline se opone a tendencia a bajar (hacia arriba del plano)
            let frDir = { x: -1, y: 0 };
            let frVal = fPush;
            let frMax = fMaxPush;
            let frNeed = FF;
            let slips = slipsPush;

            if (scene === "incline") {
              // dirección "cuesta arriba": (-cosθ, -sinθ) en coords pantalla (y+ abajo)
              frDir = { x: -Math.cos(th), y: -Math.sin(th) };
              frVal = fInc;
              frMax = fMaxInc;
              frNeed = fReqInc;
              slips = slipsInc;
            }

            const frLen = scale(frVal, 150);
            const FREND = { x: cx + frDir.x * frLen, y: cy + frDir.y * frLen };
            const frColor = slips ? C.frBad : C.frOk;

            return (
              <g>
                {/* cuerpo */}
                <circle cx={cx} cy={cy} r="10" fill={C.ink} />
                <line x1={cx - 12} y1={cy} x2={cx + 12} y2={cy} stroke={C.ink} strokeWidth="2" opacity="0.35" />
                <line x1={cx} y1={cy - 12} x2={cx} y2={cy + 12} stroke={C.ink} strokeWidth="2" opacity="0.35" />

                {/* mg */}
                {arrow(cx, cy, WEND.x, WEND.y, C.mg, 3)}
                {showLabels && (
                  <text x={WEND.x + 14} y={WEND.y - 8} fontSize="13" fill={C.mg} fontWeight="bold">
                    mg
                  </text>
                )}

                {/* N */}
                {arrow(cx, cy, NEND.x, NEND.y, C.N, 3)}
                {showLabels && (
                  <text x={NEND.x + 14} y={NEND.y + 6} fontSize="13" fill={C.N} fontWeight="bold">
                    N
                  </text>
                )}

                {/* f_s */}
                {arrow(cx, cy, FREND.x, FREND.y, frColor, 3)}
                {showLabels && (
                  <text x={FREND.x - 14} y={FREND.y + 6} fontSize="13" fill={frColor} fontWeight="bold">
                    fₛ
                  </text>
                )}

                {/* flecha F aplicada en push */}
                {scene === "push" && (
                  <>
                    {arrow(cx, cy, cx + scale(FF, 140), cy, C.axis, 3)}
                    {showLabels && (
                      <text x={cx + scale(FF, 140) + 14} y={cy + 6} fontSize="13" fill={C.axis} fontWeight="bold">
                        F
                      </text>
                    )}
                  </>
                )}

                {/* notas */}
                {showNotes && (
                  <>
                    <rect x="18" y="244" width="524" height="44" rx="12" fill="white" opacity="0.9" />
                    <text x="32" y="272" fontSize="12" fill={C.muted}>
                      {scene === "push" ? (
                        slips ? `F > μₛ·N → el rozamiento estático NO basta (máx = ${frMax.toFixed(2)} N)` :
                        `fₛ = min(F, μₛ·N). Aquí fₛ = ${frVal.toFixed(2)} N y fₛ,max = ${frMax.toFixed(2)} N`
                      ) : (
                        slips ? `mg·senθ > μₛ·mg·cosθ → desliza (f_req = ${frNeed.toFixed(2)} N, f_max = ${frMax.toFixed(2)} N)` :
                        `En reposo: fₛ = mg·senθ (hasta fₛ,max = μₛ·N). Aquí fₛ = ${frVal.toFixed(2)} N`
                      )}
                    </text>
                  </>
                )}
              </g>
            );
          })()}
        </svg>
      </div>
    </div>
  );
}
