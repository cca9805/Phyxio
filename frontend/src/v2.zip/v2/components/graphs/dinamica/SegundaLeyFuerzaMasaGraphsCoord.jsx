// frontend/src/v2/components/graphs/dinamica/SegundaLeyFuerzaMasaGraphsCoord.jsx
import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
  ReferenceLine,
} from "recharts";

import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function makeSeriesAVsF({ m, Fmin, Fmax, steps }) {
  const out = [];
  const n = Math.max(2, Math.floor(steps));
  const aM = Math.max(0.001, m);
  const lo = Math.min(Fmin, Fmax);
  const hi = Math.max(Fmin, Fmax);
  for (let i = 0; i < n; i++) {
    const F = lo + (i * (hi - lo)) / (n - 1);
    out.push({ F, a: F / aM });
  }
  return out;
}

function makeSeriesAVsM({ F, mMin, mMax, steps }) {
  const out = [];
  const n = Math.max(2, Math.floor(steps));
  const lo = Math.max(0.001, Math.min(mMin, mMax));
  const hi = Math.max(0.001, Math.max(mMin, mMax));
  for (let i = 0; i < n; i++) {
    const m = lo + (i * (hi - lo)) / (n - 1);
    out.push({ m, a: F / m });
  }
  return out;
}

export default function SegundaLeyFuerzaMasaGraphsCoord({ params }) {
  const [linked, setLinked] = useState(true);
  const [mode, setMode] = useState("a_vs_F"); // "a_vs_F" | "a_vs_m"
  const [p, setP] = useState(() => ({
    m: 10,
    F: 20,
    Fmin: 0,
    Fmax: 100,
    mMin: 1,
    mMax: 50,
    steps: 41,
  }));

  // 🔗 enlazar con calculadora
  useEffect(() => {
    if (!linked || !params) return;
    setP((prev) => ({
      ...prev,
      m: pickParam(params, ["m", "masa", "M"], prev.m),
      F: pickParam(params, ["F", "f", "force", "Fres", "F_net"], prev.F),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const m = Math.max(0.001, toNum(p.m, 10));
    const F = toNum(p.F, 20);

    const Fmin = toNum(p.Fmin, 0);
    const Fmax = toNum(p.Fmax, 100);

    const mMin = Math.max(0.001, toNum(p.mMin, 1));
    const mMax = Math.max(0.001, toNum(p.mMax, 50));

    const steps = Math.max(11, Math.round(toNum(p.steps, 41)));

    return { m, F, Fmin, Fmax, mMin, mMax, steps };
  }, [p]);

  const aNow = useMemo(() => safe.F / safe.m, [safe]);

  const data = useMemo(() => {
    if (mode === "a_vs_m") {
      return makeSeriesAVsM(safe);
    }
    return makeSeriesAVsF(safe);
  }, [safe, mode]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Segunda ley (Coord) · a = F/m</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Explora cómo cambia la aceleración al variar fuerza o masa.
        </div>

        <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Experimento
          </button>

          <button
            type="button"
            className={`btn btn-sm ${mode === "a_vs_F" ? "btn-primary" : "btn-light"}`}
            onClick={() => setMode("a_vs_F")}
          >
            a(F)
          </button>
          <button
            type="button"
            className={`btn btn-sm ${mode === "a_vs_m" ? "btn-primary" : "btn-light"}`}
            onClick={() => setMode("a_vs_m")}
          >
            a(m)
          </button>
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">m (kg)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.m}
              onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">F (N)</div>
            <input
              className="form-control"
              disabled={linked}
              inputMode="decimal"
              value={p.F}
              onChange={(e) => setP((s) => ({ ...s, F: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">puntos</div>
            <input
              className="form-control"
              inputMode="numeric"
              value={p.steps}
              onChange={(e) => setP((s) => ({ ...s, steps: e.target.value }))}
            />
          </div>

          {mode === "a_vs_F" ? (
            <>
              <div className="v2-card">
                <div className="v2-card-title">F min (N)</div>
                <input
                  className="form-control"
                  inputMode="decimal"
                  value={p.Fmin}
                  onChange={(e) => setP((s) => ({ ...s, Fmin: e.target.value }))}
                />
              </div>

              <div className="v2-card">
                <div className="v2-card-title">F max (N)</div>
                <input
                  className="form-control"
                  inputMode="decimal"
                  value={p.Fmax}
                  onChange={(e) => setP((s) => ({ ...s, Fmax: e.target.value }))}
                />
              </div>
            </>
          ) : (
            <>
              <div className="v2-card">
                <div className="v2-card-title">m min (kg)</div>
                <input
                  className="form-control"
                  inputMode="decimal"
                  value={p.mMin}
                  onChange={(e) => setP((s) => ({ ...s, mMin: e.target.value }))}
                />
              </div>

              <div className="v2-card">
                <div className="v2-card-title">m max (kg)</div>
                <input
                  className="form-control"
                  inputMode="decimal"
                  value={p.mMax}
                  onChange={(e) => setP((s) => ({ ...s, mMax: e.target.value }))}
                />
              </div>
            </>
          )}
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          En el punto actual: <b>a = {fmt(aNow, 6)} m/s²</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">
          {mode === "a_vs_F" ? "Aceleración en función de la fuerza" : "Aceleración en función de la masa"}
        </div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <CartesianGrid />
              {mode === "a_vs_F" ? (
                <XAxis
                  dataKey="F"
                  type="number"
                  domain={[Math.min(safe.Fmin, safe.Fmax), Math.max(safe.Fmin, safe.Fmax)]}
                  label={{ value: "F (N)", position: "insideBottom", offset: -5 }}
                />
              ) : (
                <XAxis
                  dataKey="m"
                  type="number"
                  domain={[Math.min(safe.mMin, safe.mMax), Math.max(safe.mMin, safe.mMax)]}
                  label={{ value: "m (kg)", position: "insideBottom", offset: -5 }}
                />
              )}

              <YAxis
                tickFormatter={(v) => fmt(v, 4)}
                label={{ value: "a (m/s²)", angle: -90, position: "insideLeft" }}
              />

              <Tooltip
                formatter={(v) => fmt(v, 6)}
                labelFormatter={(x) =>
                  mode === "a_vs_F" ? `F = ${fmt(x, 6)} N` : `m = ${fmt(x, 6)} kg`
                }
              />

              <ReferenceLine y={0} />
              <Line type="monotone" dataKey="a" dot={false} name="a = F/m" />

              {mode === "a_vs_F" ? (
                <ReferenceDot x={safe.F} y={aNow} r={5} />
              ) : (
                <ReferenceDot x={safe.m} y={aNow} r={5} />
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Relación clave: <b>a ∝ F</b> y <b>a ∝ 1/m</b>.
        </div>
      </div>
    </div>
  );
}
