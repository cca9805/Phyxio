// frontend/src/v2/components/graphs/dinamica/SegundaLeyFuerzaMasaDcl.jsx
import React, { useEffect, useMemo, useState } from "react";
import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

export default function SegundaLeyFuerzaMasaDcl({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({
    m: 10, // kg
    F: 20, // N
    g: 9.81,
    showWeight: true,
    showNormal: true,
  }));

  // 🔗 enlazar con calculadora
  useEffect(() => {
    if (!linked) return;

    // 🔎 Normaliza: a veces params viene plano, a veces dentro de known/values/sharedParams
    const src =
      params?.known ??
      params?.values ??
      params?.sharedParams ??
      params ??
      null;

    if (!src) return;

    setP((prev) => ({
      ...prev,
      m: pickParam(src, ["m", "masa", "M"], prev.m),

      // ✅ MUCHAS KEYS posibles para "fuerza neta/aplicada"
      F: pickParam(
        src,
        [
          "F",
          "Fx",
          "F_x",
          "Fap",
          "F_aplicada",
          "Faplicada",
          "Fnet",
          "F_net",
          "Fres",
          "F_res",
          "Fresultante",
          "F_resultante",
          "SigmaF",
          "SigmaFx",
          "sumFx",
        ],
        prev.F
      ),

      g: pickParam(src, ["g"], prev.g),
    }));
  }, [linked, params]);


  const safe = useMemo(() => {
    const m = Math.max(0.001, toNum(p.m, 10));
    const F = toNum(p.F, 20);
    const g = Math.max(0, toNum(p.g, 9.81));
    return { m, F, g };
  }, [p]);

  const a = useMemo(() => safe.F / safe.m, [safe]);

  // escalado visual de flechas (solo estética)
  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  const arrowLenF = clamp(40 + Math.abs(safe.F) * 2.2, 40, 150);
  const arrowLenA = clamp(30 + Math.abs(a) * 18, 30, 120);

  const dir = safe.F >= 0 ? 1 : -1;

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Segunda ley (DCL) · F = m·a</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Modelo ideal en horizontal: <b>ΣF<sub>x</sub> = F</b>, <b>ΣF<sub>y</sub> = 0</b> ⇒{" "}
          <b>a = F/m</b>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🔗 Modo:</span>
              <button
                type="button"
                className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
                onClick={() => setLinked(true)}
              >
                Seguir calculadora
              </button>
              <button
                type="button"
                className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
                onClick={() => setLinked(false)}
              >
                🧪 Experimento
              </button>
            </div>
          </div>

          {/* Segunda fila: Parámetros */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>⚙️ Parámetros:</span>
            
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span>⚖️ m (kg)</span>
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  disabled={linked}
                  inputMode="decimal"
                  value={p.m}
                  onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))}
                />
              </label>
            </div>

            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span>💪  F (N)</span>
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
               
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  disabled={linked}
                  inputMode="decimal"
                  value={p.F}
                  onChange={(e) => setP((s) => ({ ...s, F: e.target.value }))}
                />
              </label>
            </div>

            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span>🌍 g (m/s²)</span>
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  disabled={linked}
                  inputMode="decimal"
                  value={p.g}
                  onChange={(e) => setP((s) => ({ ...s, g: e.target.value }))}
                />
              </label>
            </div>
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Resultado: <b>a = {fmt(a, 6)} m/s²</b> (con <b>m = {fmt(safe.m, 6)} kg</b>,{" "}
          <b>F = {fmt(safe.F, 6)} N</b>)
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Diagrama de cuerpo libre</div>
        
        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Opciones de visualización */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(168, 85, 247, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(168, 85, 247, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#a855f7", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
            
            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showNormal" 
                checked={p.showNormal} 
                onChange={(e) => setP((s) => ({ ...s, showNormal: e.target.checked }))} 
              />
              <label className="v2-checkbox-label" htmlFor="showNormal">Normal (N)</label>
            </div>

            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showWeight" 
                checked={p.showWeight} 
                onChange={(e) => setP((s) => ({ ...s, showWeight: e.target.checked }))} 
              />
              <label className="v2-checkbox-label" htmlFor="showWeight">Peso (mg)</label>
            </div>
          </div>
        </div>

        <svg viewBox="0 0 520 230" width="100%" height="230" style={{ marginTop: 10 }}>
          <rect x="0" y="0" width="520" height="230" fill="#b8c5ffff" />
          {/* suelo */}
          <line x1="50" y1="140" x2="470" y2="140" stroke="#334155" strokeWidth="3" />

          {/* bloque */}
          <rect x="220" y="110" width="50" height="30" rx="8" fill="#e5e7eb" stroke="#0f172a" strokeWidth="2" />
          <circle cx="245" cy="125" r="4" fill="#0f172a" />

          {/* Normal */}
          {p.showNormal && (
            <>
              <line x1="245" y1="110" x2="245" y2="70" stroke="#16a34a" strokeWidth="2" />
              <polygon points="245,55 240,70 250,70" fill="#16a34a" />
              <text x="260" y="70" fontSize="13" fill="#16a34a">
                N
              </text>
            </>
          )}

          {/* Peso */}
          {p.showWeight && (
            <>
              <line x1="245" y1="140" x2="245" y2="185" stroke="#dc2626" strokeWidth="3" />
              <polygon points="245,195 240,180 250,180" fill="#dc2626" />
              <text x="255" y="190" fontSize="13" fill="#dc2626">
                P = mg
              </text>
            </>
          )}

          {/* Fuerza aplicada F */}
          <line
            x1={dir > 0 ? 270 : 200}
            y1="125"
            x2={dir > 0 ? 270 + arrowLenF : 200 - arrowLenF}
            y2="125"
            stroke="#2563eb"
            strokeWidth="3"
          />
          <polygon
            points={
              dir > 0
                ? `${270 + arrowLenF + 10},125 ${270 + arrowLenF - 2},120 ${270 + arrowLenF - 2},130`
                : `${200 - arrowLenF - 10},125 ${200 - arrowLenF + 2},120 ${200 - arrowLenF + 2},130`
            }
            fill="#2563eb"
          />
          <text
            x={dir > 0 ? 270 + arrowLenF + 14 : 270 - arrowLenF - 24}
            y="130"
            fontSize="13"
            fill="#2563eb"
            fontWeight="bold"
          >
            F
          </text>

          {/* aceleración a */}
          <line
            x1="240"
            y1="90"
            x2={dir > 0 ? 240 + arrowLenA : 240 - arrowLenA}
            y2="90"
            stroke="#7c3aed"
            strokeWidth="2"
          />
          <polygon
            points={
              dir > 0
                ? `${240 + arrowLenA + 10},90 ${240 + arrowLenA - 2},85 ${240 + arrowLenA - 2},95`
                : `${240 - arrowLenA - 10},90 ${240 - arrowLenA + 2},85 ${240 - arrowLenA + 2},95`
            }
            fill="#7c3aed"
          />
          <text
            x={dir > 0 ? 240 + arrowLenA + 14 : 240 - arrowLenA - 24}
            y="93"
            fontSize="13"
            fill="#7c3aed"
            fontWeight="bold"
          >
            a
          </text>

          {/* texto ΣF */}
          <text x="260" y="220" textAnchor="middle" fontSize="14" fill="#0f172a" fontWeight="bold">
            ΣF = m·a  ⇒  a = F/m
          </text>
        </svg>

        <div className="muted" style={{ marginTop: 6 }}>
          Nota: en horizontal ideal, <b>N</b> y <b>mg</b> se anulan y la resultante en x es <b>F</b>.
        </div>
      </div>
    </div>
  );
}
