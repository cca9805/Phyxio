import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function buildData({ g, tMax }, n = 240) {
  const data = [];
  for (let i = 0; i <= n; i++) {
    const theta = (tMax * i) / n;
    const a = g * Math.sin(theta);
    data.push({ theta, a });
  }
  return data;
}

export default function SinRozamientoGraphs() {
  const [p, setP] = useState({
    g: 9.8,
    tMax: Math.PI / 2,
  });

  const data = useMemo(() => buildData(p, 240), [p]);

  return (
    <div className="v2-card" style={{ padding: 12 }}>
      <div className="v2-card-title">Plano inclinado sin rozamiento</div>
      <div className="muted" style={{ marginBottom: 8 }}>
        Aceleración en función del ángulo: <b>a = g·sinθ</b>
      </div>

      <div className="v2-grid-fill-inputs">
        <div className="v2-card">
          <div className="v2-card-title">g (m/s²)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.g}
            onChange={(e) => setP({ ...p, g: Number(e.target.value) })}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">θ max (rad)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.tMax}
            onChange={(e) => setP({ ...p, tMax: Number(e.target.value) })}
          />
        </div>
      </div>

      <div style={{ width: "100%", height: 340, marginTop: 12 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid />
            <XAxis
              dataKey="theta"
              tickFormatter={(v) => fmt(v, 3)}
              label={{ value: "θ (rad)", position: "insideBottom", offset: -5 }}
            />
            <YAxis
              tickFormatter={(v) => fmt(v, 4)}
              label={{ value: "a (m/s²)", angle: -90, position: "insideLeft" }}
            />
            <Tooltip
              formatter={(v) => fmt(v, 6)}
              labelFormatter={(x) => `θ = ${fmt(x, 6)} rad`}
            />
            <ReferenceLine y={0} />
            <Line type="monotone" dataKey="a" dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
