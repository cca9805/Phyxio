import React, { useMemo, useState } from "react";

export default function SinRozamientoDcl() {
  const [p, setP] = useState({
    thetaDeg: 30,
    m: 2,
    g: 9.8,
    showComponents: true,
    showEjes: true,
  });

  const safe = useMemo(() => {
    const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
    const thetaDeg = clamp(Number(p.thetaDeg) || 30, 0, 70);
    const m = Math.max(0.001, Number(p.m) || 2);
    const g = Math.max(0, Number(p.g) || 9.8);
    return {
      thetaDeg,
      theta: (thetaDeg * Math.PI) / 180,
      m,
      g,
      showComponents: !!p.showComponents,
      showEjes: !!p.showEjes,
    };
  }, [p]);

  const mg = safe.m * safe.g;
  const N = mg * Math.cos(safe.theta);
  const mgPar = mg * Math.sin(safe.theta);
  const mgPer = mg * Math.cos(safe.theta);

  const k = 6.7; // px por N aproximado (reducido de 10 a ~6.7)
  const Lmg = clampLen(mg * k, 27, 147); // reducido en 1/3
  const LN = clampLen(N * k, 20, 133); // reducido en 1/3
  const Lpar = clampLen(mgPar * k, 13, 120); // reducido en 1/3
  const Lper = clampLen(mgPer * k, 13, 120); // reducido en 1/3

  return (
    <div className="v2-card" style={{ padding: 12 }}>
      <div className="v2-card-title">DCL: plano inclinado sin rozamiento</div>
      <div className="muted" style={{ marginTop: 6 }}>
        Fuerzas: <b>mg</b> y <b>N</b>. No hay rozamiento.
      </div>

      <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
        <div className="v2-card">
          <div className="v2-card-title">θ (°)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.thetaDeg}
            onChange={(e) => setP((s) => ({ ...s, thetaDeg: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">m (kg)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.m}
            onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <div className="v2-card-title">g (m/s²)</div>
          <input
            className="form-control"
            inputMode="decimal"
            value={p.g}
            onChange={(e) => setP((s) => ({ ...s, g: e.target.value }))}
          />
        </div>

        <div className="v2-card">
          <label style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <input
              type="checkbox"
              checked={!!p.showComponents}
              onChange={(e) => setP((s) => ({ ...s, showComponents: e.target.checked }))}
            />
            <span className="muted">Mostrar componentes</span>
          </label>
          <label style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 8 }}>
            <input
              type="checkbox"
              checked={!!p.showEjes}
              onChange={(e) => setP((s) => ({ ...s, showEjes: e.target.checked }))}
            />
            <span className="muted">Mostrar ejes del plano</span>
          </label>
        </div>
      </div>

      <div className="muted" style={{ marginTop: 10 }}>
        Valores (aprox): <b>N = {fmt(N)} N</b>, <b>mg·sinθ = {fmt(mgPar)} N</b>,{" "}
        <b>a = g·sinθ = {fmt(safe.g * Math.sin(safe.theta))} m/s²</b>
      </div>

      <div style={{ marginTop: 12, width: "100%", height: 830 }}>
        <svg viewBox="0 0 820 420" width="100%" height="100%">
          <defs>
            <marker id="arr" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto">
              <path d="M0,0 L10,5 L0,10 Z" fill="rgba(226,232,240,0.92)" />
            </marker>
          </defs>

          <rect x="18" y="18" width="784" height="384" rx="18" fill="rgba(148,163,184,0.06)" stroke="rgba(255,255,255,0.08)" />

          {/* Sistema plano + bloque (rotan juntos alrededor del centro del plano) */}
          {(() => {
            // Centro fijo del card donde estará el centro del plano (desplazado a la izquierda)
            const centerX = 300; // desplazado a la izquierda
            const centerY = 210; // centro vertical del panel
            
            // Dimensiones del plano (reducidas en 1/3)
            const planoWidth = 373; // ~560 * 2/3
            const planoHeight = 11; // ~16 * 2/3
            
            // Posición del bloque relativa al centro del plano (en coordenadas del plano)
            const bloqueOffsetX = 0; // centrado horizontalmente en el plano
            const bloqueOffsetY = -26; // justo sobre el plano: -(planoHeight/2 + bloqueHeight/2)
            // bloqueHeight = 40, planoHeight = 11 -> offset = -(5.5 + 20) = -25.5 ≈ -26
            
            return (
              <g transform={`translate(${centerX},${centerY}) rotate(${-safe.thetaDeg})`}>
                {/* plano (centrado en el origen) */}
                <rect 
                  x={-planoWidth/2} 
                  y={-planoHeight/2} 
                  width={planoWidth} 
                  height={planoHeight} 
                  rx="6" 
                  fill="rgba(226,232,240,0.16)" 
                  stroke="rgba(226,232,240,0.18)" 
                />
                
                {/* bloque sobre el plano (reducido en 1/3) */}
                <g transform={`translate(${bloqueOffsetX},${bloqueOffsetY})`}>
                  <rect x="-30" y="-20" width="60" height="40" rx="7" fill="rgba(226,232,240,0.20)" stroke="rgba(226,232,240,0.28)" />
                  <text x="0" y="3" textAnchor="middle" fontSize="10" fill="rgba(226,232,240,0.75)">
                    bloque
                  </text>
                </g>
              </g>
            );
          })()}

          {/* fuerzas */}
          {(() => {
            // Calcular posición del centro del bloque en coordenadas mundo
            const centerX = 300; // mismo valor que arriba
            const centerY = 210;
            const bloqueOffsetX = 0;
            const bloqueOffsetY = -26; // mismo valor que arriba
            
            // Aplicar rotación para obtener coordenadas mundo
            const theta = safe.theta;
            const cosT = Math.cos(-theta); // negativo porque rotamos -thetaDeg
            const sinT = Math.sin(-theta);
            
            const ox = centerX + bloqueOffsetX * cosT - bloqueOffsetY * sinT;
            const oy = centerY + bloqueOffsetX * sinT + bloqueOffsetY * cosT;

            // vectores en coordenadas mundo
            // Eje paralelo: dirección "subiendo por el plano" (hacia arriba-derecha)
            const tx = Math.cos(theta);   // componente x del eje paralelo
            const ty = -Math.sin(theta);  // componente y del eje paralelo (negativo = hacia arriba)
            // Eje perpendicular: "saliendo del plano" (perpendicular, hacia arriba-izquierda)
            const nx = -Math.sin(theta);  // componente x del eje perpendicular (negativo = hacia izquierda)
            const ny = -Math.cos(theta);  // componente y del eje perpendicular (negativo = hacia arriba)

            const mgx = 0, mgy = Lmg;
            const Nvx = nx * LN, Nvy = ny * LN;

            return (
              <g>
                <circle cx={ox} cy={oy} r="4.5" fill="rgba(226,232,240,0.9)" />

                {safe.showEjes ? (
                  <g>
                    <line x1={ox} y1={oy} x2={ox + tx * 80} y2={oy + ty * 80} stroke="rgba(96,165,250,0.75)" strokeWidth="2.5" markerEnd="url(#arr)" />
                    <text x={ox + tx * 87} y={oy + ty * 87} fontSize="11" fill="rgba(96,165,250,0.95)">
                      eje ∥
                    </text>

                    <line x1={ox} y1={oy} x2={ox + nx * 73} y2={oy + ny * 73} stroke="rgba(34,197,94,0.75)" strokeWidth="2.5" markerEnd="url(#arr)" />
                    <text x={ox + nx * 80} y={oy + ny * 80} fontSize="11" fill="rgba(34,197,94,0.95)">
                      eje ⟂
                    </text>
                  </g>
                ) : null}

                <line x1={ox} y1={oy} x2={ox + mgx} y2={oy + mgy} stroke="rgba(248,113,113,0.95)" strokeWidth="3" markerEnd="url(#arr)" />
                <text x={ox + 10} y={oy + mgy + 12} fontSize="11" fill="rgba(248,113,113,0.95)" fontWeight="700">
                  mg
                </text>

                <line x1={ox} y1={oy} x2={ox + Nvx} y2={oy + Nvy} stroke="rgba(34,197,94,0.95)" strokeWidth="3" markerEnd="url(#arr)" />
                <text x={ox + Nvx + 6} y={oy + Nvy + 4} fontSize="11" fill="rgba(34,197,94,0.95)" fontWeight="700">
                  N
                </text>

                {safe.showComponents ? (
                  <g>
                    <line
                      x1={ox}
                      y1={oy}
                      x2={ox - tx * Lpar}
                      y2={oy - ty * Lpar}
                      stroke="rgba(148,163,184,0.95)"
                      strokeWidth="2.5"
                      markerEnd="url(#arr)"
                      strokeDasharray="5 4"
                    />
                    <text x={ox - tx * (Lpar + 8)} y={oy - ty * (Lpar + 8)} fontSize="10" fill="rgba(148,163,184,0.95)">
                      mg·sinθ
                    </text>

                    <line
                      x1={ox}
                      y1={oy}
                      x2={ox - nx * Lper}
                      y2={oy - ny * Lper}
                      stroke="rgba(148,163,184,0.95)"
                      strokeWidth="2.5"
                      markerEnd="url(#arr)"
                      strokeDasharray="5 4"
                    />
                    <text x={ox - nx * (Lper + 8)} y={oy - ny * (Lper + 8)} fontSize="10" fill="rgba(148,163,184,0.95)">
                      mg·cosθ
                    </text>
                  </g>
                ) : null}
              </g>
            );
          })()}

          <g transform="translate(535, 85)">
            <rect x="0" y="0" width="255" height="118" rx="14" fill="rgba(0,0,0,0.55)" stroke="rgba(255,255,255,0.12)" />
            <text x="14" y="26" fontSize="13" fill="rgba(226,232,240,0.92)" fontWeight="700">
              Ecuaciones
            </text>
            <text x="14" y="54" fontSize="12" fill="rgba(226,232,240,0.78)">
              N = mg·cosθ
            </text>
            <text x="14" y="76" fontSize="12" fill="rgba(226,232,240,0.78)">
              a = g·sinθ
            </text>
            <text x="14" y="100" fontSize="12" fill="rgba(226,232,240,0.72)">
              θ = {safe.thetaDeg}°
            </text>
          </g>
        </svg>
      </div>
    </div>
  );
}

function clampLen(x, a, b) {
  const n = Number(x);
  if (!Number.isFinite(n)) return a;
  return Math.min(b, Math.max(a, n));
}
function fmt(x) {
  const n = Number(x);
  if (!Number.isFinite(n)) return "—";
  const a = Math.abs(n);
  const digits = a >= 100 ? 1 : a >= 10 ? 2 : 3;
  return n.toFixed(digits).replace(/\.?0+$/, "");
}
