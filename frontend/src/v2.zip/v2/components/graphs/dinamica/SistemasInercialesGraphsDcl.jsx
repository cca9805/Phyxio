import React, { useEffect, useMemo, useState } from "react";
import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

export default function SistemasInercialesDcl({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({
    m: 10,
    g: 9.81,
    showNormal: true,
    showWeight: true,
    showHoriz: false, // si quieres mostrar fuerzas horizontales equilibradas
  }));

  useEffect(() => {
    if (!linked) return;

    const src = params?.known ?? params?.values ?? params?.sharedParams ?? params ?? null;
    if (!src) return;

    setP((prev) => ({
      ...prev,
      m: pickParam(src, ["m", "masa", "M"], prev.m),
      g: pickParam(src, ["g"], prev.g),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const m = Math.max(0.001, toNum(p.m, 10));
    const g = Math.max(0, toNum(p.g, 9.81));
    const W = m * g;
    return { m, g, W };
  }, [p]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Sistemas inerciales (DCL)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          En un marco inercial, si <b>ΣF = 0</b> entonces <b>a = 0</b> (reposo o v constante).
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🔗 Modo:</span>
              <button
                type="button"
                className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
                onClick={() => setLinked(true)}
              >
                Seguir calculadora
              </button>
              <button
                type="button"
                className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
                onClick={() => setLinked(false)}
              >
                🧪 Experimento
              </button>
            </div>
          </div>

          {/* Segunda fila: Parámetros */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>⚙️ Parámetros:</span>
            
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span>⚖️ m (kg)</span>
              <input
                className="form-control"
                style={{ width: 80 }}
                disabled={linked}
                inputMode="decimal"
                value={p.m}
                onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))}
              />
            </div>

            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span>🌍 g (m/s²)</span>
              <input
                className="form-control"
                style={{ width: 80 }}
                disabled={linked}
                inputMode="decimal"
                value={p.g}
                onChange={(e) => setP((s) => ({ ...s, g: e.target.value }))}
              />
            </div>
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Peso: <b>mg = {fmt(safe.W, 6)} N</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Diagrama de cuerpo libre</div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Opciones de visualización */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(168, 85, 247, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(168, 85, 247, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#a855f7", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
            
            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showNormal" 
                checked={p.showNormal} 
                onChange={(e) => setP((s) => ({ ...s, showNormal: e.target.checked }))} 
              />
              <label className="v2-checkbox-label" htmlFor="showNormal">Normal (N)</label>
            </div>

            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showWeight" 
                checked={p.showWeight} 
                onChange={(e) => setP((s) => ({ ...s, showWeight: e.target.checked }))} 
              />
              <label className="v2-checkbox-label" htmlFor="showWeight">Peso (mg)</label>
            </div>

            <div className="v2-checkbox-container">
              <input 
                className="v2-checkbox" 
                type="checkbox" 
                id="showHoriz" 
                checked={p.showHoriz} 
                onChange={(e) => setP((s) => ({ ...s, showHoriz: e.target.checked }))} 
              />
              <label className="v2-checkbox-label" htmlFor="showHoriz">Fx equilibradas</label>
            </div>
          </div>
        </div>

        <svg viewBox="0 0 520 210" width="100%" height="260" style={{ marginTop: 10 }}>
          <rect x="0" y="0" width="520" height="210" fill="#b8c5ffff" />
          {/* suelo */}
          <line x1="50" y1="117" x2="470" y2="117" stroke="#334155" strokeWidth="3" />

          {/* bloque */}
          <rect x="230" y="80" width="60" height="35" rx="8" fill="#e5e7eb" stroke="#0f172a" strokeWidth="2" />
          <circle cx="260" cy="97" r="2" fill="#0f172a" />

          {/* Normal */}
          {p.showNormal && (
            <>
              <line x1="260" y1="80" x2="260" y2="35" stroke="#16a34a" strokeWidth="3" />
              <polygon points="260,20 254,35 266,35" fill="#16a34a" />
              <text x="270" y="35" fontSize="13" fill="#16a34a">
                N
              </text>
            </>
          )}

          {/* Peso */}
          {p.showWeight && (
            <>
              <line x1="260" y1="160" x2="260" y2="115" stroke="#dc2626" strokeWidth="3" />
              <polygon points="260,175 254,160 266,160" fill="#dc2626" />
              <text x="270" y="170" fontSize="13" fill="#dc2626">
                mg
              </text>
            </>
          )}

          {/* Fx equilibradas (opcional) */}
          {p.showHoriz && (
            <>
              <line x1="220" y1="172" x2="165" y2="172" stroke="#2563eb" strokeWidth="3" />
              <polygon points="155,172 167,166 167,178" fill="#2563eb" />
              <text x="140" y="166" fontSize="12" fill="#2563eb" fontWeight="bold">
                F
              </text>

              <line x1="300" y1="172" x2="355" y2="172" stroke="#2563eb" strokeWidth="3" />
              <polygon points="365,172 353,166 353,178" fill="#2563eb" />
              <text x="372" y="166" fontSize="12" fill="#2563eb" fontWeight="bold">
                F
              </text>
            </>
          )}

          <text x="260" y="200" textAnchor="middle" fontSize="12" fill="#0f172a" fontWeight="bold">
            ΣF = 0  ⇒  a = 0
          </text>
        </svg>

        <div className="muted" style={{ marginTop: 6 }}>
          En un sistema inercial no necesitas fuerzas “extra”: aplicas Newton directamente.
        </div>
      </div>
    </div>
  );
}
