import React, { useEffect, useMemo, useState } from "react";
import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

export default function SistemasNoInercialesIntroDcl({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({
    mode: "noninertial", // "inertial" | "noninertial"
    m: 10,
    aFrame: 2.0,
    g: 9.81,
    showNormal: true,
    showWeight: true,
    showFictitious: true,
  }));

  useEffect(() => {
    if (!linked) return;
    const src = params?.known ?? params?.values ?? params?.sharedParams ?? params ?? null;
    if (!src) return;

    setP((prev) => ({
      ...prev,
      m: pickParam(src, ["m", "masa", "M"], prev.m),
      aFrame: pickParam(src, ["aFrame", "a_marco", "aMarco", "a"], prev.aFrame),
      g: pickParam(src, ["g"], prev.g),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const m = Math.max(0.001, toNum(p.m, 10));
    const aFrame = toNum(p.aFrame, 2.0);
    const g = Math.max(0, toNum(p.g, 9.81));
    const W = m * g;
    const Ffic = m * aFrame;
    return { m, aFrame, g, W, Ffic };
  }, [p]);

  const isNonInertial = p.mode === "noninertial";
  const dir = safe.aFrame >= 0 ? 1 : -1; // a_marco
  const ficDir = -dir;

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Sistemas no inerciales (DCL)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          En un marco acelerado, para aplicar Newton dentro del marco añadimos{" "}
          <b>F_fic = m·a_marco</b> (opuesta a la aceleración del marco).
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🔗 Modo:</span>
              <button
                type="button"
                className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
                onClick={() => setLinked(true)}
              >
                Seguir calculadora
              </button>
              <button
                type="button"
                className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
                onClick={() => setLinked(false)}
              >
                🧪 Experimento
              </button>
            </div>
          </div>

          {/* Segunda fila: Parámetros */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>⚙️ Parámetros:</span>
            
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span>⚖️ m (kg)</span>
              <input
                className="form-control"
                style={{ width: 80 }}
                disabled={linked}
                inputMode="decimal"
                value={p.m}
                onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))}
              />
            </div>

            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span>🚀 a_marco (m/s²)</span>
              <input
                className="form-control"
                style={{ width: 80 }}
                disabled={linked}
                inputMode="decimal"
                value={p.aFrame}
                onChange={(e) => setP((s) => ({ ...s, aFrame: e.target.value }))}
              />
            </div>

            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span>🌍 g (m/s²)</span>
              <input
                className="form-control"
                style={{ width: 80 }}
                disabled={linked}
                inputMode="decimal"
                value={p.g}
                onChange={(e) => setP((s) => ({ ...s, g: e.target.value }))}
              />
            </div>
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          mg = <b>{fmt(safe.W, 6)} N</b> · F_fic = <b>{fmt(safe.Ffic, 6)} N</b>{" "}
          {isNonInertial ? "(si estás en marco no inercial)" : "(en inercial se toma 0)"}
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Diagrama (bloque sobre mesa)</div>
          <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap", alignItems: "center", justifyContent: "center" }}>
            <label style={{ color: "rgba(226, 232, 240, 0.8)", fontSize: "13px", fontWeight: "500" }}>
              Marco:
            </label>
            <select
              className="form-control"
              style={{ 
                width: 200,
                backgroundColor: "#1e293b",
                color: "#ffffff",
                border: "1px solid #475569",
                borderRadius: "6px",
                padding: "6px 10px"
              }}
              value={p.mode}
              onChange={(e) => setP((s) => ({ ...s, mode: e.target.value }))}
            >
              <option value="inertial">Inercial (a=0)</option>
              <option value="noninertial">No inercial</option>
            </select>

            <div className="v2-checkbox-container">
              <input
                type="checkbox"
                className="v2-checkbox"
                checked={p.showFictitious}
                onChange={(e) => setP((s) => ({ ...s, showFictitious: e.target.checked }))}
              />
              <label className="v2-checkbox-label">F_fic</label>
            </div>

          </div>

        <svg viewBox="0 0 560 230" width="100%" height="270" style={{ marginTop: 10 }}>
          {/* suelo */}
          <line x1="60" y1="140" x2="500" y2="140" stroke="#334155" strokeWidth="3" />
          {/* bloque */}
          <rect x="240" y="95" width="90" height="45" rx="10" fill="#e5e7eb" stroke="#0f172a" strokeWidth="2" />
          <circle cx="285" cy="118" r="3" fill="#0f172a" />

          {/* N */}
          {p.showNormal && (
            <>
              <line x1="285" y1="95" x2="285" y2="50" stroke="#16a34a" strokeWidth="3" />
              <polygon points="285,40 279,52 291,52" fill="#16a34a" />
              <text x="295" y="50" fontSize="13" fill="#16a34a">
                N
              </text>
            </>
          )}

          {/* mg */}
          {p.showWeight && (
            <>
              <line x1="285" y1="140" x2="285" y2="190" stroke="#dc2626" strokeWidth="3" />
              <polygon points="285,200 279,190 291,190" fill="#dc2626" />
              <text x="295" y="200" fontSize="13" fill="#dc2626">
                mg
              </text>
            </>
          )}

          {/* a_marco */}
          {isNonInertial && (
            <>
              <line x1="90" y1="20" x2={90 + dir * 140} y2="20" stroke="#6366f1" strokeWidth="3" />
              <polygon
                points={`${90 + dir * 150},20 ${90 + dir * 138},14 ${90 + dir * 138},26`}
                fill="#6366f1"
              />
              <text
                x={90 + dir * 160}
                y="22"
                textAnchor={dir > 0 ? "start" : "end"}
                fontSize="12"
                fill="#6366f1"
                fontWeight="bold"
              >
                a_marco
              </text>
            </>
          )}

          {/* F_fic (opuesta a a_marco) */}
          {isNonInertial && p.showFictitious && (
            <>
              <line x1="240" y1="118" x2={285 + ficDir * 160} y2="118" stroke="#f59e0b" strokeWidth="3" />
              <polygon
                points={`${285 + ficDir * 170},118 ${285 + ficDir * 158},123 ${285 + ficDir * 158},113`}
                fill="#f59e0b"
              />
              <text
                x={285 + ficDir * 182}
                y="120"
                textAnchor={ficDir > 0 ? "start" : "end"}
                fontSize="12"
                fill="#f59e0b"
                fontWeight="bold"
              >
                F_fic
              </text>
            </>
          )}

          <text x="280" y="222" textAnchor="middle" fontSize="10" fill="#0f172a" fontWeight="bold">
            En marco no inercial: añade F_fic para usar Newton en el marco
          </text>
        </svg>
      </div>
    </div>
  );
}
