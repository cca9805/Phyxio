import { useMemo, useState } from "react";

/**
 * Tensión en cuerdas y cables (DCL)
 * - Escenas: masa colgante y Atwood.
 * - Vectores: W (peso) y T (tensión). En Atwood, se muestra además un indicador de a.
 * Estilo: fondo #b8c5ffff + flechas con punta.
 */
export default function TensionEnCuerdasYCablesGraphsDcl() {
  const [scene, setScene] = useState("hanging"); // hanging | atwood
  const [m, setM] = useState(5);
  const [g, setG] = useState(9.81);

  const [m1, setM1] = useState(5);
  const [m2, setM2] = useState(3);
  const [g2, setG2] = useState(9.81);

  const [showAxes, setShowAxes] = useState(true);
  const [showLabels, setShowLabels] = useState(true);

  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const toNum = (v, d) => {
    if (v == null || v === "") return d;
    const n = Number(String(v).replace(",", "."));
    return Number.isFinite(n) ? n : d;
  };

  const safe = useMemo(() => {
    const mm = clamp(toNum(m, 5), 0.1, 50);
    const gg = clamp(toNum(g, 9.81), 0.1, 30);

    const m1v = clamp(toNum(m1, 5), 0.1, 50);
    const m2v = clamp(toNum(m2, 3), 0.1, 50);
    const gg2 = clamp(toNum(g2, 9.81), 0.1, 30);

    return { mm, gg, m1: m1v, m2: m2v, gg2 };
  }, [m, g, m1, m2, g2]);

  const aReal = useMemo(() => {
    const den = safe.m1 + safe.m2;
    if (den <= 0) return 0;
    return ((safe.m1 - safe.m2) / den) * safe.gg2;
  }, [safe]);

  const T_hanging = safe.mm * safe.gg; // reposo ideal
  const T_atwood = safe.m1 * (safe.gg2 - aReal);

  const fmt = (x) => {
    const n = Number(x);
    if (!Number.isFinite(n)) return "—";
    return n.toFixed(3).replace(".", ",");
  };

  const C = {
    bg: "#b8c5ffff",
    card: "#ffffff",
    stroke: "#d6e5ff",
    ink: "#0f172a",
    muted: "#64748b",
    axis: "#5b7aa8",
    W: "#ff2d55",
    T: "#006aff",
    acc: "#7c3aed",
  };

  const Wsvg = 900;
  const Hsvg = 420;
  const O = { x: 610, y: 240 };
  const px = 16;

  const toPt = (v) => ({ x: O.x + v.x * px, y: O.y + v.y * px });

  const Arrow = ({ v, stroke, label, w = 8, dashed = false }) => {
    const p1 = O;
    const p2 = toPt(v);
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const L = Math.hypot(dx, dy) || 1;
    const ux = dx / L;
    const uy = dy / L;

    const head = 14;
    const wing = 8;

    const hx = p2.x;
    const hy = p2.y;
    const lx = hx - ux * head - uy * wing;
    const ly = hy - uy * head + ux * wing;
    const rx = hx - ux * head + uy * wing;
    const ry = hy - uy * head - ux * wing;

    return (
      <g>
        <line
          x1={p1.x}
          y1={p1.y}
          x2={hx}
          y2={hy}
          stroke={stroke}
          strokeWidth={w}
          strokeLinecap="round"
          strokeDasharray={dashed ? "10 10" : undefined}
        />
        <polygon points={`${hx},${hy} ${lx},${ly} ${rx},${ry}`} fill={stroke} opacity="0.96" />
        {showLabels && (
          <text x={hx + 10} y={hy + 6} fontSize="18" fontWeight="900" fill={stroke}>
            {label}
          </text>
        )}
      </g>
    );
  };

  const Axis = ({ dir, label }) => {
    const len = 12;
    const v = { x: dir.x * len, y: -dir.y * len };
    const p2 = toPt(v);
    return (
      <g opacity="0.9">
        <line x1={O.x} y1={O.y} x2={p2.x} y2={p2.y} stroke={C.axis} strokeWidth={4} strokeLinecap="round" />
        <text x={p2.x + 8} y={p2.y + 6} fontSize="14" fill={C.axis} fontWeight="800">
          {label}
        </text>
      </g>
    );
  };

  // Vectores didácticos (magnitudes relativas)
  const Wmag = 10;
  const Wv = { x: 0, y: +Wmag };
  const Tv = { x: 0, y: -Wmag };

  // T en Atwood se escala respecto a m1*g para que sea visual (sin reventar el dibujo)
  const Ta = { x: 0, y: -Wmag * (T_atwood / Math.max(0.001, safe.m1 * safe.gg2)) };

  // Indicador de aceleración (si m1>m2, el sistema acelera hacia abajo para m1)
  const av = { x: 0, y: aReal > 0 ? +6 : aReal < 0 ? -6 : 0 };

  return (
    <div className="v2-graphs">
      {/* Card azul - Configuración principal */}
      <div className="v2-card" style={{ background: 'rgba(59, 130, 246, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div className="v2-grid-fill-inputs">
          <div className="v2-input-group">
            <label>🎬 Escena</label>
            <select className="form-control" value={scene} onChange={(e) => setScene(e.target.value)}>
              <option value="hanging">Masa colgante</option>
              <option value="atwood">Atwood</option>
            </select>
          </div>

          {scene === "hanging" ? (
            <>
              <div className="v2-input-group">
                <label>⚖️ m (kg)</label>
                <input className="form-control" inputMode="decimal" value={m} onChange={(e) => setM(e.target.value)} />
              </div>
              <div className="v2-input-group">
                <label>🌍 g (m/s²)</label>
                <input className="form-control" inputMode="decimal" value={g} onChange={(e) => setG(e.target.value)} />
              </div>
            </>
          ) : (
            <>
              <div className="v2-input-group">
                <label>⚖️ m1 (kg)</label>
                <input className="form-control" inputMode="decimal" value={m1} onChange={(e) => setM1(e.target.value)} />
              </div>
              <div className="v2-input-group">
                <label>⚖️ m2 (kg)</label>
                <input className="form-control" inputMode="decimal" value={m2} onChange={(e) => setM2(e.target.value)} />
              </div>
              <div className="v2-input-group">
                <label>🌍 g (m/s²)</label>
                <input className="form-control" inputMode="decimal" value={g2} onChange={(e) => setG2(e.target.value)} />
              </div>
            </>
          )}
        </div>
      </div>

      {/* Card verde - Controles de visualización */}
      <div className="v2-card" style={{ background: 'rgba(34, 197, 94, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div style={{ 
          display: "flex", 
          gap: 18, 
          alignItems: "center", 
          flexWrap: "wrap",
          justifyContent: "center"
        }}>
          <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
          
          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showLabels"
              checked={showLabels}
              onChange={(e) => setShowLabels(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showLabels">Etiquetas</label>
          </div>

          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showAxes"
              checked={showAxes}
              onChange={(e) => setShowAxes(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showAxes">Ejes</label>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12, overflow: "hidden" }}>
        <svg viewBox={`0 0 ${Wsvg} ${Hsvg}`} width="100%" height="340" style={{ display: "block" }}>
          <rect x="0" y="0" width={Wsvg} height={Hsvg} fill={C.bg} />

          <rect x="18" y="18" width="420" height="132" rx="14" fill={C.card} stroke={C.stroke} strokeWidth="3" opacity="0.96" />
          <text x="34" y="50" fontSize="18" fontWeight="900" fill={C.ink}>
            Datos
          </text>
          {scene === "hanging" ? (
            <>
              <text x="34" y="78" fontSize="14" fill={C.muted}>
                Equilibrio: T = W = mg = {fmt(T_hanging)} N
              </text>
              <text x="34" y="100" fontSize="14" fill={C.muted}>
                En reposo ideal, tensión iguala al peso
              </text>
            </>
          ) : (
            <>
              <text x="34" y="78" fontSize="14" fill={C.muted}>
                Atwood: a = {fmt(aReal)} m/s² · T = {fmt(T_atwood)} N
              </text>
              <text x="34" y="100" fontSize="14" fill={C.muted}>
                T = m1(g − a) = m2(g + a)
              </text>
            </>
          )}

          <circle cx={O.x} cy={O.y} r="10" fill={C.ink} opacity="0.85" />

          {showAxes && (
            <>
              <Axis dir={{ x: 1, y: 0 }} label="x" />
              <Axis dir={{ x: 0, y: 1 }} label="y" />
            </>
          )}

          <Arrow v={Wv} stroke={C.W} label="W" />
          {scene === "hanging" ? (
            <Arrow v={Tv} stroke={C.T} label="T" />
          ) : (
            <>
              <Arrow v={Ta} stroke={C.T} label="T" />
              <Arrow v={av} stroke={C.acc} label="a" dashed />
            </>
          )}
        </svg>
      </div>
    </div>
  );
}
