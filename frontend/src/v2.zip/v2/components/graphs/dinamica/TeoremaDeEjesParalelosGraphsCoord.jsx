import React, { useEffect, useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

// helpers
function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function buildIData({ Icm, m }, dMax = 2.0, n = 201) {
  const data = [];
  const N = Math.max(50, n);
  for (let i = 0; i < N; i++) {
    const d = (dMax * i) / (N - 1);
    const I = Icm + m * d * d;
    data.push({ d, I });
  }
  return data;
}

export default function TeoremaDeEjesParalelosGraphsCoord({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({
    Icm: 0.12, // kg·m²
    m: 2.0, // kg
    d: 0.4, // m
    dMax: 2.0, // m
  }));

  // 🔗 enlazar con calculadora (si llega)
  useEffect(() => {
    if (!linked || !params) return;
    setP((prev) => ({
      ...prev,
      Icm: pickParam(params, ["Icm", "I_cm", "IcmVal"], prev.Icm),
      m: pickParam(params, ["m"], prev.m),
      d: pickParam(params, ["d"], prev.d),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const Icm = Math.max(0, toNum(p.Icm, 0.12));
    const m = Math.max(0.0001, toNum(p.m, 2.0));
    const dMax = Math.max(0.2, toNum(p.dMax, 2.0));
    const d = Math.min(Math.max(0, toNum(p.d, 0.4)), dMax);
    return { Icm, m, d, dMax };
  }, [p]);

  const INow = useMemo(() => safe.Icm + safe.m * safe.d * safe.d, [safe]);

  const curve = useMemo(
    () => buildIData({ Icm: safe.Icm, m: safe.m }, safe.dMax, 201),
    [safe.Icm, safe.m, safe.dMax]
  );

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {/* Controles */}
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Teorema de ejes paralelos</div>

        <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Experimento
          </button>
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">I_cm (kg·m²)</div>
            <input
              className="form-control"
              disabled={linked}
              value={p.Icm}
              inputMode="decimal"
              onChange={(e) => setP((s) => ({ ...s, Icm: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">m (kg)</div>
            <input
              className="form-control"
              disabled={linked}
              value={p.m}
              inputMode="decimal"
              onChange={(e) => setP((s) => ({ ...s, m: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">d (m)</div>
            <input
              className="form-control"
              disabled={linked}
              value={p.d}
              inputMode="decimal"
              onChange={(e) => setP((s) => ({ ...s, d: e.target.value }))}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">d_max (m)</div>
            <input
              className="form-control"
              value={p.dMax}
              inputMode="decimal"
              onChange={(e) => setP((s) => ({ ...s, dMax: e.target.value }))}
            />
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Steiner: <b>I = I_cm + m·d²</b> →{" "}
          <b>I = {fmt(INow, 6)} kg·m²</b>
        </div>
      </div>

      {/* Gráfica */}
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Curva I(d) con I_cm y m fijos</div>
        <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>
          La curva es una parábola: el incremento crece con d².
        </div>

        <div style={{ width: "100%", height: 340, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={curve}>
              <CartesianGrid />
              <XAxis
                dataKey="d"
                type="number"
                domain={[0, safe.dMax]}
                tickFormatter={(v) => fmt(v, 3)}
                label={{ value: "d (m)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 4)}
                label={{ value: "I (kg·m²)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(v) => fmt(v, 6)}
                labelFormatter={(x) => `d = ${fmt(x, 6)} m`}
              />
              <Line type="monotone" dataKey="I" dot={false} name="I" />
              {Number.isFinite(safe.d) && Number.isFinite(INow) ? (
                <ReferenceDot x={safe.d} y={INow} r={5} />
              ) : null}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
