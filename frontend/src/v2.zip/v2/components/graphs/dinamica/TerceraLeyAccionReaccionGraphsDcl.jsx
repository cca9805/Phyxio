import React, { useEffect, useMemo, useState } from "react";
import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

export default function TerceraLeyAccionReaccionDcl({ params }) {
  const [linked, setLinked] = useState(true);
  const [p, setP] = useState(() => ({
    F: 20,   // N (fuerza de empuje)
    mA: 5,   // kg (opcional)
    mB: 8,   // kg (opcional)
  }));

  // 🔗 Enlazar con calculadora (si llega params)
  useEffect(() => {
    if (!linked) return;

    const src =
      params?.known ??
      params?.values ??
      params?.sharedParams ??
      params ??
      null;

    if (!src) return;

    setP((prev) => ({
      ...prev,
      F: pickParam(
        src,
        [
          "F",
          "Fx",
          "F_x",
          "Fap",
          "F_aplicada",
          "Faplicada",
          "Fnet",
          "F_net",
          "Fres",
          "F_res",
          "SigmaF",
          "SigmaFx",
          "sumFx",
        ],
        prev.F
      ),
      mA: pickParam(src, ["mA", "m_a", "m1", "m"], prev.mA),
      mB: pickParam(src, ["mB", "m_b", "m2"], prev.mB),
    }));
  }, [linked, params]);

  const safe = useMemo(() => {
    const F = toNum(p.F, 20);
    const mA = Math.max(0.001, toNum(p.mA, 5));
    const mB = Math.max(0.001, toNum(p.mB, 8));
    return { F, mA, mB };
  }, [p]);

  // Aquí lo didáctico es el PAR acción-reacción en el contacto A↔B:
  // F_{A->B} = -F_{B->A} (igual módulo, sentido opuesto)
  const F_AB = safe.F;
  const F_BA = -safe.F;

  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  const arrowLen = clamp(40 + Math.abs(safe.F) * 2.0, 40, 160);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Tercera ley (DCL) · Acción–reacción</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Par en la interacción A↔B: <b>F</b><sub>A→B</sub> = − <b>F</b><sub>B→A</sub>.  
          <span className="muted"> (No se cancelan: actúan en cuerpos distintos.)</span>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🔗 Modo:</span>
              <button
                type="button"
                className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
                onClick={() => setLinked(true)}
              >
                Seguir calculadora
              </button>
              <button
                type="button"
                className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
                onClick={() => setLinked(false)}
              >
                🧪 Experimento
              </button>
            </div>
          </div>

          {/* Segunda fila: Parámetros */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>⚙️ Parámetros:</span>
            
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span >💪 F (N)</span>
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  disabled={linked}
                  inputMode="decimal"
                  value={p.F}
                  onChange={(e) => setP((s) => ({ ...s, F: e.target.value }))}
                />
              </label>
            </div>

            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span>🅰️ mA (kg)</span>
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  disabled={linked}
                  inputMode="decimal"
                  value={p.mA}
                  onChange={(e) => setP((s) => ({ ...s, mA: e.target.value }))}
                />
              </label>
            </div>

            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span>🅱️ mB (kg)</span>
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  disabled={linked}
                  inputMode="decimal"
                  value={p.mB}
                  onChange={(e) => setP((s) => ({ ...s, mB: e.target.value }))}
                />
              </label>
            </div>
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          En el contacto: <b>F</b><sub>A→B</sub> = <b>{fmt(F_AB, 6)} N</b> ·{" "}
          <b>F</b><sub>B→A</sub> = <b>{fmt(F_BA, 6)} N</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">DCL por cuerpos (A y B separados)</div>

        <svg viewBox="0 0 720 260" width="100%" height="260" style={{ marginTop: 10 }}>
          <rect x="0" y="0" width="720" height="260" fill="#b8c5ffff" />
          {/* Panel A */}
          
          <text x="205" y="45" textAnchor="middle" fontSize="14" fill="#0f172a" fontWeight="bold">
            Cuerpo A
          </text>

          {/* bloque A */}
          <rect x="160" y="110" width="90" height="60" rx="10" fill="#e5e7eb" stroke="#0f172a" strokeWidth="2" />
          <circle cx="205" cy="140" r="4" fill="#0f172a" />

          {/* F externa aplicada a A (a la derecha) */}
          <line x1="250" y1="140" x2={250 + arrowLen} y2="140" stroke="#2563eb" strokeWidth="3" />
          <polygon
            points={`${250 + arrowLen + 10},140 ${250 + arrowLen - 2},134 ${250 + arrowLen - 2},146`}
            fill="#2563eb"
          />
          <text x={250 + arrowLen + 16} y="134" fontSize="13" fill="#2563eb" fontWeight="bold">
            F
          </text>

          {/* Fuerza de contacto sobre A (B->A) hacia la izquierda */}
          <line x1="160" y1="140" x2={160 - arrowLen} y2="140" stroke="#7c3aed" strokeWidth="3" />
          <polygon
            points={`${160 - arrowLen - 10},140 ${160 - arrowLen + 2},134 ${160 - arrowLen + 2},146`}
            fill="#7c3aed"
          />
          <text x={160 - arrowLen - 54} y="134" fontSize="12" fill="#7c3aed" fontWeight="bold">
            F(B→A)
          </text>

          {/* Panel B */}
          
          <text x="485" y="45" textAnchor="middle" fontSize="14" fill="#0f172a" fontWeight="bold">
            Cuerpo B
          </text>

          {/* bloque B */}
          <rect x="440" y="110" width="90" height="60" rx="10" fill="#e5e7eb" stroke="#0f172a" strokeWidth="2" />
          <circle cx="485" cy="140" r="4" fill="#0f172a" />

          {/* Fuerza de contacto sobre B (A->B) hacia la derecha */}
          <line x1="530" y1="140" x2={540 + arrowLen} y2="140" stroke="#7c3aed" strokeWidth="3" />
          <polygon
            points={`${540 + arrowLen + 10},140 ${540 + arrowLen - 2},134 ${540 + arrowLen - 2},146`}
            fill="#7c3aed"
          />
          <text x={540 + arrowLen + 16} y="134" fontSize="12" fill="#7c3aed" fontWeight="bold">
            F(A→B)
          </text>

          {/* Mensaje inferior */}
          <text x="360" y="245" textAnchor="middle" fontSize="12" fill="#0f172a" fontWeight="bold">
            |F(A→B)| = |F(B→A)|  y sentidos opuestos (actúan en cuerpos distintos)
          </text>
        </svg>

        <div className="muted" style={{ marginTop: 6 }}>
          Si sumas fuerzas <b>en el mismo cuerpo</b>, entonces sí puedes hablar de resultante. Aquí comparamos fuerzas
          <b> en cuerpos distintos</b>.
        </div>
      </div>
    </div>
  );
}
