import React, { useEffect, useMemo, useState } from "react";
import { pickParam } from "../../../utils/pickParamGraphs";
import { fmt } from "../../../utils/graphFormat";

// -------------------- utils --------------------
function toNum(v, fallback = NaN) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).trim().replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

// Asegura que el tipo se refleje como ORDEN geométrico
// PAR: A en medio
// APR: P en medio
// ARP: R en medio
function enforceOrder(tipo, { xA, xP, xR }) {
  const vals = [xA, xP, xR].slice().sort((a, b) => a - b);

  if (tipo === "PAR") {
    return { xP: vals[0], xA: vals[1], xR: vals[2] };
  }
  if (tipo === "APR") {
    return { xA: vals[0], xP: vals[1], xR: vals[2] };
  }
  // ARP
  return { xA: vals[0], xR: vals[1], xP: vals[2] };
}

// Construye una “situación real” desde brazos (sin inventar m/g)
// La idea: colocar 3 puntos en una barra, respetando el orden del tipo.
function geometryFromArms(tipo, d_P, d_R) {
  const dP = Math.max(0, toNum(d_P, 0));
  const dR = Math.max(0, toNum(d_R, 0));

  // margen visual mínimo (si alguien mete 0, que el dibujo no colapse)
  const eps = 0.2;
  const a = Math.max(dP, eps);
  const b = Math.max(dR, eps);

  if (tipo === "APR") {
    // A - P - R
    const xA = 0;
    const xP = a;
    const xR = a + b;
    const L = xR;
    return { L, xA, xP, xR };
  }

  if (tipo === "ARP") {
    // A - R - P
    const xA = 0;
    const xR = b;
    const xP = b + a;
    const L = xP;
    return { L, xA, xP, xR };
  }

  // PAR (default): P - A - R
  const xP = 0;
  const xA = a;
  const xR = a + b;
  const L = xR;
  return { L, xA, xP, xR };
}

function armsFromGeometry({ xA, xP, xR }) {
  return {
    d_P: Math.abs(xP - xA),
    d_R: Math.abs(xR - xA),
  };
}

// -------------------- UI atoms --------------------
function NumInput({ label, value, onChange, disabled, hint }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <input
        className="form-control"
        type="text"
        inputMode="decimal"
        disabled={disabled}
        value={value ?? ""}
        onChange={(e) => onChange?.(e.target.value)}
      />
      {hint ? (
        <div className="muted" style={{ marginTop: 6, fontSize: 12 }}>
          {hint}
        </div>
      ) : null}
    </div>
  );
}

function SelectInput({ label, value, onChange, disabled, options, hint }) {
  return (
    <div className="v2-card">
      <div className="v2-card-title">{label}</div>
      <select className="form-control" disabled={disabled} value={value} onChange={(e) => onChange?.(e.target.value)}>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      {hint ? (
        <div className="muted" style={{ marginTop: 6, fontSize: 12 }}>
          {hint}
        </div>
      ) : null}
    </div>
  );
}

// -------------------- main --------------------
export default function TiposDePalancasGraphs({ params }) {
  const [linked, setLinked] = useState(true);

  // Estado “principal” del graph
  const [p, setP] = useState(() => {
    // defaults razonables
    const tipo = "PAR";
    const d_P = 6;
    const d_R = 1;
    const geo = geometryFromArms(tipo, d_P, d_R);
    return {
      tipo,
      P: 122.666, // marcador
      R: 736,
      d_P,
      d_R,
      ...geo,
    };
  });

  // Mapeo de tipo por si la calculadora manda 1/2/3 en algún caso
  function normalizeTipo(raw) {
    const t = String(raw ?? "").toUpperCase();
    if (t === "PAR" || t === "APR" || t === "ARP") return t;

    // por si llega "1","2","3" desde algún nodo
    if (t === "1") return "PAR"; // A entre P y R
    if (t === "2") return "ARP"; // R entre A y P (habitualmente 2º género es A-R-P)
    if (t === "3") return "APR"; // P entre A y R
    return "PAR";
  }

  // 🔗 Seguir calculadora: lee P, R, d_P, d_R (ids del formulas.yaml)
  useEffect(() => {
    if (!linked) return;
    if (!params) return;

    setP((prev) => {
      const next = { ...prev };

      const tipo = normalizeTipo(pickParam(params, ["tipo"], prev.tipo));
      const P = pickParam(params, ["P"], prev.P);
      const R = pickParam(params, ["R"], prev.R);
      const d_P = pickParam(params, ["d_P"], prev.d_P);
      const d_R = pickParam(params, ["d_R"], prev.d_R);

      next.tipo = tipo;
      next.P = P;
      next.R = R;
      next.d_P = d_P;
      next.d_R = d_R;

      const safe_dP = Math.max(0, toNum(next.d_P, prev.d_P));
      const safe_dR = Math.max(0, toNum(next.d_R, prev.d_R));
      const geo = geometryFromArms(tipo, safe_dP, safe_dR);

      return { ...next, ...geo };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [linked, params]);

  // ↩️ Cargar desde calculadora (cuando estás en experimento)
  const loadFromCalculator = () => {
    if (!params) return;

    setP((prev) => {
      const next = { ...prev };

      const tipo = normalizeTipo(pickParam(params, ["tipo"], prev.tipo));
      const P = pickParam(params, ["P"], prev.P);
      const R = pickParam(params, ["R"], prev.R);
      const d_P = pickParam(params, ["d_P"], prev.d_P);
      const d_R = pickParam(params, ["d_R"], prev.d_R);

      next.tipo = tipo;
      next.P = P;
      next.R = R;
      next.d_P = d_P;
      next.d_R = d_R;

      const safe_dP = Math.max(0, toNum(next.d_P, prev.d_P));
      const safe_dR = Math.max(0, toNum(next.d_R, prev.d_R));
      const geo = geometryFromArms(tipo, safe_dP, safe_dR);

      return { ...next, ...geo };
    });
  };

  // En experimento permitimos tocar L/xA/xP/xR, pero forzamos el orden del tipo
  const updateGeometry = (patch) => {
    setP((prev) => {
      const tipo = normalizeTipo(prev.tipo);

      let L = Math.max(0.2, toNum(patch.L ?? prev.L, prev.L));
      let xA = clamp(toNum(patch.xA ?? prev.xA, prev.xA), 0, L);
      let xP = clamp(toNum(patch.xP ?? prev.xP, prev.xP), 0, L);
      let xR = clamp(toNum(patch.xR ?? prev.xR, prev.xR), 0, L);

      // Forzar orden según tipo para que el dibujo SIEMPRE refleje el significado
      const ordered = enforceOrder(tipo, { xA, xP, xR });
      xA = ordered.xA;
      xP = ordered.xP;
      xR = ordered.xR;

      // Derivar brazos desde posiciones (en experimento)
      const arms = armsFromGeometry({ xA, xP, xR });

      return { ...prev, ...patch, L, xA, xP, xR, ...arms };
    });
  };

  // Safe parse (siempre)
  const safeP = useMemo(() => {
    const tipo = normalizeTipo(p.tipo);

    const R = Math.max(0, toNum(p.R, 0));
    const d_R = Math.max(0, toNum(p.d_R, 0));
    const d_P = Math.max(0, toNum(p.d_P, 0));
    const P = Math.max(0, toNum(p.P, 0));

    // Si estamos en linked o si los brazos cambian, el dibujo se construye desde brazos para ser “situación real”
    // En experimento, el usuario puede tocar geometría, así que respetamos L/x*
    const L = Math.max(0.2, toNum(p.L, 1));
    const xA0 = clamp(toNum(p.xA, 0), 0, L);
    const xP0 = clamp(toNum(p.xP, 0), 0, L);
    const xR0 = clamp(toNum(p.xR, 0), 0, L);

    const ordered = enforceOrder(tipo, { xA: xA0, xP: xP0, xR: xR0 });
    const xA = ordered.xA;
    const xP = ordered.xP;
    const xR = ordered.xR;

    // brazos desde geometría (en experimento) o desde inputs (si no cuadra)
    const armsGeom = armsFromGeometry({ xA, xP, xR });
    const dP_eff = linked ? d_P : armsGeom.d_P;
    const dR_eff = linked ? d_R : armsGeom.d_R;

    const MP = P * dP_eff;
    const MR = R * dR_eff;
    const deltaM = MR - MP;

    const P_eq = dP_eff > 0 ? (R * dR_eff) / dP_eff : NaN;

    const tipoLabel =
      tipo === "PAR" ? "PAR (P - A - R)" : tipo === "APR" ? "APR (A - P - R)" : "ARP (A - R - P)";

    const tipoExplain =
      tipo === "PAR"
        ? "A está entre P y R (1er género)."
        : tipo === "APR"
        ? "P está entre A y R (3er género)."
        : "R está entre A y P (2º género).";

    return {
      tipo,
      tipoLabel,
      tipoExplain,
      P,
      R,
      d_P: dP_eff,
      d_R: dR_eff,
      L,
      xA,
      xP,
      xR,
      MP,
      MR,
      deltaM,
      P_eq,
    };
  }, [p, linked]);

  // --- SVG layout (centrado, triángulo pequeño, etiquetas sin pisarse) ---
  const viewW = 900;
  const viewH = 260;
  const pad = 70;
  const yBar = 135;

  const sx = (x) => pad + (x / safeP.L) * (viewW - 2 * pad);

  const xP_px = sx(safeP.xP);
  const xA_px = sx(safeP.xA);
  const xR_px = sx(safeP.xR);

  const closePR = Math.abs(xP_px - xR_px) < 90;
  const yLabelP = closePR ? 18 : 24;
  const yLabelR = closePR ? 44 : 24;

  const closePA = Math.abs(xP_px - xA_px) < 70;
  const closeRA = Math.abs(xR_px - xA_px) < 70;

  const yArrowTopP = closePA ? 58 : 52;
  const yArrowTopR = closeRA ? 58 : 52;

  const triW = 14;
  const triH = 22;

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {/* Card de controles */}
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Tipos de palancas</div>

        <div className="muted" style={{ marginTop: 6 }}>
          El tipo define el orden sobre la barra: <b>{safeP.tipoLabel}</b>. {safeP.tipoExplain}
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10 }}>
          <button
            type="button"
            className={`btn btn-sm ${linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(true)}
          >
            🔗 Seguir calculadora
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!linked ? "btn-primary" : "btn-light"}`}
            onClick={() => setLinked(false)}
          >
            🧪 Modo experimento (solo gráficas)
          </button>

          {!linked ? (
            <button type="button" className="btn btn-sm btn-light" onClick={loadFromCalculator}>
              ↩️ Cargar desde calculadora
            </button>
          ) : null}
        </div>

        {/* Inputs: en linked, bloqueados. En experimento, editables */}
        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <SelectInput
            label="Tipo (orden)"
            value={safeP.tipo}
            disabled={linked}
            onChange={(v) => {
              const tipo = normalizeTipo(v);
              setP((s) => {
                // al cambiar tipo en experimento, recoloca orden manteniendo coordenadas
                const ordered = enforceOrder(tipo, { xA: toNum(s.xA, 0), xP: toNum(s.xP, 0), xR: toNum(s.xR, 0) });
                return { ...s, tipo, ...ordered };
              });
            }}
            options={[
              { value: "PAR", label: "A entre P y R (P - A - R)" },
              { value: "APR", label: "P entre A y R (A - P - R)" },
              { value: "ARP", label: "R entre A y P (A - R - P)" },
            ]}
            hint="Refleja los 3 tipos clásicos por el elemento central."
          />

          <NumInput
            label="R (N) resistencia"
            value={safeP.R}
            disabled={linked}
            onChange={(v) => setP((s) => ({ ...s, R: v }))}
            hint="Fuerza de la carga. Si tienes masa: R = m·g."
          />
          <NumInput
            label="d_R (m) brazo resistencia"
            value={safeP.d_R}
            disabled={linked}
            onChange={(v) => {
              // en experimento, cambiar brazo reconstruye geometría realista
              const dR = Math.max(0, toNum(v, safeP.d_R));
              setP((s) => {
                const geo = geometryFromArms(normalizeTipo(s.tipo), toNum(s.d_P, safeP.d_P), dR);
                return { ...s, d_R: v, ...geo };
              });
            }}
            hint="Distancia del apoyo a la carga (perpendicular)."
          />
          <NumInput
            label="d_P (m) brazo potencia"
            value={safeP.d_P}
            disabled={linked}
            onChange={(v) => {
              const dP = Math.max(0, toNum(v, safeP.d_P));
              setP((s) => {
                const geo = geometryFromArms(normalizeTipo(s.tipo), dP, toNum(s.d_R, safeP.d_R));
                return { ...s, d_P: v, ...geo };
              });
            }}
            hint="Distancia del apoyo al punto donde aplicas P (perpendicular)."
          />
          <NumInput
            label="P (N) fuerza aplicada"
            value={safeP.P}
            disabled={linked}
            onChange={(v) => setP((s) => ({ ...s, P: v }))}
            hint="Dato o marcador. El equilibrio ideal es P*."
          />

          {/* Geometría real (solo en experimento) */}
          <NumInput
            label="L (m) longitud barra"
            value={safeP.L}
            disabled={linked}
            onChange={(v) => updateGeometry({ L: v })}
            hint="Barra de x=0 a x=L."
          />
          <NumInput
            label="xA (m) apoyo desde x=0"
            value={safeP.xA}
            disabled={linked}
            onChange={(v) => updateGeometry({ xA: v })}
            hint="Punto de apoyo (fulcro)."
          />
          <NumInput
            label="xP (m) punto de potencia"
            value={safeP.xP}
            disabled={linked}
            onChange={(v) => updateGeometry({ xP: v })}
            hint="Dónde aplicas la fuerza."
          />
          <NumInput
            label="xR (m) punto de carga"
            value={safeP.xR}
            disabled={linked}
            onChange={(v) => updateGeometry({ xR: v })}
            hint="Dónde actúa la carga (idealmente su CM)."
          />
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Equilibrio ideal: <b>P·d_P = R·d_R</b> ·· P* = <b>{fmt(safeP.P_eq, 6)} N</b>
        </div>
      </div>

      {/* Card del diagrama SVG */}
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Diagrama (barra + apoyo + fuerzas)</div>

        <div className="muted" style={{ marginTop: 6 }}>
          Brazos: d_P = <b>{fmt(safeP.d_P, 4)} m</b> ·· d_R = <b>{fmt(safeP.d_R, 4)} m</b>
        </div>

        <div style={{ width: "100%", marginTop: 10, display: "flex", justifyContent: "center" }}>
          <div style={{ width: "min(980px, 100%)" }}>
            <svg
              width="100%"
              height="260"
              viewBox={`0 0 ${viewW} ${viewH}`}
              preserveAspectRatio="xMidYMid meet"
              className="text-slate-800 dark:text-slate-100"
              aria-label="Diagrama de palanca"
            >
              {/* Barra */}
              <line
                x1={sx(0)}
                y1={yBar}
                x2={sx(safeP.L)}
                y2={yBar}
                stroke="currentColor"
                strokeWidth={7}
                strokeLinecap="round"
                opacity="0.95"
              />

              {/* Extremos */}
              <text x={sx(0)} y={yBar + 52} textAnchor="middle" fontSize="12" fill="currentColor" opacity="0.8">
                x=0
              </text>
              <text
                x={sx(safeP.L)}
                y={yBar + 52}
                textAnchor="middle"
                fontSize="12"
                fill="currentColor"
                opacity="0.8"
              >
                x=L
              </text>

              {/* Apoyo */}
              <polygon
                points={`${xA_px},${yBar } ${xA_px - triW},${yBar + triH} ${xA_px + triW},${yBar + triH}`}
                fill="orange"
                opacity="0.92"
              />
              <text x={xA_px} y={yBar + 38} textAnchor="middle" fontSize="13" fill="orange" opacity="0.95">
                A
              </text>

              {/* Flecha P */}
              <line x1={xP_px} y1={yArrowTopP} x2={xP_px} y2={yBar - 20} stroke="currentColor" strokeWidth="3" />
              <polygon
                points={`${xP_px - 7},${yBar - 20} ${xP_px + 7},${yBar - 20} ${xP_px},${yBar + 0}`}
                fill="currentColor"
              />
              <text x={xP_px} y={yLabelP} textAnchor="middle" fontSize="13" fill="currentColor">
                P = {fmt(safeP.P, 3)} N
              </text>

              {/* Flecha R */}
              <line x1={xR_px} y1={yArrowTopR} x2={xR_px} y2={yBar - 20} stroke="currentColor" strokeWidth="3" />
              <polygon
                points={`${xR_px - 7},${yBar - 20} ${xR_px + 7},${yBar - 20} ${xR_px},${yBar + 0}`}
                fill="currentColor"
              />
              <text x={xR_px} y={yLabelR} textAnchor="middle" fontSize="13" fill="currentColor">
                R = {fmt(safeP.R, 3)} N
              </text>

              {/* d_R (arriba) */}
              <line x1={xA_px} y1={210} x2={xR_px} y2={210} stroke="currentColor" strokeWidth="2" opacity="0.85" />
              <line x1={xA_px} y1={195} x2={xA_px} y2={210} stroke="currentColor" strokeWidth="2" opacity="0.9" />
              <line x1={xR_px} y1={195} x2={xR_px} y2={210} stroke="currentColor" strokeWidth="2" opacity="0.9" />
              <text x={(xA_px + xR_px) / 2} y={180} textAnchor="middle" fontSize="12" fill="currentColor" opacity="0.9">
                d_R = {fmt(safeP.d_R, 4)} m
              </text>

              {/* d_P (abajo) */}
              <line x1={xA_px} y1={210} x2={xP_px} y2={210} stroke="currentColor" strokeWidth="2" opacity="0.85" />
              <line x1={xA_px} y1={195} x2={xA_px} y2={210} stroke="currentColor" strokeWidth="2" opacity="0.9" />
              <line x1={xP_px} y1={195} x2={xP_px} y2={210} stroke="currentColor" strokeWidth="2" opacity="0.9" />
              <text x={(xA_px + xP_px) / 2} y={200} textAnchor="middle" fontSize="12" fill="currentColor" opacity="0.9">
                d_P = {fmt(safeP.d_P, 4)} m
              </text>
              <text x={(xR_px + xP_px) / 2} y={230} textAnchor="middle" fontSize="12" fill="currentColor" opacity="0.9">
                L = {fmt(safeP.L, 4)} m
              </text>
            </svg>
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Momentos: MP = P·d_P = <b>{fmt(safeP.MP, 4)} N·m</b> ·· MR = R·d_R = <b>{fmt(safeP.MR, 4)} N·m</b> ··
          MR - MP = <b>{fmt(safeP.deltaM, 4)} N·m</b>
        </div>
      </div>
    </div>
  );
}
