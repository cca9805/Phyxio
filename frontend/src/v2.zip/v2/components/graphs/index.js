export * as cinematica from "./cinematica/index.js";
export * as dinamica from "./dinamica/index.js";
