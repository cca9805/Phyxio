import { useEffect, useMemo, useRef, useState, useCallback } from "react";

function toNum(v) {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

function shallowEqualObj(a, b) {
  if (a === b) return true;
  if (!a || !b) return false;
  const ak = Object.keys(a);
  const bk = Object.keys(b);
  if (ak.length !== bk.length) return false;
  for (const k of ak) {
    if (a[k] !== b[k]) return false;
  }
  return true;
}

/**
 * schema: [{ key, label, unit?, step?, min?, max?, default?, aliases? }]
 *
 * - params: shared params desde calculadora
 * - mode:
 *   - "follow": por defecto, sigue a la calculadora
 *   - "experiment": el usuario toca sliders/inputs sin afectar calculadora
 */
export function useExperimentParams({ params, schema, modeDefault = "follow" }) {
  const [mode, setMode] = useState(modeDefault); // "follow" | "experiment"
  const [local, setLocal] = useState({}); // valores experimentales

  // Firma estable del schema (evita que arrays inline disparen recomputes infinitos)
  const schemaSig = useMemo(() => {
    const s = Array.isArray(schema) ? schema : [];
    // Solo lo que afecta al seeding (key/aliases/default)
    return JSON.stringify(
      s.map((x) => ({
        key: x?.key ?? "",
        aliases: Array.isArray(x?.aliases) ? x.aliases : [],
        def: x?.default ?? null,
      }))
    );
  }, [schema]);

  // seed inicial: a partir de params (con aliases) + defaults
  const seeded = useMemo(() => {
    const s = Array.isArray(schema) ? schema : [];
    const out = {};
    for (const item of s) {
      const keys = [item.key, ...(item.aliases || [])];
      let val = null;

      for (const k of keys) {
        val = toNum(params?.[k]);
        if (val !== null) break;
      }

      if (val === null) val = item.default ?? null;
      out[item.key] = val;
    }
    return out;
    // Importante: dependemos de schemaSig, no del array schema "por identidad"
  }, [params, schemaSig, schema]);

  // Evitar rebotes: solo setLocal si realmente cambia
  const lastAppliedSeedRef = useRef(null);

  // Si estamos en follow, reflejar params -> local automáticamente
  useEffect(() => {
    if (mode !== "follow") return;

    // Si local ya coincide con seeded, no tocar estado
    if (shallowEqualObj(local, seeded)) return;

    // Si ya aplicamos exactamente este seeded, evita rebote extra
    if (lastAppliedSeedRef.current && shallowEqualObj(lastAppliedSeedRef.current, seeded)) return;

    lastAppliedSeedRef.current = seeded;
    setLocal(seeded);
    // OJO: local NO debe estar en deps si no quieres loops.
    // Aquí hacemos la comparación con local actual, así que lo incluimos con cuidado:
    // Si prefieres, puedes quitar local de deps y leerlo con ref.
    // En esta versión lo dejamos en deps pero protegido por shallowEqual.
  }, [seeded, mode, local]);

  const setValue = useCallback((key, value) => {
    setLocal((prev) => {
      if (prev?.[key] === value) return prev;
      return { ...prev, [key]: value };
    });
  }, []);

  const resetToCalculator = useCallback(() => {
    lastAppliedSeedRef.current = seeded;
    setLocal(seeded);
    setMode("follow");
  }, [seeded]);

  const startExperiment = useCallback(() => {
    setMode("experiment");
  }, []);

  // params efectivos para el gráfico
  const effective =
    mode === "experiment" ? { ...seeded, ...local } : seeded;

  return {
    mode,
    setMode,
    startExperiment,
    resetToCalculator,
    local,
    setValue,
    effectiveParams: effective,
    seededFromCalculator: seeded,
  };
}
