import { useMemo, useState, useEffect, Suspense, lazy, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import yaml from "js-yaml";

import CalculatorV2 from "../components/CalculatorV2.jsx";
import { SvgBlock, loadSvgConfigByLeafRelPath } from "../components/graphs_shared/svg2/index.js";

// Importar el mapa (para icons/nombres en prerequisitos)
import phyxioMapYaml from "../map/phyxio-map.yaml?raw";

// ============================================
// GRÁFICOS - Barrel Exports
// ============================================

// Gráficos (contrato): el index exporta { graphs }
import { graphs as cinematicaGraphs } from "../components/graphs/cinematica/index.js";
import { graphs as dinamicaGraphs } from "../components/graphs/dinamica/index.js";

const MarkdownRenderer = lazy(() => import("../../components/MarkdownRenderer.jsx"));
const MarkdownLoading = () => <div className="p-3">Cargando contenido…</div>;

const [svg2Config, setSvg2Config] = useState(null);
const [svg2Err, setSvg2Err] = useState("");
const leafRelPath = meta?.ruta_relativa;

useEffect(() => {
  let alive = true;
  setSvg2Config(null);
  setSvg2Err("");

  if (!leafRelPath) return;

  loadSvgConfigByLeafRelPath(leafRelPath)
    .then((cfg) => { if (alive) setSvg2Config(cfg); })
    .catch(() => { if (alive) setSvg2Config(null); }); // silencioso: si no existe, no pasa nada

  return () => { alive = false; };
}, [leafRelPath]);

function TabButton({ active, onClick, children }) {
  return (
    <button
      className={`v2-tab ${active ? "active" : ""}`}
      onClick={onClick}
      type="button"
    >
      {children}
    </button>
  );
}

function normalizeDoc(doc) {
  if (!doc) return null;
  if (doc?.default && typeof doc.default === "object") return doc.default;
  return doc;
}

// ============================================
// GRÁFICOS - Resolver por motionId (sin ternarios gigantes)
// ============================================

// Alias de motionId (cuando el contenido real es el mismo)
const motionIdAliases = {
  "rodadura-cinematica-sin-deslizamiento": "rodadura-sin-deslizamiento",
  // si aparece el typo histórico:
  "diagramas-decuerpo-libre": "diagramas-cuerpo-libre",
};

// ============================================
// Packs (para dropdown): cuando un leaf tenga 2–3 vistas.
// Si un leaf no está en GRAPH_PACKS, caerá en GRAPH_COMPONENTS.
// ============================================

// ============================================
// DEFAULT_MOTION_PARAMS (LaTeX) – mantenido por compatibilidad.
// OJO: NO es estado numérico compartido.
// ============================================
const DEFAULT_MOTION_PARAMS = {
  dt: "\\Delta t",
  dx: "\\Delta x",
  dy: "\\Delta y",
  dz: "\\Delta z",
  dr: "\\Delta r",
  dtheta: "\\Delta \\theta",
  dphi: "\\Delta \\varphi",

  x0: "x_0",
  y0: "y_0",
  z0: "z_0",
  r0: "r_0",
  t0: "t_0",
  v0: "v_0",
  vx0: "v_{x0}",
  vy0: "v_{y0}",
  vz0: "v_{z0}",
  a0: "a_0",
  ax0: "a_{x0}",
  ay0: "a_{y0}",
  az0: "a_{z0}",

  t: "t",
  x: "x",
  y: "y",
  z: "z",
  r: "r",
  s: "s",
  v: "v",
  a: "a",
  vx: "v_x",
  vy: "v_y",
  vz: "v_z",
  ax: "a_x",
  ay: "a_y",
  az: "a_z",

  theta: "\\theta",
  phi: "\\varphi",

  g: "g",

  omega: "\\omega",
  alpha: "\\alpha",
  thetaAng: "\\theta",
  w: "\\omega",
  R: "R",

  F: "F",
  Fx: "F_x",
  Fy: "F_y",
  Fz: "F_z",

  m: "m",
};

export default function V2LeafTabs({
  meta,
  teoria,
  modelos,
  errores,
  ejemplos,
  formulasDoc,
  magnitudesDoc,
  aplicaciones,
  historia,
}) {
  const motionId = meta?.id;

  // ---------------------------
  // Normalización de docs
  // ---------------------------
  const normFormulasDoc = useMemo(() => {
    const doc = normalizeDoc(formulasDoc);
    if (!doc) return null;
    if (Array.isArray(doc)) return { formulas: doc };
    if (Array.isArray(doc?.formulas)) return doc;
    if (Array.isArray(doc?.default?.formulas)) return doc.default;
    return doc;
  }, [formulasDoc]);

  const normMagnitudesDoc = useMemo(() => {
    const doc = normalizeDoc(magnitudesDoc);
    if (!doc) return null;
    if (Array.isArray(doc)) return { magnitudes: doc };
    if (Array.isArray(doc?.magnitudes)) return doc;
    if (Array.isArray(doc?.default?.magnitudes)) return doc.default;
    return doc;
  }, [magnitudesDoc]);

  const hasFormulas =
    !!normFormulasDoc &&
    Array.isArray(normFormulasDoc.formulas) &&
    normFormulasDoc.formulas.length > 0;

  const hasLegend =
    !!normMagnitudesDoc &&
    Array.isArray(normMagnitudesDoc.magnitudes) &&
    normMagnitudesDoc.magnitudes.length > 0;

  const hasApps = (aplicaciones || "").trim().length > 0;
  const hasHistory = (historia || "").trim().length > 0;

  const motionKey = useMemo(() => {
    const raw = String(motionId ?? "").trim();
    const clean = raw.split("?")[0].split("#")[0];
    const last = clean.split("/").filter(Boolean).pop() || clean;
    return String(last).trim();
  }, [motionId]);

  const resolvedGraphId = motionIdAliases[motionKey] || motionKey;

  // ---------------------------
  // Gráficas: resolver vistas (desde contrato graphs[id][tipo])
  // ---------------------------
  const ALL_GRAPHS = useMemo(
    () => ({ ...cinematicaGraphs, ...dinamicaGraphs }),
    []
  );

  const graphEntry = ALL_GRAPHS[resolvedGraphId]; // { Coord, Svg, Dcl } | undefined

  const typeOrder = ["Coord", "Svg", "Dcl"];
  const typeLabel = {
    Coord: "Coordenadas",
    Svg: "Esquema (SVG)",
    Dcl: "Vectorial (DCL)",
  };

  const views = useMemo(() => {
    const out = [];

    // 1) SVG v2 (desde data_v2/.../graphs/svg.config.js)
    if (svg2Config) {
      out.push({
        id: "svg2",
        label: "Esquema (SVG)",
        Comp: (props) => <SvgBlock config={svg2Config} {...props} />,
      });
    }

    // 2) Sistema actual (graphs/cinematica + dinamica)
    if (!graphEntry) return [];
    return typeOrder
      .filter((t) => typeof graphEntry?.[t] === "function")
      .map((t) => ({
        id: t.toLowerCase(),         // "coord" | "svg" | "dcl"
        label: typeLabel[t] || t,
        Comp: graphEntry[t],
      }));
      return out;
  }, [graphEntry, svg2Config]);

  const defaultViewId = views[0]?.id || "coord";
  const [graphViewId, setGraphViewId] = useState(defaultViewId);

  useEffect(() => {
    const nextDefault = views[0]?.id || "coord";
      setGraphViewId(nextDefault);
  }, [resolvedGraphId, svg2Config, views.length]);


  const hasGraphs = views.length > 0;

  const hasPrerequisites = Array.isArray(meta?.prerequisitos) && meta.prerequisitos.length > 0;

  // Estado compartido con la calculadora y gráficos (valores numéricos)
  const [motionParams, setMotionParams] = useState({});
  const updateMotion = useCallback((patch) => {
    setMotionParams((p) => ({ ...p, ...patch }));
  }, []);

  const tabs = useMemo(() => {
    const base = [];

    if (hasPrerequisites) base.push({ id: "prerequisitos", label: "📋 Prerequisitos" });

    base.push(
      { id: "teoria", label: "📘 Teoría" },
      { id: "modelos", label: "🧩 Modelo y validez" },
      { id: "errores", label: "⚠️ Errores comunes" },
      { id: "ejemplos", label: "📝 Ejemplos" }
    );

    if (hasFormulas) base.splice(hasPrerequisites ? 2 : 1, 0, { id: "calculadora", label: "🧮 Calculadora" });
    if (hasLegend) base.splice(hasPrerequisites ? 3 : 2, 0, { id: "leyenda", label: "📚 Leyenda" });

    if (hasApps) base.push({ id: "aplicaciones", label: "🏗️ Aplicaciones" });
    if (hasHistory) base.push({ id: "historia", label: "📖 Historia" });
    base.push({ id: "graficas", label: "📈 Gráficas" });

    base.push({ id: "practica", label: "🎯 Práctica" });
    return base;
  }, [hasPrerequisites, hasFormulas, hasLegend, hasApps, hasHistory]);

  const [searchParams, setSearchParams] = useSearchParams();
  const validTabs = useMemo(() => tabs.map((t) => t.id), [tabs]);

  const [tab, setTab] = useState(() => {
    const fromUrl = searchParams.get("tab");
    return validTabs.includes(fromUrl) ? fromUrl : "teoria";
  });

  useEffect(() => {
    if (!validTabs.includes(tab)) setTab("teoria");
  }, [validTabs, tab]);

  useEffect(() => {
    const current = searchParams.get("tab");
    if (current !== tab) setSearchParams({ tab }, { replace: true });
  }, [tab, searchParams, setSearchParams]);

  const renderMarkdown = (src) => (
    <Suspense fallback={<MarkdownLoading />}>
      <MarkdownRenderer
        source={normalizeMath(src || "*(Sin contenido aún)*")}
        magnitudesDoc={magnitudesDoc}
      />
    </Suspense>
  );

  const legendMarkdown = useMemo(() => {
    if (!hasLegend) return "";
    const lines = [];
    lines.push("# Leyenda de variables\n");
    for (const m of normMagnitudesDoc.magnitudes) {
      const sym = m.symbol ? `$${m.symbol}$` : `\`${m.id}\``;
      const nombre = (m.nombre || m.name || m.id || "").replace(/_/g, " ").trim();
      const unidad = m.unidad_si || m.si_unit || "";
      const desc = m.descripcion || m.description || "";
      lines.push(
        `- **${sym}** — **${nombre || m.id}**${unidad ? ` (${unidad})` : ""}${desc ? `: ${desc}` : ""}`
      );
    }
    return lines.join("\n");
  }, [hasLegend, normMagnitudesDoc]);

  const graphProps = (p, onSharedParamsChange) => ({
    params: p,
    paramsFromCalculator: p,
    onSharedParamsChange,
  });

  return (
    <div className="v2-leaf">
      <div className="v2-header">
        <h2 className="v2-title">{meta?.nombre || "Tema"}</h2>
        {meta?.descripcion_corta ? <p className="v2-subtitle">{meta.descripcion_corta}</p> : null}

        <div className="v2-chips">
          {Array.isArray(meta?.niveles) &&
            meta.niveles.map((n) => (
              <span key={n} className="v2-chip">
                {n}
              </span>
            ))}
          {meta?.dificultad != null && (
            <span className="v2-chip">Dificultad {meta.dificultad}/5</span>
          )}
          {meta?.tiempo_estimado_min != null && (
            <span className="v2-chip">{meta.tiempo_estimado_min} min</span>
          )}
        </div>
      </div>

      <div className="v2-tabs">
        {tabs.map((t) => (
          <TabButton key={t.id} active={tab === t.id} onClick={() => setTab(t.id)}>
            {t.label}
          </TabButton>
        ))}
      </div>

      <div className="v2-panel">
        {tab === "prerequisitos" && hasPrerequisites && (
          <PrerequisitesTab prerequisites={meta.prerequisitos} />
        )}

        {tab === "teoria" && renderMarkdown(teoria)}
        {tab === "modelos" && renderMarkdown(modelos)}
        {tab === "errores" && renderMarkdown(errores)}
        {tab === "ejemplos" && renderMarkdown(ejemplos)}

        {tab === "leyenda" && hasLegend && renderMarkdown(legendMarkdown)}

        {tab === "calculadora" && hasFormulas && (
          <CalculatorV2
            formulasDoc={normFormulasDoc}
            magnitudesDoc={normMagnitudesDoc}
            sharedParams={hasGraphs ? motionParams : undefined}
            onSharedParamsChange={hasGraphs ? updateMotion : undefined}
          />
        )}

        {tab === "aplicaciones" && hasApps && renderMarkdown(aplicaciones)}
        {tab === "historia" && hasHistory && renderMarkdown(historia)}
        {tab === "practica" && <PracticePlaceholder />}

        {tab === "graficas" && (() => {
          if (!hasGraphs) return <GraphicsPlaceholder />;

          const activeView = views.find(v => v.id === graphViewId) || views[0];
          const ActiveGraph = activeView?.Comp;

          return (
            <div style={{ display: "grid", gap: 12 }}>
              {views.length > 1 && (
                <div
                  className="v2-card"
                  style={{ display: "flex", alignItems: "center", gap: 12 }}
                >
                  <div style={{ fontWeight: 600 }}>Vista</div>
                  <select
                    className="form-control"
                    value={graphViewId}
                    onChange={(e) => setGraphViewId(e.target.value)}
                    style={{ maxWidth: 340 }}
                  >
                    {views.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.label}
                      </option>
                    ))}
                  </select>
                  <div className="muted" style={{ fontSize: 12 }}>
                    {resolvedGraphId}
                  </div>
                </div>
              )}

              {ActiveGraph ? (
                <ActiveGraph {...graphProps(motionParams, updateMotion)} />
              ) : (
                <GraphicsPlaceholder />
              )}
            </div>
          );
        })()}
      </div>
    </div>
  );
}

function PracticePlaceholder() {
  return (
    <div className="v2-card">
      <div className="v2-card-title">Práctica (próximamente)</div>
      <p className="muted">
        Aquí irán ejercicios interactivos, autocorrección y generación automática.
      </p>
    </div>
  );
}

function GraphicsPlaceholder() {
  return (
    <div className="v2-card">
      <div className="v2-card-title">📈 Gráficas no disponibles</div>
      <p className="muted">
        Este tema aún no dispone de gráficas interactivas. Estamos trabajando para añadirlas próximamente.
      </p>
      <p className="muted" style={{ marginTop: 10 }}>
        Mientras tanto, puedes consultar la teoría, ejemplos y calculadora para comprender mejor el contenido.
      </p>
    </div>
  );
}

function PrerequisitesTab({ prerequisites }) {
  const mapData = useMemo(() => {
    try {
      return yaml.load(phyxioMapYaml);
    } catch (e) {
      console.error("[PrerequisitesTab] Error cargando mapa:", e);
      return null;
    }
  }, []);

  const findNodeByPath = (node, targetPath) => {
    if (!node) return null;
    if (node.ruta_relativa === targetPath) return node;
    if (node.children && Array.isArray(node.children)) {
      for (const child of node.children) {
        const found = findNodeByPath(child, targetPath);
        if (found) return found;
      }
    }
    return null;
  };

  const getPrereqIcon = (prereqPath) => {
    if (!mapData?.root) return "📚";
    const node = findNodeByPath(mapData.root, prereqPath);
    return node?.icon || "📚";
  };

  const getPrereqName = (prereqPath) => {
    if (!mapData?.root) {
      const parts = prereqPath.split("/");
      return parts[parts.length - 1]
        .split("-")
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(" ");
    }
    const node = findNodeByPath(mapData.root, prereqPath);
    return node?.nombre || prereqPath.split("/").pop().replace(/-/g, " ");
  };

  if (!Array.isArray(prerequisites) || prerequisites.length === 0) {
    return (
      <div className="v2-card">
        <div className="v2-card-title">📋 Conocimientos previos</div>
        <p className="muted">No hay prerequisitos definidos para este tema.</p>
      </div>
    );
  }

  return (
    <div className="v2-card">
      <div className="v2-card-title">📋 Conocimientos previos recomendados</div>

      <p className="muted" style={{ marginBottom: 20 }}>
        Para aprovechar al máximo este tema, es importante que tengas una base sólida en los siguientes conceptos.
        Si no estás familiarizado con alguno de ellos, te recomendamos revisarlos antes de continuar.
      </p>

      <div style={{ display: "grid", gap: 12 }}>
        {prerequisites.map((prereq, index) => {
          const icon = getPrereqIcon(prereq);
          const topicName = getPrereqName(prereq);

          return (
            <a
              key={index}
              href={`#/v2/${prereq}`}
              className="v2-card"
              style={{
                textDecoration: "none",
                color: "inherit",
                transition: "all 0.2s ease",
                cursor: "pointer",
                border: "2px solid #e5e7eb",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = "#6366f1";
                e.currentTarget.style.transform = "translateY(-2px)";
                e.currentTarget.style.boxShadow = "0 4px 6px rgba(0,0,0,0.1)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = "#e5e7eb";
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = "none";
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span style={{ fontSize: "24px" }}>{icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, marginBottom: 4 }}>{topicName}</div>
                  <div className="muted" style={{ fontSize: "0.9em" }}>
                    {prereq}
                  </div>
                </div>
                <span style={{ fontSize: "20px", color: "#6366f1" }}>→</span>
              </div>
            </a>
          );
        })}
      </div>
    </div>
  );
}

function normalizeMath(md) {
  if (!md) return "";
  md = md.replace(/\\\[(.+?)\\\]/gs, (_, expr) => `$${expr.trim()}$`);
  md = md.replace(/\\\((.+?)\\\)/gs, (_, expr) => `$${expr.trim()}$`);
  md = md.replace(
    /\[\s*([^\[\]\n]*?(\\frac|\\Delta|\\cdot|\\sqrt|=)[^\[\]\n]*?)\s*\]/g,
    (_, expr) => `$${expr.trim()}$`
  );
  return md;
}
