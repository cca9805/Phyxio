import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function toNum(v, fb) {
  if (v == null || v === "") return fb;
  if (typeof v === "number") return Number.isFinite(v) ? v : fb;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fb;
}
function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}
const deg2rad = (d) => (d * Math.PI) / 180;

function torque({ r, F, thetaDeg }) {
  return r * F * Math.sin(deg2rad(thetaDeg));
}

/**
 * Equilibrio rotacional (condición de sumatoria de momentos):
 *   Στ = 0
 *
 * Modelo didáctico:
 *   - τ1 = r1·F1·sin(θ1)  (sentido +)
 *   - τ2 = r2·F2·sin(θ2)  (sentido -)
 *   - τnet = τ1 - τ2
 *
 * Se grafica τnet vs θ2 (0°..180°), y se marca el punto actual.
 */
function buildSeries({ r1, F1, theta1, r2, F2 }, stepDeg = 2) {
  const out = [];
  const tau1 = torque({ r: r1, F: F1, thetaDeg: theta1 });
  for (let th2 = 0; th2 <= 180 + 1e-9; th2 += stepDeg) {
    const tau2 = torque({ r: r2, F: F2, thetaDeg: th2 });
    out.push({
      th2,
      tau1,
      tau2,
      tauNet: tau1 - tau2,
    });
  }
  return out;
}

export default function CondicionSumatoriaMomentosGraphsCoord() {
  // valores “agradables” para clase
  const [r1, setR1] = useState(0.35);
  const [F1, setF1] = useState(30);
  const [theta1, setTheta1] = useState(90);

  const [r2, setR2] = useState(0.25);
  const [F2, setF2] = useState(35);
  const [theta2, setTheta2] = useState(60);

  const safe = useMemo(() => {
    const _r1 = clamp(toNum(r1, 0.35), 0, 1e6);
    const _F1 = clamp(toNum(F1, 30), 0, 1e6);
    const _t1 = clamp(toNum(theta1, 90), 0, 180);

    const _r2 = clamp(toNum(r2, 0.25), 0, 1e6);
    const _F2 = clamp(toNum(F2, 35), 0, 1e6);
    const _t2 = clamp(toNum(theta2, 60), 0, 180);

    return { r1: _r1, F1: _F1, theta1: _t1, r2: _r2, F2: _F2, theta2: _t2 };
  }, [r1, F1, theta1, r2, F2, theta2]);

  const inst = useMemo(() => {
    const tau1 = torque({ r: safe.r1, F: safe.F1, thetaDeg: safe.theta1 });
    const tau2 = torque({ r: safe.r2, F: safe.F2, thetaDeg: safe.theta2 });
    const tauNet = tau1 - tau2;

    const s2 = Math.sin(deg2rad(safe.theta2));
    const F2eq = s2 !== 0 ? tau1 / (safe.r2 * s2) : Infinity;

    return { tau1, tau2, tauNet, F2eq };
  }, [safe.r1, safe.F1, safe.theta1, safe.r2, safe.F2, safe.theta2]);

  const data = useMemo(
    () => buildSeries({ r1: safe.r1, F1: safe.F1, theta1: safe.theta1, r2: safe.r2, F2: safe.F2 }, 2),
    [safe.r1, safe.F1, safe.theta1, safe.r2, safe.F2]
  );

  // dato exacto para el punto marcado
  const dot = useMemo(() => {
    const tau2 = torque({ r: safe.r2, F: safe.F2, thetaDeg: safe.theta2 });
    return { th2: safe.theta2, tauNet: inst.tau1 - tau2 };
  }, [safe.r2, safe.F2, safe.theta2, inst.tau1]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Equilibrio rotacional (Coord): Στ = 0</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Dos torques: τ1 (positivo) y τ2 (negativo). El equilibrio se cumple cuando τnet = τ1 − τ2 = 0.
        </div>

        <div className="v2-grid-fill-inputs" style={{ marginTop: 10 }}>
          <div className="v2-card">
            <div className="v2-card-title">r1 (m)</div>
            <input className="form-control" inputMode="decimal" value={r1} onChange={(e) => setR1(e.target.value)} />
          </div>
          <div className="v2-card">
            <div className="v2-card-title">F1 (N)</div>
            <input className="form-control" inputMode="decimal" value={F1} onChange={(e) => setF1(e.target.value)} />
          </div>
          <div className="v2-card">
            <div className="v2-card-title">θ1 (°)</div>
            <input
              className="form-control"
              inputMode="decimal"
              value={theta1}
              onChange={(e) => setTheta1(e.target.value)}
            />
          </div>

          <div className="v2-card">
            <div className="v2-card-title">r2 (m)</div>
            <input className="form-control" inputMode="decimal" value={r2} onChange={(e) => setR2(e.target.value)} />
          </div>
          <div className="v2-card">
            <div className="v2-card-title">F2 (N)</div>
            <input className="form-control" inputMode="decimal" value={F2} onChange={(e) => setF2(e.target.value)} />
          </div>
          <div className="v2-card">
            <div className="v2-card-title">θ2 (°) (variable)</div>
            <input
              className="form-control"
              inputMode="decimal"
              value={theta2}
              onChange={(e) => setTheta2(e.target.value)}
            />
          </div>
        </div>

        <div className="v2-grid-2" style={{ marginTop: 10, gap: 10 }}>
          <div className="v2-card" style={{ padding: 12 }}>
            <div className="v2-card-title">Valores en el punto actual</div>
            <div className="muted" style={{ marginTop: 6 }}>
              τ1 = {fmt(inst.tau1, 4)} N·m
              <br />
              τ2 = {fmt(inst.tau2, 4)} N·m
              <br />
              τnet = {fmt(inst.tauNet, 4)} N·m
            </div>
          </div>

          <div className="v2-card" style={{ padding: 12 }}>
            <div className="v2-card-title">F2 para equilibrio en θ2</div>
            <div className="muted" style={{ marginTop: 6 }}>
              Para Στ = 0: F2 = τ1 / (r2·sinθ2)
              <br />
              F2(eq) = {Number.isFinite(inst.F2eq) ? `${fmt(inst.F2eq, 4)} N` : "∞ (sinθ2 = 0)"}
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">τnet(θ2)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Recorre θ2 para ver dónde cruza por 0 (equilibrio). La marca indica el θ2 actual.
        </div>

        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data} margin={{ top: 8, right: 10, left: 6, bottom: 8 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="th2"
                tickFormatter={(v) => fmt(v, 0)}
                label={{ value: "θ2 (°)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 3)}
                label={{ value: "τ (N·m)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(val) => fmt(val, 6)}
                labelFormatter={(x) => `θ2 = ${fmt(x, 1)}°`}
              />
              <Line type="monotone" dataKey="tauNet" dot={false} name="τnet = τ1 − τ2" />
              <Line type="monotone" dataKey="tau1" dot={false} name="τ1 (constante)" />
              <Line type="monotone" dataKey="tau2" dot={false} name="τ2" />
              <ReferenceDot x={dot.th2} y={dot.tauNet} r={5} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          Nota: aquí usamos |τ| = r·F·sin(θ), donde θ es el ángulo entre r y F.
        </div>
      </div>
    </div>
  );
}
