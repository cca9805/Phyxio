import { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function toNum(v, d) {
  if (v == null || v === "") return d;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : d;
}
function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function seriesHooke({ k, xMax = 0.4, step = 0.01 }) {
  const out = [];
  for (let x = -xMax; x <= xMax + 1e-12; x += step) {
    const F = -k * x;          // F = -k x
    const U = 0.5 * k * x * x; // U = 1/2 k x^2
    out.push({ x, F, U });
  }
  return out;
}

export default function LeyDeHookeGraphsCoord() {
  const [k, setK] = useState(80);        // N/m
  const [x, setX] = useState(0.12);      // m
  const [mode, setMode] = useState("F"); // F | U

  const [showGrid, setShowGrid] = useState(true);
  const [showPoint, setShowPoint] = useState(true);

  const safe = useMemo(() => {
    const kk = clamp(toNum(k, 80), 0.1, 2000);
    const xx = clamp(toNum(x, 0.12), -0.4, 0.4);
    return { k: kk, x: xx };
  }, [k, x]);

  const data = useMemo(() => seriesHooke({ k: safe.k, xMax: 0.4, step: 0.01 }), [safe.k]);

  const Fnow = -safe.k * safe.x;
  const Unow = 0.5 * safe.k * safe.x * safe.x;

  return (
    <div className="v2-graphs">
      {/* Card azul - Configuración principal */}
      <div className="v2-card" style={{ background: 'rgba(59, 130, 246, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div className="v2-grid-fill-inputs">
          <div className="v2-input-group">
            <label>🔧 k (N/m)</label>
            <input className="form-control" inputMode="decimal" value={k} onChange={(e) => setK(e.target.value)} />
          </div>

          <div className="v2-input-group">
            <label>📏 x (m)</label>
            <input className="form-control" inputMode="decimal" value={x} onChange={(e) => setX(e.target.value)} />
          </div>

          <div className="v2-input-group">
            <label>📊 Gráfico</label>
            <select className="form-control" value={mode} onChange={(e) => setMode(e.target.value)}>
              <option value="F">F(x)</option>
              <option value="U">U(x)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Card verde - Controles de visualización */}
      <div className="v2-card" style={{ background: 'rgba(34, 197, 94, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div style={{ 
          display: "flex", 
          gap: 18, 
          alignItems: "center", 
          flexWrap: "wrap",
          justifyContent: "center"
        }}>
          <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
          
          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showGrid"
              checked={showGrid}
              onChange={(e) => setShowGrid(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showGrid">Cuadrícula</label>
          </div>

          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showPoint"
              checked={showPoint}
              onChange={(e) => setShowPoint(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showPoint">Punto de referencia</label>
          </div>
        </div>
      </div>

      <div className="v2-card">
        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              {showGrid && <CartesianGrid />}
              <XAxis
                dataKey="x"
                type="number"
                domain={[-0.4, 0.4]}
                tickFormatter={(v) => fmt(v, 2)}
                label={{ value: "x (m)", position: "insideBottom", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 2)}
                domain={mode === "F" ? ["auto", "auto"] : [0, "auto"]}
                label={{ value: mode === "F" ? "F (N)" : "U (J)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(v, name) => [fmt(v, 6), name]}
                labelFormatter={(lab) => `x = ${fmt(lab, 4)} m`}
              />
              {mode === "F" ? (
                <Line dataKey="F" dot={false} name="F = −k·x" />
              ) : (
                <Line dataKey="U" dot={false} name="U = ½ k x²" />
              )}
              {showPoint && <ReferenceDot x={safe.x} y={mode === "F" ? Fnow : Unow} r={5} />}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
