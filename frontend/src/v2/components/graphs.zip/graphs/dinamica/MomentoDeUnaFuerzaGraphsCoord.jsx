import React, { useMemo, useState } from "react";
import { useExperimentParams } from "@/v2/components/graphs_shared/experiment/useExperimentParams";
import ExperimentPanel from "@/v2/components/graphs_shared/experiment/ExperimentPanel";
import 'katex/dist/katex.min.css';
import { InlineMath } from 'react-katex';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

function fmt(n, d = 2) {
  return Number.isFinite(n) ? n.toFixed(d) : "";
}

function niceDomain(values) {
  if (!values.length) return { min: 0, max: 1 };
  let min = Math.min(...values);
  let max = Math.max(...values);
  if (!Number.isFinite(min) || !Number.isFinite(max)) return { min: 0, max: 1 };
  if (min === max) {
    const dd = Math.abs(min) || 1;
    min -= dd;
    max += dd;
  }
  const pad = (max - min) * 0.12;
  return { min: min - pad, max: max + pad };
}

function Plot({ label, points, marks, xLabel, yLabel, height = 320 }) {
  // Encontrar el punto actual para el ReferenceDot
  const currentPoint = marks?.find(m => m.label === 'máx') || marks?.[0];
  
  return (
    <div className="mt-4">
      <div className="text-sm font-semibold mb-2">{label}</div>
      <div style={{ width: '100%', height }}>
        <ResponsiveContainer>
          <LineChart data={points}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis 
              dataKey="x" 
              label={{ value: xLabel, position: 'insideBottom', offset: -5, fontSize: 12 }}
              tick={{ fontSize: 10 }}
            />
            <YAxis 
              label={{ value: yLabel, angle: -90, position: 'insideLeft', fontSize: 12 }}
              tick={{ fontSize: 10 }}
            />
            <Tooltip 
              formatter={(value) => [value, yLabel]}
              labelFormatter={(value) => `${xLabel}: ${value}`}
            />
            <Line 
              type="monotone" 
              dataKey="y" 
              stroke="#3b82f6" 
              strokeWidth={1.5} 
              dot={false} 
              activeDot={{ r: 4 }}
            />
            {currentPoint && (
              <ReferenceDot 
                x={currentPoint.x} 
                y={currentPoint.y} 
                r={4} 
                fill="#ef4444" 
                stroke="#fff" 
                strokeWidth={1} 
              />
            )}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default function MomentoDeUnaFuerzaGraphsCoord({ title, params, onSharedParamsChange }) {
  // Variables en data/formulas: tau, F, r, theta (rad)
  // Aquí usamos grados para que sea más "visual", y al aplicar al cálculo convertimos a rad.
  const schema = [
    { key: "r", label: "Brazo (r)", unit: "m", step: 0.01, default: 0.5 },
    { key: "F", label: "Fuerza (F)", unit: "N", step: 0.5, default: 50 },
    { key: "thetaDeg", label: "Ángulo (θ)", unit: "°", step: 1, default: 60, aliases: ["theta", "θ"] },
  ];

  const exp = useExperimentParams({ params, schema });

  const r = Number.isFinite(exp.effectiveParams?.r) ? exp.effectiveParams.r : 0.5;
  const F = Number.isFinite(exp.effectiveParams?.F) ? exp.effectiveParams.F : 50;
  const thetaDeg = Number.isFinite(exp.effectiveParams?.thetaDeg) ? exp.effectiveParams.thetaDeg : 60;
  const thetaRad = (thetaDeg * Math.PI) / 180;

  const [showMaxMark, setShowMaxMark] = useState(true);
  const [showCurve, setShowCurve] = useState(true);

  const { points, marks, tauAtTheta, tauMax } = useMemo(() => {
    const points = [];
    // 0..180°
    for (let d = 0; d <= 180; d++) {
      const t = r * F * Math.sin((d * Math.PI) / 180);
      points.push({ x: d, y: t });
    }

    const baseMarks = [0, 30, 60, 90, 120, 150, 180].map((d) => {
      const t = r * F * Math.sin((d * Math.PI) / 180);
      const label = d === 90 ? "máx" : `${d}°`;
      return { x: d, y: t, label };
    });

    const tauAtTheta = r * F * Math.sin(thetaRad);
    const tauMax = r * F;

    return { points, marks: baseMarks, tauAtTheta, tauMax };
  }, [r, F, thetaRad]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">{title || "Momento de una fuerza"}</div>

        <div className="muted" style={{ marginTop: 6 }}>
          Gráfico de coordenadas: cómo varía el momento con el ángulo de aplicación de la fuerza.
          Fórmula: <b>τ = r·F·sinθ</b>.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>⚙️ Parámetros:</span>
            
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#fbbf24" }}>📏</span> r (m)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={r}
                  onChange={(e) => exp.setValue('r', parseFloat(e.target.value) || 0)}
                />
              </label>

              <span style={{ color: "#34d399" }}>🦾</span> F (N)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={F}
                  onChange={(e) => exp.setValue('F', parseFloat(e.target.value) || 0)}
                />
              </label>

              <span style={{ color: "#f87171" }}>📐</span> θ (°)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="numeric"
                  value={thetaDeg}
                  onChange={(e) => exp.setValue('thetaDeg', parseFloat(e.target.value) || 0)}
                />
              </label>
            </div>
          </div>

          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showCurve"
                checked={showCurve}
                onChange={(e) => setShowCurve(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showCurve">Curva τ(θ)</label>
            </div>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showMaxMark"
                checked={showMaxMark}
                onChange={(e) => setShowMaxMark(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showMaxMark">Marcar máximo</label>
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="muted" style={{ marginBottom: 10 }}>
          τ(θ) = <b>{fmt(tauAtTheta, 3)}</b> N·m · τ<sub>máx</sub> = <b>{fmt(tauMax, 3)}</b> N·m
        </div>

        <div style={{ width: "100%", height: 360 }}>
          <ResponsiveContainer>
            <LineChart data={points} margin={{ top: 10, right: 18, left: 8, bottom: 10 }}>
              <CartesianGrid strokeDasharray="4 4" />
              <XAxis
                dataKey="x"
                type="number"
                domain={[0, 180]}
                tickFormatter={(v) => `${v}°`}
                label={{ value: "θ (°)", position: "insideBottomRight", offset: -5 }}
              />
              <YAxis
                tickFormatter={(v) => fmt(v, 0)}
                label={{ value: "τ (N·m)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(value, name) => [fmt(value, 3), name]}
                labelFormatter={(label) => `θ = ${fmt(label, 0)}°`}
              />

              {showCurve && (
                <Line
                  type="monotone"
                  dataKey="y"
                  name="τ = rF·sinθ"
                  strokeWidth={3}
                  dot={false}
                />
              )}

              {showMaxMark && (
                <ReferenceDot x={90} y={tauMax} r={5} isFront />
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="mt-4 rounded-xl bg-black/5 p-3 text-xs opacity-80">
          <div className="font-semibold mb-1">Lectura rápida</div>
          <ul className="list-disc pl-5 space-y-1">
            <li>
              Si duplicas <span className="font-mono">F</span> o <span className="font-mono">r</span>, el momento se duplica.
            </li>
            <li>
              Con <span className="font-mono">θ=0°</span> o <span className="font-mono">180°</span>, <InlineMath math="\\sin\\theta=0"/> y no hay giro.
            </li>
            <li>
              El máximo se da en <span className="font-mono">90°</span>: <InlineMath math="\\tau_{\\max}=rF"/>.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
