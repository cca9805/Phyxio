import React, { useMemo, useState } from "react";

const CONTEXTS = [
  { value: "earth", label: "🌍 Tierra", g: 9.81 },
  { value: "moon", label: "🌙 Luna", g: 1.62 },
  { value: "mars", label: "🔴 Marte", g: 3.71 },
  { value: "jupiter", label: "🪐 Júpiter", g: 24.79 },
  { value: "elevator", label: "🏢 Ascensor", g: 9.81 },
];

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function num(v, fb) {
  if (v == null || v === "") return fb;
  const n = typeof v === "number" ? v : Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fb;
}

export default function PesoEnDiferentesContextosGraphsDcl() {
  const [context, setContext] = useState("earth");
  const [m, setM] = useState(10);
  const [a, setA] = useState(0);
  const [showLabels, setShowLabels] = useState(true);
  const [showAxes, setShowAxes] = useState(false);

  const ctx = useMemo(() => CONTEXTS.find((c) => c.value === context) ?? CONTEXTS[0], [context]);

  const mm = useMemo(() => clamp(num(m, 10), 0.1, 200), [m]);
  const aa = useMemo(() => clamp(num(a, 0), -9.5, 9.5), [a]);

  const gEff = ctx.value === "elevator" ? ctx.g + aa : ctx.g;
  const W = mm * ctx.g;
  const N = mm * gEff;

  // Escala para flechas
  const Fmax = Math.max(W, Math.abs(N), 1) * 1.2;

  const C = {
    bg: "#b8c5ffff",
    ink: "#0f172a",
    muted: "#64748b",
    mg: "#dc2626",
    N: "#60a5fa",
    axis: "#6366f1",
    stroke: "#e2e8f0",
  };

  const Arrow = ({ x1, y1, x2, y2, color, w = 10 }) => {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const L = Math.hypot(dx, dy) || 1;
    const ux = dx / L;
    const uy = dy / L;
    const head = 16;

    const hx = x2;
    const hy = y2;
    const leftx = hx - ux * head - uy * (head * 0.6);
    const lefty = hy - uy * head + ux * (head * 0.6);
    const rightx = hx - ux * head + uy * (head * 0.6);
    const righty = hy - uy * head - ux * (head * 0.6);

    return (
      <g>
        <line x1={x1} y1={y1} x2={hx} y2={hy} stroke={color} strokeWidth={w} strokeLinecap="round" />
        <polygon points={`${hx},${hy} ${leftx},${lefty} ${rightx},${righty}`} fill={color} opacity="0.95" />
      </g>
    );
  };

  const fmt = (x) => {
    const n = Number(x);
    if (!Number.isFinite(n)) return "—";
    return n.toFixed(2).replace(".", ",");
  };

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Peso en diferentes contextos (DCL)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          DCL vertical: <b>W = m·g</b> (siempre hacia abajo) y lectura de báscula <b>N</b> (cambia con aceleración).
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>🌍 Contexto:</span>
              <select
                className="form-control"
                style={{ width: 200 }}
                value={context}
                onChange={(e) => setContext(e.target.value)}
              >
                {CONTEXTS.map((c) => (
                  <option key={c.value} value={c.value}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#fbbf24" }}>⚖️</span> m (kg)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={m}
                  onChange={(e) => setM(e.target.value)}
                />
              </label>
              
              {context === "elevator" && (
                <>
                  <span style={{ color: "#f87171" }}>🚀</span> a (m/s²)
                  <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                    <input
                      className="form-control"
                      style={{ width: 80 }}
                      inputMode="decimal"
                      value={a}
                      onChange={(e) => setA(e.target.value)}
                    />
                  </label>
                </>
              )}
            </div>
          </div>

          {/* Segunda fila: Controles de visualización */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
            
            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showLabels"
                checked={showLabels}
                onChange={(e) => setShowLabels(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showLabels">Etiquetas</label>
            </div>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showAxes"
                checked={showAxes}
                onChange={(e) => setShowAxes(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showAxes">Ejes</label>
            </div>
          </div>
        </div>

        <div className="muted" style={{ marginTop: 10 }}>
          g = <b>{fmt(ctx.g)} m/s²</b> · W = <b>{fmt(W)} N</b> · N = <b>{fmt(N)} N</b>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12, overflow: "hidden" }}>
        <div className="v2-card-title">Gráfico</div>
        
        <svg width="100%" height="370" viewBox="0 0 860 370" preserveAspectRatio="xMidYMid meet">
          <rect x="0" y="0" width="860" height="370" fill={C.bg} />

          {/* Panel info */}
          <rect x="44" y="64" width="312" height="138" rx="18" fill="white" opacity="0.92" stroke={C.stroke} strokeWidth="2" />
          <text x="64" y="88" fontSize="16" fontWeight="900" fill={C.ink}>
            Datos
          </text>
          <text x="64" y="116" fontSize="14" fill={C.muted}>
            g = {fmt(ctx.g)} m/s²
          </text>
          <text x="64" y="140" fontSize="14" fill={C.muted}>
            m = {fmt(mm)} kg
          </text>
          <text x="64" y="164" fontSize="14" fill={C.muted}>
            W = m·g = {fmt(W)} N
          </text>
          <text x="64" y="188" fontSize="14" fill={C.N}>
            N = m·(g+a) = {fmt(N)} N
          </text>

          {/* Ejes opcionales */}
          {showAxes && (
            <g opacity="0.95">
              <line x1="430" y1="230" x2="720" y2="230" stroke={C.axis} strokeWidth="4" />
              <line x1="430" y1="230" x2="430" y2="80" stroke={C.axis} strokeWidth="4" />
              <text x="730" y="235" fontSize="14" fill={C.muted}>
                x
              </text>
              <text x="410" y="90" fontSize="14" fill={C.muted}>
                y
              </text>
            </g>
          )}

          {/* "cuerpo" punto (DCL) */}
          {(() => {
            const cx = 570;
            const cy = 210;
            const arrowLen = 160;

            const wLen = arrowLen * clamp(W / Fmax, 0, 1);
            const nLen = arrowLen * clamp(N / Fmax, 0, 1);

            return (
              <g>
                <circle cx={cx} cy={cy} r="12" fill={C.ink} opacity="0.85" />
                <line x1={cx - 18} y1={cy} x2={cx + 18} y2={cy} stroke={C.ink} strokeWidth="2" opacity="0.25" />
                <line x1={cx} y1={cy - 18} x2={cx} y2={cy + 18} stroke={C.ink} strokeWidth="2" opacity="0.25" />

                {/* N arriba */}
                <Arrow x1={cx} y1={cy} x2={cx} y2={cy - nLen} color={C.N} w={10} />
                {showLabels && (
                  <text x={cx + 16} y={cy - nLen - 2} fontSize="16" fontWeight="900" fill={C.N}>
                    N
                  </text>
                )}

                {/* W abajo */}
                <Arrow x1={cx} y1={cy} x2={cx} y2={cy + wLen} color={C.mg} w={10} />
                {showLabels && (
                  <text x={cx + 16} y={cy + wLen + 18} fontSize="16" fontWeight="900" fill={C.mg}>
                    W = mg
                  </text>
                )}

                {/* Nota de contexto */}
                <text x="100" y="320" fontSize="12" fill={C.muted}>
                  {context === "elevator" ? "Ascensor: si a>0, N>W; si a<0, N<W" : "Sin aceleración: N ≈ W"}
                </text>
              </g>
            );
          })()}
        </svg>
      </div>
    </div>
  );
}
