import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

// Ajusta la ruta si tu helper está en otro sitio
import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  const n = typeof v === "number" ? v : Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}
function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function seriesHorizontal({ m, mu, g, Fmax = 200, step = 2 }) {
  const N = m * g;
  const fk = mu * N;
  const out = [];
  for (let F = 0; F <= Fmax; F += step) {
    const Fnet = F - fk; // suponiendo movimiento →
    const a = Fnet / m;
    out.push({ F, fk, Fnet, a });
  }
  return out;
}

function seriesIncline({ mu, g, thetaMax = 60, stepDeg = 1 }) {
  const out = [];
  for (let th = 0; th <= thetaMax; th += stepDeg) {
    const rad = (th * Math.PI) / 180;
    // a = g(sinθ - μk cosθ) si desliza cuesta abajo
    const a = g * (Math.sin(rad) - mu * Math.cos(rad));
    out.push({ theta: th, a });
  }
  return out;
}

export default function RozamientoDinamicoGraphsCoord() {
  const [mode, setMode] = useState("horizontal"); // horizontal | incline
  const [m, setM] = useState(10);
  const [mu, setMu] = useState(0.25);
  const [g, setG] = useState(9.81);

  const [F, setF] = useState(60);
  const [theta, setTheta] = useState(25);

  const [showFk, setShowFk] = useState(true);
  const [showFnet, setShowFnet] = useState(true);
  const [showA, setShowA] = useState(true);

  const mm = useMemo(() => clamp(toNum(m, 10), 0.1, 200), [m]);
  const muu = useMemo(() => clamp(toNum(mu, 0.25), 0, 2), [mu]);
  const gg = useMemo(() => clamp(toNum(g, 9.81), 0.1, 30), [g]);

  const FF = useMemo(() => clamp(toNum(F, 60), 0, 300), [F]);
  const thDeg = useMemo(() => clamp(toNum(theta, 25), 0, 60), [theta]);

  const data = useMemo(() => {
    if (mode === "horizontal") return seriesHorizontal({ m: mm, mu: muu, g: gg, Fmax: 200, step: 2 });
    return seriesIncline({ mu: muu, g: gg, thetaMax: 60, stepDeg: 1 });
  }, [mode, mm, muu, gg]);

  const current = useMemo(() => {
    if (mode === "horizontal") {
      const N = mm * gg;
      const fk = muu * N;
      const Fnet = FF - fk;
      const a = Fnet / mm;
      return { x: FF, fk, Fnet, a, N };
    }
    const rad = (thDeg * Math.PI) / 180;
    const a = gg * (Math.sin(rad) - muu * Math.cos(rad));
    return { x: thDeg, a };
  }, [mode, mm, muu, gg, FF, thDeg]);

  const yDomain = useMemo(() => {
    if (mode === "horizontal") {
      const fk = muu * mm * gg;
      const minV = -fk;
      const maxV = 200 - fk;
      const pad = 0.15 * Math.max(Math.abs(minV), Math.abs(maxV), 1);
      return [minV - pad, maxV + pad];
    }
    const aMin = gg * (0 - muu * 1);
    const aMax = gg * (Math.sin(Math.PI / 3) - muu * Math.cos(Math.PI / 3));
    const pad = 0.2 * Math.max(Math.abs(aMin), Math.abs(aMax), 1);
    return [aMin - pad, aMax + pad];
  }, [mode, mm, muu, gg]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Rozamiento dinámico (Coord)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          Coordenadas (Recharts). En rozamiento dinámico: <b>fₖ = μₖ·N</b>.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>📊 Escena:</span>
              <select
                className="form-control"
                style={{ width: 220 }}
                value={mode}
                onChange={(e) => setMode(e.target.value)}
              >
                <option value="horizontal">Mesa + fuerza F</option>
                <option value="incline">Plano inclinado (baja)</option>
              </select>
            </div>

            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#fbbf24" }}>⚖️</span> m (kg)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={m}
                  onChange={(e) => setM(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#34d399" }}>🌍</span> g (m/s²)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={g}
                  onChange={(e) => setG(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#a855f7" }}>🔧</span> μₖ
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={mu}
                  onChange={(e) => setMu(e.target.value)}
                />
              </label>
              
              {mode === "horizontal" ? (
                <>
                  <span style={{ color: "#60a5fa" }}>💪</span> F aplicada (N)
                  <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                    <input
                      className="form-control"
                      style={{ width: 80 }}
                      inputMode="decimal"
                      value={F}
                      onChange={(e) => setF(e.target.value)}
                    />
                  </label>
                </>
              ) : (
                <>
                  <span style={{ color: "#f87171" }}>📐</span> θ actual (°)
                  <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                    <input
                      className="form-control"
                      style={{ width: 80 }}
                      inputMode="numeric"
                      value={theta}
                      onChange={(e) => setTheta(e.target.value)}
                    />
                  </label>
                </>
              )}
            </div>
          </div>

          {/* Segunda fila: Controles de visualización */}
          <div style={{ 
            display: "flex", 
            gap: 18, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(34, 197, 94, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(34, 197, 94, 0.2)",
            justifyContent: "center"
          }}>
            <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
            
            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showFk"
                checked={showFk}
                onChange={(e) => setShowFk(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showFk">fₖ</label>
            </div>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showFnet"
                checked={showFnet}
                onChange={(e) => setShowFnet(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showFnet">Fₙₑₜ</label>
            </div>

            <div className="v2-checkbox-container">
              <input
                className="v2-checkbox"
                type="checkbox"
                id="showA"
                checked={showA}
                onChange={(e) => setShowA(e.target.checked)}
              />
              <label className="v2-checkbox-label" htmlFor="showA">a</label>
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="muted" style={{ marginBottom: 10 }}>
          {mode === "horizontal" ? (
            <>
              N = <b>{fmt(current.N, 2)} N</b> · fₖ = <b>{fmt(current.fk, 2)} N</b> · Fₙₑₜ = <b>{fmt(current.Fnet, 2)} N</b> · a = <b>{fmt(current.a, 2)} m/s²</b>
            </>
          ) : (
            <>
              a(θ) = g(senθ − μₖcosθ) → a = <b>{fmt(current.a, 2)} m/s²</b>
            </>
          )}
        </div>

        <div style={{ width: "100%", height: 360 }}>
          <ResponsiveContainer>
            <LineChart data={data} margin={{ top: 10, right: 18, left: 8, bottom: 10 }}>
              <CartesianGrid strokeDasharray="4 4" />
              {mode === "horizontal" ? (
                <XAxis
                  dataKey="F"
                  type="number"
                  domain={[0, 200]}
                  tickFormatter={(v) => fmt(v, 0)}
                  label={{ value: "F (N)", position: "insideBottomRight", offset: -5 }}
                />
              ) : (
                <XAxis
                  dataKey="theta"
                  type="number"
                  domain={[0, 60]}
                  tickFormatter={(v) => `${v}°`}
                  label={{ value: "θ (°)", position: "insideBottomRight", offset: -5 }}
                />
              )}

              <YAxis
                domain={yDomain}
                tickFormatter={(v) => fmt(v, 2)}
                label={{ value: mode === "horizontal" ? "F (N) / a (m/s²)" : "a (m/s²)", angle: -90, position: "insideLeft" }}
              />

              <Tooltip
                formatter={(value, name) => [fmt(value, 3), name]}
                labelFormatter={(label) => (mode === "horizontal" ? `F = ${fmt(label, 0)} N` : `θ = ${fmt(label, 0)}°`)}
              />

              {mode === "horizontal" ? (
                <>
                  {showFk && (
                    <Line type="monotone" dataKey="fk" name="fₖ = μₖN" strokeWidth={2} dot={false} strokeDasharray="6 6" />
                  )}
                  {showFnet && (
                    <Line type="monotone" dataKey="Fnet" name="Fₙₑₜ = F − fₖ" strokeWidth={3} dot={false} />
                  )}
                  {showA && (
                    <Line type="monotone" dataKey="a" name="a = Fₙₑₜ/m" strokeWidth={3} dot={false} strokeDasharray="2 10" />
                  )}
                  {showFnet && <ReferenceDot x={current.x} y={current.Fnet} r={5} isFront />}
                </>
              ) : (
                <>
                  {showA && <Line type="monotone" dataKey="a" name="a(θ)" strokeWidth={3} dot={false} />}
                  {showA && <ReferenceDot x={current.x} y={current.a} r={5} isFront />}
                </>
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
