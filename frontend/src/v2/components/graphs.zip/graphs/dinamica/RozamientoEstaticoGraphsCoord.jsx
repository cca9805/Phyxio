import React, { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
  ReferenceLine,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function toNum(v, fallback) {
  if (v == null || v === "") return fallback;
  if (typeof v === "number") return Number.isFinite(v) ? v : fallback;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function buildInclineSeries({ m, g, mu, thetaMax = 60, stepDeg = 1 }) {
  const out = [];
  const W = m * g;
  for (let th = 0; th <= thetaMax; th += stepDeg) {
    const rad = (th * Math.PI) / 180;
    const N = W * Math.cos(rad);
    const fReq = W * Math.sin(rad); // necesario para no deslizar
    const fMax = mu * N;           // máximo estático
    out.push({ theta: th, fReq, fMax, N });
  }
  return out;
}

function buildPushSeries({ m, g, mu, Fmax = 200, step = 2 }) {
  const out = [];
  const N = m * g;
  const fMax = mu * N;
  for (let F = 0; F <= Fmax; F += step) {
    const f = Math.min(F, fMax); // estático: se adapta hasta el máximo
    out.push({ F, f, fMax });
  }
  return out;
}

export default function RozamientoEstaticoGraphsCoord() {
  const [mode, setMode] = useState("incline"); // incline | push
  const [m, setM] = useState(10);
  const [g, setG] = useState(9.81);
  const [muS, setMuS] = useState(0.4);

  // Puntos de referencia
  const [theta, setTheta] = useState(25);
  const [Fapplied, setFapplied] = useState(50);

  const mm = useMemo(() => clamp(toNum(m, 10), 0.1, 200), [m]);
  const gg = useMemo(() => clamp(toNum(g, 9.81), 0.1, 30), [g]);
  const mu = useMemo(() => clamp(toNum(muS, 0.4), 0, 2), [muS]);

  const thDeg = useMemo(() => clamp(toNum(theta, 25), 0, 60), [theta]);
  const Fref = useMemo(() => clamp(toNum(Fapplied, 50), 0, 300), [Fapplied]);

  const data = useMemo(() => {
    if (mode === "incline") return buildInclineSeries({ m: mm, g: gg, mu, thetaMax: 60, stepDeg: 1 });
    return buildPushSeries({ m: mm, g: gg, mu, Fmax: 300, step: 2 });
  }, [mode, mm, gg, mu]);

  const current = useMemo(() => {
    const W = mm * gg;
    if (mode === "incline") {
      const rad = (thDeg * Math.PI) / 180;
      const N = W * Math.cos(rad);
      const fReq = W * Math.sin(rad);
      const fMax = mu * N;
      return { x: thDeg, fReq, fMax, N, slips: fReq > fMax + 1e-9 };
    }
    const N = W;
    const fMax = mu * N;
    const f = Math.min(Fref, fMax);
    return { x: Fref, f, fMax, N, slips: Fref > fMax + 1e-9 };
  }, [mode, mm, gg, mu, thDeg, Fref]);

  const yMax = useMemo(() => {
    if (mode === "incline") {
      const W = mm * gg;
      return Math.max(W, 1) * 1.05;
    }
    const fMax = mu * (mm * gg);
    return Math.max(fMax, 1) * 1.2;
  }, [mode, mm, gg, mu]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="v2-card" style={{ padding: 12 }}>
        <div className="v2-card-title">Rozamiento estático (Coord)</div>
        <div className="muted" style={{ marginTop: 6 }}>
          En rozamiento estático, la fricción se “ajusta” para impedir el movimiento, pero tiene un límite:
          <b> fₛ ≤ μₛ·N</b>. Aquí comparamos <b>f necesaria</b> con <b>f máxima</b>.
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }}>
          {/* Primera fila: Configuración principal */}
          <div style={{ 
            display: "flex", 
            gap: 15, 
            alignItems: "center", 
            flexWrap: "wrap",
            padding: "8px 12px",
            background: "rgba(59, 130, 246, 0.08)",
            borderRadius: "10px",
            border: "1px solid rgba(59, 130, 246, 0.2)"
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#60a5fa", fontSize: "14px", fontWeight: "600" }}>📊 Modo:</span>
              <select
                className="form-control"
                style={{ width: 280 }}
                value={mode}
                onChange={(e) => setMode(e.target.value)}
              >
                <option value="incline">Plano inclinado: f_req(θ) vs f_max(θ)</option>
                <option value="push">Empuje horizontal: f(F) hasta f_max</option>
              </select>
            </div>

            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <span style={{ color: "#fbbf24" }}>⚖️</span> m (kg)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={m}
                  onChange={(e) => setM(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#34d399" }}>🌍</span> g (m/s²)
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={g}
                  onChange={(e) => setG(e.target.value)}
                />
              </label>
              
              <span style={{ color: "#a855f7" }}>🔧</span> μₛ
              <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                <input
                  className="form-control"
                  style={{ width: 80 }}
                  inputMode="decimal"
                  value={muS}
                  onChange={(e) => setMuS(e.target.value)}
                />
              </label>
              
              {mode === "incline" ? (
                <>
                  <span style={{ color: "#f87171" }}>📐</span> θ actual (°)
                  <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                    <input
                      className="form-control"
                      style={{ width: 80 }}
                      inputMode="numeric"
                      value={theta}
                      onChange={(e) => setTheta(e.target.value)}
                    />
                  </label>
                </>
              ) : (
                <>
                  <span style={{ color: "#60a5fa" }}>💪</span> F aplicada (N)
                  <label style={{ display: "flex", gap: 6, alignItems: "center", color: "#e2e8f0", fontSize: "14px" }}>
                    <input
                      className="form-control"
                      style={{ width: 80 }}
                      inputMode="decimal"
                      value={Fapplied}
                      onChange={(e) => setFapplied(e.target.value)}
                    />
                  </label>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="v2-card" style={{ padding: 12 }}>
        <div className="muted" style={{ marginBottom: 10 }}>
          {mode === "incline" ? (
            <>
              θ = <b>{fmt(current.x, 0)}°</b> · f_req = <b>{fmt(current.fReq, 2)} N</b> · f_max ={" "}
              <b>{fmt(current.fMax, 2)} N</b>{" "}
              {current.slips ? <b style={{ color: "#dc2626" }}>→ desliza</b> : <b style={{ color: "#16a34a" }}>→ no desliza</b>}
            </>
          ) : (
            <>
              F = <b>{fmt(current.x, 0)} N</b> · f = <b>{fmt(current.f, 2)} N</b> · f_max ={" "}
              <b>{fmt(current.fMax, 2)} N</b>{" "}
              {current.slips ? <b style={{ color: "#dc2626" }}>→ supera el estático</b> : <b style={{ color: "#16a34a" }}>→ estático</b>}
            </>
          )}
        </div>

        <div style={{ width: "100%", height: 360 }}>
          <ResponsiveContainer>
            <LineChart data={data} margin={{ top: 10, right: 18, left: 8, bottom: 10 }}>
              <CartesianGrid strokeDasharray="4 4" />
              <XAxis
                dataKey={mode === "incline" ? "theta" : "F"}
                type="number"
                domain={mode === "incline" ? [0, 60] : [0, 300]}
                tickFormatter={(v) => (mode === "incline" ? `${fmt(v, 0)}°` : fmt(v, 0))}
                label={{
                  value: mode === "incline" ? "θ (°)" : "F (N)",
                  position: "insideBottomRight",
                  offset: -5,
                }}
              />
              <YAxis
                domain={[0, yMax]}
                tickFormatter={(v) => fmt(v, 0)}
                label={{ value: "Fuerza (N)", angle: -90, position: "insideLeft" }}
              />
              <Tooltip
                formatter={(value, name) => [fmt(value, 2), name]}
                labelFormatter={(label) => (mode === "incline" ? `θ = ${fmt(label, 0)}°` : `F = ${fmt(label, 0)} N`)}
              />

              {mode === "incline" ? (
                <>
                  <Line type="monotone" dataKey="fReq" name="f_req = mg·senθ" strokeWidth={3} dot={false} />
                  <Line type="monotone" dataKey="fMax" name="f_max = μₛ·N = μₛ·mg·cosθ" strokeWidth={3} dot={false} strokeDasharray="6 6" />
                  <ReferenceDot x={current.x} y={current.fReq} r={5} isFront />
                  <ReferenceLine x={current.x} stroke="#64748b" strokeDasharray="4 4" />
                </>
              ) : (
                <>
                  <Line type="monotone" dataKey="f" name="f (estático) = min(F, f_max)" strokeWidth={3} dot={false} />
                  <Line type="monotone" dataKey="fMax" name="f_max = μₛ·N" strokeWidth={3} dot={false} strokeDasharray="6 6" />
                  <ReferenceDot x={current.x} y={current.f} r={5} isFront />
                  <ReferenceLine x={current.x} stroke="#64748b" strokeDasharray="4 4" />
                </>
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
