import { useMemo, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
} from "recharts";

import { fmt } from "../../../utils/graphFormat";

function toNum(v, d) {
  if (v == null || v === "") return d;
  const n = Number(String(v).replace(",", "."));
  return Number.isFinite(n) ? n : d;
}
function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function buildSeriesMass({ g, mMax = 20, step = 0.5 }) {
  const out = [];
  for (let m = 0; m <= mMax + 1e-9; m += step) out.push({ m, T: m * g });
  return out;
}

function buildSeriesAtwood({ m1, m2, g, aMax = 8, step = 0.25 }) {
  // Curva didáctica: T en función de a (no necesariamente el a real de Atwood)
  const out = [];
  for (let a = -aMax; a <= aMax + 1e-9; a += step) {
    out.push({ a, T1: m1 * (g - a), T2: m2 * (g + a) });
  }
  return out;
}

export default function TensionEnCuerdasYCablesGraphsCoord() {
  const [mode, setMode] = useState("mass"); // mass | atwood

  // masa colgante
  const [m, setM] = useState(5);
  const [g, setG] = useState(9.81);

  // Atwood
  const [m1, setM1] = useState(5);
  const [m2, setM2] = useState(3);
  const [g2, setG2] = useState(9.81);

  const [showGrid, setShowGrid] = useState(true);
  const [showPoint, setShowPoint] = useState(true);

  const safe = useMemo(() => {
    const gg = clamp(toNum(g, 9.81), 0.1, 30);
    const mm = clamp(toNum(m, 5), 0, 50);
    const m1v = clamp(toNum(m1, 5), 0.1, 50);
    const m2v = clamp(toNum(m2, 3), 0.1, 50);
    const gg2 = clamp(toNum(g2, 9.81), 0.1, 30);
    return { gg, mm, m1: m1v, m2: m2v, gg2 };
  }, [m, g, m1, m2, g2]);

  const aReal = useMemo(() => {
    const den = safe.m1 + safe.m2;
    if (den <= 0) return 0;
    return ((safe.m1 - safe.m2) / den) * safe.gg2;
  }, [safe]);

  const Treal = useMemo(() => safe.m1 * (safe.gg2 - aReal), [safe, aReal]);

  const data = useMemo(() => {
    if (mode === "mass") return buildSeriesMass({ g: safe.gg, mMax: 20, step: 0.5 });
    return buildSeriesAtwood({ m1: safe.m1, m2: safe.m2, g: safe.gg2, aMax: 8, step: 0.25 });
  }, [mode, safe]);

  return (
    <div className="v2-graphs">
      {/* Card azul - Configuración principal */}
      <div className="v2-card" style={{ background: 'rgba(59, 130, 246, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div className="v2-grid-fill-inputs">
          <div className="v2-input-group">
            <label>📊 Modo</label>
            <select className="form-control" value={mode} onChange={(e) => setMode(e.target.value)}>
              <option value="mass">Masa colgante (T = mg)</option>
              <option value="atwood">Máquina de Atwood</option>
            </select>
          </div>

          {mode === "mass" ? (
            <>
              <div className="v2-input-group">
                <label>⚖️ m (kg)</label>
                <input className="form-control" inputMode="decimal" value={m} onChange={(e) => setM(e.target.value)} />
              </div>
              <div className="v2-input-group">
                <label>🌍 g (m/s²)</label>
                <input className="form-control" inputMode="decimal" value={g} onChange={(e) => setG(e.target.value)} />
              </div>
            </>
          ) : (
            <>
              <div className="v2-input-group">
                <label>⚖️ m1 (kg)</label>
                <input className="form-control" inputMode="decimal" value={m1} onChange={(e) => setM1(e.target.value)} />
              </div>
              <div className="v2-input-group">
                <label>⚖️ m2 (kg)</label>
                <input className="form-control" inputMode="decimal" value={m2} onChange={(e) => setM2(e.target.value)} />
              </div>
              <div className="v2-input-group">
                <label>🌍 g (m/s²)</label>
                <input className="form-control" inputMode="decimal" value={g2} onChange={(e) => setG2(e.target.value)} />
              </div>
            </>
          )}
        </div>
      </div>

      {/* Card verde - Controles de visualización */}
      <div className="v2-card" style={{ background: 'rgba(34, 197, 94, 0.08)', padding: '16px', marginBottom: '12px' }}>
        <div style={{ 
          display: "flex", 
          gap: 18, 
          alignItems: "center", 
          flexWrap: "wrap",
          justifyContent: "center"
        }}>
          <span style={{ color: "#4ade80", fontSize: "14px", fontWeight: "600", marginRight: "8px" }}>👁️ Mostrar:</span>
          
          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showGrid"
              checked={showGrid}
              onChange={(e) => setShowGrid(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showGrid">Cuadrícula</label>
          </div>

          <div className="v2-checkbox-container">
            <input
              className="v2-checkbox"
              type="checkbox"
              id="showPoint"
              checked={showPoint}
              onChange={(e) => setShowPoint(e.target.checked)}
            />
            <label className="v2-checkbox-label" htmlFor="showPoint">Punto de referencia</label>
          </div>
        </div>
      </div>

      <div className="v2-card">
        <div style={{ width: "100%", height: 320, marginTop: 10 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              {showGrid && <CartesianGrid />}
              {mode === "mass" ? (
                <>
                  <XAxis dataKey="m" type="number" domain={[0, 20]} label={{ value: "m (kg)", position: "insideBottom", offset: -5 }} />
                  <YAxis tickFormatter={(v) => fmt(v, 4)} domain={[0, "auto"]} label={{ value: "T (N)", angle: -90, position: "insideLeft" }} />
                  <Tooltip formatter={(v) => fmt(v, 6)} labelFormatter={(x) => `m = ${x} kg`} />
                  <Line dataKey="T" dot={false} name="T = mg" />
                  {showPoint && <ReferenceDot x={safe.mm} y={safe.mm * safe.gg} r={5} />}
                </>
              ) : (
                <>
                  <XAxis dataKey="a" type="number" domain={[-8, 8]} label={{ value: "a (m/s²)", position: "insideBottom", offset: -5 }} />
                  <YAxis tickFormatter={(v) => fmt(v, 4)} domain={[0, "auto"]} label={{ value: "T (N)", angle: -90, position: "insideLeft" }} />
                  <Tooltip formatter={(v) => fmt(v, 6)} labelFormatter={(x) => `a = ${fmt(x, 3)} m/s²`} />
                  <Line dataKey="T1" dot={false} name="T (m1)" />
                  <Line dataKey="T2" dot={false} name="T (m2)" strokeDasharray="8 8" />
                  {showPoint && <ReferenceDot x={aReal} y={Treal} r={5} />}
                </>
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
