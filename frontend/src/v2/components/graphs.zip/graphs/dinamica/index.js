/**
 * Dinamica - Graph Components Index
 * 
 * Auto-generado desde phyxio-map.yaml
 * Fecha: 2026-01-23
 * 
 * Estructura:
 * export const graphs = {
 *   "topic-id": {
 *     Coord: TopicGraphsCoord,
 *     Dcl: TopicGraphsDcl
 *   }
 * };
 */

// Fundamentos 
import PrimeraLeyInerciaGraphsDcl from "./PrimeraLeyInerciaGraphsDcl";
import SegundaLeyFuerzaMasaGraphsCoord from "./SegundaLeyFuerzaMasaGraphsCoord";
import SegundaLeyFuerzaMasaGraphsDcl from "./SegundaLeyFuerzaMasaGraphsDcl";
import TerceraLeyAccionReaccionGraphsDcl from "./TerceraLeyAccionReaccionGraphsDcl";
import SistemasInercialesGraphsDcl from "./SistemasInercialesGraphsDcl";
import SistemasNoInercialesIntroGraphsDcl from "./SistemasNoInercialesIntroGraphsDcl";
import IdentificacionDeFuerzasGraphsDcl from "./IdentificacionDeFuerzasGraphsDcl";
import DiagramasCuerpoLibreGraphsCoord from "./DiagramasCuerpoLibreGraphsCoord";
import DiagramasCuerpoLibreGraphsDcl from "./DiagramasCuerpoLibreGraphsDcl";
import DescomposicionVectorialGraphsDcl from "./DescomposicionVectorialGraphsDcl";
// Fuerzas
import PesoEnDiferentesContextosGraphsCoord from "./PesoEnDiferentesContextosGraphsCoord";
import PesoEnDiferentesContextosGraphsDcl from "./PesoEnDiferentesContextosGraphsDcl";
import NormalEnPlanosGraphsCoord from "./NormalEnPlanosGraphsCoord";
import NormalEnPlanosGraphsDcl from "./NormalEnPlanosGraphsDcl";
import RozamientoEstaticoGraphsCoord from "./RozamientoEstaticoGraphsCoord";
import RozamientoEstaticoGraphsDcl from "./RozamientoEstaticoGraphsDcl";
import RozamientoDinamicoGraphsCoord from "./RozamientoDinamicoGraphsCoord";
import RozamientoDinamicoGraphsDcl from "./RozamientoDinamicoGraphsDcl";
import CoeficienteDeRozamientoGraphsCoord from "./CoeficienteDeRozamientoGraphsCoord";
import CoeficienteDeRozamientoGraphsDcl from "./CoeficienteDeRozamientoGraphsDcl";
import TensionEnCuerdasYCablesGraphsCoord from "./TensionEnCuerdasYCablesGraphsCoord";
import TensionEnCuerdasYCablesGraphsDcl from "./TensionEnCuerdasYCablesGraphsDcl";
import LeyDeHookeGraphsCoord from "./LeyDeHookeGraphsCoord";
import LeyDeHookeGraphsDcl from "./LeyDeHookeGraphsDcl";
import SistemasConMuellesGraphsCoord from "./SistemasConMuellesGraphsCoord";
import SistemasConMuellesGraphsSvg from "./SistemasConMuellesGraphsSvg";
import ConceptoFuerzaCentripetaGraphsCoord from "./ConceptoFuerzaCentripetaGraphsCoord";
import ConceptoFuerzaCentripetaGraphsDcl from "./ConceptoFuerzaCentripetaGraphsDcl";
import EjemplosTipicosGraphsCoord from "./EjemplosTipicosGraphsCoord";
import CondicionSumatoriaFuerzasGraphsCoord from "./CondicionSumatoriaFuerzasGraphsCoord";
import CondicionSumatoriaFuerzasGraphsDcl from "./CondicionSumatoriaFuerzasGraphsDcl";
import EjemplosDeEquilibrioGraphsDcl from "./EjemplosDeEquilibrioGraphsDcl";
import EjemplosDeEquilibrioSim from "./EjemplosDeEquilibrioSim";
import MomentoDeUnaFuerzaGraphsCoord from "./MomentoDeUnaFuerzaGraphsCoord";
import CondicionSumatoriaMomentosGraphsCoord from "./CondicionSumatoriaMomentosGraphsCoord";




import AnalisisCompletoGraphsCoord from "./AnalisisCompletoGraphsCoord";
import AnalisisCompletoGraphsDcl from "./AnalisisCompletoGraphsDcl";
import AnalogiaTraslacionalGraphsCoord from "./AnalogiaTraslacionalGraphsCoord";
import AplicacionesFisicasGraphsCoord from "./AplicacionesFisicasGraphsCoord";
import BernoulliGraphsCoord from "./BernoulliGraphsCoord";
import BloqueColganteGraphsCoord from "./BloqueColganteGraphsCoord";
import BloqueSobreSuperficieGraphsCoord from "./BloqueSobreSuperficieGraphsCoord";
import CalculoDelTorqueGraphsCoord from "./CalculoDelTorqueGraphsCoord";
import CentroDeMasasEnCuerposExtendidosGraphsCoord from "./CentroDeMasasEnCuerposExtendidosGraphsCoord";
import CentroDeMasasEnCuerposExtendidosGraphsSvg from "./CentroDeMasasEnCuerposExtendidosGraphsSvg";
import CentroDeMasasEnSistemasDiscretosGraphsCoord from "./CentroDeMasasEnSistemasDiscretosGraphsCoord";
import CentroDeMasasEnSistemasDiscretosGraphsSvg from "./CentroDeMasasEnSistemasDiscretosGraphsSvg";
import ConRozamientoGraphsCoord from "./ConRozamientoGraphsCoord";
import ConRozamientoGraphsDcl from "./ConRozamientoGraphsDcl";
import ConceptoFuerzasFicticiasGraphsCoord from "./ConceptoFuerzasFicticiasGraphsCoord";
import ConceptoFuerzasFicticiasGraphsDcl from "./ConceptoFuerzasFicticiasGraphsDcl";
import CondicionCinematicaGraphsCoord from "./CondicionCinematicaGraphsCoord";
import ContinuidadGraphsCoord from "./ContinuidadGraphsCoord";
import DosMasasUnidasPorCuerdaGraphsCoord from "./DosMasasUnidasPorCuerdaGraphsCoord";
import DosMasasUnidasPorCuerdaGraphsSvg from "./DosMasasUnidasPorCuerdaGraphsSvg";
import EcuacionFundamentalGraphsCoord from "./EcuacionFundamentalGraphsCoord";
import EjemplosAplicadosGraphsCoord from "./EcuacionFundamentalGraphsCoord";
import EjemplosClasicosGraphsCoord from "./EjemplosClasicosGraphsCoord";

import EjemplosGraphsCoord from "./EjemplosGraphsCoord";

import ErroresFrecuentesGraphsCoord from "./ErroresFrecuentesGraphsCoord";
import FuerzaCentrifugaGraphsCoord from "./FuerzaCentrifugaGraphsCoord";


// import MomentosTipicosGraphsCoord from "./MomentosTipicosGraphsCoord";
import PalancasGraphsCoord from "./PalancasGraphsCoord";
import PlanosInclinadosGraphsCoord from "./PlanosInclinadosGraphsCoord";
import PlanosInclinadosGraphsDcl from "./PlanosInclinadosGraphsDcl";
import PlanosInclinadosGraphsSvg from "./PlanosInclinadosGraphsSvg";
import PoleasCompuestasGraphsCoord from "./PoleasCompuestasGraphsCoord";
import PoleasGraphsCoord from "./PoleasGraphsCoord";
import PoleasSimplesGraphsCoord from "./PoleasSimplesGraphsCoord";
import ProblemasTipoExamenGraphsCoord from "./ProblemasTipoExamenGraphsCoord";
import ProblemasTipoExamenGraphsSvg from "./ProblemasTipoExamenGraphsSvg";
import SinRozamientoGraphsCoord from "./SinRozamientoGraphsCoord";
import SinRozamientoGraphsDcl from "./SinRozamientoGraphsDcl";
import SistemasRealesGraphsCoord from "./SistemasRealesGraphsCoord";
import SistemasRealesGraphsSvg from "./SistemasRealesGraphsSvg";
import TeoremaDeEjesParalelosGraphsCoord from "./TeoremaDeEjesParalelosGraphsCoord";
import TiposDePalancasGraphsSvg from "./TiposDePalancasGraphsSvg";
import DefinicionTorqueSvg from "./DefinicionTorqueSvg";
import TorqueMomentoGraphsCoord from "./TorqueMomentoGraphsCoord";
import TraslacionYRotacionGraphsCoord from "./TraslacionYRotacionGraphsCoord";
import VentajaMecanicaGraphsCoord from "./VentajaMecanicaGraphsCoord";

export const graphs = {
  "primera-ley-inercia": {
    Dcl: PrimeraLeyInerciaGraphsDcl,
  },
  "segunda-ley-fuerza-masa": {
    Coord: SegundaLeyFuerzaMasaGraphsCoord,
    Dcl: SegundaLeyFuerzaMasaGraphsDcl,
  },
  "tercera-ley-accion-reaccion": {
    Dcl: TerceraLeyAccionReaccionGraphsDcl,
  },
  "sistemas-inerciales": {
    Dcl: SistemasInercialesGraphsDcl,
  },
  "sistemas-no-inerciales-intro": {
    Dcl: SistemasNoInercialesIntroGraphsDcl,
  },
  "identificacion-de-fuerzas": {
    Dcl: IdentificacionDeFuerzasGraphsDcl,
  },
  "diagramas-cuerpo-libre": {
    Coord: DiagramasCuerpoLibreGraphsCoord,
    Dcl: DiagramasCuerpoLibreGraphsDcl,
  },
  "descomposicion-vectorial": {
    Dcl: DescomposicionVectorialGraphsDcl,
  },
  "peso-en-diferentes-contextos": {
    Coord: PesoEnDiferentesContextosGraphsCoord,
    Dcl: PesoEnDiferentesContextosGraphsDcl,
  },
  "normal-en-planos": {
    Coord: NormalEnPlanosGraphsCoord,
    Dcl: NormalEnPlanosGraphsDcl,
  },
  "rozamiento-estatico": {
    Coord: RozamientoEstaticoGraphsCoord,
    Dcl: RozamientoEstaticoGraphsDcl,
  },
  "rozamiento-dinamico": {
    Coord: RozamientoDinamicoGraphsCoord,
    Dcl: RozamientoDinamicoGraphsDcl,
  },
  "coeficiente-de-rozamiento": {
    Coord: CoeficienteDeRozamientoGraphsCoord,
    Dcl: CoeficienteDeRozamientoGraphsDcl,
  },
  "tension-en-cuerdas-y-cables": {
    Coord: TensionEnCuerdasYCablesGraphsCoord,
    Dcl: TensionEnCuerdasYCablesGraphsDcl,
  },
  "ley-de-hooke": {
    Coord: LeyDeHookeGraphsCoord,
    Dcl: LeyDeHookeGraphsDcl,
  },
  "sistemas-con-muelles": {
    Coord: SistemasConMuellesGraphsCoord,
    Svg: SistemasConMuellesGraphsSvg,
  },
  "concepto-fuerza-centripeta": {
    Coord: ConceptoFuerzaCentripetaGraphsCoord,
    Dcl: ConceptoFuerzaCentripetaGraphsDcl,
  },
  "ejemplos-tipicos": {
    Coord: EjemplosTipicosGraphsCoord,
  },
  "condicion-sumatoria-fuerzas": {
    Coord: CondicionSumatoriaFuerzasGraphsCoord,
    Dcl: CondicionSumatoriaFuerzasGraphsDcl,
  },
  "ejemplos-de-equilibrio": {
    Dcl: EjemplosDeEquilibrioGraphsDcl,
    Svg: EjemplosDeEquilibrioSim,
  },
  "momento-de-una-fuerza": {
    Coord: MomentoDeUnaFuerzaGraphsCoord,
  },
  "condicion-sumatoria-momentos": {
    Coord: CondicionSumatoriaMomentosGraphsCoord,
  },



  "tipos-de-palancas": {
    Svg: TiposDePalancasGraphsSvg,
  },
  "ventaja-mecanica": {
    Coord: VentajaMecanicaGraphsCoord,
  },
  "centro-de-masas-en-sistemas-discretos": {
    Coord: CentroDeMasasEnSistemasDiscretosGraphsCoord,
    Svg: CentroDeMasasEnSistemasDiscretosGraphsSvg,
  },
  "centro-de-masas-en-cuerpos-extendidos": {
    Coord: CentroDeMasasEnCuerposExtendidosGraphsCoord,
    Svg: CentroDeMasasEnCuerposExtendidosGraphsSvg,
  },
  "definicion-torque": {
    Svg: DefinicionTorqueSvg,
  },
  "calculo-del-torque": {
    Coord: TorqueMomentoGraphsCoord,
  },
  "analogia-traslacional": {
    Coord: AnalogiaTraslacionalGraphsCoord,
  },
  "ecuacion-fundamental": {
    Coord: EcuacionFundamentalGraphsCoord,
  },
  "ejemplos-aplicados": {
    Coord: EcuacionFundamentalGraphsCoord,
  },
  "teorema-de-ejes-paralelos": {
    Coord: TeoremaDeEjesParalelosGraphsCoord,
  },
  "condicion-cinematica": {
    Coord: CondicionCinematicaGraphsCoord,
  },
  "ejemplos-clasicos": {
    Coord: EjemplosClasicosGraphsCoord,
  },
  "bloque-sobre-superficie": {
    Coord: BloqueSobreSuperficieGraphsCoord,
  },
  "bloque-colgante": {
    Coord: BloqueColganteGraphsCoord,
  },
  "sin-rozamiento": {
    Coord: SinRozamientoGraphsCoord,
    Dcl: SinRozamientoGraphsDcl,
  },
  "con-rozamiento": {
    Coord: ConRozamientoGraphsCoord,
    Dcl: ConRozamientoGraphsDcl,
  },
  "analisis-completo": {
    Coord: AnalisisCompletoGraphsCoord,
    Dcl: AnalisisCompletoGraphsDcl,
  },
  "dos-masas-unidas-por-cuerda": {
    Coord: DosMasasUnidasPorCuerdaGraphsCoord,
  },
  "poleas-simples": {
    Coord: PoleasSimplesGraphsCoord,
  },
  "poleas-compuestas": {
    Coord: PoleasCompuestasGraphsCoord,
  },
  "concepto-fuerzas-ficticias": {
    Coord: ConceptoFuerzasFicticiasGraphsCoord,
    Dcl: ConceptoFuerzasFicticiasGraphsDcl,
  },
  "definicion-fuerza-centrifuga": {
    Coord: FuerzaCentrifugaGraphsCoord,
  },
  "aplicaciones-fisicas": {
    Coord: AplicacionesFisicasGraphsCoord,
  },
  "palancas": {
    Coord: PalancasGraphsCoord,
  },
  "poleas": {
    Coord: PoleasGraphsCoord,
  },
  "planos-inclinados": {
    Coord: PlanosInclinadosGraphsCoord,
    Dcl: PlanosInclinadosGraphsDcl,
    Svg: PlanosInclinadosGraphsSvg,
  },
  "traslacion-y-rotacion": {
    Coord: TraslacionYRotacionGraphsCoord,
  },
  "sistemas-reales": {
    Coord: SistemasRealesGraphsCoord,
    Svg: SistemasRealesGraphsSvg,
  },
  "problemas-tipo-examen": {
    Coord: ProblemasTipoExamenGraphsCoord,
    Svg: ProblemasTipoExamenGraphsSvg,
  },
  "errores-frecuentes": {
    Coord: ErroresFrecuentesGraphsCoord,
  },
};

// Exports individuales para compatibilidad
export { default as PrimeraLeyInerciaGraphsDcl } from "./PrimeraLeyInerciaGraphsDcl";
export { default as SegundaLeyFuerzaMasaGraphsCoord } from "./SegundaLeyFuerzaMasaGraphsCoord";
export { default as SegundaLeyFuerzaMasaGraphsDcl } from "./SegundaLeyFuerzaMasaGraphsDcl";
export { default as TerceraLeyAccionReaccionGraphsDcl } from "./TerceraLeyAccionReaccionGraphsDcl";
export { default as SistemasInercialesGraphsDcl } from "./SistemasInercialesGraphsDcl";
export { default as SistemasNoInercialesIntroGraphsDcl } from "./SistemasNoInercialesIntroGraphsDcl";
export { default as IdentificacionDeFuerzasGraphsDcl } from "./IdentificacionDeFuerzasGraphsDcl";
export { default as DiagramasCuerpoLibreGraphsCoord } from "./DiagramasCuerpoLibreGraphsCoord";
export { default as DiagramasCuerpoLibreGraphsDcl } from "./DiagramasCuerpoLibreGraphsDcl";
export { default as DescomposicionVectorialGraphsDcl } from "./DescomposicionVectorialGraphsDcl";
export { default as PesoEnDiferentesContextosGraphsCoord } from "./PesoEnDiferentesContextosGraphsCoord";
export { default as PesoEnDiferentesContextosGraphsDcl } from "./PesoEnDiferentesContextosGraphsDcl";
export { default as NormalEnPlanosGraphsCoord } from "./NormalEnPlanosGraphsCoord";
export { default as NormalEnPlanosGraphsDcl } from "./NormalEnPlanosGraphsDcl";
export { default as RozamientoEstaticoGraphsCoord } from "./RozamientoEstaticoGraphsCoord";
export { default as RozamientoEstaticoGraphsDcl } from "./RozamientoEstaticoGraphsDcl";
export { default as RozamientoDinamicoGraphsCoord } from "./RozamientoDinamicoGraphsCoord";
export { default as RozamientoDinamicoGraphsDcl } from "./RozamientoDinamicoGraphsDcl";
export { default as CoeficienteDeRozamientoGraphsCoord } from "./CoeficienteDeRozamientoGraphsCoord";
export { default as CoeficienteDeRozamientoGraphsDcl } from "./CoeficienteDeRozamientoGraphsDcl";
export { default as TensionEnCuerdasYCablesGraphsCoord } from "./TensionEnCuerdasYCablesGraphsCoord";
export { default as TensionEnCuerdasYCablesGraphsDcl } from "./TensionEnCuerdasYCablesGraphsDcl";
export { default as LeyDeHookeGraphsCoord } from "./LeyDeHookeGraphsCoord";
export { default as LeyDeHookeGraphsDcl } from "./LeyDeHookeGraphsDcl";
export { default as SistemasConMuellesGraphsCoord } from "./SistemasConMuellesGraphsCoord";
export { default as SistemasConMuellesGraphsSvg } from "./SistemasConMuellesGraphsSvg";
export { default as ConceptoFuerzaCentripetaGraphsCoord } from "./ConceptoFuerzaCentripetaGraphsCoord";
export { default as ConceptoFuerzaCentripetaGraphsDcl } from "./ConceptoFuerzaCentripetaGraphsDcl";
export { default as EjemplosTipicosGraphsCoord } from "./EjemplosTipicosGraphsCoord";
export { default as CondicionSumatoriaFuerzasGraphsCoord } from "./CondicionSumatoriaFuerzasGraphsCoord";
export { default as CondicionSumatoriaFuerzasGraphsDcl } from "./CondicionSumatoriaFuerzasGraphsDcl";
export { default as EjemplosDeEquilibrioGraphsDcl } from "./EjemplosDeEquilibrioGraphsDcl";
export { default as EjemplosDeEquilibrioSim } from "./EjemplosDeEquilibrioSim";
export { default as MomentoDeUnaFuerzaGraphsCoord } from "./MomentoDeUnaFuerzaGraphsCoord";
export { default as CondicionSumatoriaMomentosGraphsCoord } from "./CondicionSumatoriaMomentosGraphsCoord";




export { default as AplicacionesFisicasGraphsCoord } from "./AplicacionesFisicasGraphsCoord";
export { default as FuerzaCentrifugaGraphsCoord } from "./FuerzaCentrifugaGraphsCoord";
export { default as TiposDePalancasGraphsSvg } from "./TiposDePalancasGraphsSvg";
export { default as VentajaMecanicaGraphsCoord } from "./VentajaMecanicaGraphsCoord";
export { default as CentroDeMasasEnSistemasDiscretosGraphsCoord } from "./CentroDeMasasEnSistemasDiscretosGraphsCoord";
export { default as CentroDeMasasEnSistemasDiscretosGraphsSvg } from "./CentroDeMasasEnSistemasDiscretosGraphsSvg";
export { default as CentroDeMasasEnCuerposExtendidosGraphsCoord } from "./CentroDeMasasEnCuerposExtendidosGraphsCoord";
export { default as CentroDeMasasEnCuerposExtendidosGraphsSvg } from "./CentroDeMasasEnCuerposExtendidosGraphsSvg";
export { default as CalculoDelTorqueGraphsCoord } from "./CalculoDelTorqueGraphsCoord";
export { default as DefinicionTorqueSvg } from "./DefinicionTorqueSvg";
export { default as TorqueMomentoGraphsCoord } from "./TorqueMomentoGraphsCoord";
export { default as AnalogiaTraslacionalGraphsCoord } from "./AnalogiaTraslacionalGraphsCoord";
export { default as EcuacionFundamentalGraphsCoord } from "./EcuacionFundamentalGraphsCoord";
export { default as EjemplosAplicadosGraphsCoord } from "./EjemplosAplicadosGraphsCoord";
// export { default as MomentosTipicosGraphsCoord } from "./MomentosTipicosGraphsCoord";
export { default as TeoremaDeEjesParalelosGraphsCoord } from "./TeoremaDeEjesParalelosGraphsCoord";
export { default as CondicionCinematicaGraphsCoord } from "./CondicionCinematicaGraphsCoord";
export { default as EjemplosClasicosGraphsCoord } from "./EjemplosClasicosGraphsCoord";
export { default as BloqueSobreSuperficieGraphsCoord } from "./BloqueSobreSuperficieGraphsCoord";
export { default as BloqueColganteGraphsCoord } from "./BloqueColganteGraphsCoord";
export { default as SinRozamientoGraphsCoord } from "./SinRozamientoGraphsCoord";
export { default as SinRozamientoGraphsDcl } from "./SinRozamientoGraphsDcl";
export { default as ConRozamientoGraphsCoord } from "./ConRozamientoGraphsCoord";
export { default as ConRozamientoGraphsDcl } from "./ConRozamientoGraphsDcl";
export { default as AnalisisCompletoGraphsCoord } from "./AnalisisCompletoGraphsCoord";
export { default as AnalisisCompletoGraphsDcl } from "./AnalisisCompletoGraphsDcl";
export { default as DosMasasUnidasPorCuerdaGraphsCoord } from "./DosMasasUnidasPorCuerdaGraphsCoord";
export { default as PoleasSimplesGraphsCoord } from "./PoleasSimplesGraphsCoord";
export { default as PoleasCompuestasGraphsCoord } from "./PoleasCompuestasGraphsCoord";
export { default as ConceptoFuerzasFicticiasGraphsCoord } from "./ConceptoFuerzasFicticiasGraphsCoord";
export { default as ConceptoFuerzasFicticiasGraphsDcl } from "./ConceptoFuerzasFicticiasGraphsDcl";
export { default as EjemplosGraphsCoord } from "./EjemplosGraphsCoord";

export { default as PalancasGraphsCoord } from "./PalancasGraphsCoord";
export { default as PoleasGraphsCoord } from "./PoleasGraphsCoord";
export { default as PlanosInclinadosGraphsCoord } from "./PlanosInclinadosGraphsCoord";
export { default as PlanosInclinadosGraphsDcl } from "./PlanosInclinadosGraphsDcl";
export { default as PlanosInclinadosGraphsSvg } from "./PlanosInclinadosGraphsSvg";
export { default as TraslacionYRotacionGraphsCoord } from "./TraslacionYRotacionGraphsCoord";
export { default as SistemasRealesGraphsCoord } from "./SistemasRealesGraphsCoord";
export { default as SistemasRealesGraphsSvg } from "./SistemasRealesGraphsSvg";
export { default as ProblemasTipoExamenGraphsCoord } from "./ProblemasTipoExamenGraphsCoord";
export { default as ProblemasTipoExamenGraphsSvg } from "./ProblemasTipoExamenGraphsSvg";
export { default as ErroresFrecuentesGraphsCoord } from "./ErroresFrecuentesGraphsCoord";
export { default as ContinuidadGraphsCoord } from "./ContinuidadGraphsCoord";
export { default as BernoulliGraphsCoord } from "./BernoulliGraphsCoord";
